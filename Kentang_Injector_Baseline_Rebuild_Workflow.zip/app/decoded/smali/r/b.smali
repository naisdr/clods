.class public abstract Lr/b;
.super Lr/d;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lr/b$e;,
        Lr/b$d;,
        Lr/b$c;,
        Lr/b$b;,
        Lr/b$a;
    }
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Lr/d<",
        "Ljava/security/interfaces/ECPublicKey;",
        "Ljava/security/interfaces/ECPrivateKey;",
        ">;"
    }
.end annotation


# instance fields
.field public final e:Ljava/lang/String;

.field public final f:Ljava/security/spec/ECParameterSpec;


# direct methods
.method public constructor <init>(Ljava/lang/String;Ljava/lang/String;Ljava/security/spec/ECParameterSpec;)V
    .locals 2

    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const-string v1, "ecdsa-sha2-"

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const-class v1, Ljava/security/interfaces/ECPrivateKey;

    invoke-direct {p0, p1, v0, v1}, Lr/d;-><init>(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Class;)V

    iput-object p2, p0, Lr/b;->e:Ljava/lang/String;

    iput-object p3, p0, Lr/b;->f:Ljava/security/spec/ECParameterSpec;

    return-void
.end method

.method public static g([BLjava/security/spec/EllipticCurve;)Ljava/security/spec/ECPoint;
    .locals 5

    invoke-virtual {p1}, Ljava/security/spec/EllipticCurve;->getField()Ljava/security/spec/ECField;

    move-result-object p1

    invoke-interface {p1}, Ljava/security/spec/ECField;->getFieldSize()I

    move-result p1

    add-int/lit8 p1, p1, 0x7

    div-int/lit8 p1, p1, 0x8

    array-length v0, p0

    mul-int/lit8 v1, p1, 0x2

    const/4 v2, 0x1

    add-int/2addr v1, v2

    if-ne v0, v1, :cond_1

    const/4 v0, 0x0

    aget-byte v1, p0, v0

    const/4 v3, 0x4

    if-ne v1, v3, :cond_1

    array-length v1, p0

    if-nez v1, :cond_0

    goto :goto_0

    :cond_0
    new-array v1, p1, [B

    invoke-static {p0, v2, v1, v0, p1}, Ljava/lang/System;->arraycopy(Ljava/lang/Object;ILjava/lang/Object;II)V

    new-array v3, p1, [B

    add-int/lit8 v4, p1, 0x1

    invoke-static {p0, v4, v3, v0, p1}, Ljava/lang/System;->arraycopy(Ljava/lang/Object;ILjava/lang/Object;II)V

    new-instance p0, Ljava/security/spec/ECPoint;

    new-instance p1, Ljava/math/BigInteger;

    invoke-direct {p1, v2, v1}, Ljava/math/BigInteger;-><init>(I[B)V

    new-instance v0, Ljava/math/BigInteger;

    invoke-direct {v0, v2, v3}, Ljava/math/BigInteger;-><init>(I[B)V

    invoke-direct {p0, p1, v0}, Ljava/security/spec/ECPoint;-><init>(Ljava/math/BigInteger;Ljava/math/BigInteger;)V

    return-object p0

    :cond_1
    :goto_0
    const/4 p0, 0x0

    return-object p0
.end method

.method public static j([B)[B
    .locals 4

    const/4 v0, 0x0

    aget-byte v1, p0, v0

    if-eqz v1, :cond_0

    return-object p0

    :cond_0
    const/4 v1, 0x1

    const/4 v2, 0x1

    :goto_0
    array-length v3, p0

    sub-int/2addr v3, v1

    if-ge v2, v3, :cond_1

    aget-byte v3, p0, v2

    if-nez v3, :cond_1

    add-int/lit8 v2, v2, 0x1

    goto :goto_0

    :cond_1
    array-length v1, p0

    sub-int/2addr v1, v2

    new-array v3, v1, [B

    invoke-static {p0, v2, v3, v0, v1}, Ljava/lang/System;->arraycopy(Ljava/lang/Object;ILjava/lang/Object;II)V

    return-object v3
.end method

.method public static k(ILjava/io/OutputStream;)V
    .locals 2

    const/16 v0, 0x7f

    if-gt p0, v0, :cond_0

    invoke-virtual {p1, p0}, Ljava/io/OutputStream;->write(I)V

    return-void

    :cond_0
    const/4 v0, 0x0

    move v1, p0

    :goto_0
    if-eqz v1, :cond_1

    ushr-int/lit8 v1, v1, 0x8

    add-int/lit8 v0, v0, 0x1

    goto :goto_0

    :cond_1
    or-int/lit16 v1, v0, 0x80

    invoke-virtual {p1, v1}, Ljava/io/OutputStream;->write(I)V

    add-int/lit8 v0, v0, -0x1

    mul-int/lit8 v0, v0, 0x8

    :goto_1
    if-ltz v0, :cond_2

    shr-int v1, p0, v0

    int-to-byte v1, v1

    invoke-virtual {p1, v1}, Ljava/io/OutputStream;->write(I)V

    add-int/lit8 v0, v0, -0x8

    goto :goto_1

    :cond_2
    return-void
.end method


# virtual methods
.method public bridge synthetic a([B)Ljava/security/PublicKey;
    .locals 0

    invoke-virtual {p0, p1}, Lr/b;->h([B)Ljava/security/interfaces/ECPublicKey;

    move-result-object p1

    return-object p1
.end method

.method public final b([B)[B
    .locals 7

    new-instance v0, Lq/c;

    invoke-direct {v0, p1}, Lq/c;-><init>([B)V

    invoke-virtual {v0}, Lq/c;->g()Ljava/lang/String;

    move-result-object p1

    .line 1
    iget-object v1, p0, Lr/d;->b:Ljava/lang/String;

    .line 2
    invoke-virtual {p1, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_5

    invoke-virtual {v0}, Lq/c;->c()[B

    move-result-object p1

    .line 3
    iget v1, v0, Lq/c;->c:I

    iget v0, v0, Lq/c;->b:I

    sub-int/2addr v1, v0

    if-nez v1, :cond_4

    .line 4
    new-instance v0, Lq/c;

    invoke-direct {v0, p1}, Lq/c;-><init>([B)V

    invoke-virtual {v0}, Lq/c;->e()Ljava/math/BigInteger;

    move-result-object p1

    invoke-virtual {p1}, Ljava/math/BigInteger;->toByteArray()[B

    move-result-object p1

    invoke-virtual {v0}, Lq/c;->e()Ljava/math/BigInteger;

    move-result-object v0

    invoke-virtual {v0}, Ljava/math/BigInteger;->toByteArray()[B

    move-result-object v0

    array-length v1, p1

    array-length v2, v0

    const/4 v3, 0x0

    aget-byte v4, p1, v3

    and-int/lit16 v4, v4, 0x80

    if-eqz v4, :cond_0

    add-int/lit8 v1, v1, 0x1

    :cond_0
    aget-byte v4, v0, v3

    and-int/lit16 v4, v4, 0x80

    if-eqz v4, :cond_1

    add-int/lit8 v2, v2, 0x1

    :cond_1
    add-int/lit8 v4, v1, 0x6

    add-int/2addr v4, v2

    new-instance v5, Ljava/io/ByteArrayOutputStream;

    invoke-direct {v5, v4}, Ljava/io/ByteArrayOutputStream;-><init>(I)V

    const/16 v6, 0x30

    invoke-virtual {v5, v6}, Ljava/io/ByteArrayOutputStream;->write(I)V

    const/4 v6, 0x2

    sub-int/2addr v4, v6

    invoke-static {v4, v5}, Lr/b;->k(ILjava/io/OutputStream;)V

    invoke-virtual {v5, v6}, Ljava/io/ByteArrayOutputStream;->write(I)V

    invoke-static {v1, v5}, Lr/b;->k(ILjava/io/OutputStream;)V

    array-length v4, p1

    if-eq v1, v4, :cond_2

    invoke-virtual {v5, v3}, Ljava/io/ByteArrayOutputStream;->write(I)V

    :cond_2
    invoke-virtual {v5, p1}, Ljava/io/OutputStream;->write([B)V

    invoke-virtual {v5, v6}, Ljava/io/ByteArrayOutputStream;->write(I)V

    invoke-static {v2, v5}, Lr/b;->k(ILjava/io/OutputStream;)V

    array-length p1, v0

    if-eq v2, p1, :cond_3

    invoke-virtual {v5, v3}, Ljava/io/ByteArrayOutputStream;->write(I)V

    :cond_3
    invoke-virtual {v5, v0}, Ljava/io/OutputStream;->write([B)V

    invoke-virtual {v5}, Ljava/io/ByteArrayOutputStream;->toByteArray()[B

    move-result-object p1

    return-object p1

    :cond_4
    new-instance p1, Ljava/io/IOException;

    const-string v0, "Unexpected padding in ECDSA signature"

    invoke-direct {p1, v0}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    throw p1

    :cond_5
    new-instance v0, Ljava/io/IOException;

    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const-string v2, "Unsupported signature format: "

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    invoke-direct {v0, p1}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    throw v0
.end method

.method public bridge synthetic c(Ljava/security/PublicKey;)[B
    .locals 0

    check-cast p1, Ljava/security/interfaces/ECPublicKey;

    invoke-virtual {p0, p1}, Lr/b;->i(Ljava/security/interfaces/ECPublicKey;)[B

    move-result-object p1

    return-object p1
.end method

.method public final d([B)[B
    .locals 3

    new-instance v0, Lcom/trilead/ssh2/crypto/SimpleDERReader;

    new-instance v1, Lcom/trilead/ssh2/crypto/SimpleDERReader;

    invoke-direct {v1, p1}, Lcom/trilead/ssh2/crypto/SimpleDERReader;-><init>([B)V

    invoke-virtual {v1}, Lcom/trilead/ssh2/crypto/SimpleDERReader;->f()[B

    move-result-object p1

    invoke-direct {v0, p1}, Lcom/trilead/ssh2/crypto/SimpleDERReader;-><init>([B)V

    invoke-virtual {v0}, Lcom/trilead/ssh2/crypto/SimpleDERReader;->c()Ljava/math/BigInteger;

    move-result-object p1

    invoke-virtual {v0}, Lcom/trilead/ssh2/crypto/SimpleDERReader;->c()Ljava/math/BigInteger;

    move-result-object v0

    new-instance v1, Lq/b;

    invoke-direct {v1}, Lq/b;-><init>()V

    invoke-virtual {v1, p1}, Lq/b;->f(Ljava/math/BigInteger;)V

    invoke-virtual {v1, v0}, Lq/b;->f(Ljava/math/BigInteger;)V

    invoke-virtual {v1}, Lq/b;->a()[B

    move-result-object p1

    new-instance v0, Lq/b;

    invoke-direct {v0}, Lq/b;-><init>()V

    .line 1
    iget-object v1, p0, Lr/d;->b:Ljava/lang/String;

    .line 2
    invoke-virtual {v0, v1}, Lq/b;->h(Ljava/lang/String;)V

    const/4 v1, 0x0

    array-length v2, p1

    invoke-virtual {v0, p1, v1, v2}, Lq/b;->i([BII)V

    invoke-virtual {v0}, Lq/b;->a()[B

    move-result-object p1

    return-object p1
.end method

.method public final f(Ljava/security/PrivateKey;)Z
    .locals 3

    instance-of v0, p1, Ljava/security/interfaces/ECPrivateKey;

    const/4 v1, 0x0

    if-nez v0, :cond_0

    return v1

    :cond_0
    check-cast p1, Ljava/security/interfaces/ECPrivateKey;

    .line 1
    iget-object v0, p0, Lr/d;->c:Ljava/lang/Class;

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-result-object v2

    invoke-virtual {v0, v2}, Ljava/lang/Class;->isAssignableFrom(Ljava/lang/Class;)Z

    move-result v0

    if-eqz v0, :cond_1

    .line 2
    invoke-interface {p1}, Ljava/security/interfaces/ECKey;->getParams()Ljava/security/spec/ECParameterSpec;

    move-result-object p1

    invoke-virtual {p1}, Ljava/security/spec/ECParameterSpec;->getCurve()Ljava/security/spec/EllipticCurve;

    move-result-object p1

    invoke-virtual {p1}, Ljava/security/spec/EllipticCurve;->getField()Ljava/security/spec/ECField;

    move-result-object p1

    invoke-interface {p1}, Ljava/security/spec/ECField;->getFieldSize()I

    move-result p1

    .line 3
    iget-object v0, p0, Lr/b;->f:Ljava/security/spec/ECParameterSpec;

    .line 4
    invoke-virtual {v0}, Ljava/security/spec/ECParameterSpec;->getCurve()Ljava/security/spec/EllipticCurve;

    move-result-object v0

    invoke-virtual {v0}, Ljava/security/spec/EllipticCurve;->getField()Ljava/security/spec/ECField;

    move-result-object v0

    invoke-interface {v0}, Ljava/security/spec/ECField;->getFieldSize()I

    move-result v0

    if-ne p1, v0, :cond_1

    const/4 v1, 0x1

    :cond_1
    return v1
.end method

.method public final h([B)Ljava/security/interfaces/ECPublicKey;
    .locals 2

    new-instance v0, Lq/c;

    invoke-direct {v0, p1}, Lq/c;-><init>([B)V

    invoke-virtual {v0}, Lq/c;->g()Ljava/lang/String;

    move-result-object p1

    .line 1
    iget-object v1, p0, Lr/d;->b:Ljava/lang/String;

    .line 2
    invoke-virtual {p1, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p1

    if-eqz p1, :cond_2

    invoke-virtual {v0}, Lq/c;->g()Ljava/lang/String;

    invoke-virtual {v0}, Lq/c;->c()[B

    move-result-object p1

    .line 3
    iget v1, v0, Lq/c;->c:I

    iget v0, v0, Lq/c;->b:I

    sub-int/2addr v1, v0

    if-nez v1, :cond_1

    .line 4
    iget-object v0, p0, Lr/b;->f:Ljava/security/spec/ECParameterSpec;

    .line 5
    invoke-virtual {v0}, Ljava/security/spec/ECParameterSpec;->getCurve()Ljava/security/spec/EllipticCurve;

    move-result-object v1

    invoke-static {p1, v1}, Lr/b;->g([BLjava/security/spec/EllipticCurve;)Ljava/security/spec/ECPoint;

    move-result-object p1

    if-eqz p1, :cond_0

    :try_start_0
    new-instance v1, Ljava/security/spec/ECPublicKeySpec;

    invoke-direct {v1, p1, v0}, Ljava/security/spec/ECPublicKeySpec;-><init>(Ljava/security/spec/ECPoint;Ljava/security/spec/ECParameterSpec;)V

    const-string p1, "EC"

    invoke-static {p1}, Ljava/security/KeyFactory;->getInstance(Ljava/lang/String;)Ljava/security/KeyFactory;

    move-result-object p1

    invoke-virtual {p1, v1}, Ljava/security/KeyFactory;->generatePublic(Ljava/security/spec/KeySpec;)Ljava/security/PublicKey;

    move-result-object p1

    check-cast p1, Ljava/security/interfaces/ECPublicKey;
    :try_end_0
    .catch Ljava/security/GeneralSecurityException; {:try_start_0 .. :try_end_0} :catch_0

    return-object p1

    :catch_0
    move-exception p1

    new-instance v0, Ljava/io/IOException;

    const-string v1, "Could not decode ECDSA key"

    invoke-direct {v0, v1, p1}, Ljava/io/IOException;-><init>(Ljava/lang/String;Ljava/lang/Throwable;)V

    throw v0

    :cond_0
    new-instance p1, Ljava/io/IOException;

    const-string v0, "Invalid ECDSA group"

    invoke-direct {p1, v0}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    throw p1

    :cond_1
    new-instance p1, Ljava/io/IOException;

    const-string v0, "Unexpected adding in ECDSA public key"

    invoke-direct {p1, v0}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    throw p1

    :cond_2
    new-instance p1, Ljava/io/IOException;

    const-string v0, "Invalid key format"

    invoke-direct {p1, v0}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    throw p1
.end method

.method public final i(Ljava/security/interfaces/ECPublicKey;)[B
    .locals 8

    invoke-interface {p1}, Ljava/security/interfaces/ECPublicKey;->getW()Ljava/security/spec/ECPoint;

    move-result-object v0

    invoke-interface {p1}, Ljava/security/interfaces/ECKey;->getParams()Ljava/security/spec/ECParameterSpec;

    move-result-object p1

    invoke-virtual {p1}, Ljava/security/spec/ECParameterSpec;->getCurve()Ljava/security/spec/EllipticCurve;

    move-result-object p1

    .line 1
    invoke-virtual {p1}, Ljava/security/spec/EllipticCurve;->getField()Ljava/security/spec/ECField;

    move-result-object p1

    invoke-interface {p1}, Ljava/security/spec/ECField;->getFieldSize()I

    move-result p1

    add-int/lit8 p1, p1, 0x7

    div-int/lit8 p1, p1, 0x8

    mul-int/lit8 v1, p1, 0x2

    add-int/lit8 v1, v1, 0x1

    new-array v2, v1, [B

    const/4 v3, 0x4

    const/4 v4, 0x0

    aput-byte v3, v2, v4

    invoke-virtual {v0}, Ljava/security/spec/ECPoint;->getAffineX()Ljava/math/BigInteger;

    move-result-object v3

    invoke-virtual {v3}, Ljava/math/BigInteger;->toByteArray()[B

    move-result-object v3

    invoke-static {v3}, Lr/b;->j([B)[B

    move-result-object v3

    add-int/lit8 v5, p1, 0x1

    array-length v6, v3

    sub-int v6, v5, v6

    array-length v7, v3

    invoke-static {v3, v4, v2, v6, v7}, Ljava/lang/System;->arraycopy(Ljava/lang/Object;ILjava/lang/Object;II)V

    invoke-virtual {v0}, Ljava/security/spec/ECPoint;->getAffineY()Ljava/math/BigInteger;

    move-result-object v0

    invoke-virtual {v0}, Ljava/math/BigInteger;->toByteArray()[B

    move-result-object v0

    invoke-static {v0}, Lr/b;->j([B)[B

    move-result-object v0

    add-int/2addr v5, p1

    array-length p1, v0

    sub-int/2addr v5, p1

    array-length p1, v0

    invoke-static {v0, v4, v2, v5, p1}, Ljava/lang/System;->arraycopy(Ljava/lang/Object;ILjava/lang/Object;II)V

    .line 2
    new-instance p1, Lq/b;

    invoke-direct {p1}, Lq/b;-><init>()V

    .line 3
    iget-object v0, p0, Lr/d;->b:Ljava/lang/String;

    .line 4
    invoke-virtual {p1, v0}, Lq/b;->h(Ljava/lang/String;)V

    .line 5
    iget-object v0, p0, Lr/b;->e:Ljava/lang/String;

    .line 6
    invoke-virtual {p1, v0}, Lq/b;->h(Ljava/lang/String;)V

    invoke-virtual {p1, v2, v4, v1}, Lq/b;->i([BII)V

    invoke-virtual {p1}, Lq/b;->a()[B

    move-result-object p1

    return-object p1
.end method
