.class public final Lnet/i2p/crypto/eddsa/EdDSAEngine;
.super Ljava/security/Signature;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lnet/i2p/crypto/eddsa/EdDSAEngine$OneShotSpec;
    }
.end annotation


# static fields
.field public static final h:Ljava/security/spec/AlgorithmParameterSpec;


# instance fields
.field public a:Ljava/security/MessageDigest;

.field public b:Ljava/io/ByteArrayOutputStream;

.field public c:Lnet/i2p/crypto/eddsa/EdDSAKey;

.field public d:Z

.field public e:[B

.field public f:I

.field public g:I


# direct methods
.method public static constructor <clinit>()V
    .locals 2

    new-instance v0, Lnet/i2p/crypto/eddsa/EdDSAEngine$OneShotSpec;

    const/4 v1, 0x0

    invoke-direct {v0, v1}, Lnet/i2p/crypto/eddsa/EdDSAEngine$OneShotSpec;-><init>(Lnet/i2p/crypto/eddsa/EdDSAEngine$1;)V

    sput-object v0, Lnet/i2p/crypto/eddsa/EdDSAEngine;->h:Ljava/security/spec/AlgorithmParameterSpec;

    return-void
.end method

.method public constructor <init>()V
    .locals 1

    const-string v0, "NONEwithEdDSA"

    invoke-direct {p0, v0}, Ljava/security/Signature;-><init>(Ljava/lang/String;)V

    return-void
.end method


# virtual methods
.method public final a(Lnet/i2p/crypto/eddsa/EdDSAPrivateKey;)V
    .locals 3

    .line 1
    iget-object v0, p1, Lnet/i2p/crypto/eddsa/EdDSAPrivateKey;->f:Lnet/i2p/crypto/eddsa/spec/EdDSAParameterSpec;

    .line 2
    iget-object v0, v0, Lnet/i2p/crypto/eddsa/spec/EdDSAParameterSpec;->a:Lnet/i2p/crypto/eddsa/math/Curve;

    .line 3
    iget-object v0, v0, Lnet/i2p/crypto/eddsa/math/Curve;->a:Lnet/i2p/crypto/eddsa/math/Field;

    .line 4
    iget v0, v0, Lnet/i2p/crypto/eddsa/math/Field;->c:I

    .line 5
    iget-object v1, p0, Lnet/i2p/crypto/eddsa/EdDSAEngine;->a:Ljava/security/MessageDigest;

    .line 6
    iget-object p1, p1, Lnet/i2p/crypto/eddsa/EdDSAPrivateKey;->b:[B

    .line 7
    div-int/lit8 v2, v0, 0x8

    div-int/lit8 v0, v0, 0x4

    sub-int/2addr v0, v2

    invoke-virtual {v1, p1, v2, v0}, Ljava/security/MessageDigest;->update([BII)V

    return-void
.end method

.method public final b()V
    .locals 1

    iget-object v0, p0, Lnet/i2p/crypto/eddsa/EdDSAEngine;->a:Ljava/security/MessageDigest;

    if-eqz v0, :cond_0

    invoke-virtual {v0}, Ljava/security/MessageDigest;->reset()V

    :cond_0
    iget-object v0, p0, Lnet/i2p/crypto/eddsa/EdDSAEngine;->b:Ljava/io/ByteArrayOutputStream;

    if-eqz v0, :cond_1

    invoke-virtual {v0}, Ljava/io/ByteArrayOutputStream;->reset()V

    :cond_1
    const/4 v0, 0x0

    iput-boolean v0, p0, Lnet/i2p/crypto/eddsa/EdDSAEngine;->d:Z

    const/4 v0, 0x0

    iput-object v0, p0, Lnet/i2p/crypto/eddsa/EdDSAEngine;->e:[B

    return-void
.end method

.method public final c()[B
    .locals 10

    iget-object v0, p0, Lnet/i2p/crypto/eddsa/EdDSAEngine;->c:Lnet/i2p/crypto/eddsa/EdDSAKey;

    invoke-interface {v0}, Lnet/i2p/crypto/eddsa/EdDSAKey;->a()Lnet/i2p/crypto/eddsa/spec/EdDSAParameterSpec;

    move-result-object v0

    .line 1
    iget-object v0, v0, Lnet/i2p/crypto/eddsa/spec/EdDSAParameterSpec;->a:Lnet/i2p/crypto/eddsa/math/Curve;

    .line 2
    iget-object v1, p0, Lnet/i2p/crypto/eddsa/EdDSAEngine;->c:Lnet/i2p/crypto/eddsa/EdDSAKey;

    invoke-interface {v1}, Lnet/i2p/crypto/eddsa/EdDSAKey;->a()Lnet/i2p/crypto/eddsa/spec/EdDSAParameterSpec;

    move-result-object v1

    .line 3
    iget-object v1, v1, Lnet/i2p/crypto/eddsa/spec/EdDSAParameterSpec;->c:Lnet/i2p/crypto/eddsa/math/ScalarOps;

    .line 4
    iget-object v2, p0, Lnet/i2p/crypto/eddsa/EdDSAEngine;->c:Lnet/i2p/crypto/eddsa/EdDSAKey;

    check-cast v2, Lnet/i2p/crypto/eddsa/EdDSAPrivateKey;

    .line 5
    iget-object v2, v2, Lnet/i2p/crypto/eddsa/EdDSAPrivateKey;->c:[B

    .line 6
    iget-boolean v3, p0, Lnet/i2p/crypto/eddsa/EdDSAEngine;->d:Z

    const/4 v4, 0x0

    if-eqz v3, :cond_1

    iget-object v3, p0, Lnet/i2p/crypto/eddsa/EdDSAEngine;->e:[B

    if-eqz v3, :cond_0

    iget v4, p0, Lnet/i2p/crypto/eddsa/EdDSAEngine;->f:I

    iget v5, p0, Lnet/i2p/crypto/eddsa/EdDSAEngine;->g:I

    goto :goto_1

    :cond_0
    new-instance v0, Ljava/security/SignatureException;

    const-string v1, "update() not called first"

    invoke-direct {v0, v1}, Ljava/security/SignatureException;-><init>(Ljava/lang/String;)V

    throw v0

    :cond_1
    iget-object v3, p0, Lnet/i2p/crypto/eddsa/EdDSAEngine;->b:Ljava/io/ByteArrayOutputStream;

    if-nez v3, :cond_2

    new-array v3, v4, [B

    goto :goto_0

    :cond_2
    invoke-virtual {v3}, Ljava/io/ByteArrayOutputStream;->toByteArray()[B

    move-result-object v3

    :goto_0
    array-length v5, v3

    :goto_1
    iget-object v6, p0, Lnet/i2p/crypto/eddsa/EdDSAEngine;->a:Ljava/security/MessageDigest;

    invoke-virtual {v6, v3, v4, v5}, Ljava/security/MessageDigest;->update([BII)V

    iget-object v6, p0, Lnet/i2p/crypto/eddsa/EdDSAEngine;->a:Ljava/security/MessageDigest;

    invoke-virtual {v6}, Ljava/security/MessageDigest;->digest()[B

    move-result-object v6

    invoke-interface {v1, v6}, Lnet/i2p/crypto/eddsa/math/ScalarOps;->a([B)[B

    move-result-object v6

    iget-object v7, p0, Lnet/i2p/crypto/eddsa/EdDSAEngine;->c:Lnet/i2p/crypto/eddsa/EdDSAKey;

    invoke-interface {v7}, Lnet/i2p/crypto/eddsa/EdDSAKey;->a()Lnet/i2p/crypto/eddsa/spec/EdDSAParameterSpec;

    move-result-object v7

    .line 7
    iget-object v7, v7, Lnet/i2p/crypto/eddsa/spec/EdDSAParameterSpec;->d:Lnet/i2p/crypto/eddsa/math/GroupElement;

    .line 8
    invoke-virtual {v7, v6}, Lnet/i2p/crypto/eddsa/math/GroupElement;->k([B)Lnet/i2p/crypto/eddsa/math/GroupElement;

    move-result-object v7

    invoke-virtual {v7}, Lnet/i2p/crypto/eddsa/math/GroupElement;->n()[B

    move-result-object v7

    iget-object v8, p0, Lnet/i2p/crypto/eddsa/EdDSAEngine;->a:Ljava/security/MessageDigest;

    invoke-virtual {v8, v7}, Ljava/security/MessageDigest;->update([B)V

    iget-object v8, p0, Lnet/i2p/crypto/eddsa/EdDSAEngine;->a:Ljava/security/MessageDigest;

    iget-object v9, p0, Lnet/i2p/crypto/eddsa/EdDSAEngine;->c:Lnet/i2p/crypto/eddsa/EdDSAKey;

    check-cast v9, Lnet/i2p/crypto/eddsa/EdDSAPrivateKey;

    .line 9
    iget-object v9, v9, Lnet/i2p/crypto/eddsa/EdDSAPrivateKey;->e:[B

    .line 10
    invoke-virtual {v8, v9}, Ljava/security/MessageDigest;->update([B)V

    iget-object v8, p0, Lnet/i2p/crypto/eddsa/EdDSAEngine;->a:Ljava/security/MessageDigest;

    invoke-virtual {v8, v3, v4, v5}, Ljava/security/MessageDigest;->update([BII)V

    iget-object v3, p0, Lnet/i2p/crypto/eddsa/EdDSAEngine;->a:Ljava/security/MessageDigest;

    invoke-virtual {v3}, Ljava/security/MessageDigest;->digest()[B

    move-result-object v3

    invoke-interface {v1, v3}, Lnet/i2p/crypto/eddsa/math/ScalarOps;->a([B)[B

    move-result-object v3

    invoke-interface {v1, v3, v2, v6}, Lnet/i2p/crypto/eddsa/math/ScalarOps;->b([B[B[B)[B

    move-result-object v1

    .line 11
    iget-object v0, v0, Lnet/i2p/crypto/eddsa/math/Curve;->a:Lnet/i2p/crypto/eddsa/math/Field;

    .line 12
    iget v0, v0, Lnet/i2p/crypto/eddsa/math/Field;->c:I

    .line 13
    div-int/lit8 v0, v0, 0x4

    invoke-static {v0}, Ljava/nio/ByteBuffer;->allocate(I)Ljava/nio/ByteBuffer;

    move-result-object v0

    invoke-virtual {v0, v7}, Ljava/nio/ByteBuffer;->put([B)Ljava/nio/ByteBuffer;

    move-result-object v2

    invoke-virtual {v2, v1}, Ljava/nio/ByteBuffer;->put([B)Ljava/nio/ByteBuffer;

    invoke-virtual {v0}, Ljava/nio/ByteBuffer;->array()[B

    move-result-object v0

    return-object v0
.end method

.method public final d([B)Z
    .locals 11

    iget-object v0, p0, Lnet/i2p/crypto/eddsa/EdDSAEngine;->c:Lnet/i2p/crypto/eddsa/EdDSAKey;

    invoke-interface {v0}, Lnet/i2p/crypto/eddsa/EdDSAKey;->a()Lnet/i2p/crypto/eddsa/spec/EdDSAParameterSpec;

    move-result-object v0

    .line 1
    iget-object v0, v0, Lnet/i2p/crypto/eddsa/spec/EdDSAParameterSpec;->a:Lnet/i2p/crypto/eddsa/math/Curve;

    .line 2
    iget-object v0, v0, Lnet/i2p/crypto/eddsa/math/Curve;->a:Lnet/i2p/crypto/eddsa/math/Field;

    .line 3
    iget v0, v0, Lnet/i2p/crypto/eddsa/math/Field;->c:I

    .line 4
    array-length v1, p1

    div-int/lit8 v2, v0, 0x4

    if-ne v1, v2, :cond_10

    iget-object v1, p0, Lnet/i2p/crypto/eddsa/EdDSAEngine;->a:Ljava/security/MessageDigest;

    div-int/lit8 v0, v0, 0x8

    const/4 v3, 0x0

    invoke-virtual {v1, p1, v3, v0}, Ljava/security/MessageDigest;->update([BII)V

    iget-object v1, p0, Lnet/i2p/crypto/eddsa/EdDSAEngine;->a:Ljava/security/MessageDigest;

    iget-object v4, p0, Lnet/i2p/crypto/eddsa/EdDSAEngine;->c:Lnet/i2p/crypto/eddsa/EdDSAKey;

    check-cast v4, Lnet/i2p/crypto/eddsa/EdDSAPublicKey;

    .line 5
    iget-object v4, v4, Lnet/i2p/crypto/eddsa/EdDSAPublicKey;->c:[B

    .line 6
    invoke-virtual {v1, v4}, Ljava/security/MessageDigest;->update([B)V

    iget-boolean v1, p0, Lnet/i2p/crypto/eddsa/EdDSAEngine;->d:Z

    if-eqz v1, :cond_1

    iget-object v1, p0, Lnet/i2p/crypto/eddsa/EdDSAEngine;->e:[B

    if-eqz v1, :cond_0

    iget v4, p0, Lnet/i2p/crypto/eddsa/EdDSAEngine;->f:I

    iget v5, p0, Lnet/i2p/crypto/eddsa/EdDSAEngine;->g:I

    goto :goto_1

    :cond_0
    new-instance p1, Ljava/security/SignatureException;

    const-string v0, "update() not called first"

    invoke-direct {p1, v0}, Ljava/security/SignatureException;-><init>(Ljava/lang/String;)V

    throw p1

    :cond_1
    iget-object v1, p0, Lnet/i2p/crypto/eddsa/EdDSAEngine;->b:Ljava/io/ByteArrayOutputStream;

    if-nez v1, :cond_2

    new-array v1, v3, [B

    goto :goto_0

    :cond_2
    invoke-virtual {v1}, Ljava/io/ByteArrayOutputStream;->toByteArray()[B

    move-result-object v1

    :goto_0
    array-length v5, v1

    const/4 v4, 0x0

    :goto_1
    iget-object v6, p0, Lnet/i2p/crypto/eddsa/EdDSAEngine;->a:Ljava/security/MessageDigest;

    invoke-virtual {v6, v1, v4, v5}, Ljava/security/MessageDigest;->update([BII)V

    iget-object v1, p0, Lnet/i2p/crypto/eddsa/EdDSAEngine;->a:Ljava/security/MessageDigest;

    invoke-virtual {v1}, Ljava/security/MessageDigest;->digest()[B

    move-result-object v1

    iget-object v4, p0, Lnet/i2p/crypto/eddsa/EdDSAEngine;->c:Lnet/i2p/crypto/eddsa/EdDSAKey;

    invoke-interface {v4}, Lnet/i2p/crypto/eddsa/EdDSAKey;->a()Lnet/i2p/crypto/eddsa/spec/EdDSAParameterSpec;

    move-result-object v4

    .line 7
    iget-object v4, v4, Lnet/i2p/crypto/eddsa/spec/EdDSAParameterSpec;->c:Lnet/i2p/crypto/eddsa/math/ScalarOps;

    .line 8
    invoke-interface {v4, v1}, Lnet/i2p/crypto/eddsa/math/ScalarOps;->a([B)[B

    move-result-object v1

    invoke-static {p1, v0, v2}, Ljava/util/Arrays;->copyOfRange([BII)[B

    move-result-object v0

    iget-object v2, p0, Lnet/i2p/crypto/eddsa/EdDSAEngine;->c:Lnet/i2p/crypto/eddsa/EdDSAKey;

    invoke-interface {v2}, Lnet/i2p/crypto/eddsa/EdDSAKey;->a()Lnet/i2p/crypto/eddsa/spec/EdDSAParameterSpec;

    move-result-object v2

    .line 9
    iget-object v2, v2, Lnet/i2p/crypto/eddsa/spec/EdDSAParameterSpec;->d:Lnet/i2p/crypto/eddsa/math/GroupElement;

    .line 10
    iget-object v4, p0, Lnet/i2p/crypto/eddsa/EdDSAEngine;->c:Lnet/i2p/crypto/eddsa/EdDSAKey;

    check-cast v4, Lnet/i2p/crypto/eddsa/EdDSAPublicKey;

    .line 11
    iget-object v5, v4, Lnet/i2p/crypto/eddsa/EdDSAPublicKey;->b:Lnet/i2p/crypto/eddsa/math/GroupElement;

    if-nez v5, :cond_6

    iget-object v5, v4, Lnet/i2p/crypto/eddsa/EdDSAPublicKey;->a:Lnet/i2p/crypto/eddsa/math/GroupElement;

    .line 12
    iget-object v6, v5, Lnet/i2p/crypto/eddsa/math/GroupElement;->b:Lnet/i2p/crypto/eddsa/math/GroupElement$Representation;

    sget-object v7, Lnet/i2p/crypto/eddsa/math/GroupElement$Representation;->b:Lnet/i2p/crypto/eddsa/math/GroupElement$Representation;

    if-ne v6, v7, :cond_5

    iget-object v6, v5, Lnet/i2p/crypto/eddsa/math/GroupElement;->a:Lnet/i2p/crypto/eddsa/math/Curve;

    invoke-virtual {v6, v7}, Lnet/i2p/crypto/eddsa/math/Curve;->a(Lnet/i2p/crypto/eddsa/math/GroupElement$Representation;)Lnet/i2p/crypto/eddsa/math/GroupElement;

    move-result-object v6

    invoke-virtual {v5}, Lnet/i2p/crypto/eddsa/math/GroupElement;->o()Lnet/i2p/crypto/eddsa/math/GroupElement;

    move-result-object v5

    .line 13
    iget-object v8, v6, Lnet/i2p/crypto/eddsa/math/GroupElement;->b:Lnet/i2p/crypto/eddsa/math/GroupElement$Representation;

    if-ne v8, v7, :cond_4

    iget-object v7, v5, Lnet/i2p/crypto/eddsa/math/GroupElement;->b:Lnet/i2p/crypto/eddsa/math/GroupElement$Representation;

    sget-object v8, Lnet/i2p/crypto/eddsa/math/GroupElement$Representation;->f:Lnet/i2p/crypto/eddsa/math/GroupElement$Representation;

    if-ne v7, v8, :cond_3

    iget-object v7, v6, Lnet/i2p/crypto/eddsa/math/GroupElement;->d:Lnet/i2p/crypto/eddsa/math/FieldElement;

    iget-object v8, v6, Lnet/i2p/crypto/eddsa/math/GroupElement;->c:Lnet/i2p/crypto/eddsa/math/FieldElement;

    invoke-virtual {v7, v8}, Lnet/i2p/crypto/eddsa/math/FieldElement;->a(Lnet/i2p/crypto/eddsa/math/FieldElement;)Lnet/i2p/crypto/eddsa/math/FieldElement;

    move-result-object v7

    iget-object v8, v6, Lnet/i2p/crypto/eddsa/math/GroupElement;->d:Lnet/i2p/crypto/eddsa/math/FieldElement;

    iget-object v9, v6, Lnet/i2p/crypto/eddsa/math/GroupElement;->c:Lnet/i2p/crypto/eddsa/math/FieldElement;

    invoke-virtual {v8, v9}, Lnet/i2p/crypto/eddsa/math/FieldElement;->l(Lnet/i2p/crypto/eddsa/math/FieldElement;)Lnet/i2p/crypto/eddsa/math/FieldElement;

    move-result-object v8

    iget-object v9, v5, Lnet/i2p/crypto/eddsa/math/GroupElement;->d:Lnet/i2p/crypto/eddsa/math/FieldElement;

    invoke-virtual {v7, v9}, Lnet/i2p/crypto/eddsa/math/FieldElement;->g(Lnet/i2p/crypto/eddsa/math/FieldElement;)Lnet/i2p/crypto/eddsa/math/FieldElement;

    move-result-object v7

    iget-object v9, v5, Lnet/i2p/crypto/eddsa/math/GroupElement;->c:Lnet/i2p/crypto/eddsa/math/FieldElement;

    invoke-virtual {v8, v9}, Lnet/i2p/crypto/eddsa/math/FieldElement;->g(Lnet/i2p/crypto/eddsa/math/FieldElement;)Lnet/i2p/crypto/eddsa/math/FieldElement;

    move-result-object v8

    iget-object v9, v5, Lnet/i2p/crypto/eddsa/math/GroupElement;->f:Lnet/i2p/crypto/eddsa/math/FieldElement;

    iget-object v10, v6, Lnet/i2p/crypto/eddsa/math/GroupElement;->f:Lnet/i2p/crypto/eddsa/math/FieldElement;

    invoke-virtual {v9, v10}, Lnet/i2p/crypto/eddsa/math/FieldElement;->g(Lnet/i2p/crypto/eddsa/math/FieldElement;)Lnet/i2p/crypto/eddsa/math/FieldElement;

    move-result-object v9

    iget-object v10, v6, Lnet/i2p/crypto/eddsa/math/GroupElement;->e:Lnet/i2p/crypto/eddsa/math/FieldElement;

    iget-object v5, v5, Lnet/i2p/crypto/eddsa/math/GroupElement;->e:Lnet/i2p/crypto/eddsa/math/FieldElement;

    invoke-virtual {v10, v5}, Lnet/i2p/crypto/eddsa/math/FieldElement;->g(Lnet/i2p/crypto/eddsa/math/FieldElement;)Lnet/i2p/crypto/eddsa/math/FieldElement;

    move-result-object v5

    invoke-virtual {v5, v5}, Lnet/i2p/crypto/eddsa/math/FieldElement;->a(Lnet/i2p/crypto/eddsa/math/FieldElement;)Lnet/i2p/crypto/eddsa/math/FieldElement;

    move-result-object v5

    iget-object v6, v6, Lnet/i2p/crypto/eddsa/math/GroupElement;->a:Lnet/i2p/crypto/eddsa/math/Curve;

    invoke-virtual {v7, v8}, Lnet/i2p/crypto/eddsa/math/FieldElement;->l(Lnet/i2p/crypto/eddsa/math/FieldElement;)Lnet/i2p/crypto/eddsa/math/FieldElement;

    move-result-object v10

    invoke-virtual {v7, v8}, Lnet/i2p/crypto/eddsa/math/FieldElement;->a(Lnet/i2p/crypto/eddsa/math/FieldElement;)Lnet/i2p/crypto/eddsa/math/FieldElement;

    move-result-object v7

    invoke-virtual {v5, v9}, Lnet/i2p/crypto/eddsa/math/FieldElement;->l(Lnet/i2p/crypto/eddsa/math/FieldElement;)Lnet/i2p/crypto/eddsa/math/FieldElement;

    move-result-object v8

    invoke-virtual {v5, v9}, Lnet/i2p/crypto/eddsa/math/FieldElement;->a(Lnet/i2p/crypto/eddsa/math/FieldElement;)Lnet/i2p/crypto/eddsa/math/FieldElement;

    move-result-object v5

    invoke-static {v6, v10, v7, v8, v5}, Lnet/i2p/crypto/eddsa/math/GroupElement;->f(Lnet/i2p/crypto/eddsa/math/Curve;Lnet/i2p/crypto/eddsa/math/FieldElement;Lnet/i2p/crypto/eddsa/math/FieldElement;Lnet/i2p/crypto/eddsa/math/FieldElement;Lnet/i2p/crypto/eddsa/math/FieldElement;)Lnet/i2p/crypto/eddsa/math/GroupElement;

    move-result-object v5

    .line 14
    sget-object v6, Lnet/i2p/crypto/eddsa/math/GroupElement$Representation;->c:Lnet/i2p/crypto/eddsa/math/GroupElement$Representation;

    invoke-virtual {v5, v6}, Lnet/i2p/crypto/eddsa/math/GroupElement;->r(Lnet/i2p/crypto/eddsa/math/GroupElement$Representation;)Lnet/i2p/crypto/eddsa/math/GroupElement;

    move-result-object v5

    .line 15
    iput-object v5, v4, Lnet/i2p/crypto/eddsa/EdDSAPublicKey;->b:Lnet/i2p/crypto/eddsa/math/GroupElement;

    goto :goto_2

    .line 16
    :cond_3
    new-instance p1, Ljava/lang/IllegalArgumentException;

    invoke-direct {p1}, Ljava/lang/IllegalArgumentException;-><init>()V

    throw p1

    :cond_4
    new-instance p1, Ljava/lang/UnsupportedOperationException;

    invoke-direct {p1}, Ljava/lang/UnsupportedOperationException;-><init>()V

    throw p1

    .line 17
    :cond_5
    new-instance p1, Ljava/lang/UnsupportedOperationException;

    invoke-direct {p1}, Ljava/lang/UnsupportedOperationException;-><init>()V

    throw p1

    .line 18
    :cond_6
    :goto_2
    invoke-static {v2}, Ljava/util/Objects;->requireNonNull(Ljava/lang/Object;)Ljava/lang/Object;

    .line 19
    invoke-static {v1}, Lnet/i2p/crypto/eddsa/math/GroupElement;->m([B)[B

    move-result-object v1

    invoke-static {v0}, Lnet/i2p/crypto/eddsa/math/GroupElement;->m([B)[B

    move-result-object v0

    iget-object v4, v2, Lnet/i2p/crypto/eddsa/math/GroupElement;->a:Lnet/i2p/crypto/eddsa/math/Curve;

    sget-object v6, Lnet/i2p/crypto/eddsa/math/GroupElement$Representation;->a:Lnet/i2p/crypto/eddsa/math/GroupElement$Representation;

    invoke-virtual {v4, v6}, Lnet/i2p/crypto/eddsa/math/Curve;->a(Lnet/i2p/crypto/eddsa/math/GroupElement$Representation;)Lnet/i2p/crypto/eddsa/math/GroupElement;

    move-result-object v4

    const/16 v6, 0xff

    :goto_3
    if-ltz v6, :cond_8

    aget-byte v7, v1, v6

    if-nez v7, :cond_8

    aget-byte v7, v0, v6

    if-eqz v7, :cond_7

    goto :goto_4

    :cond_7
    add-int/lit8 v6, v6, -0x1

    goto :goto_3

    :cond_8
    :goto_4
    if-ltz v6, :cond_d

    invoke-virtual {v4}, Lnet/i2p/crypto/eddsa/math/GroupElement;->c()Lnet/i2p/crypto/eddsa/math/GroupElement;

    move-result-object v4

    aget-byte v7, v1, v6

    if-lez v7, :cond_9

    invoke-virtual {v4}, Lnet/i2p/crypto/eddsa/math/GroupElement;->q()Lnet/i2p/crypto/eddsa/math/GroupElement;

    move-result-object v4

    iget-object v7, v5, Lnet/i2p/crypto/eddsa/math/GroupElement;->h:[Lnet/i2p/crypto/eddsa/math/GroupElement;

    aget-byte v8, v1, v6

    div-int/lit8 v8, v8, 0x2

    aget-object v7, v7, v8

    invoke-virtual {v4, v7}, Lnet/i2p/crypto/eddsa/math/GroupElement;->d(Lnet/i2p/crypto/eddsa/math/GroupElement;)Lnet/i2p/crypto/eddsa/math/GroupElement;

    move-result-object v4

    goto :goto_5

    :cond_9
    aget-byte v7, v1, v6

    if-gez v7, :cond_a

    invoke-virtual {v4}, Lnet/i2p/crypto/eddsa/math/GroupElement;->q()Lnet/i2p/crypto/eddsa/math/GroupElement;

    move-result-object v4

    iget-object v7, v5, Lnet/i2p/crypto/eddsa/math/GroupElement;->h:[Lnet/i2p/crypto/eddsa/math/GroupElement;

    aget-byte v8, v1, v6

    neg-int v8, v8

    div-int/lit8 v8, v8, 0x2

    aget-object v7, v7, v8

    invoke-virtual {v4, v7}, Lnet/i2p/crypto/eddsa/math/GroupElement;->e(Lnet/i2p/crypto/eddsa/math/GroupElement;)Lnet/i2p/crypto/eddsa/math/GroupElement;

    move-result-object v4

    :cond_a
    :goto_5
    aget-byte v7, v0, v6

    if-lez v7, :cond_b

    invoke-virtual {v4}, Lnet/i2p/crypto/eddsa/math/GroupElement;->q()Lnet/i2p/crypto/eddsa/math/GroupElement;

    move-result-object v4

    iget-object v7, v2, Lnet/i2p/crypto/eddsa/math/GroupElement;->h:[Lnet/i2p/crypto/eddsa/math/GroupElement;

    aget-byte v8, v0, v6

    div-int/lit8 v8, v8, 0x2

    aget-object v7, v7, v8

    invoke-virtual {v4, v7}, Lnet/i2p/crypto/eddsa/math/GroupElement;->d(Lnet/i2p/crypto/eddsa/math/GroupElement;)Lnet/i2p/crypto/eddsa/math/GroupElement;

    move-result-object v4

    goto :goto_6

    :cond_b
    aget-byte v7, v0, v6

    if-gez v7, :cond_c

    invoke-virtual {v4}, Lnet/i2p/crypto/eddsa/math/GroupElement;->q()Lnet/i2p/crypto/eddsa/math/GroupElement;

    move-result-object v4

    iget-object v7, v2, Lnet/i2p/crypto/eddsa/math/GroupElement;->h:[Lnet/i2p/crypto/eddsa/math/GroupElement;

    aget-byte v8, v0, v6

    neg-int v8, v8

    div-int/lit8 v8, v8, 0x2

    aget-object v7, v7, v8

    invoke-virtual {v4, v7}, Lnet/i2p/crypto/eddsa/math/GroupElement;->e(Lnet/i2p/crypto/eddsa/math/GroupElement;)Lnet/i2p/crypto/eddsa/math/GroupElement;

    move-result-object v4

    :cond_c
    :goto_6
    invoke-virtual {v4}, Lnet/i2p/crypto/eddsa/math/GroupElement;->p()Lnet/i2p/crypto/eddsa/math/GroupElement;

    move-result-object v4

    add-int/lit8 v6, v6, -0x1

    goto :goto_4

    .line 20
    :cond_d
    invoke-virtual {v4}, Lnet/i2p/crypto/eddsa/math/GroupElement;->n()[B

    move-result-object v0

    const/4 v1, 0x0

    :goto_7
    array-length v2, v0

    if-ge v1, v2, :cond_f

    aget-byte v2, v0, v1

    aget-byte v4, p1, v1

    if-eq v2, v4, :cond_e

    return v3

    :cond_e
    add-int/lit8 v1, v1, 0x1

    goto :goto_7

    :cond_f
    const/4 p1, 0x1

    return p1

    :cond_10
    new-instance p1, Ljava/security/SignatureException;

    const-string v0, "signature length is wrong"

    invoke-direct {p1, v0}, Ljava/security/SignatureException;-><init>(Ljava/lang/String;)V

    throw p1
.end method

.method public final engineGetParameter(Ljava/lang/String;)Ljava/lang/Object;
    .locals 1

    new-instance p1, Ljava/lang/UnsupportedOperationException;

    const-string v0, "engineSetParameter unsupported"

    invoke-direct {p1, v0}, Ljava/lang/UnsupportedOperationException;-><init>(Ljava/lang/String;)V

    throw p1
.end method

.method public final engineInitSign(Ljava/security/PrivateKey;)V
    .locals 2

    invoke-virtual {p0}, Lnet/i2p/crypto/eddsa/EdDSAEngine;->b()V

    instance-of v0, p1, Lnet/i2p/crypto/eddsa/EdDSAPrivateKey;

    if-eqz v0, :cond_2

    check-cast p1, Lnet/i2p/crypto/eddsa/EdDSAPrivateKey;

    iput-object p1, p0, Lnet/i2p/crypto/eddsa/EdDSAEngine;->c:Lnet/i2p/crypto/eddsa/EdDSAKey;

    iget-object v0, p0, Lnet/i2p/crypto/eddsa/EdDSAEngine;->a:Ljava/security/MessageDigest;

    if-nez v0, :cond_0

    :try_start_0
    invoke-interface {p1}, Lnet/i2p/crypto/eddsa/EdDSAKey;->a()Lnet/i2p/crypto/eddsa/spec/EdDSAParameterSpec;

    move-result-object v0

    .line 1
    iget-object v0, v0, Lnet/i2p/crypto/eddsa/spec/EdDSAParameterSpec;->b:Ljava/lang/String;

    .line 2
    invoke-static {v0}, Ljava/security/MessageDigest;->getInstance(Ljava/lang/String;)Ljava/security/MessageDigest;

    move-result-object v0

    iput-object v0, p0, Lnet/i2p/crypto/eddsa/EdDSAEngine;->a:Ljava/security/MessageDigest;
    :try_end_0
    .catch Ljava/security/NoSuchAlgorithmException; {:try_start_0 .. :try_end_0} :catch_0

    goto :goto_0

    :catch_0
    new-instance p1, Ljava/security/InvalidKeyException;

    const-string v0, "cannot get required digest "

    .line 3
    invoke-static {v0}, Lcom/trilead/ssh2/crypto/digest/a;->e(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    .line 4
    iget-object v1, p0, Lnet/i2p/crypto/eddsa/EdDSAEngine;->c:Lnet/i2p/crypto/eddsa/EdDSAKey;

    invoke-interface {v1}, Lnet/i2p/crypto/eddsa/EdDSAKey;->a()Lnet/i2p/crypto/eddsa/spec/EdDSAParameterSpec;

    move-result-object v1

    .line 5
    iget-object v1, v1, Lnet/i2p/crypto/eddsa/spec/EdDSAParameterSpec;->b:Ljava/lang/String;

    .line 6
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v1, " for private key."

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-direct {p1, v0}, Ljava/security/InvalidKeyException;-><init>(Ljava/lang/String;)V

    throw p1

    :cond_0
    invoke-interface {p1}, Lnet/i2p/crypto/eddsa/EdDSAKey;->a()Lnet/i2p/crypto/eddsa/spec/EdDSAParameterSpec;

    move-result-object v0

    .line 7
    iget-object v0, v0, Lnet/i2p/crypto/eddsa/spec/EdDSAParameterSpec;->b:Ljava/lang/String;

    .line 8
    iget-object v1, p0, Lnet/i2p/crypto/eddsa/EdDSAEngine;->a:Ljava/security/MessageDigest;

    invoke-virtual {v1}, Ljava/security/MessageDigest;->getAlgorithm()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_1

    :goto_0
    invoke-virtual {p0, p1}, Lnet/i2p/crypto/eddsa/EdDSAEngine;->a(Lnet/i2p/crypto/eddsa/EdDSAPrivateKey;)V

    return-void

    :cond_1
    new-instance p1, Ljava/security/InvalidKeyException;

    const-string v0, "Key hash algorithm does not match chosen digest"

    invoke-direct {p1, v0}, Ljava/security/InvalidKeyException;-><init>(Ljava/lang/String;)V

    throw p1

    :cond_2
    new-instance v0, Ljava/security/InvalidKeyException;

    const-string v1, "cannot identify EdDSA private key: "

    .line 9
    invoke-static {v1}, Lcom/trilead/ssh2/crypto/digest/a;->e(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    .line 10
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-result-object p1

    invoke-virtual {v1, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    invoke-direct {v0, p1}, Ljava/security/InvalidKeyException;-><init>(Ljava/lang/String;)V

    throw v0
.end method

.method public final engineInitVerify(Ljava/security/PublicKey;)V
    .locals 3

    invoke-virtual {p0}, Lnet/i2p/crypto/eddsa/EdDSAEngine;->b()V

    instance-of v0, p1, Lnet/i2p/crypto/eddsa/EdDSAPublicKey;

    if-eqz v0, :cond_2

    check-cast p1, Lnet/i2p/crypto/eddsa/EdDSAPublicKey;

    iput-object p1, p0, Lnet/i2p/crypto/eddsa/EdDSAEngine;->c:Lnet/i2p/crypto/eddsa/EdDSAKey;

    iget-object v0, p0, Lnet/i2p/crypto/eddsa/EdDSAEngine;->a:Ljava/security/MessageDigest;

    if-nez v0, :cond_0

    .line 1
    :try_start_0
    iget-object p1, p1, Lnet/i2p/crypto/eddsa/EdDSAPublicKey;->d:Lnet/i2p/crypto/eddsa/spec/EdDSAParameterSpec;

    .line 2
    iget-object p1, p1, Lnet/i2p/crypto/eddsa/spec/EdDSAParameterSpec;->b:Ljava/lang/String;

    .line 3
    invoke-static {p1}, Ljava/security/MessageDigest;->getInstance(Ljava/lang/String;)Ljava/security/MessageDigest;

    move-result-object p1

    iput-object p1, p0, Lnet/i2p/crypto/eddsa/EdDSAEngine;->a:Ljava/security/MessageDigest;
    :try_end_0
    .catch Ljava/security/NoSuchAlgorithmException; {:try_start_0 .. :try_end_0} :catch_0

    goto :goto_0

    :catch_0
    new-instance p1, Ljava/security/InvalidKeyException;

    const-string v0, "cannot get required digest "

    .line 4
    invoke-static {v0}, Lcom/trilead/ssh2/crypto/digest/a;->e(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    .line 5
    iget-object v1, p0, Lnet/i2p/crypto/eddsa/EdDSAEngine;->c:Lnet/i2p/crypto/eddsa/EdDSAKey;

    invoke-interface {v1}, Lnet/i2p/crypto/eddsa/EdDSAKey;->a()Lnet/i2p/crypto/eddsa/spec/EdDSAParameterSpec;

    move-result-object v1

    .line 6
    iget-object v1, v1, Lnet/i2p/crypto/eddsa/spec/EdDSAParameterSpec;->b:Ljava/lang/String;

    .line 7
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v1, " for private key."

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-direct {p1, v0}, Ljava/security/InvalidKeyException;-><init>(Ljava/lang/String;)V

    throw p1

    .line 8
    :cond_0
    iget-object p1, p1, Lnet/i2p/crypto/eddsa/EdDSAPublicKey;->d:Lnet/i2p/crypto/eddsa/spec/EdDSAParameterSpec;

    .line 9
    iget-object p1, p1, Lnet/i2p/crypto/eddsa/spec/EdDSAParameterSpec;->b:Ljava/lang/String;

    .line 10
    invoke-virtual {v0}, Ljava/security/MessageDigest;->getAlgorithm()Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p1, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p1

    if-eqz p1, :cond_1

    goto :goto_0

    :cond_1
    new-instance p1, Ljava/security/InvalidKeyException;

    const-string v0, "Key hash algorithm does not match chosen digest"

    invoke-direct {p1, v0}, Ljava/security/InvalidKeyException;-><init>(Ljava/lang/String;)V

    throw p1

    :cond_2
    :try_start_1
    new-instance v0, Lnet/i2p/crypto/eddsa/EdDSAPublicKey;

    new-instance v1, Ljava/security/spec/X509EncodedKeySpec;

    invoke-interface {p1}, Ljava/security/Key;->getEncoded()[B

    move-result-object v2

    invoke-direct {v1, v2}, Ljava/security/spec/X509EncodedKeySpec;-><init>([B)V

    invoke-direct {v0, v1}, Lnet/i2p/crypto/eddsa/EdDSAPublicKey;-><init>(Ljava/security/spec/X509EncodedKeySpec;)V
    :try_end_1
    .catch Ljava/security/spec/InvalidKeySpecException; {:try_start_1 .. :try_end_1} :catch_1

    invoke-virtual {p0, v0}, Lnet/i2p/crypto/eddsa/EdDSAEngine;->engineInitVerify(Ljava/security/PublicKey;)V

    :goto_0
    return-void

    :catch_1
    new-instance v0, Ljava/security/InvalidKeyException;

    const-string v1, "cannot handle X.509 EdDSA public key: "

    .line 11
    invoke-static {v1}, Lcom/trilead/ssh2/crypto/digest/a;->e(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    .line 12
    invoke-interface {p1}, Ljava/security/Key;->getAlgorithm()Ljava/lang/String;

    move-result-object p1

    invoke-virtual {v1, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    invoke-direct {v0, p1}, Ljava/security/InvalidKeyException;-><init>(Ljava/lang/String;)V

    throw v0
.end method

.method public final engineSetParameter(Ljava/lang/String;Ljava/lang/Object;)V
    .locals 0

    new-instance p1, Ljava/lang/UnsupportedOperationException;

    const-string p2, "engineSetParameter unsupported"

    invoke-direct {p1, p2}, Ljava/lang/UnsupportedOperationException;-><init>(Ljava/lang/String;)V

    throw p1
.end method

.method public final engineSetParameter(Ljava/security/spec/AlgorithmParameterSpec;)V
    .locals 1

    sget-object v0, Lnet/i2p/crypto/eddsa/EdDSAEngine;->h:Ljava/security/spec/AlgorithmParameterSpec;

    invoke-virtual {p1, v0}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_2

    iget-object p1, p0, Lnet/i2p/crypto/eddsa/EdDSAEngine;->e:[B

    if-nez p1, :cond_1

    iget-object p1, p0, Lnet/i2p/crypto/eddsa/EdDSAEngine;->b:Ljava/io/ByteArrayOutputStream;

    if-eqz p1, :cond_0

    invoke-virtual {p1}, Ljava/io/ByteArrayOutputStream;->size()I

    move-result p1

    if-gtz p1, :cond_1

    :cond_0
    const/4 p1, 0x1

    iput-boolean p1, p0, Lnet/i2p/crypto/eddsa/EdDSAEngine;->d:Z

    goto :goto_0

    :cond_1
    new-instance p1, Ljava/security/InvalidAlgorithmParameterException;

    const-string v0, "update() already called"

    invoke-direct {p1, v0}, Ljava/security/InvalidAlgorithmParameterException;-><init>(Ljava/lang/String;)V

    throw p1

    :cond_2
    invoke-super {p0, p1}, Ljava/security/SignatureSpi;->engineSetParameter(Ljava/security/spec/AlgorithmParameterSpec;)V

    :goto_0
    return-void
.end method

.method public final engineSign()[B
    .locals 2

    :try_start_0
    invoke-virtual {p0}, Lnet/i2p/crypto/eddsa/EdDSAEngine;->c()[B

    move-result-object v0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    invoke-virtual {p0}, Lnet/i2p/crypto/eddsa/EdDSAEngine;->b()V

    iget-object v1, p0, Lnet/i2p/crypto/eddsa/EdDSAEngine;->c:Lnet/i2p/crypto/eddsa/EdDSAKey;

    check-cast v1, Lnet/i2p/crypto/eddsa/EdDSAPrivateKey;

    invoke-virtual {p0, v1}, Lnet/i2p/crypto/eddsa/EdDSAEngine;->a(Lnet/i2p/crypto/eddsa/EdDSAPrivateKey;)V

    return-object v0

    :catchall_0
    move-exception v0

    invoke-virtual {p0}, Lnet/i2p/crypto/eddsa/EdDSAEngine;->b()V

    iget-object v1, p0, Lnet/i2p/crypto/eddsa/EdDSAEngine;->c:Lnet/i2p/crypto/eddsa/EdDSAKey;

    check-cast v1, Lnet/i2p/crypto/eddsa/EdDSAPrivateKey;

    invoke-virtual {p0, v1}, Lnet/i2p/crypto/eddsa/EdDSAEngine;->a(Lnet/i2p/crypto/eddsa/EdDSAPrivateKey;)V

    throw v0
.end method

.method public final engineUpdate(B)V
    .locals 2

    iget-boolean v0, p0, Lnet/i2p/crypto/eddsa/EdDSAEngine;->d:Z

    if-nez v0, :cond_1

    iget-object v0, p0, Lnet/i2p/crypto/eddsa/EdDSAEngine;->b:Ljava/io/ByteArrayOutputStream;

    if-nez v0, :cond_0

    new-instance v0, Ljava/io/ByteArrayOutputStream;

    const/16 v1, 0x100

    invoke-direct {v0, v1}, Ljava/io/ByteArrayOutputStream;-><init>(I)V

    iput-object v0, p0, Lnet/i2p/crypto/eddsa/EdDSAEngine;->b:Ljava/io/ByteArrayOutputStream;

    :cond_0
    iget-object v0, p0, Lnet/i2p/crypto/eddsa/EdDSAEngine;->b:Ljava/io/ByteArrayOutputStream;

    invoke-virtual {v0, p1}, Ljava/io/ByteArrayOutputStream;->write(I)V

    return-void

    :cond_1
    new-instance p1, Ljava/security/SignatureException;

    const-string v0, "unsupported in one-shot mode"

    invoke-direct {p1, v0}, Ljava/security/SignatureException;-><init>(Ljava/lang/String;)V

    throw p1
.end method

.method public final engineUpdate([BII)V
    .locals 2

    iget-boolean v0, p0, Lnet/i2p/crypto/eddsa/EdDSAEngine;->d:Z

    if-eqz v0, :cond_1

    iget-object v0, p0, Lnet/i2p/crypto/eddsa/EdDSAEngine;->e:[B

    if-nez v0, :cond_0

    iput-object p1, p0, Lnet/i2p/crypto/eddsa/EdDSAEngine;->e:[B

    iput p2, p0, Lnet/i2p/crypto/eddsa/EdDSAEngine;->f:I

    iput p3, p0, Lnet/i2p/crypto/eddsa/EdDSAEngine;->g:I

    goto :goto_0

    :cond_0
    new-instance p1, Ljava/security/SignatureException;

    const-string p2, "update() already called"

    invoke-direct {p1, p2}, Ljava/security/SignatureException;-><init>(Ljava/lang/String;)V

    throw p1

    :cond_1
    iget-object v0, p0, Lnet/i2p/crypto/eddsa/EdDSAEngine;->b:Ljava/io/ByteArrayOutputStream;

    if-nez v0, :cond_2

    new-instance v0, Ljava/io/ByteArrayOutputStream;

    const/16 v1, 0x100

    invoke-direct {v0, v1}, Ljava/io/ByteArrayOutputStream;-><init>(I)V

    iput-object v0, p0, Lnet/i2p/crypto/eddsa/EdDSAEngine;->b:Ljava/io/ByteArrayOutputStream;

    :cond_2
    iget-object v0, p0, Lnet/i2p/crypto/eddsa/EdDSAEngine;->b:Ljava/io/ByteArrayOutputStream;

    invoke-virtual {v0, p1, p2, p3}, Ljava/io/ByteArrayOutputStream;->write([BII)V

    :goto_0
    return-void
.end method

.method public final engineVerify([B)Z
    .locals 0

    :try_start_0
    invoke-virtual {p0, p1}, Lnet/i2p/crypto/eddsa/EdDSAEngine;->d([B)Z

    move-result p1
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    invoke-virtual {p0}, Lnet/i2p/crypto/eddsa/EdDSAEngine;->b()V

    return p1

    :catchall_0
    move-exception p1

    invoke-virtual {p0}, Lnet/i2p/crypto/eddsa/EdDSAEngine;->b()V

    throw p1
.end method
