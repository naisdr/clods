.class Lcom/trilead/ssh2/crypto/cipher/BlockCipherFactory$CipherEntry;
.super Ljava/lang/Object;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/trilead/ssh2/crypto/cipher/BlockCipherFactory;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x9
    name = "CipherEntry"
.end annotation


# instance fields
.field public a:Ljava/lang/String;

.field public b:I

.field public c:I

.field public d:Ljava/lang/String;


# direct methods
.method public constructor <init>(Ljava/lang/String;IILjava/lang/String;)V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lcom/trilead/ssh2/crypto/cipher/BlockCipherFactory$CipherEntry;->a:Ljava/lang/String;

    iput p2, p0, Lcom/trilead/ssh2/crypto/cipher/BlockCipherFactory$CipherEntry;->b:I

    iput p3, p0, Lcom/trilead/ssh2/crypto/cipher/BlockCipherFactory$CipherEntry;->c:I

    iput-object p4, p0, Lcom/trilead/ssh2/crypto/cipher/BlockCipherFactory$CipherEntry;->d:Ljava/lang/String;

    return-void
.end method
