.class public final Lq/c;
.super Ljava/lang/Object;
.source "SourceFile"


# instance fields
.field public a:[B

.field public b:I

.field public c:I


# direct methods
.method public constructor <init>([B)V
    .locals 1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v0, 0x0

    iput v0, p0, Lq/c;->c:I

    iput-object p1, p0, Lq/c;->a:[B

    iput v0, p0, Lq/c;->b:I

    array-length p1, p1

    iput p1, p0, Lq/c;->c:I

    return-void
.end method

.method public constructor <init>([BI)V
    .locals 1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lq/c;->a:[B

    const/4 v0, 0x0

    iput v0, p0, Lq/c;->b:I

    add-int/2addr p2, v0

    iput p2, p0, Lq/c;->c:I

    array-length v0, p1

    if-ltz v0, :cond_1

    if-ltz p2, :cond_0

    array-length p1, p1

    if-gt p2, p1, :cond_0

    return-void

    :cond_0
    new-instance p1, Ljava/lang/IllegalArgumentException;

    const-string p2, "Illegal length."

    invoke-direct {p1, p2}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw p1

    :cond_1
    new-instance p1, Ljava/lang/IllegalArgumentException;

    const-string p2, "Illegal offset."

    invoke-direct {p1, p2}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw p1
.end method


# virtual methods
.method public final a()Z
    .locals 3

    iget v0, p0, Lq/c;->b:I

    iget v1, p0, Lq/c;->c:I

    if-ge v0, v1, :cond_1

    iget-object v1, p0, Lq/c;->a:[B

    add-int/lit8 v2, v0, 0x1

    iput v2, p0, Lq/c;->b:I

    aget-byte v0, v1, v0

    if-eqz v0, :cond_0

    const/4 v0, 0x1

    goto :goto_0

    :cond_0
    const/4 v0, 0x0

    :goto_0
    return v0

    :cond_1
    new-instance v0, Ljava/io/IOException;

    const-string v1, "Packet too short."

    invoke-direct {v0, v1}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    throw v0
.end method

.method public final b()I
    .locals 3

    iget v0, p0, Lq/c;->b:I

    iget v1, p0, Lq/c;->c:I

    if-ge v0, v1, :cond_0

    iget-object v1, p0, Lq/c;->a:[B

    add-int/lit8 v2, v0, 0x1

    iput v2, p0, Lq/c;->b:I

    aget-byte v0, v1, v0

    and-int/lit16 v0, v0, 0xff

    return v0

    :cond_0
    new-instance v0, Ljava/io/IOException;

    const-string v1, "Packet too short."

    invoke-direct {v0, v1}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    throw v0
.end method

.method public final c()[B
    .locals 5

    invoke-virtual {p0}, Lq/c;->i()I

    move-result v0

    iget v1, p0, Lq/c;->b:I

    add-int v2, v0, v1

    iget v3, p0, Lq/c;->c:I

    if-gt v2, v3, :cond_0

    new-array v2, v0, [B

    iget-object v3, p0, Lq/c;->a:[B

    const/4 v4, 0x0

    invoke-static {v3, v1, v2, v4, v0}, Ljava/lang/System;->arraycopy(Ljava/lang/Object;ILjava/lang/Object;II)V

    iget v1, p0, Lq/c;->b:I

    add-int/2addr v1, v0

    iput v1, p0, Lq/c;->b:I

    return-object v2

    :cond_0
    new-instance v0, Ljava/io/IOException;

    const-string v1, "Malformed SSH byte string."

    invoke-direct {v0, v1}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    throw v0
.end method

.method public final d(I)[B
    .locals 4

    iget v0, p0, Lq/c;->b:I

    add-int v1, v0, p1

    iget v2, p0, Lq/c;->c:I

    if-gt v1, v2, :cond_0

    new-array v1, p1, [B

    iget-object v2, p0, Lq/c;->a:[B

    const/4 v3, 0x0

    invoke-static {v2, v0, v1, v3, p1}, Ljava/lang/System;->arraycopy(Ljava/lang/Object;ILjava/lang/Object;II)V

    iget v0, p0, Lq/c;->b:I

    add-int/2addr v0, p1

    iput v0, p0, Lq/c;->b:I

    return-object v1

    :cond_0
    new-instance p1, Ljava/io/IOException;

    const-string v0, "Packet too short."

    invoke-direct {p1, v0}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    throw p1
.end method

.method public final e()Ljava/math/BigInteger;
    .locals 2

    invoke-virtual {p0}, Lq/c;->c()[B

    move-result-object v0

    array-length v1, v0

    if-nez v1, :cond_0

    sget-object v0, Ljava/math/BigInteger;->ZERO:Ljava/math/BigInteger;

    goto :goto_0

    :cond_0
    new-instance v1, Ljava/math/BigInteger;

    invoke-direct {v1, v0}, Ljava/math/BigInteger;-><init>([B)V

    move-object v0, v1

    :goto_0
    return-object v0
.end method

.method public final f()[Ljava/lang/String;
    .locals 2

    invoke-virtual {p0}, Lq/c;->g()Ljava/lang/String;

    move-result-object v0

    const/16 v1, 0x2c

    invoke-static {v0, v1}, La/b;->e(Ljava/lang/String;C)[Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method

.method public final g()Ljava/lang/String;
    .locals 5

    invoke-virtual {p0}, Lq/c;->i()I

    move-result v0

    iget v1, p0, Lq/c;->b:I

    add-int v2, v0, v1

    iget v3, p0, Lq/c;->c:I

    if-gt v2, v3, :cond_0

    new-instance v2, Ljava/lang/String;

    iget-object v3, p0, Lq/c;->a:[B

    const-string v4, "ISO-8859-1"

    invoke-direct {v2, v3, v1, v0, v4}, Ljava/lang/String;-><init>([BIILjava/lang/String;)V

    iget v1, p0, Lq/c;->b:I

    add-int/2addr v1, v0

    iput v1, p0, Lq/c;->b:I

    return-object v2

    :cond_0
    new-instance v0, Ljava/io/IOException;

    const-string v1, "Malformed SSH string."

    invoke-direct {v0, v1}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    throw v0
.end method

.method public final h(Ljava/lang/String;)Ljava/lang/String;
    .locals 4

    invoke-virtual {p0}, Lq/c;->i()I

    move-result v0

    iget v1, p0, Lq/c;->b:I

    add-int v2, v0, v1

    iget v3, p0, Lq/c;->c:I

    if-gt v2, v3, :cond_0

    new-instance v2, Ljava/lang/String;

    iget-object v3, p0, Lq/c;->a:[B

    invoke-direct {v2, v3, v1, v0, p1}, Ljava/lang/String;-><init>([BIILjava/lang/String;)V

    iget p1, p0, Lq/c;->b:I

    add-int/2addr p1, v0

    iput p1, p0, Lq/c;->b:I

    return-object v2

    :cond_0
    new-instance p1, Ljava/io/IOException;

    const-string v0, "Malformed SSH string."

    invoke-direct {p1, v0}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    throw p1
.end method

.method public final i()I
    .locals 4

    iget v0, p0, Lq/c;->b:I

    add-int/lit8 v1, v0, 0x4

    iget v2, p0, Lq/c;->c:I

    if-gt v1, v2, :cond_0

    iget-object v1, p0, Lq/c;->a:[B

    add-int/lit8 v2, v0, 0x1

    iput v2, p0, Lq/c;->b:I

    aget-byte v0, v1, v0

    and-int/lit16 v0, v0, 0xff

    shl-int/lit8 v0, v0, 0x18

    add-int/lit8 v3, v2, 0x1

    iput v3, p0, Lq/c;->b:I

    aget-byte v2, v1, v2

    and-int/lit16 v2, v2, 0xff

    shl-int/lit8 v2, v2, 0x10

    or-int/2addr v0, v2

    add-int/lit8 v2, v3, 0x1

    iput v2, p0, Lq/c;->b:I

    aget-byte v3, v1, v3

    and-int/lit16 v3, v3, 0xff

    shl-int/lit8 v3, v3, 0x8

    or-int/2addr v0, v3

    add-int/lit8 v3, v2, 0x1

    iput v3, p0, Lq/c;->b:I

    aget-byte v1, v1, v2

    and-int/lit16 v1, v1, 0xff

    or-int/2addr v0, v1

    return v0

    :cond_0
    new-instance v0, Ljava/io/IOException;

    const-string v1, "Packet too short."

    invoke-direct {v0, v1}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    throw v0
.end method
