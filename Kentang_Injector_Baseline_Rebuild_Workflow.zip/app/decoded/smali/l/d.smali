.class public final Ll/d;
.super Ljava/lang/Object;
.source "SourceFile"


# instance fields
.field public final a:La/b;

.field public b:Z

.field public final c:Ll/f;


# direct methods
.method public constructor <init>(Ll/f;I)V
    .locals 1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Ll/d;->c:Ll/f;

    new-instance v0, La/b;

    invoke-direct {v0}, La/b;-><init>()V

    iput-object v0, p0, Ll/d;->a:La/b;

    new-array p2, p2, [B

    iget-object p1, p1, Ll/f;->a:Ll/e;

    iget p1, p1, Ll/e;->a:I

    if-nez p1, :cond_0

    const/4 p1, 0x0

    goto :goto_0

    :cond_0
    const/4 p1, 0x1

    :goto_0
    iput-boolean p1, p0, Ll/d;->b:Z

    invoke-virtual {p0}, Ll/d;->a()V

    return-void
.end method


# virtual methods
.method public final a()V
    .locals 1

    iget-boolean v0, p0, Ll/d;->b:Z

    if-eqz v0, :cond_0

    iget-object v0, p0, Ll/d;->c:Ll/f;

    iget-object v0, v0, Ll/f;->b:Ll/a;

    invoke-interface {v0}, Ll/a;->a()V

    :cond_0
    return-void
.end method
