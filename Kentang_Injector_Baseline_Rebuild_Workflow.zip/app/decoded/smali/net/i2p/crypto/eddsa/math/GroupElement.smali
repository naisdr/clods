.class public Lnet/i2p/crypto/eddsa/math/GroupElement;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ljava/io/Serializable;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lnet/i2p/crypto/eddsa/math/GroupElement$Representation;
    }
.end annotation


# instance fields
.field public final a:Lnet/i2p/crypto/eddsa/math/Curve;

.field public final b:Lnet/i2p/crypto/eddsa/math/GroupElement$Representation;

.field public final c:Lnet/i2p/crypto/eddsa/math/FieldElement;

.field public final d:Lnet/i2p/crypto/eddsa/math/FieldElement;

.field public final e:Lnet/i2p/crypto/eddsa/math/FieldElement;

.field public final f:Lnet/i2p/crypto/eddsa/math/FieldElement;

.field public final g:[[Lnet/i2p/crypto/eddsa/math/GroupElement;

.field public final h:[Lnet/i2p/crypto/eddsa/math/GroupElement;


# direct methods
.method public constructor <init>(Lnet/i2p/crypto/eddsa/math/Curve;Lnet/i2p/crypto/eddsa/math/GroupElement$Representation;Lnet/i2p/crypto/eddsa/math/FieldElement;Lnet/i2p/crypto/eddsa/math/FieldElement;Lnet/i2p/crypto/eddsa/math/FieldElement;Lnet/i2p/crypto/eddsa/math/FieldElement;)V
    .locals 8

    const/4 v7, 0x0

    move-object v0, p0

    move-object v1, p1

    move-object v2, p2

    move-object v3, p3

    move-object v4, p4

    move-object v5, p5

    move-object v6, p6

    invoke-direct/range {v0 .. v7}, Lnet/i2p/crypto/eddsa/math/GroupElement;-><init>(Lnet/i2p/crypto/eddsa/math/Curve;Lnet/i2p/crypto/eddsa/math/GroupElement$Representation;Lnet/i2p/crypto/eddsa/math/FieldElement;Lnet/i2p/crypto/eddsa/math/FieldElement;Lnet/i2p/crypto/eddsa/math/FieldElement;Lnet/i2p/crypto/eddsa/math/FieldElement;Z)V

    return-void
.end method

.method public constructor <init>(Lnet/i2p/crypto/eddsa/math/Curve;Lnet/i2p/crypto/eddsa/math/GroupElement$Representation;Lnet/i2p/crypto/eddsa/math/FieldElement;Lnet/i2p/crypto/eddsa/math/FieldElement;Lnet/i2p/crypto/eddsa/math/FieldElement;Lnet/i2p/crypto/eddsa/math/FieldElement;Z)V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lnet/i2p/crypto/eddsa/math/GroupElement;->a:Lnet/i2p/crypto/eddsa/math/Curve;

    iput-object p2, p0, Lnet/i2p/crypto/eddsa/math/GroupElement;->b:Lnet/i2p/crypto/eddsa/math/GroupElement$Representation;

    iput-object p3, p0, Lnet/i2p/crypto/eddsa/math/GroupElement;->c:Lnet/i2p/crypto/eddsa/math/FieldElement;

    iput-object p4, p0, Lnet/i2p/crypto/eddsa/math/GroupElement;->d:Lnet/i2p/crypto/eddsa/math/FieldElement;

    iput-object p5, p0, Lnet/i2p/crypto/eddsa/math/GroupElement;->e:Lnet/i2p/crypto/eddsa/math/FieldElement;

    iput-object p6, p0, Lnet/i2p/crypto/eddsa/math/GroupElement;->f:Lnet/i2p/crypto/eddsa/math/FieldElement;

    const/4 p1, 0x0

    iput-object p1, p0, Lnet/i2p/crypto/eddsa/math/GroupElement;->g:[[Lnet/i2p/crypto/eddsa/math/GroupElement;

    if-eqz p7, :cond_0

    invoke-virtual {p0}, Lnet/i2p/crypto/eddsa/math/GroupElement;->j()[Lnet/i2p/crypto/eddsa/math/GroupElement;

    move-result-object p1

    :cond_0
    iput-object p1, p0, Lnet/i2p/crypto/eddsa/math/GroupElement;->h:[Lnet/i2p/crypto/eddsa/math/GroupElement;

    return-void
.end method

.method public constructor <init>(Lnet/i2p/crypto/eddsa/math/Curve;[BZ)V
    .locals 9

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 1
    iget-object v0, p1, Lnet/i2p/crypto/eddsa/math/Curve;->a:Lnet/i2p/crypto/eddsa/math/Field;

    .line 2
    invoke-virtual {v0, p2}, Lnet/i2p/crypto/eddsa/math/Field;->a([B)Lnet/i2p/crypto/eddsa/math/FieldElement;

    move-result-object v0

    invoke-virtual {v0}, Lnet/i2p/crypto/eddsa/math/FieldElement;->j()Lnet/i2p/crypto/eddsa/math/FieldElement;

    move-result-object v1

    invoke-virtual {v1}, Lnet/i2p/crypto/eddsa/math/FieldElement;->m()Lnet/i2p/crypto/eddsa/math/FieldElement;

    move-result-object v2

    .line 3
    iget-object v3, p1, Lnet/i2p/crypto/eddsa/math/Curve;->b:Lnet/i2p/crypto/eddsa/math/FieldElement;

    .line 4
    invoke-virtual {v1, v3}, Lnet/i2p/crypto/eddsa/math/FieldElement;->g(Lnet/i2p/crypto/eddsa/math/FieldElement;)Lnet/i2p/crypto/eddsa/math/FieldElement;

    move-result-object v1

    invoke-virtual {v1}, Lnet/i2p/crypto/eddsa/math/FieldElement;->b()Lnet/i2p/crypto/eddsa/math/FieldElement;

    move-result-object v1

    invoke-virtual {v1}, Lnet/i2p/crypto/eddsa/math/FieldElement;->j()Lnet/i2p/crypto/eddsa/math/FieldElement;

    move-result-object v3

    invoke-virtual {v3, v1}, Lnet/i2p/crypto/eddsa/math/FieldElement;->g(Lnet/i2p/crypto/eddsa/math/FieldElement;)Lnet/i2p/crypto/eddsa/math/FieldElement;

    move-result-object v3

    invoke-virtual {v3}, Lnet/i2p/crypto/eddsa/math/FieldElement;->j()Lnet/i2p/crypto/eddsa/math/FieldElement;

    move-result-object v4

    invoke-virtual {v4, v1}, Lnet/i2p/crypto/eddsa/math/FieldElement;->g(Lnet/i2p/crypto/eddsa/math/FieldElement;)Lnet/i2p/crypto/eddsa/math/FieldElement;

    move-result-object v4

    invoke-virtual {v4, v2}, Lnet/i2p/crypto/eddsa/math/FieldElement;->g(Lnet/i2p/crypto/eddsa/math/FieldElement;)Lnet/i2p/crypto/eddsa/math/FieldElement;

    move-result-object v4

    invoke-virtual {v4}, Lnet/i2p/crypto/eddsa/math/FieldElement;->i()Lnet/i2p/crypto/eddsa/math/FieldElement;

    move-result-object v4

    invoke-virtual {v3, v2}, Lnet/i2p/crypto/eddsa/math/FieldElement;->g(Lnet/i2p/crypto/eddsa/math/FieldElement;)Lnet/i2p/crypto/eddsa/math/FieldElement;

    move-result-object v3

    invoke-virtual {v3, v4}, Lnet/i2p/crypto/eddsa/math/FieldElement;->g(Lnet/i2p/crypto/eddsa/math/FieldElement;)Lnet/i2p/crypto/eddsa/math/FieldElement;

    move-result-object v3

    invoke-virtual {v3}, Lnet/i2p/crypto/eddsa/math/FieldElement;->j()Lnet/i2p/crypto/eddsa/math/FieldElement;

    move-result-object v4

    invoke-virtual {v4, v1}, Lnet/i2p/crypto/eddsa/math/FieldElement;->g(Lnet/i2p/crypto/eddsa/math/FieldElement;)Lnet/i2p/crypto/eddsa/math/FieldElement;

    move-result-object v1

    invoke-virtual {v1, v2}, Lnet/i2p/crypto/eddsa/math/FieldElement;->l(Lnet/i2p/crypto/eddsa/math/FieldElement;)Lnet/i2p/crypto/eddsa/math/FieldElement;

    move-result-object v4

    invoke-virtual {v4}, Lnet/i2p/crypto/eddsa/math/FieldElement;->f()Z

    move-result v4

    if-eqz v4, :cond_1

    invoke-virtual {v1, v2}, Lnet/i2p/crypto/eddsa/math/FieldElement;->a(Lnet/i2p/crypto/eddsa/math/FieldElement;)Lnet/i2p/crypto/eddsa/math/FieldElement;

    move-result-object v1

    invoke-virtual {v1}, Lnet/i2p/crypto/eddsa/math/FieldElement;->f()Z

    move-result v1

    if-nez v1, :cond_0

    .line 5
    iget-object v1, p1, Lnet/i2p/crypto/eddsa/math/Curve;->d:Lnet/i2p/crypto/eddsa/math/FieldElement;

    .line 6
    invoke-virtual {v3, v1}, Lnet/i2p/crypto/eddsa/math/FieldElement;->g(Lnet/i2p/crypto/eddsa/math/FieldElement;)Lnet/i2p/crypto/eddsa/math/FieldElement;

    move-result-object v3

    goto :goto_0

    :cond_0
    new-instance p1, Ljava/lang/IllegalArgumentException;

    const-string p2, "not a valid GroupElement"

    invoke-direct {p1, p2}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw p1

    .line 7
    :cond_1
    :goto_0
    iget-object v1, v3, Lnet/i2p/crypto/eddsa/math/FieldElement;->a:Lnet/i2p/crypto/eddsa/math/Field;

    .line 8
    iget-object v1, v1, Lnet/i2p/crypto/eddsa/math/Field;->f:Lnet/i2p/crypto/eddsa/math/Encoding;

    .line 9
    invoke-virtual {v1, v3}, Lnet/i2p/crypto/eddsa/math/Encoding;->c(Lnet/i2p/crypto/eddsa/math/FieldElement;)Z

    move-result v1

    .line 10
    iget-object v2, p1, Lnet/i2p/crypto/eddsa/math/Curve;->a:Lnet/i2p/crypto/eddsa/math/Field;

    .line 11
    iget v2, v2, Lnet/i2p/crypto/eddsa/math/Field;->c:I

    add-int/lit8 v2, v2, -0x1

    shr-int/lit8 v4, v2, 0x3

    .line 12
    aget-byte p2, p2, v4

    and-int/lit8 v2, v2, 0x7

    shr-int/2addr p2, v2

    and-int/lit8 p2, p2, 0x1

    if-eq v1, p2, :cond_2

    .line 13
    invoke-virtual {v3}, Lnet/i2p/crypto/eddsa/math/FieldElement;->h()Lnet/i2p/crypto/eddsa/math/FieldElement;

    move-result-object v3

    :cond_2
    iput-object p1, p0, Lnet/i2p/crypto/eddsa/math/GroupElement;->a:Lnet/i2p/crypto/eddsa/math/Curve;

    sget-object p2, Lnet/i2p/crypto/eddsa/math/GroupElement$Representation;->b:Lnet/i2p/crypto/eddsa/math/GroupElement$Representation;

    iput-object p2, p0, Lnet/i2p/crypto/eddsa/math/GroupElement;->b:Lnet/i2p/crypto/eddsa/math/GroupElement$Representation;

    iput-object v3, p0, Lnet/i2p/crypto/eddsa/math/GroupElement;->c:Lnet/i2p/crypto/eddsa/math/FieldElement;

    iput-object v0, p0, Lnet/i2p/crypto/eddsa/math/GroupElement;->d:Lnet/i2p/crypto/eddsa/math/FieldElement;

    .line 14
    iget-object p1, p1, Lnet/i2p/crypto/eddsa/math/Curve;->a:Lnet/i2p/crypto/eddsa/math/Field;

    .line 15
    iget-object p1, p1, Lnet/i2p/crypto/eddsa/math/Field;->b:Lnet/i2p/crypto/eddsa/math/FieldElement;

    iput-object p1, p0, Lnet/i2p/crypto/eddsa/math/GroupElement;->e:Lnet/i2p/crypto/eddsa/math/FieldElement;

    invoke-virtual {v3, v0}, Lnet/i2p/crypto/eddsa/math/FieldElement;->g(Lnet/i2p/crypto/eddsa/math/FieldElement;)Lnet/i2p/crypto/eddsa/math/FieldElement;

    move-result-object p1

    iput-object p1, p0, Lnet/i2p/crypto/eddsa/math/GroupElement;->f:Lnet/i2p/crypto/eddsa/math/FieldElement;

    if-eqz p3, :cond_6

    const/4 p1, 0x2

    new-array p1, p1, [I

    .line 16
    fill-array-data p1, :array_0

    const-class p2, Lnet/i2p/crypto/eddsa/math/GroupElement;

    invoke-static {p2, p1}, Ljava/lang/reflect/Array;->newInstance(Ljava/lang/Class;[I)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, [[Lnet/i2p/crypto/eddsa/math/GroupElement;

    const/4 p2, 0x0

    move-object v0, p0

    const/4 p3, 0x0

    :goto_1
    const/16 v1, 0x20

    if-ge p3, v1, :cond_5

    move-object v2, v0

    const/4 v1, 0x0

    :goto_2
    const/16 v3, 0x8

    if-ge v1, v3, :cond_3

    iget-object v3, v2, Lnet/i2p/crypto/eddsa/math/GroupElement;->e:Lnet/i2p/crypto/eddsa/math/FieldElement;

    invoke-virtual {v3}, Lnet/i2p/crypto/eddsa/math/FieldElement;->e()Lnet/i2p/crypto/eddsa/math/FieldElement;

    move-result-object v3

    iget-object v4, v2, Lnet/i2p/crypto/eddsa/math/GroupElement;->c:Lnet/i2p/crypto/eddsa/math/FieldElement;

    invoke-virtual {v4, v3}, Lnet/i2p/crypto/eddsa/math/FieldElement;->g(Lnet/i2p/crypto/eddsa/math/FieldElement;)Lnet/i2p/crypto/eddsa/math/FieldElement;

    move-result-object v4

    iget-object v5, v2, Lnet/i2p/crypto/eddsa/math/GroupElement;->d:Lnet/i2p/crypto/eddsa/math/FieldElement;

    invoke-virtual {v5, v3}, Lnet/i2p/crypto/eddsa/math/FieldElement;->g(Lnet/i2p/crypto/eddsa/math/FieldElement;)Lnet/i2p/crypto/eddsa/math/FieldElement;

    move-result-object v3

    aget-object v5, p1, p3

    iget-object v6, p0, Lnet/i2p/crypto/eddsa/math/GroupElement;->a:Lnet/i2p/crypto/eddsa/math/Curve;

    invoke-virtual {v3, v4}, Lnet/i2p/crypto/eddsa/math/FieldElement;->a(Lnet/i2p/crypto/eddsa/math/FieldElement;)Lnet/i2p/crypto/eddsa/math/FieldElement;

    move-result-object v7

    invoke-virtual {v3, v4}, Lnet/i2p/crypto/eddsa/math/FieldElement;->l(Lnet/i2p/crypto/eddsa/math/FieldElement;)Lnet/i2p/crypto/eddsa/math/FieldElement;

    move-result-object v8

    invoke-virtual {v4, v3}, Lnet/i2p/crypto/eddsa/math/FieldElement;->g(Lnet/i2p/crypto/eddsa/math/FieldElement;)Lnet/i2p/crypto/eddsa/math/FieldElement;

    move-result-object v3

    iget-object v4, p0, Lnet/i2p/crypto/eddsa/math/GroupElement;->a:Lnet/i2p/crypto/eddsa/math/Curve;

    .line 17
    iget-object v4, v4, Lnet/i2p/crypto/eddsa/math/Curve;->c:Lnet/i2p/crypto/eddsa/math/FieldElement;

    .line 18
    invoke-virtual {v3, v4}, Lnet/i2p/crypto/eddsa/math/FieldElement;->g(Lnet/i2p/crypto/eddsa/math/FieldElement;)Lnet/i2p/crypto/eddsa/math/FieldElement;

    move-result-object v3

    invoke-static {v6, v7, v8, v3}, Lnet/i2p/crypto/eddsa/math/GroupElement;->i(Lnet/i2p/crypto/eddsa/math/Curve;Lnet/i2p/crypto/eddsa/math/FieldElement;Lnet/i2p/crypto/eddsa/math/FieldElement;Lnet/i2p/crypto/eddsa/math/FieldElement;)Lnet/i2p/crypto/eddsa/math/GroupElement;

    move-result-object v3

    aput-object v3, v5, v1

    invoke-virtual {v0}, Lnet/i2p/crypto/eddsa/math/GroupElement;->o()Lnet/i2p/crypto/eddsa/math/GroupElement;

    move-result-object v3

    invoke-virtual {v2, v3}, Lnet/i2p/crypto/eddsa/math/GroupElement;->a(Lnet/i2p/crypto/eddsa/math/GroupElement;)Lnet/i2p/crypto/eddsa/math/GroupElement;

    move-result-object v2

    invoke-virtual {v2}, Lnet/i2p/crypto/eddsa/math/GroupElement;->q()Lnet/i2p/crypto/eddsa/math/GroupElement;

    move-result-object v2

    add-int/lit8 v1, v1, 0x1

    goto :goto_2

    :cond_3
    const/4 v1, 0x0

    :goto_3
    if-ge v1, v3, :cond_4

    invoke-virtual {v0}, Lnet/i2p/crypto/eddsa/math/GroupElement;->o()Lnet/i2p/crypto/eddsa/math/GroupElement;

    move-result-object v2

    invoke-virtual {v0, v2}, Lnet/i2p/crypto/eddsa/math/GroupElement;->a(Lnet/i2p/crypto/eddsa/math/GroupElement;)Lnet/i2p/crypto/eddsa/math/GroupElement;

    move-result-object v0

    invoke-virtual {v0}, Lnet/i2p/crypto/eddsa/math/GroupElement;->q()Lnet/i2p/crypto/eddsa/math/GroupElement;

    move-result-object v0

    add-int/lit8 v1, v1, 0x1

    goto :goto_3

    :cond_4
    add-int/lit8 p3, p3, 0x1

    goto :goto_1

    .line 19
    :cond_5
    iput-object p1, p0, Lnet/i2p/crypto/eddsa/math/GroupElement;->g:[[Lnet/i2p/crypto/eddsa/math/GroupElement;

    invoke-virtual {p0}, Lnet/i2p/crypto/eddsa/math/GroupElement;->j()[Lnet/i2p/crypto/eddsa/math/GroupElement;

    move-result-object p1

    iput-object p1, p0, Lnet/i2p/crypto/eddsa/math/GroupElement;->h:[Lnet/i2p/crypto/eddsa/math/GroupElement;

    goto :goto_4

    :cond_6
    const/4 p1, 0x0

    iput-object p1, p0, Lnet/i2p/crypto/eddsa/math/GroupElement;->g:[[Lnet/i2p/crypto/eddsa/math/GroupElement;

    iput-object p1, p0, Lnet/i2p/crypto/eddsa/math/GroupElement;->h:[Lnet/i2p/crypto/eddsa/math/GroupElement;

    :goto_4
    return-void

    nop

    :array_0
    .array-data 4
        0x20
        0x8
    .end array-data
.end method

.method public static f(Lnet/i2p/crypto/eddsa/math/Curve;Lnet/i2p/crypto/eddsa/math/FieldElement;Lnet/i2p/crypto/eddsa/math/FieldElement;Lnet/i2p/crypto/eddsa/math/FieldElement;Lnet/i2p/crypto/eddsa/math/FieldElement;)Lnet/i2p/crypto/eddsa/math/GroupElement;
    .locals 8

    new-instance v7, Lnet/i2p/crypto/eddsa/math/GroupElement;

    sget-object v2, Lnet/i2p/crypto/eddsa/math/GroupElement$Representation;->d:Lnet/i2p/crypto/eddsa/math/GroupElement$Representation;

    move-object v0, v7

    move-object v1, p0

    move-object v3, p1

    move-object v4, p2

    move-object v5, p3

    move-object v6, p4

    invoke-direct/range {v0 .. v6}, Lnet/i2p/crypto/eddsa/math/GroupElement;-><init>(Lnet/i2p/crypto/eddsa/math/Curve;Lnet/i2p/crypto/eddsa/math/GroupElement$Representation;Lnet/i2p/crypto/eddsa/math/FieldElement;Lnet/i2p/crypto/eddsa/math/FieldElement;Lnet/i2p/crypto/eddsa/math/FieldElement;Lnet/i2p/crypto/eddsa/math/FieldElement;)V

    return-object v7
.end method

.method public static g(Lnet/i2p/crypto/eddsa/math/Curve;Lnet/i2p/crypto/eddsa/math/FieldElement;Lnet/i2p/crypto/eddsa/math/FieldElement;Lnet/i2p/crypto/eddsa/math/FieldElement;)Lnet/i2p/crypto/eddsa/math/GroupElement;
    .locals 8

    new-instance v7, Lnet/i2p/crypto/eddsa/math/GroupElement;

    sget-object v2, Lnet/i2p/crypto/eddsa/math/GroupElement$Representation;->a:Lnet/i2p/crypto/eddsa/math/GroupElement$Representation;

    const/4 v6, 0x0

    move-object v0, v7

    move-object v1, p0

    move-object v3, p1

    move-object v4, p2

    move-object v5, p3

    invoke-direct/range {v0 .. v6}, Lnet/i2p/crypto/eddsa/math/GroupElement;-><init>(Lnet/i2p/crypto/eddsa/math/Curve;Lnet/i2p/crypto/eddsa/math/GroupElement$Representation;Lnet/i2p/crypto/eddsa/math/FieldElement;Lnet/i2p/crypto/eddsa/math/FieldElement;Lnet/i2p/crypto/eddsa/math/FieldElement;Lnet/i2p/crypto/eddsa/math/FieldElement;)V

    return-object v7
.end method

.method public static h(Lnet/i2p/crypto/eddsa/math/Curve;Lnet/i2p/crypto/eddsa/math/FieldElement;Lnet/i2p/crypto/eddsa/math/FieldElement;Lnet/i2p/crypto/eddsa/math/FieldElement;Lnet/i2p/crypto/eddsa/math/FieldElement;Z)Lnet/i2p/crypto/eddsa/math/GroupElement;
    .locals 9

    new-instance v8, Lnet/i2p/crypto/eddsa/math/GroupElement;

    sget-object v2, Lnet/i2p/crypto/eddsa/math/GroupElement$Representation;->b:Lnet/i2p/crypto/eddsa/math/GroupElement$Representation;

    move-object v0, v8

    move-object v1, p0

    move-object v3, p1

    move-object v4, p2

    move-object v5, p3

    move-object v6, p4

    move v7, p5

    invoke-direct/range {v0 .. v7}, Lnet/i2p/crypto/eddsa/math/GroupElement;-><init>(Lnet/i2p/crypto/eddsa/math/Curve;Lnet/i2p/crypto/eddsa/math/GroupElement$Representation;Lnet/i2p/crypto/eddsa/math/FieldElement;Lnet/i2p/crypto/eddsa/math/FieldElement;Lnet/i2p/crypto/eddsa/math/FieldElement;Lnet/i2p/crypto/eddsa/math/FieldElement;Z)V

    return-object v8
.end method

.method public static i(Lnet/i2p/crypto/eddsa/math/Curve;Lnet/i2p/crypto/eddsa/math/FieldElement;Lnet/i2p/crypto/eddsa/math/FieldElement;Lnet/i2p/crypto/eddsa/math/FieldElement;)Lnet/i2p/crypto/eddsa/math/GroupElement;
    .locals 8

    new-instance v7, Lnet/i2p/crypto/eddsa/math/GroupElement;

    sget-object v2, Lnet/i2p/crypto/eddsa/math/GroupElement$Representation;->e:Lnet/i2p/crypto/eddsa/math/GroupElement$Representation;

    const/4 v6, 0x0

    move-object v0, v7

    move-object v1, p0

    move-object v3, p1

    move-object v4, p2

    move-object v5, p3

    invoke-direct/range {v0 .. v6}, Lnet/i2p/crypto/eddsa/math/GroupElement;-><init>(Lnet/i2p/crypto/eddsa/math/Curve;Lnet/i2p/crypto/eddsa/math/GroupElement$Representation;Lnet/i2p/crypto/eddsa/math/FieldElement;Lnet/i2p/crypto/eddsa/math/FieldElement;Lnet/i2p/crypto/eddsa/math/FieldElement;Lnet/i2p/crypto/eddsa/math/FieldElement;)V

    return-object v7
.end method

.method public static m([B)[B
    .locals 8

    const/16 v0, 0x100

    new-array v1, v0, [B

    const/4 v2, 0x0

    const/4 v3, 0x0

    :goto_0
    const/4 v4, 0x1

    if-ge v3, v0, :cond_0

    shr-int/lit8 v5, v3, 0x3

    aget-byte v5, p0, v5

    and-int/lit8 v6, v3, 0x7

    shr-int/2addr v5, v6

    and-int/2addr v4, v5

    int-to-byte v4, v4

    aput-byte v4, v1, v3

    add-int/lit8 v3, v3, 0x1

    goto :goto_0

    :cond_0
    const/4 p0, 0x0

    :goto_1
    if-ge p0, v0, :cond_5

    aget-byte v3, v1, p0

    if-eqz v3, :cond_4

    const/4 v3, 0x1

    :goto_2
    const/4 v5, 0x6

    if-gt v3, v5, :cond_4

    add-int v5, p0, v3

    if-ge v5, v0, :cond_4

    aget-byte v6, v1, v5

    if-eqz v6, :cond_3

    aget-byte v6, v1, p0

    aget-byte v7, v1, v5

    shl-int/2addr v7, v3

    add-int/2addr v6, v7

    const/16 v7, 0xf

    if-gt v6, v7, :cond_1

    aget-byte v6, v1, p0

    aget-byte v7, v1, v5

    shl-int/2addr v7, v3

    add-int/2addr v6, v7

    int-to-byte v6, v6

    aput-byte v6, v1, p0

    aput-byte v2, v1, v5

    goto :goto_4

    :cond_1
    aget-byte v6, v1, p0

    aget-byte v7, v1, v5

    shl-int/2addr v7, v3

    sub-int/2addr v6, v7

    const/16 v7, -0xf

    if-lt v6, v7, :cond_4

    aget-byte v6, v1, p0

    aget-byte v7, v1, v5

    shl-int/2addr v7, v3

    sub-int/2addr v6, v7

    int-to-byte v6, v6

    aput-byte v6, v1, p0

    :goto_3
    if-ge v5, v0, :cond_3

    aget-byte v6, v1, v5

    if-nez v6, :cond_2

    aput-byte v4, v1, v5

    goto :goto_4

    :cond_2
    aput-byte v2, v1, v5

    add-int/lit8 v5, v5, 0x1

    goto :goto_3

    :cond_3
    :goto_4
    add-int/lit8 v3, v3, 0x1

    goto :goto_2

    :cond_4
    add-int/lit8 p0, p0, 0x1

    goto :goto_1

    :cond_5
    return-object v1
.end method


# virtual methods
.method public final a(Lnet/i2p/crypto/eddsa/math/GroupElement;)Lnet/i2p/crypto/eddsa/math/GroupElement;
    .locals 5

    iget-object v0, p0, Lnet/i2p/crypto/eddsa/math/GroupElement;->b:Lnet/i2p/crypto/eddsa/math/GroupElement$Representation;

    sget-object v1, Lnet/i2p/crypto/eddsa/math/GroupElement$Representation;->b:Lnet/i2p/crypto/eddsa/math/GroupElement$Representation;

    if-ne v0, v1, :cond_1

    iget-object v0, p1, Lnet/i2p/crypto/eddsa/math/GroupElement;->b:Lnet/i2p/crypto/eddsa/math/GroupElement$Representation;

    sget-object v1, Lnet/i2p/crypto/eddsa/math/GroupElement$Representation;->f:Lnet/i2p/crypto/eddsa/math/GroupElement$Representation;

    if-ne v0, v1, :cond_0

    iget-object v0, p0, Lnet/i2p/crypto/eddsa/math/GroupElement;->d:Lnet/i2p/crypto/eddsa/math/FieldElement;

    iget-object v1, p0, Lnet/i2p/crypto/eddsa/math/GroupElement;->c:Lnet/i2p/crypto/eddsa/math/FieldElement;

    invoke-virtual {v0, v1}, Lnet/i2p/crypto/eddsa/math/FieldElement;->a(Lnet/i2p/crypto/eddsa/math/FieldElement;)Lnet/i2p/crypto/eddsa/math/FieldElement;

    move-result-object v0

    iget-object v1, p0, Lnet/i2p/crypto/eddsa/math/GroupElement;->d:Lnet/i2p/crypto/eddsa/math/FieldElement;

    iget-object v2, p0, Lnet/i2p/crypto/eddsa/math/GroupElement;->c:Lnet/i2p/crypto/eddsa/math/FieldElement;

    invoke-virtual {v1, v2}, Lnet/i2p/crypto/eddsa/math/FieldElement;->l(Lnet/i2p/crypto/eddsa/math/FieldElement;)Lnet/i2p/crypto/eddsa/math/FieldElement;

    move-result-object v1

    iget-object v2, p1, Lnet/i2p/crypto/eddsa/math/GroupElement;->c:Lnet/i2p/crypto/eddsa/math/FieldElement;

    invoke-virtual {v0, v2}, Lnet/i2p/crypto/eddsa/math/FieldElement;->g(Lnet/i2p/crypto/eddsa/math/FieldElement;)Lnet/i2p/crypto/eddsa/math/FieldElement;

    move-result-object v0

    iget-object v2, p1, Lnet/i2p/crypto/eddsa/math/GroupElement;->d:Lnet/i2p/crypto/eddsa/math/FieldElement;

    invoke-virtual {v1, v2}, Lnet/i2p/crypto/eddsa/math/FieldElement;->g(Lnet/i2p/crypto/eddsa/math/FieldElement;)Lnet/i2p/crypto/eddsa/math/FieldElement;

    move-result-object v1

    iget-object v2, p1, Lnet/i2p/crypto/eddsa/math/GroupElement;->f:Lnet/i2p/crypto/eddsa/math/FieldElement;

    iget-object v3, p0, Lnet/i2p/crypto/eddsa/math/GroupElement;->f:Lnet/i2p/crypto/eddsa/math/FieldElement;

    invoke-virtual {v2, v3}, Lnet/i2p/crypto/eddsa/math/FieldElement;->g(Lnet/i2p/crypto/eddsa/math/FieldElement;)Lnet/i2p/crypto/eddsa/math/FieldElement;

    move-result-object v2

    iget-object v3, p0, Lnet/i2p/crypto/eddsa/math/GroupElement;->e:Lnet/i2p/crypto/eddsa/math/FieldElement;

    iget-object p1, p1, Lnet/i2p/crypto/eddsa/math/GroupElement;->e:Lnet/i2p/crypto/eddsa/math/FieldElement;

    invoke-virtual {v3, p1}, Lnet/i2p/crypto/eddsa/math/FieldElement;->g(Lnet/i2p/crypto/eddsa/math/FieldElement;)Lnet/i2p/crypto/eddsa/math/FieldElement;

    move-result-object p1

    invoke-virtual {p1, p1}, Lnet/i2p/crypto/eddsa/math/FieldElement;->a(Lnet/i2p/crypto/eddsa/math/FieldElement;)Lnet/i2p/crypto/eddsa/math/FieldElement;

    move-result-object p1

    iget-object v3, p0, Lnet/i2p/crypto/eddsa/math/GroupElement;->a:Lnet/i2p/crypto/eddsa/math/Curve;

    invoke-virtual {v0, v1}, Lnet/i2p/crypto/eddsa/math/FieldElement;->l(Lnet/i2p/crypto/eddsa/math/FieldElement;)Lnet/i2p/crypto/eddsa/math/FieldElement;

    move-result-object v4

    invoke-virtual {v0, v1}, Lnet/i2p/crypto/eddsa/math/FieldElement;->a(Lnet/i2p/crypto/eddsa/math/FieldElement;)Lnet/i2p/crypto/eddsa/math/FieldElement;

    move-result-object v0

    invoke-virtual {p1, v2}, Lnet/i2p/crypto/eddsa/math/FieldElement;->a(Lnet/i2p/crypto/eddsa/math/FieldElement;)Lnet/i2p/crypto/eddsa/math/FieldElement;

    move-result-object v1

    invoke-virtual {p1, v2}, Lnet/i2p/crypto/eddsa/math/FieldElement;->l(Lnet/i2p/crypto/eddsa/math/FieldElement;)Lnet/i2p/crypto/eddsa/math/FieldElement;

    move-result-object p1

    invoke-static {v3, v4, v0, v1, p1}, Lnet/i2p/crypto/eddsa/math/GroupElement;->f(Lnet/i2p/crypto/eddsa/math/Curve;Lnet/i2p/crypto/eddsa/math/FieldElement;Lnet/i2p/crypto/eddsa/math/FieldElement;Lnet/i2p/crypto/eddsa/math/FieldElement;Lnet/i2p/crypto/eddsa/math/FieldElement;)Lnet/i2p/crypto/eddsa/math/GroupElement;

    move-result-object p1

    return-object p1

    :cond_0
    new-instance p1, Ljava/lang/IllegalArgumentException;

    invoke-direct {p1}, Ljava/lang/IllegalArgumentException;-><init>()V

    throw p1

    :cond_1
    new-instance p1, Ljava/lang/UnsupportedOperationException;

    invoke-direct {p1}, Ljava/lang/UnsupportedOperationException;-><init>()V

    throw p1
.end method

.method public final b(Lnet/i2p/crypto/eddsa/math/GroupElement;I)Lnet/i2p/crypto/eddsa/math/GroupElement;
    .locals 4

    iget-object v0, p0, Lnet/i2p/crypto/eddsa/math/GroupElement;->a:Lnet/i2p/crypto/eddsa/math/Curve;

    iget-object v1, p0, Lnet/i2p/crypto/eddsa/math/GroupElement;->c:Lnet/i2p/crypto/eddsa/math/FieldElement;

    iget-object v2, p1, Lnet/i2p/crypto/eddsa/math/GroupElement;->c:Lnet/i2p/crypto/eddsa/math/FieldElement;

    invoke-virtual {v1, v2, p2}, Lnet/i2p/crypto/eddsa/math/FieldElement;->c(Lnet/i2p/crypto/eddsa/math/FieldElement;I)Lnet/i2p/crypto/eddsa/math/FieldElement;

    move-result-object v1

    iget-object v2, p0, Lnet/i2p/crypto/eddsa/math/GroupElement;->d:Lnet/i2p/crypto/eddsa/math/FieldElement;

    iget-object v3, p1, Lnet/i2p/crypto/eddsa/math/GroupElement;->d:Lnet/i2p/crypto/eddsa/math/FieldElement;

    invoke-virtual {v2, v3, p2}, Lnet/i2p/crypto/eddsa/math/FieldElement;->c(Lnet/i2p/crypto/eddsa/math/FieldElement;I)Lnet/i2p/crypto/eddsa/math/FieldElement;

    move-result-object v2

    iget-object v3, p0, Lnet/i2p/crypto/eddsa/math/GroupElement;->e:Lnet/i2p/crypto/eddsa/math/FieldElement;

    iget-object p1, p1, Lnet/i2p/crypto/eddsa/math/GroupElement;->e:Lnet/i2p/crypto/eddsa/math/FieldElement;

    invoke-virtual {v3, p1, p2}, Lnet/i2p/crypto/eddsa/math/FieldElement;->c(Lnet/i2p/crypto/eddsa/math/FieldElement;I)Lnet/i2p/crypto/eddsa/math/FieldElement;

    move-result-object p1

    invoke-static {v0, v1, v2, p1}, Lnet/i2p/crypto/eddsa/math/GroupElement;->i(Lnet/i2p/crypto/eddsa/math/Curve;Lnet/i2p/crypto/eddsa/math/FieldElement;Lnet/i2p/crypto/eddsa/math/FieldElement;Lnet/i2p/crypto/eddsa/math/FieldElement;)Lnet/i2p/crypto/eddsa/math/GroupElement;

    move-result-object p1

    return-object p1
.end method

.method public final c()Lnet/i2p/crypto/eddsa/math/GroupElement;
    .locals 5

    iget-object v0, p0, Lnet/i2p/crypto/eddsa/math/GroupElement;->b:Lnet/i2p/crypto/eddsa/math/GroupElement$Representation;

    invoke-virtual {v0}, Ljava/lang/Enum;->ordinal()I

    move-result v0

    if-eqz v0, :cond_1

    const/4 v1, 0x1

    if-ne v0, v1, :cond_0

    goto :goto_0

    :cond_0
    new-instance v0, Ljava/lang/UnsupportedOperationException;

    invoke-direct {v0}, Ljava/lang/UnsupportedOperationException;-><init>()V

    throw v0

    :cond_1
    :goto_0
    iget-object v0, p0, Lnet/i2p/crypto/eddsa/math/GroupElement;->c:Lnet/i2p/crypto/eddsa/math/FieldElement;

    invoke-virtual {v0}, Lnet/i2p/crypto/eddsa/math/FieldElement;->j()Lnet/i2p/crypto/eddsa/math/FieldElement;

    move-result-object v0

    iget-object v1, p0, Lnet/i2p/crypto/eddsa/math/GroupElement;->d:Lnet/i2p/crypto/eddsa/math/FieldElement;

    invoke-virtual {v1}, Lnet/i2p/crypto/eddsa/math/FieldElement;->j()Lnet/i2p/crypto/eddsa/math/FieldElement;

    move-result-object v1

    iget-object v2, p0, Lnet/i2p/crypto/eddsa/math/GroupElement;->e:Lnet/i2p/crypto/eddsa/math/FieldElement;

    invoke-virtual {v2}, Lnet/i2p/crypto/eddsa/math/FieldElement;->k()Lnet/i2p/crypto/eddsa/math/FieldElement;

    move-result-object v2

    iget-object v3, p0, Lnet/i2p/crypto/eddsa/math/GroupElement;->c:Lnet/i2p/crypto/eddsa/math/FieldElement;

    iget-object v4, p0, Lnet/i2p/crypto/eddsa/math/GroupElement;->d:Lnet/i2p/crypto/eddsa/math/FieldElement;

    invoke-virtual {v3, v4}, Lnet/i2p/crypto/eddsa/math/FieldElement;->a(Lnet/i2p/crypto/eddsa/math/FieldElement;)Lnet/i2p/crypto/eddsa/math/FieldElement;

    move-result-object v3

    invoke-virtual {v3}, Lnet/i2p/crypto/eddsa/math/FieldElement;->j()Lnet/i2p/crypto/eddsa/math/FieldElement;

    move-result-object v3

    invoke-virtual {v1, v0}, Lnet/i2p/crypto/eddsa/math/FieldElement;->a(Lnet/i2p/crypto/eddsa/math/FieldElement;)Lnet/i2p/crypto/eddsa/math/FieldElement;

    move-result-object v4

    invoke-virtual {v1, v0}, Lnet/i2p/crypto/eddsa/math/FieldElement;->l(Lnet/i2p/crypto/eddsa/math/FieldElement;)Lnet/i2p/crypto/eddsa/math/FieldElement;

    move-result-object v0

    iget-object v1, p0, Lnet/i2p/crypto/eddsa/math/GroupElement;->a:Lnet/i2p/crypto/eddsa/math/Curve;

    invoke-virtual {v3, v4}, Lnet/i2p/crypto/eddsa/math/FieldElement;->l(Lnet/i2p/crypto/eddsa/math/FieldElement;)Lnet/i2p/crypto/eddsa/math/FieldElement;

    move-result-object v3

    invoke-virtual {v2, v0}, Lnet/i2p/crypto/eddsa/math/FieldElement;->l(Lnet/i2p/crypto/eddsa/math/FieldElement;)Lnet/i2p/crypto/eddsa/math/FieldElement;

    move-result-object v2

    invoke-static {v1, v3, v4, v0, v2}, Lnet/i2p/crypto/eddsa/math/GroupElement;->f(Lnet/i2p/crypto/eddsa/math/Curve;Lnet/i2p/crypto/eddsa/math/FieldElement;Lnet/i2p/crypto/eddsa/math/FieldElement;Lnet/i2p/crypto/eddsa/math/FieldElement;Lnet/i2p/crypto/eddsa/math/FieldElement;)Lnet/i2p/crypto/eddsa/math/GroupElement;

    move-result-object v0

    return-object v0
.end method

.method public final d(Lnet/i2p/crypto/eddsa/math/GroupElement;)Lnet/i2p/crypto/eddsa/math/GroupElement;
    .locals 5

    iget-object v0, p0, Lnet/i2p/crypto/eddsa/math/GroupElement;->b:Lnet/i2p/crypto/eddsa/math/GroupElement$Representation;

    sget-object v1, Lnet/i2p/crypto/eddsa/math/GroupElement$Representation;->b:Lnet/i2p/crypto/eddsa/math/GroupElement$Representation;

    if-ne v0, v1, :cond_1

    iget-object v0, p1, Lnet/i2p/crypto/eddsa/math/GroupElement;->b:Lnet/i2p/crypto/eddsa/math/GroupElement$Representation;

    sget-object v1, Lnet/i2p/crypto/eddsa/math/GroupElement$Representation;->e:Lnet/i2p/crypto/eddsa/math/GroupElement$Representation;

    if-ne v0, v1, :cond_0

    iget-object v0, p0, Lnet/i2p/crypto/eddsa/math/GroupElement;->d:Lnet/i2p/crypto/eddsa/math/FieldElement;

    iget-object v1, p0, Lnet/i2p/crypto/eddsa/math/GroupElement;->c:Lnet/i2p/crypto/eddsa/math/FieldElement;

    invoke-virtual {v0, v1}, Lnet/i2p/crypto/eddsa/math/FieldElement;->a(Lnet/i2p/crypto/eddsa/math/FieldElement;)Lnet/i2p/crypto/eddsa/math/FieldElement;

    move-result-object v0

    iget-object v1, p0, Lnet/i2p/crypto/eddsa/math/GroupElement;->d:Lnet/i2p/crypto/eddsa/math/FieldElement;

    iget-object v2, p0, Lnet/i2p/crypto/eddsa/math/GroupElement;->c:Lnet/i2p/crypto/eddsa/math/FieldElement;

    invoke-virtual {v1, v2}, Lnet/i2p/crypto/eddsa/math/FieldElement;->l(Lnet/i2p/crypto/eddsa/math/FieldElement;)Lnet/i2p/crypto/eddsa/math/FieldElement;

    move-result-object v1

    iget-object v2, p1, Lnet/i2p/crypto/eddsa/math/GroupElement;->c:Lnet/i2p/crypto/eddsa/math/FieldElement;

    invoke-virtual {v0, v2}, Lnet/i2p/crypto/eddsa/math/FieldElement;->g(Lnet/i2p/crypto/eddsa/math/FieldElement;)Lnet/i2p/crypto/eddsa/math/FieldElement;

    move-result-object v0

    iget-object v2, p1, Lnet/i2p/crypto/eddsa/math/GroupElement;->d:Lnet/i2p/crypto/eddsa/math/FieldElement;

    invoke-virtual {v1, v2}, Lnet/i2p/crypto/eddsa/math/FieldElement;->g(Lnet/i2p/crypto/eddsa/math/FieldElement;)Lnet/i2p/crypto/eddsa/math/FieldElement;

    move-result-object v1

    iget-object p1, p1, Lnet/i2p/crypto/eddsa/math/GroupElement;->e:Lnet/i2p/crypto/eddsa/math/FieldElement;

    iget-object v2, p0, Lnet/i2p/crypto/eddsa/math/GroupElement;->f:Lnet/i2p/crypto/eddsa/math/FieldElement;

    invoke-virtual {p1, v2}, Lnet/i2p/crypto/eddsa/math/FieldElement;->g(Lnet/i2p/crypto/eddsa/math/FieldElement;)Lnet/i2p/crypto/eddsa/math/FieldElement;

    move-result-object p1

    iget-object v2, p0, Lnet/i2p/crypto/eddsa/math/GroupElement;->e:Lnet/i2p/crypto/eddsa/math/FieldElement;

    invoke-virtual {v2, v2}, Lnet/i2p/crypto/eddsa/math/FieldElement;->a(Lnet/i2p/crypto/eddsa/math/FieldElement;)Lnet/i2p/crypto/eddsa/math/FieldElement;

    move-result-object v2

    iget-object v3, p0, Lnet/i2p/crypto/eddsa/math/GroupElement;->a:Lnet/i2p/crypto/eddsa/math/Curve;

    invoke-virtual {v0, v1}, Lnet/i2p/crypto/eddsa/math/FieldElement;->l(Lnet/i2p/crypto/eddsa/math/FieldElement;)Lnet/i2p/crypto/eddsa/math/FieldElement;

    move-result-object v4

    invoke-virtual {v0, v1}, Lnet/i2p/crypto/eddsa/math/FieldElement;->a(Lnet/i2p/crypto/eddsa/math/FieldElement;)Lnet/i2p/crypto/eddsa/math/FieldElement;

    move-result-object v0

    invoke-virtual {v2, p1}, Lnet/i2p/crypto/eddsa/math/FieldElement;->a(Lnet/i2p/crypto/eddsa/math/FieldElement;)Lnet/i2p/crypto/eddsa/math/FieldElement;

    move-result-object v1

    invoke-virtual {v2, p1}, Lnet/i2p/crypto/eddsa/math/FieldElement;->l(Lnet/i2p/crypto/eddsa/math/FieldElement;)Lnet/i2p/crypto/eddsa/math/FieldElement;

    move-result-object p1

    invoke-static {v3, v4, v0, v1, p1}, Lnet/i2p/crypto/eddsa/math/GroupElement;->f(Lnet/i2p/crypto/eddsa/math/Curve;Lnet/i2p/crypto/eddsa/math/FieldElement;Lnet/i2p/crypto/eddsa/math/FieldElement;Lnet/i2p/crypto/eddsa/math/FieldElement;Lnet/i2p/crypto/eddsa/math/FieldElement;)Lnet/i2p/crypto/eddsa/math/GroupElement;

    move-result-object p1

    return-object p1

    :cond_0
    new-instance p1, Ljava/lang/IllegalArgumentException;

    invoke-direct {p1}, Ljava/lang/IllegalArgumentException;-><init>()V

    throw p1

    :cond_1
    new-instance p1, Ljava/lang/UnsupportedOperationException;

    invoke-direct {p1}, Ljava/lang/UnsupportedOperationException;-><init>()V

    throw p1
.end method

.method public final e(Lnet/i2p/crypto/eddsa/math/GroupElement;)Lnet/i2p/crypto/eddsa/math/GroupElement;
    .locals 5

    iget-object v0, p0, Lnet/i2p/crypto/eddsa/math/GroupElement;->b:Lnet/i2p/crypto/eddsa/math/GroupElement$Representation;

    sget-object v1, Lnet/i2p/crypto/eddsa/math/GroupElement$Representation;->b:Lnet/i2p/crypto/eddsa/math/GroupElement$Representation;

    if-ne v0, v1, :cond_1

    iget-object v0, p1, Lnet/i2p/crypto/eddsa/math/GroupElement;->b:Lnet/i2p/crypto/eddsa/math/GroupElement$Representation;

    sget-object v1, Lnet/i2p/crypto/eddsa/math/GroupElement$Representation;->e:Lnet/i2p/crypto/eddsa/math/GroupElement$Representation;

    if-ne v0, v1, :cond_0

    iget-object v0, p0, Lnet/i2p/crypto/eddsa/math/GroupElement;->d:Lnet/i2p/crypto/eddsa/math/FieldElement;

    iget-object v1, p0, Lnet/i2p/crypto/eddsa/math/GroupElement;->c:Lnet/i2p/crypto/eddsa/math/FieldElement;

    invoke-virtual {v0, v1}, Lnet/i2p/crypto/eddsa/math/FieldElement;->a(Lnet/i2p/crypto/eddsa/math/FieldElement;)Lnet/i2p/crypto/eddsa/math/FieldElement;

    move-result-object v0

    iget-object v1, p0, Lnet/i2p/crypto/eddsa/math/GroupElement;->d:Lnet/i2p/crypto/eddsa/math/FieldElement;

    iget-object v2, p0, Lnet/i2p/crypto/eddsa/math/GroupElement;->c:Lnet/i2p/crypto/eddsa/math/FieldElement;

    invoke-virtual {v1, v2}, Lnet/i2p/crypto/eddsa/math/FieldElement;->l(Lnet/i2p/crypto/eddsa/math/FieldElement;)Lnet/i2p/crypto/eddsa/math/FieldElement;

    move-result-object v1

    iget-object v2, p1, Lnet/i2p/crypto/eddsa/math/GroupElement;->d:Lnet/i2p/crypto/eddsa/math/FieldElement;

    invoke-virtual {v0, v2}, Lnet/i2p/crypto/eddsa/math/FieldElement;->g(Lnet/i2p/crypto/eddsa/math/FieldElement;)Lnet/i2p/crypto/eddsa/math/FieldElement;

    move-result-object v0

    iget-object v2, p1, Lnet/i2p/crypto/eddsa/math/GroupElement;->c:Lnet/i2p/crypto/eddsa/math/FieldElement;

    invoke-virtual {v1, v2}, Lnet/i2p/crypto/eddsa/math/FieldElement;->g(Lnet/i2p/crypto/eddsa/math/FieldElement;)Lnet/i2p/crypto/eddsa/math/FieldElement;

    move-result-object v1

    iget-object p1, p1, Lnet/i2p/crypto/eddsa/math/GroupElement;->e:Lnet/i2p/crypto/eddsa/math/FieldElement;

    iget-object v2, p0, Lnet/i2p/crypto/eddsa/math/GroupElement;->f:Lnet/i2p/crypto/eddsa/math/FieldElement;

    invoke-virtual {p1, v2}, Lnet/i2p/crypto/eddsa/math/FieldElement;->g(Lnet/i2p/crypto/eddsa/math/FieldElement;)Lnet/i2p/crypto/eddsa/math/FieldElement;

    move-result-object p1

    iget-object v2, p0, Lnet/i2p/crypto/eddsa/math/GroupElement;->e:Lnet/i2p/crypto/eddsa/math/FieldElement;

    invoke-virtual {v2, v2}, Lnet/i2p/crypto/eddsa/math/FieldElement;->a(Lnet/i2p/crypto/eddsa/math/FieldElement;)Lnet/i2p/crypto/eddsa/math/FieldElement;

    move-result-object v2

    iget-object v3, p0, Lnet/i2p/crypto/eddsa/math/GroupElement;->a:Lnet/i2p/crypto/eddsa/math/Curve;

    invoke-virtual {v0, v1}, Lnet/i2p/crypto/eddsa/math/FieldElement;->l(Lnet/i2p/crypto/eddsa/math/FieldElement;)Lnet/i2p/crypto/eddsa/math/FieldElement;

    move-result-object v4

    invoke-virtual {v0, v1}, Lnet/i2p/crypto/eddsa/math/FieldElement;->a(Lnet/i2p/crypto/eddsa/math/FieldElement;)Lnet/i2p/crypto/eddsa/math/FieldElement;

    move-result-object v0

    invoke-virtual {v2, p1}, Lnet/i2p/crypto/eddsa/math/FieldElement;->l(Lnet/i2p/crypto/eddsa/math/FieldElement;)Lnet/i2p/crypto/eddsa/math/FieldElement;

    move-result-object v1

    invoke-virtual {v2, p1}, Lnet/i2p/crypto/eddsa/math/FieldElement;->a(Lnet/i2p/crypto/eddsa/math/FieldElement;)Lnet/i2p/crypto/eddsa/math/FieldElement;

    move-result-object p1

    invoke-static {v3, v4, v0, v1, p1}, Lnet/i2p/crypto/eddsa/math/GroupElement;->f(Lnet/i2p/crypto/eddsa/math/Curve;Lnet/i2p/crypto/eddsa/math/FieldElement;Lnet/i2p/crypto/eddsa/math/FieldElement;Lnet/i2p/crypto/eddsa/math/FieldElement;Lnet/i2p/crypto/eddsa/math/FieldElement;)Lnet/i2p/crypto/eddsa/math/GroupElement;

    move-result-object p1

    return-object p1

    :cond_0
    new-instance p1, Ljava/lang/IllegalArgumentException;

    invoke-direct {p1}, Ljava/lang/IllegalArgumentException;-><init>()V

    throw p1

    :cond_1
    new-instance p1, Ljava/lang/UnsupportedOperationException;

    invoke-direct {p1}, Ljava/lang/UnsupportedOperationException;-><init>()V

    throw p1
.end method

.method public final equals(Ljava/lang/Object;)Z
    .locals 8

    const/4 v0, 0x1

    if-ne p1, p0, :cond_0

    return v0

    :cond_0
    instance-of v1, p1, Lnet/i2p/crypto/eddsa/math/GroupElement;

    const/4 v2, 0x0

    if-nez v1, :cond_1

    return v2

    :cond_1
    check-cast p1, Lnet/i2p/crypto/eddsa/math/GroupElement;

    iget-object v1, p0, Lnet/i2p/crypto/eddsa/math/GroupElement;->b:Lnet/i2p/crypto/eddsa/math/GroupElement$Representation;

    iget-object v3, p1, Lnet/i2p/crypto/eddsa/math/GroupElement;->b:Lnet/i2p/crypto/eddsa/math/GroupElement$Representation;

    invoke-virtual {v1, v3}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_2

    :try_start_0
    iget-object v1, p0, Lnet/i2p/crypto/eddsa/math/GroupElement;->b:Lnet/i2p/crypto/eddsa/math/GroupElement$Representation;

    invoke-virtual {p1, v1}, Lnet/i2p/crypto/eddsa/math/GroupElement;->r(Lnet/i2p/crypto/eddsa/math/GroupElement$Representation;)Lnet/i2p/crypto/eddsa/math/GroupElement;

    move-result-object p1
    :try_end_0
    .catch Ljava/lang/RuntimeException; {:try_start_0 .. :try_end_0} :catch_0

    goto :goto_0

    :catch_0
    return v2

    :cond_2
    :goto_0
    iget-object v1, p0, Lnet/i2p/crypto/eddsa/math/GroupElement;->b:Lnet/i2p/crypto/eddsa/math/GroupElement$Representation;

    invoke-virtual {v1}, Ljava/lang/Enum;->ordinal()I

    move-result v1

    if-eqz v1, :cond_a

    if-eq v1, v0, :cond_a

    const/4 v3, 0x3

    if-eq v1, v3, :cond_9

    const/4 v3, 0x4

    if-eq v1, v3, :cond_7

    const/4 v3, 0x5

    if-eq v1, v3, :cond_3

    return v2

    :cond_3
    iget-object v1, p0, Lnet/i2p/crypto/eddsa/math/GroupElement;->e:Lnet/i2p/crypto/eddsa/math/FieldElement;

    iget-object v3, p1, Lnet/i2p/crypto/eddsa/math/GroupElement;->e:Lnet/i2p/crypto/eddsa/math/FieldElement;

    invoke-virtual {v1, v3}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_5

    iget-object v1, p0, Lnet/i2p/crypto/eddsa/math/GroupElement;->c:Lnet/i2p/crypto/eddsa/math/FieldElement;

    iget-object v3, p1, Lnet/i2p/crypto/eddsa/math/GroupElement;->c:Lnet/i2p/crypto/eddsa/math/FieldElement;

    invoke-virtual {v1, v3}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_4

    iget-object v1, p0, Lnet/i2p/crypto/eddsa/math/GroupElement;->d:Lnet/i2p/crypto/eddsa/math/FieldElement;

    iget-object v3, p1, Lnet/i2p/crypto/eddsa/math/GroupElement;->d:Lnet/i2p/crypto/eddsa/math/FieldElement;

    invoke-virtual {v1, v3}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_4

    iget-object v1, p0, Lnet/i2p/crypto/eddsa/math/GroupElement;->f:Lnet/i2p/crypto/eddsa/math/FieldElement;

    iget-object p1, p1, Lnet/i2p/crypto/eddsa/math/GroupElement;->f:Lnet/i2p/crypto/eddsa/math/FieldElement;

    invoke-virtual {v1, p1}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    move-result p1

    if-eqz p1, :cond_4

    goto :goto_1

    :cond_4
    const/4 v0, 0x0

    :goto_1
    return v0

    :cond_5
    iget-object v1, p0, Lnet/i2p/crypto/eddsa/math/GroupElement;->c:Lnet/i2p/crypto/eddsa/math/FieldElement;

    iget-object v3, p1, Lnet/i2p/crypto/eddsa/math/GroupElement;->e:Lnet/i2p/crypto/eddsa/math/FieldElement;

    invoke-virtual {v1, v3}, Lnet/i2p/crypto/eddsa/math/FieldElement;->g(Lnet/i2p/crypto/eddsa/math/FieldElement;)Lnet/i2p/crypto/eddsa/math/FieldElement;

    move-result-object v1

    iget-object v3, p0, Lnet/i2p/crypto/eddsa/math/GroupElement;->d:Lnet/i2p/crypto/eddsa/math/FieldElement;

    iget-object v4, p1, Lnet/i2p/crypto/eddsa/math/GroupElement;->e:Lnet/i2p/crypto/eddsa/math/FieldElement;

    invoke-virtual {v3, v4}, Lnet/i2p/crypto/eddsa/math/FieldElement;->g(Lnet/i2p/crypto/eddsa/math/FieldElement;)Lnet/i2p/crypto/eddsa/math/FieldElement;

    move-result-object v3

    iget-object v4, p0, Lnet/i2p/crypto/eddsa/math/GroupElement;->f:Lnet/i2p/crypto/eddsa/math/FieldElement;

    iget-object v5, p1, Lnet/i2p/crypto/eddsa/math/GroupElement;->e:Lnet/i2p/crypto/eddsa/math/FieldElement;

    invoke-virtual {v4, v5}, Lnet/i2p/crypto/eddsa/math/FieldElement;->g(Lnet/i2p/crypto/eddsa/math/FieldElement;)Lnet/i2p/crypto/eddsa/math/FieldElement;

    move-result-object v4

    iget-object v5, p1, Lnet/i2p/crypto/eddsa/math/GroupElement;->c:Lnet/i2p/crypto/eddsa/math/FieldElement;

    iget-object v6, p0, Lnet/i2p/crypto/eddsa/math/GroupElement;->e:Lnet/i2p/crypto/eddsa/math/FieldElement;

    invoke-virtual {v5, v6}, Lnet/i2p/crypto/eddsa/math/FieldElement;->g(Lnet/i2p/crypto/eddsa/math/FieldElement;)Lnet/i2p/crypto/eddsa/math/FieldElement;

    move-result-object v5

    iget-object v6, p1, Lnet/i2p/crypto/eddsa/math/GroupElement;->d:Lnet/i2p/crypto/eddsa/math/FieldElement;

    iget-object v7, p0, Lnet/i2p/crypto/eddsa/math/GroupElement;->e:Lnet/i2p/crypto/eddsa/math/FieldElement;

    invoke-virtual {v6, v7}, Lnet/i2p/crypto/eddsa/math/FieldElement;->g(Lnet/i2p/crypto/eddsa/math/FieldElement;)Lnet/i2p/crypto/eddsa/math/FieldElement;

    move-result-object v6

    iget-object p1, p1, Lnet/i2p/crypto/eddsa/math/GroupElement;->f:Lnet/i2p/crypto/eddsa/math/FieldElement;

    iget-object v7, p0, Lnet/i2p/crypto/eddsa/math/GroupElement;->e:Lnet/i2p/crypto/eddsa/math/FieldElement;

    invoke-virtual {p1, v7}, Lnet/i2p/crypto/eddsa/math/FieldElement;->g(Lnet/i2p/crypto/eddsa/math/FieldElement;)Lnet/i2p/crypto/eddsa/math/FieldElement;

    move-result-object p1

    invoke-virtual {v1, v5}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_6

    invoke-virtual {v3, v6}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_6

    invoke-virtual {v4, p1}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    move-result p1

    if-eqz p1, :cond_6

    goto :goto_2

    :cond_6
    const/4 v0, 0x0

    :goto_2
    return v0

    :cond_7
    iget-object v1, p0, Lnet/i2p/crypto/eddsa/math/GroupElement;->c:Lnet/i2p/crypto/eddsa/math/FieldElement;

    iget-object v3, p1, Lnet/i2p/crypto/eddsa/math/GroupElement;->c:Lnet/i2p/crypto/eddsa/math/FieldElement;

    invoke-virtual {v1, v3}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_8

    iget-object v1, p0, Lnet/i2p/crypto/eddsa/math/GroupElement;->d:Lnet/i2p/crypto/eddsa/math/FieldElement;

    iget-object v3, p1, Lnet/i2p/crypto/eddsa/math/GroupElement;->d:Lnet/i2p/crypto/eddsa/math/FieldElement;

    invoke-virtual {v1, v3}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_8

    iget-object v1, p0, Lnet/i2p/crypto/eddsa/math/GroupElement;->e:Lnet/i2p/crypto/eddsa/math/FieldElement;

    iget-object p1, p1, Lnet/i2p/crypto/eddsa/math/GroupElement;->e:Lnet/i2p/crypto/eddsa/math/FieldElement;

    invoke-virtual {v1, p1}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    move-result p1

    if-eqz p1, :cond_8

    goto :goto_3

    :cond_8
    const/4 v0, 0x0

    :goto_3
    return v0

    :cond_9
    invoke-virtual {p0}, Lnet/i2p/crypto/eddsa/math/GroupElement;->p()Lnet/i2p/crypto/eddsa/math/GroupElement;

    move-result-object v0

    invoke-virtual {v0, p1}, Lnet/i2p/crypto/eddsa/math/GroupElement;->equals(Ljava/lang/Object;)Z

    move-result p1

    return p1

    :cond_a
    iget-object v1, p0, Lnet/i2p/crypto/eddsa/math/GroupElement;->e:Lnet/i2p/crypto/eddsa/math/FieldElement;

    iget-object v3, p1, Lnet/i2p/crypto/eddsa/math/GroupElement;->e:Lnet/i2p/crypto/eddsa/math/FieldElement;

    invoke-virtual {v1, v3}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_c

    iget-object v1, p0, Lnet/i2p/crypto/eddsa/math/GroupElement;->c:Lnet/i2p/crypto/eddsa/math/FieldElement;

    iget-object v3, p1, Lnet/i2p/crypto/eddsa/math/GroupElement;->c:Lnet/i2p/crypto/eddsa/math/FieldElement;

    invoke-virtual {v1, v3}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_b

    iget-object v1, p0, Lnet/i2p/crypto/eddsa/math/GroupElement;->d:Lnet/i2p/crypto/eddsa/math/FieldElement;

    iget-object p1, p1, Lnet/i2p/crypto/eddsa/math/GroupElement;->d:Lnet/i2p/crypto/eddsa/math/FieldElement;

    invoke-virtual {v1, p1}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    move-result p1

    if-eqz p1, :cond_b

    goto :goto_4

    :cond_b
    const/4 v0, 0x0

    :goto_4
    return v0

    :cond_c
    iget-object v1, p0, Lnet/i2p/crypto/eddsa/math/GroupElement;->c:Lnet/i2p/crypto/eddsa/math/FieldElement;

    iget-object v3, p1, Lnet/i2p/crypto/eddsa/math/GroupElement;->e:Lnet/i2p/crypto/eddsa/math/FieldElement;

    invoke-virtual {v1, v3}, Lnet/i2p/crypto/eddsa/math/FieldElement;->g(Lnet/i2p/crypto/eddsa/math/FieldElement;)Lnet/i2p/crypto/eddsa/math/FieldElement;

    move-result-object v1

    iget-object v3, p0, Lnet/i2p/crypto/eddsa/math/GroupElement;->d:Lnet/i2p/crypto/eddsa/math/FieldElement;

    iget-object v4, p1, Lnet/i2p/crypto/eddsa/math/GroupElement;->e:Lnet/i2p/crypto/eddsa/math/FieldElement;

    invoke-virtual {v3, v4}, Lnet/i2p/crypto/eddsa/math/FieldElement;->g(Lnet/i2p/crypto/eddsa/math/FieldElement;)Lnet/i2p/crypto/eddsa/math/FieldElement;

    move-result-object v3

    iget-object v4, p1, Lnet/i2p/crypto/eddsa/math/GroupElement;->c:Lnet/i2p/crypto/eddsa/math/FieldElement;

    iget-object v5, p0, Lnet/i2p/crypto/eddsa/math/GroupElement;->e:Lnet/i2p/crypto/eddsa/math/FieldElement;

    invoke-virtual {v4, v5}, Lnet/i2p/crypto/eddsa/math/FieldElement;->g(Lnet/i2p/crypto/eddsa/math/FieldElement;)Lnet/i2p/crypto/eddsa/math/FieldElement;

    move-result-object v4

    iget-object p1, p1, Lnet/i2p/crypto/eddsa/math/GroupElement;->d:Lnet/i2p/crypto/eddsa/math/FieldElement;

    iget-object v5, p0, Lnet/i2p/crypto/eddsa/math/GroupElement;->e:Lnet/i2p/crypto/eddsa/math/FieldElement;

    invoke-virtual {p1, v5}, Lnet/i2p/crypto/eddsa/math/FieldElement;->g(Lnet/i2p/crypto/eddsa/math/FieldElement;)Lnet/i2p/crypto/eddsa/math/FieldElement;

    move-result-object p1

    invoke-virtual {v1, v4}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_d

    invoke-virtual {v3, p1}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    move-result p1

    if-eqz p1, :cond_d

    goto :goto_5

    :cond_d
    const/4 v0, 0x0

    :goto_5
    return v0
.end method

.method public final hashCode()I
    .locals 1

    invoke-virtual {p0}, Lnet/i2p/crypto/eddsa/math/GroupElement;->n()[B

    move-result-object v0

    invoke-static {v0}, Ljava/util/Arrays;->hashCode([B)I

    move-result v0

    return v0
.end method

.method public final j()[Lnet/i2p/crypto/eddsa/math/GroupElement;
    .locals 9

    const/16 v0, 0x8

    new-array v1, v0, [Lnet/i2p/crypto/eddsa/math/GroupElement;

    const/4 v2, 0x0

    move-object v3, p0

    :goto_0
    if-ge v2, v0, :cond_0

    iget-object v4, v3, Lnet/i2p/crypto/eddsa/math/GroupElement;->e:Lnet/i2p/crypto/eddsa/math/FieldElement;

    invoke-virtual {v4}, Lnet/i2p/crypto/eddsa/math/FieldElement;->e()Lnet/i2p/crypto/eddsa/math/FieldElement;

    move-result-object v4

    iget-object v5, v3, Lnet/i2p/crypto/eddsa/math/GroupElement;->c:Lnet/i2p/crypto/eddsa/math/FieldElement;

    invoke-virtual {v5, v4}, Lnet/i2p/crypto/eddsa/math/FieldElement;->g(Lnet/i2p/crypto/eddsa/math/FieldElement;)Lnet/i2p/crypto/eddsa/math/FieldElement;

    move-result-object v5

    iget-object v6, v3, Lnet/i2p/crypto/eddsa/math/GroupElement;->d:Lnet/i2p/crypto/eddsa/math/FieldElement;

    invoke-virtual {v6, v4}, Lnet/i2p/crypto/eddsa/math/FieldElement;->g(Lnet/i2p/crypto/eddsa/math/FieldElement;)Lnet/i2p/crypto/eddsa/math/FieldElement;

    move-result-object v4

    iget-object v6, p0, Lnet/i2p/crypto/eddsa/math/GroupElement;->a:Lnet/i2p/crypto/eddsa/math/Curve;

    invoke-virtual {v4, v5}, Lnet/i2p/crypto/eddsa/math/FieldElement;->a(Lnet/i2p/crypto/eddsa/math/FieldElement;)Lnet/i2p/crypto/eddsa/math/FieldElement;

    move-result-object v7

    invoke-virtual {v4, v5}, Lnet/i2p/crypto/eddsa/math/FieldElement;->l(Lnet/i2p/crypto/eddsa/math/FieldElement;)Lnet/i2p/crypto/eddsa/math/FieldElement;

    move-result-object v8

    invoke-virtual {v5, v4}, Lnet/i2p/crypto/eddsa/math/FieldElement;->g(Lnet/i2p/crypto/eddsa/math/FieldElement;)Lnet/i2p/crypto/eddsa/math/FieldElement;

    move-result-object v4

    iget-object v5, p0, Lnet/i2p/crypto/eddsa/math/GroupElement;->a:Lnet/i2p/crypto/eddsa/math/Curve;

    .line 1
    iget-object v5, v5, Lnet/i2p/crypto/eddsa/math/Curve;->c:Lnet/i2p/crypto/eddsa/math/FieldElement;

    .line 2
    invoke-virtual {v4, v5}, Lnet/i2p/crypto/eddsa/math/FieldElement;->g(Lnet/i2p/crypto/eddsa/math/FieldElement;)Lnet/i2p/crypto/eddsa/math/FieldElement;

    move-result-object v4

    invoke-static {v6, v7, v8, v4}, Lnet/i2p/crypto/eddsa/math/GroupElement;->i(Lnet/i2p/crypto/eddsa/math/Curve;Lnet/i2p/crypto/eddsa/math/FieldElement;Lnet/i2p/crypto/eddsa/math/FieldElement;Lnet/i2p/crypto/eddsa/math/FieldElement;)Lnet/i2p/crypto/eddsa/math/GroupElement;

    move-result-object v4

    aput-object v4, v1, v2

    invoke-virtual {v3}, Lnet/i2p/crypto/eddsa/math/GroupElement;->o()Lnet/i2p/crypto/eddsa/math/GroupElement;

    move-result-object v3

    invoke-virtual {p0, v3}, Lnet/i2p/crypto/eddsa/math/GroupElement;->a(Lnet/i2p/crypto/eddsa/math/GroupElement;)Lnet/i2p/crypto/eddsa/math/GroupElement;

    move-result-object v3

    invoke-virtual {v3}, Lnet/i2p/crypto/eddsa/math/GroupElement;->q()Lnet/i2p/crypto/eddsa/math/GroupElement;

    move-result-object v3

    invoke-virtual {v3}, Lnet/i2p/crypto/eddsa/math/GroupElement;->o()Lnet/i2p/crypto/eddsa/math/GroupElement;

    move-result-object v3

    invoke-virtual {p0, v3}, Lnet/i2p/crypto/eddsa/math/GroupElement;->a(Lnet/i2p/crypto/eddsa/math/GroupElement;)Lnet/i2p/crypto/eddsa/math/GroupElement;

    move-result-object v3

    invoke-virtual {v3}, Lnet/i2p/crypto/eddsa/math/GroupElement;->q()Lnet/i2p/crypto/eddsa/math/GroupElement;

    move-result-object v3

    add-int/lit8 v2, v2, 0x1

    goto :goto_0

    :cond_0
    return-object v1
.end method

.method public final k([B)Lnet/i2p/crypto/eddsa/math/GroupElement;
    .locals 8

    const/16 v0, 0x40

    new-array v1, v0, [B

    const/4 v2, 0x0

    const/4 v3, 0x0

    :goto_0
    const/16 v4, 0x20

    const/4 v5, 0x1

    if-ge v3, v4, :cond_0

    mul-int/lit8 v4, v3, 0x2

    add-int/lit8 v6, v4, 0x0

    .line 1
    aget-byte v7, p1, v3

    and-int/lit8 v7, v7, 0xf

    int-to-byte v7, v7

    aput-byte v7, v1, v6

    add-int/2addr v4, v5

    aget-byte v5, p1, v3

    shr-int/lit8 v5, v5, 0x4

    and-int/lit8 v5, v5, 0xf

    int-to-byte v5, v5

    aput-byte v5, v1, v4

    add-int/lit8 v3, v3, 0x1

    goto :goto_0

    :cond_0
    const/4 p1, 0x0

    const/4 v3, 0x0

    :goto_1
    const/16 v4, 0x3f

    if-ge p1, v4, :cond_1

    aget-byte v4, v1, p1

    add-int/2addr v4, v3

    int-to-byte v3, v4

    aput-byte v3, v1, p1

    aget-byte v3, v1, p1

    add-int/lit8 v3, v3, 0x8

    shr-int/lit8 v3, v3, 0x4

    aget-byte v4, v1, p1

    shl-int/lit8 v6, v3, 0x4

    sub-int/2addr v4, v6

    int-to-byte v4, v4

    aput-byte v4, v1, p1

    add-int/lit8 p1, p1, 0x1

    goto :goto_1

    :cond_1
    aget-byte p1, v1, v4

    add-int/2addr p1, v3

    int-to-byte p1, p1

    aput-byte p1, v1, v4

    .line 2
    iget-object p1, p0, Lnet/i2p/crypto/eddsa/math/GroupElement;->a:Lnet/i2p/crypto/eddsa/math/Curve;

    sget-object v3, Lnet/i2p/crypto/eddsa/math/GroupElement$Representation;->b:Lnet/i2p/crypto/eddsa/math/GroupElement$Representation;

    invoke-virtual {p1, v3}, Lnet/i2p/crypto/eddsa/math/Curve;->a(Lnet/i2p/crypto/eddsa/math/GroupElement$Representation;)Lnet/i2p/crypto/eddsa/math/GroupElement;

    move-result-object p1

    :goto_2
    if-ge v5, v0, :cond_2

    div-int/lit8 v3, v5, 0x2

    aget-byte v4, v1, v5

    invoke-virtual {p0, v3, v4}, Lnet/i2p/crypto/eddsa/math/GroupElement;->l(II)Lnet/i2p/crypto/eddsa/math/GroupElement;

    move-result-object v3

    invoke-virtual {p1, v3}, Lnet/i2p/crypto/eddsa/math/GroupElement;->d(Lnet/i2p/crypto/eddsa/math/GroupElement;)Lnet/i2p/crypto/eddsa/math/GroupElement;

    move-result-object p1

    invoke-virtual {p1}, Lnet/i2p/crypto/eddsa/math/GroupElement;->q()Lnet/i2p/crypto/eddsa/math/GroupElement;

    move-result-object p1

    add-int/lit8 v5, v5, 0x2

    goto :goto_2

    :cond_2
    invoke-virtual {p1}, Lnet/i2p/crypto/eddsa/math/GroupElement;->c()Lnet/i2p/crypto/eddsa/math/GroupElement;

    move-result-object p1

    invoke-virtual {p1}, Lnet/i2p/crypto/eddsa/math/GroupElement;->p()Lnet/i2p/crypto/eddsa/math/GroupElement;

    move-result-object p1

    invoke-virtual {p1}, Lnet/i2p/crypto/eddsa/math/GroupElement;->c()Lnet/i2p/crypto/eddsa/math/GroupElement;

    move-result-object p1

    invoke-virtual {p1}, Lnet/i2p/crypto/eddsa/math/GroupElement;->p()Lnet/i2p/crypto/eddsa/math/GroupElement;

    move-result-object p1

    invoke-virtual {p1}, Lnet/i2p/crypto/eddsa/math/GroupElement;->c()Lnet/i2p/crypto/eddsa/math/GroupElement;

    move-result-object p1

    invoke-virtual {p1}, Lnet/i2p/crypto/eddsa/math/GroupElement;->p()Lnet/i2p/crypto/eddsa/math/GroupElement;

    move-result-object p1

    invoke-virtual {p1}, Lnet/i2p/crypto/eddsa/math/GroupElement;->c()Lnet/i2p/crypto/eddsa/math/GroupElement;

    move-result-object p1

    invoke-virtual {p1}, Lnet/i2p/crypto/eddsa/math/GroupElement;->q()Lnet/i2p/crypto/eddsa/math/GroupElement;

    move-result-object p1

    :goto_3
    if-ge v2, v0, :cond_3

    div-int/lit8 v3, v2, 0x2

    aget-byte v4, v1, v2

    invoke-virtual {p0, v3, v4}, Lnet/i2p/crypto/eddsa/math/GroupElement;->l(II)Lnet/i2p/crypto/eddsa/math/GroupElement;

    move-result-object v3

    invoke-virtual {p1, v3}, Lnet/i2p/crypto/eddsa/math/GroupElement;->d(Lnet/i2p/crypto/eddsa/math/GroupElement;)Lnet/i2p/crypto/eddsa/math/GroupElement;

    move-result-object p1

    invoke-virtual {p1}, Lnet/i2p/crypto/eddsa/math/GroupElement;->q()Lnet/i2p/crypto/eddsa/math/GroupElement;

    move-result-object p1

    add-int/lit8 v2, v2, 0x2

    goto :goto_3

    :cond_3
    return-object p1
.end method

.method public final l(II)Lnet/i2p/crypto/eddsa/math/GroupElement;
    .locals 5

    shr-int/lit8 v0, p2, 0x8

    const/4 v1, 0x1

    and-int/2addr v0, v1

    neg-int v2, v0

    and-int/2addr v2, p2

    shl-int/2addr v2, v1

    sub-int/2addr p2, v2

    iget-object v2, p0, Lnet/i2p/crypto/eddsa/math/GroupElement;->a:Lnet/i2p/crypto/eddsa/math/Curve;

    sget-object v3, Lnet/i2p/crypto/eddsa/math/GroupElement$Representation;->e:Lnet/i2p/crypto/eddsa/math/GroupElement$Representation;

    invoke-virtual {v2, v3}, Lnet/i2p/crypto/eddsa/math/Curve;->a(Lnet/i2p/crypto/eddsa/math/GroupElement$Representation;)Lnet/i2p/crypto/eddsa/math/GroupElement;

    move-result-object v2

    iget-object v3, p0, Lnet/i2p/crypto/eddsa/math/GroupElement;->g:[[Lnet/i2p/crypto/eddsa/math/GroupElement;

    aget-object v3, v3, p1

    const/4 v4, 0x0

    aget-object v3, v3, v4

    invoke-static {p2, v1}, Lnet/i2p/crypto/eddsa/Utils;->a(II)I

    move-result v4

    invoke-virtual {v2, v3, v4}, Lnet/i2p/crypto/eddsa/math/GroupElement;->b(Lnet/i2p/crypto/eddsa/math/GroupElement;I)Lnet/i2p/crypto/eddsa/math/GroupElement;

    move-result-object v2

    iget-object v3, p0, Lnet/i2p/crypto/eddsa/math/GroupElement;->g:[[Lnet/i2p/crypto/eddsa/math/GroupElement;

    aget-object v3, v3, p1

    aget-object v1, v3, v1

    const/4 v3, 0x2

    invoke-static {p2, v3}, Lnet/i2p/crypto/eddsa/Utils;->a(II)I

    move-result v4

    invoke-virtual {v2, v1, v4}, Lnet/i2p/crypto/eddsa/math/GroupElement;->b(Lnet/i2p/crypto/eddsa/math/GroupElement;I)Lnet/i2p/crypto/eddsa/math/GroupElement;

    move-result-object v1

    iget-object v2, p0, Lnet/i2p/crypto/eddsa/math/GroupElement;->g:[[Lnet/i2p/crypto/eddsa/math/GroupElement;

    aget-object v2, v2, p1

    aget-object v2, v2, v3

    const/4 v3, 0x3

    invoke-static {p2, v3}, Lnet/i2p/crypto/eddsa/Utils;->a(II)I

    move-result v4

    invoke-virtual {v1, v2, v4}, Lnet/i2p/crypto/eddsa/math/GroupElement;->b(Lnet/i2p/crypto/eddsa/math/GroupElement;I)Lnet/i2p/crypto/eddsa/math/GroupElement;

    move-result-object v1

    iget-object v2, p0, Lnet/i2p/crypto/eddsa/math/GroupElement;->g:[[Lnet/i2p/crypto/eddsa/math/GroupElement;

    aget-object v2, v2, p1

    aget-object v2, v2, v3

    const/4 v3, 0x4

    invoke-static {p2, v3}, Lnet/i2p/crypto/eddsa/Utils;->a(II)I

    move-result v4

    invoke-virtual {v1, v2, v4}, Lnet/i2p/crypto/eddsa/math/GroupElement;->b(Lnet/i2p/crypto/eddsa/math/GroupElement;I)Lnet/i2p/crypto/eddsa/math/GroupElement;

    move-result-object v1

    iget-object v2, p0, Lnet/i2p/crypto/eddsa/math/GroupElement;->g:[[Lnet/i2p/crypto/eddsa/math/GroupElement;

    aget-object v2, v2, p1

    aget-object v2, v2, v3

    const/4 v3, 0x5

    invoke-static {p2, v3}, Lnet/i2p/crypto/eddsa/Utils;->a(II)I

    move-result v4

    invoke-virtual {v1, v2, v4}, Lnet/i2p/crypto/eddsa/math/GroupElement;->b(Lnet/i2p/crypto/eddsa/math/GroupElement;I)Lnet/i2p/crypto/eddsa/math/GroupElement;

    move-result-object v1

    iget-object v2, p0, Lnet/i2p/crypto/eddsa/math/GroupElement;->g:[[Lnet/i2p/crypto/eddsa/math/GroupElement;

    aget-object v2, v2, p1

    aget-object v2, v2, v3

    const/4 v3, 0x6

    invoke-static {p2, v3}, Lnet/i2p/crypto/eddsa/Utils;->a(II)I

    move-result v4

    invoke-virtual {v1, v2, v4}, Lnet/i2p/crypto/eddsa/math/GroupElement;->b(Lnet/i2p/crypto/eddsa/math/GroupElement;I)Lnet/i2p/crypto/eddsa/math/GroupElement;

    move-result-object v1

    iget-object v2, p0, Lnet/i2p/crypto/eddsa/math/GroupElement;->g:[[Lnet/i2p/crypto/eddsa/math/GroupElement;

    aget-object v2, v2, p1

    aget-object v2, v2, v3

    const/4 v3, 0x7

    invoke-static {p2, v3}, Lnet/i2p/crypto/eddsa/Utils;->a(II)I

    move-result v4

    invoke-virtual {v1, v2, v4}, Lnet/i2p/crypto/eddsa/math/GroupElement;->b(Lnet/i2p/crypto/eddsa/math/GroupElement;I)Lnet/i2p/crypto/eddsa/math/GroupElement;

    move-result-object v1

    iget-object v2, p0, Lnet/i2p/crypto/eddsa/math/GroupElement;->g:[[Lnet/i2p/crypto/eddsa/math/GroupElement;

    aget-object p1, v2, p1

    aget-object p1, p1, v3

    const/16 v2, 0x8

    invoke-static {p2, v2}, Lnet/i2p/crypto/eddsa/Utils;->a(II)I

    move-result p2

    invoke-virtual {v1, p1, p2}, Lnet/i2p/crypto/eddsa/math/GroupElement;->b(Lnet/i2p/crypto/eddsa/math/GroupElement;I)Lnet/i2p/crypto/eddsa/math/GroupElement;

    move-result-object p1

    iget-object p2, p0, Lnet/i2p/crypto/eddsa/math/GroupElement;->a:Lnet/i2p/crypto/eddsa/math/Curve;

    iget-object v1, p1, Lnet/i2p/crypto/eddsa/math/GroupElement;->d:Lnet/i2p/crypto/eddsa/math/FieldElement;

    iget-object v2, p1, Lnet/i2p/crypto/eddsa/math/GroupElement;->c:Lnet/i2p/crypto/eddsa/math/FieldElement;

    iget-object v3, p1, Lnet/i2p/crypto/eddsa/math/GroupElement;->e:Lnet/i2p/crypto/eddsa/math/FieldElement;

    invoke-virtual {v3}, Lnet/i2p/crypto/eddsa/math/FieldElement;->h()Lnet/i2p/crypto/eddsa/math/FieldElement;

    move-result-object v3

    invoke-static {p2, v1, v2, v3}, Lnet/i2p/crypto/eddsa/math/GroupElement;->i(Lnet/i2p/crypto/eddsa/math/Curve;Lnet/i2p/crypto/eddsa/math/FieldElement;Lnet/i2p/crypto/eddsa/math/FieldElement;Lnet/i2p/crypto/eddsa/math/FieldElement;)Lnet/i2p/crypto/eddsa/math/GroupElement;

    move-result-object p2

    invoke-virtual {p1, p2, v0}, Lnet/i2p/crypto/eddsa/math/GroupElement;->b(Lnet/i2p/crypto/eddsa/math/GroupElement;I)Lnet/i2p/crypto/eddsa/math/GroupElement;

    move-result-object p1

    return-object p1
.end method

.method public final n()[B
    .locals 5

    iget-object v0, p0, Lnet/i2p/crypto/eddsa/math/GroupElement;->b:Lnet/i2p/crypto/eddsa/math/GroupElement$Representation;

    invoke-virtual {v0}, Ljava/lang/Enum;->ordinal()I

    move-result v0

    const/4 v1, 0x1

    if-eqz v0, :cond_0

    if-eq v0, v1, :cond_0

    invoke-virtual {p0}, Lnet/i2p/crypto/eddsa/math/GroupElement;->p()Lnet/i2p/crypto/eddsa/math/GroupElement;

    move-result-object v0

    invoke-virtual {v0}, Lnet/i2p/crypto/eddsa/math/GroupElement;->n()[B

    move-result-object v0

    return-object v0

    :cond_0
    iget-object v0, p0, Lnet/i2p/crypto/eddsa/math/GroupElement;->e:Lnet/i2p/crypto/eddsa/math/FieldElement;

    invoke-virtual {v0}, Lnet/i2p/crypto/eddsa/math/FieldElement;->e()Lnet/i2p/crypto/eddsa/math/FieldElement;

    move-result-object v0

    iget-object v2, p0, Lnet/i2p/crypto/eddsa/math/GroupElement;->c:Lnet/i2p/crypto/eddsa/math/FieldElement;

    invoke-virtual {v2, v0}, Lnet/i2p/crypto/eddsa/math/FieldElement;->g(Lnet/i2p/crypto/eddsa/math/FieldElement;)Lnet/i2p/crypto/eddsa/math/FieldElement;

    move-result-object v2

    iget-object v3, p0, Lnet/i2p/crypto/eddsa/math/GroupElement;->d:Lnet/i2p/crypto/eddsa/math/FieldElement;

    invoke-virtual {v3, v0}, Lnet/i2p/crypto/eddsa/math/FieldElement;->g(Lnet/i2p/crypto/eddsa/math/FieldElement;)Lnet/i2p/crypto/eddsa/math/FieldElement;

    move-result-object v0

    invoke-virtual {v0}, Lnet/i2p/crypto/eddsa/math/FieldElement;->n()[B

    move-result-object v0

    array-length v3, v0

    sub-int/2addr v3, v1

    aget-byte v1, v0, v3

    .line 1
    iget-object v4, v2, Lnet/i2p/crypto/eddsa/math/FieldElement;->a:Lnet/i2p/crypto/eddsa/math/Field;

    .line 2
    iget-object v4, v4, Lnet/i2p/crypto/eddsa/math/Field;->f:Lnet/i2p/crypto/eddsa/math/Encoding;

    .line 3
    invoke-virtual {v4, v2}, Lnet/i2p/crypto/eddsa/math/Encoding;->c(Lnet/i2p/crypto/eddsa/math/FieldElement;)Z

    move-result v2

    if-eqz v2, :cond_1

    const/16 v2, -0x80

    goto :goto_0

    :cond_1
    const/4 v2, 0x0

    :goto_0
    or-int/2addr v1, v2

    int-to-byte v1, v1

    .line 4
    aput-byte v1, v0, v3

    return-object v0
.end method

.method public final o()Lnet/i2p/crypto/eddsa/math/GroupElement;
    .locals 1

    sget-object v0, Lnet/i2p/crypto/eddsa/math/GroupElement$Representation;->f:Lnet/i2p/crypto/eddsa/math/GroupElement$Representation;

    invoke-virtual {p0, v0}, Lnet/i2p/crypto/eddsa/math/GroupElement;->r(Lnet/i2p/crypto/eddsa/math/GroupElement$Representation;)Lnet/i2p/crypto/eddsa/math/GroupElement;

    move-result-object v0

    return-object v0
.end method

.method public final p()Lnet/i2p/crypto/eddsa/math/GroupElement;
    .locals 1

    sget-object v0, Lnet/i2p/crypto/eddsa/math/GroupElement$Representation;->a:Lnet/i2p/crypto/eddsa/math/GroupElement$Representation;

    invoke-virtual {p0, v0}, Lnet/i2p/crypto/eddsa/math/GroupElement;->r(Lnet/i2p/crypto/eddsa/math/GroupElement$Representation;)Lnet/i2p/crypto/eddsa/math/GroupElement;

    move-result-object v0

    return-object v0
.end method

.method public final q()Lnet/i2p/crypto/eddsa/math/GroupElement;
    .locals 1

    sget-object v0, Lnet/i2p/crypto/eddsa/math/GroupElement$Representation;->b:Lnet/i2p/crypto/eddsa/math/GroupElement$Representation;

    invoke-virtual {p0, v0}, Lnet/i2p/crypto/eddsa/math/GroupElement;->r(Lnet/i2p/crypto/eddsa/math/GroupElement$Representation;)Lnet/i2p/crypto/eddsa/math/GroupElement;

    move-result-object v0

    return-object v0
.end method

.method public final r(Lnet/i2p/crypto/eddsa/math/GroupElement$Representation;)Lnet/i2p/crypto/eddsa/math/GroupElement;
    .locals 7

    sget-object v2, Lnet/i2p/crypto/eddsa/math/GroupElement$Representation;->f:Lnet/i2p/crypto/eddsa/math/GroupElement$Representation;

    iget-object v0, p0, Lnet/i2p/crypto/eddsa/math/GroupElement;->b:Lnet/i2p/crypto/eddsa/math/GroupElement$Representation;

    invoke-virtual {v0}, Ljava/lang/Enum;->ordinal()I

    move-result v0

    if-eqz v0, :cond_d

    const/4 v1, 0x5

    const/4 v3, 0x1

    if-eq v0, v3, :cond_9

    const/4 v4, 0x3

    if-eq v0, v4, :cond_4

    const/4 v3, 0x4

    if-eq v0, v3, :cond_2

    if-ne v0, v1, :cond_1

    invoke-virtual {p1}, Ljava/lang/Enum;->ordinal()I

    move-result p1

    if-ne p1, v1, :cond_0

    iget-object v1, p0, Lnet/i2p/crypto/eddsa/math/GroupElement;->a:Lnet/i2p/crypto/eddsa/math/Curve;

    iget-object v3, p0, Lnet/i2p/crypto/eddsa/math/GroupElement;->c:Lnet/i2p/crypto/eddsa/math/FieldElement;

    iget-object v4, p0, Lnet/i2p/crypto/eddsa/math/GroupElement;->d:Lnet/i2p/crypto/eddsa/math/FieldElement;

    iget-object v5, p0, Lnet/i2p/crypto/eddsa/math/GroupElement;->e:Lnet/i2p/crypto/eddsa/math/FieldElement;

    iget-object v6, p0, Lnet/i2p/crypto/eddsa/math/GroupElement;->f:Lnet/i2p/crypto/eddsa/math/FieldElement;

    .line 1
    new-instance p1, Lnet/i2p/crypto/eddsa/math/GroupElement;

    move-object v0, p1

    invoke-direct/range {v0 .. v6}, Lnet/i2p/crypto/eddsa/math/GroupElement;-><init>(Lnet/i2p/crypto/eddsa/math/Curve;Lnet/i2p/crypto/eddsa/math/GroupElement$Representation;Lnet/i2p/crypto/eddsa/math/FieldElement;Lnet/i2p/crypto/eddsa/math/FieldElement;Lnet/i2p/crypto/eddsa/math/FieldElement;Lnet/i2p/crypto/eddsa/math/FieldElement;)V

    return-object p1

    .line 2
    :cond_0
    new-instance p1, Ljava/lang/IllegalArgumentException;

    invoke-direct {p1}, Ljava/lang/IllegalArgumentException;-><init>()V

    throw p1

    :cond_1
    new-instance p1, Ljava/lang/UnsupportedOperationException;

    invoke-direct {p1}, Ljava/lang/UnsupportedOperationException;-><init>()V

    throw p1

    :cond_2
    invoke-virtual {p1}, Ljava/lang/Enum;->ordinal()I

    move-result p1

    if-ne p1, v3, :cond_3

    iget-object p1, p0, Lnet/i2p/crypto/eddsa/math/GroupElement;->a:Lnet/i2p/crypto/eddsa/math/Curve;

    iget-object v0, p0, Lnet/i2p/crypto/eddsa/math/GroupElement;->c:Lnet/i2p/crypto/eddsa/math/FieldElement;

    iget-object v1, p0, Lnet/i2p/crypto/eddsa/math/GroupElement;->d:Lnet/i2p/crypto/eddsa/math/FieldElement;

    iget-object v2, p0, Lnet/i2p/crypto/eddsa/math/GroupElement;->e:Lnet/i2p/crypto/eddsa/math/FieldElement;

    invoke-static {p1, v0, v1, v2}, Lnet/i2p/crypto/eddsa/math/GroupElement;->i(Lnet/i2p/crypto/eddsa/math/Curve;Lnet/i2p/crypto/eddsa/math/FieldElement;Lnet/i2p/crypto/eddsa/math/FieldElement;Lnet/i2p/crypto/eddsa/math/FieldElement;)Lnet/i2p/crypto/eddsa/math/GroupElement;

    move-result-object p1

    return-object p1

    :cond_3
    new-instance p1, Ljava/lang/IllegalArgumentException;

    invoke-direct {p1}, Ljava/lang/IllegalArgumentException;-><init>()V

    throw p1

    :cond_4
    invoke-virtual {p1}, Ljava/lang/Enum;->ordinal()I

    move-result p1

    if-eqz p1, :cond_8

    if-eq p1, v3, :cond_7

    const/4 v0, 0x2

    if-eq p1, v0, :cond_6

    if-ne p1, v4, :cond_5

    iget-object p1, p0, Lnet/i2p/crypto/eddsa/math/GroupElement;->a:Lnet/i2p/crypto/eddsa/math/Curve;

    iget-object v0, p0, Lnet/i2p/crypto/eddsa/math/GroupElement;->c:Lnet/i2p/crypto/eddsa/math/FieldElement;

    iget-object v1, p0, Lnet/i2p/crypto/eddsa/math/GroupElement;->d:Lnet/i2p/crypto/eddsa/math/FieldElement;

    iget-object v2, p0, Lnet/i2p/crypto/eddsa/math/GroupElement;->e:Lnet/i2p/crypto/eddsa/math/FieldElement;

    iget-object v3, p0, Lnet/i2p/crypto/eddsa/math/GroupElement;->f:Lnet/i2p/crypto/eddsa/math/FieldElement;

    invoke-static {p1, v0, v1, v2, v3}, Lnet/i2p/crypto/eddsa/math/GroupElement;->f(Lnet/i2p/crypto/eddsa/math/Curve;Lnet/i2p/crypto/eddsa/math/FieldElement;Lnet/i2p/crypto/eddsa/math/FieldElement;Lnet/i2p/crypto/eddsa/math/FieldElement;Lnet/i2p/crypto/eddsa/math/FieldElement;)Lnet/i2p/crypto/eddsa/math/GroupElement;

    move-result-object p1

    return-object p1

    :cond_5
    new-instance p1, Ljava/lang/IllegalArgumentException;

    invoke-direct {p1}, Ljava/lang/IllegalArgumentException;-><init>()V

    throw p1

    :cond_6
    iget-object v0, p0, Lnet/i2p/crypto/eddsa/math/GroupElement;->a:Lnet/i2p/crypto/eddsa/math/Curve;

    iget-object p1, p0, Lnet/i2p/crypto/eddsa/math/GroupElement;->c:Lnet/i2p/crypto/eddsa/math/FieldElement;

    iget-object v1, p0, Lnet/i2p/crypto/eddsa/math/GroupElement;->f:Lnet/i2p/crypto/eddsa/math/FieldElement;

    invoke-virtual {p1, v1}, Lnet/i2p/crypto/eddsa/math/FieldElement;->g(Lnet/i2p/crypto/eddsa/math/FieldElement;)Lnet/i2p/crypto/eddsa/math/FieldElement;

    move-result-object v1

    iget-object p1, p0, Lnet/i2p/crypto/eddsa/math/GroupElement;->d:Lnet/i2p/crypto/eddsa/math/FieldElement;

    iget-object v2, p0, Lnet/i2p/crypto/eddsa/math/GroupElement;->e:Lnet/i2p/crypto/eddsa/math/FieldElement;

    invoke-virtual {p1, v2}, Lnet/i2p/crypto/eddsa/math/FieldElement;->g(Lnet/i2p/crypto/eddsa/math/FieldElement;)Lnet/i2p/crypto/eddsa/math/FieldElement;

    move-result-object v2

    iget-object p1, p0, Lnet/i2p/crypto/eddsa/math/GroupElement;->e:Lnet/i2p/crypto/eddsa/math/FieldElement;

    iget-object v3, p0, Lnet/i2p/crypto/eddsa/math/GroupElement;->f:Lnet/i2p/crypto/eddsa/math/FieldElement;

    invoke-virtual {p1, v3}, Lnet/i2p/crypto/eddsa/math/FieldElement;->g(Lnet/i2p/crypto/eddsa/math/FieldElement;)Lnet/i2p/crypto/eddsa/math/FieldElement;

    move-result-object v3

    iget-object p1, p0, Lnet/i2p/crypto/eddsa/math/GroupElement;->c:Lnet/i2p/crypto/eddsa/math/FieldElement;

    iget-object v4, p0, Lnet/i2p/crypto/eddsa/math/GroupElement;->d:Lnet/i2p/crypto/eddsa/math/FieldElement;

    invoke-virtual {p1, v4}, Lnet/i2p/crypto/eddsa/math/FieldElement;->g(Lnet/i2p/crypto/eddsa/math/FieldElement;)Lnet/i2p/crypto/eddsa/math/FieldElement;

    move-result-object v4

    const/4 v5, 0x1

    invoke-static/range {v0 .. v5}, Lnet/i2p/crypto/eddsa/math/GroupElement;->h(Lnet/i2p/crypto/eddsa/math/Curve;Lnet/i2p/crypto/eddsa/math/FieldElement;Lnet/i2p/crypto/eddsa/math/FieldElement;Lnet/i2p/crypto/eddsa/math/FieldElement;Lnet/i2p/crypto/eddsa/math/FieldElement;Z)Lnet/i2p/crypto/eddsa/math/GroupElement;

    move-result-object p1

    return-object p1

    :cond_7
    iget-object v0, p0, Lnet/i2p/crypto/eddsa/math/GroupElement;->a:Lnet/i2p/crypto/eddsa/math/Curve;

    iget-object p1, p0, Lnet/i2p/crypto/eddsa/math/GroupElement;->c:Lnet/i2p/crypto/eddsa/math/FieldElement;

    iget-object v1, p0, Lnet/i2p/crypto/eddsa/math/GroupElement;->f:Lnet/i2p/crypto/eddsa/math/FieldElement;

    invoke-virtual {p1, v1}, Lnet/i2p/crypto/eddsa/math/FieldElement;->g(Lnet/i2p/crypto/eddsa/math/FieldElement;)Lnet/i2p/crypto/eddsa/math/FieldElement;

    move-result-object v1

    iget-object p1, p0, Lnet/i2p/crypto/eddsa/math/GroupElement;->d:Lnet/i2p/crypto/eddsa/math/FieldElement;

    iget-object v2, p0, Lnet/i2p/crypto/eddsa/math/GroupElement;->e:Lnet/i2p/crypto/eddsa/math/FieldElement;

    invoke-virtual {p1, v2}, Lnet/i2p/crypto/eddsa/math/FieldElement;->g(Lnet/i2p/crypto/eddsa/math/FieldElement;)Lnet/i2p/crypto/eddsa/math/FieldElement;

    move-result-object v2

    iget-object p1, p0, Lnet/i2p/crypto/eddsa/math/GroupElement;->e:Lnet/i2p/crypto/eddsa/math/FieldElement;

    iget-object v3, p0, Lnet/i2p/crypto/eddsa/math/GroupElement;->f:Lnet/i2p/crypto/eddsa/math/FieldElement;

    invoke-virtual {p1, v3}, Lnet/i2p/crypto/eddsa/math/FieldElement;->g(Lnet/i2p/crypto/eddsa/math/FieldElement;)Lnet/i2p/crypto/eddsa/math/FieldElement;

    move-result-object v3

    iget-object p1, p0, Lnet/i2p/crypto/eddsa/math/GroupElement;->c:Lnet/i2p/crypto/eddsa/math/FieldElement;

    iget-object v4, p0, Lnet/i2p/crypto/eddsa/math/GroupElement;->d:Lnet/i2p/crypto/eddsa/math/FieldElement;

    invoke-virtual {p1, v4}, Lnet/i2p/crypto/eddsa/math/FieldElement;->g(Lnet/i2p/crypto/eddsa/math/FieldElement;)Lnet/i2p/crypto/eddsa/math/FieldElement;

    move-result-object v4

    const/4 v5, 0x0

    invoke-static/range {v0 .. v5}, Lnet/i2p/crypto/eddsa/math/GroupElement;->h(Lnet/i2p/crypto/eddsa/math/Curve;Lnet/i2p/crypto/eddsa/math/FieldElement;Lnet/i2p/crypto/eddsa/math/FieldElement;Lnet/i2p/crypto/eddsa/math/FieldElement;Lnet/i2p/crypto/eddsa/math/FieldElement;Z)Lnet/i2p/crypto/eddsa/math/GroupElement;

    move-result-object p1

    return-object p1

    :cond_8
    iget-object p1, p0, Lnet/i2p/crypto/eddsa/math/GroupElement;->a:Lnet/i2p/crypto/eddsa/math/Curve;

    iget-object v0, p0, Lnet/i2p/crypto/eddsa/math/GroupElement;->c:Lnet/i2p/crypto/eddsa/math/FieldElement;

    iget-object v1, p0, Lnet/i2p/crypto/eddsa/math/GroupElement;->f:Lnet/i2p/crypto/eddsa/math/FieldElement;

    invoke-virtual {v0, v1}, Lnet/i2p/crypto/eddsa/math/FieldElement;->g(Lnet/i2p/crypto/eddsa/math/FieldElement;)Lnet/i2p/crypto/eddsa/math/FieldElement;

    move-result-object v0

    iget-object v1, p0, Lnet/i2p/crypto/eddsa/math/GroupElement;->d:Lnet/i2p/crypto/eddsa/math/FieldElement;

    iget-object v2, p0, Lnet/i2p/crypto/eddsa/math/GroupElement;->e:Lnet/i2p/crypto/eddsa/math/FieldElement;

    invoke-virtual {v1, v2}, Lnet/i2p/crypto/eddsa/math/FieldElement;->g(Lnet/i2p/crypto/eddsa/math/FieldElement;)Lnet/i2p/crypto/eddsa/math/FieldElement;

    move-result-object v1

    iget-object v2, p0, Lnet/i2p/crypto/eddsa/math/GroupElement;->e:Lnet/i2p/crypto/eddsa/math/FieldElement;

    iget-object v3, p0, Lnet/i2p/crypto/eddsa/math/GroupElement;->f:Lnet/i2p/crypto/eddsa/math/FieldElement;

    invoke-virtual {v2, v3}, Lnet/i2p/crypto/eddsa/math/FieldElement;->g(Lnet/i2p/crypto/eddsa/math/FieldElement;)Lnet/i2p/crypto/eddsa/math/FieldElement;

    move-result-object v2

    invoke-static {p1, v0, v1, v2}, Lnet/i2p/crypto/eddsa/math/GroupElement;->g(Lnet/i2p/crypto/eddsa/math/Curve;Lnet/i2p/crypto/eddsa/math/FieldElement;Lnet/i2p/crypto/eddsa/math/FieldElement;Lnet/i2p/crypto/eddsa/math/FieldElement;)Lnet/i2p/crypto/eddsa/math/GroupElement;

    move-result-object p1

    return-object p1

    :cond_9
    invoke-virtual {p1}, Ljava/lang/Enum;->ordinal()I

    move-result p1

    if-eqz p1, :cond_c

    if-eq p1, v3, :cond_b

    if-ne p1, v1, :cond_a

    iget-object v1, p0, Lnet/i2p/crypto/eddsa/math/GroupElement;->a:Lnet/i2p/crypto/eddsa/math/Curve;

    iget-object p1, p0, Lnet/i2p/crypto/eddsa/math/GroupElement;->d:Lnet/i2p/crypto/eddsa/math/FieldElement;

    iget-object v0, p0, Lnet/i2p/crypto/eddsa/math/GroupElement;->c:Lnet/i2p/crypto/eddsa/math/FieldElement;

    invoke-virtual {p1, v0}, Lnet/i2p/crypto/eddsa/math/FieldElement;->a(Lnet/i2p/crypto/eddsa/math/FieldElement;)Lnet/i2p/crypto/eddsa/math/FieldElement;

    move-result-object v3

    iget-object p1, p0, Lnet/i2p/crypto/eddsa/math/GroupElement;->d:Lnet/i2p/crypto/eddsa/math/FieldElement;

    iget-object v0, p0, Lnet/i2p/crypto/eddsa/math/GroupElement;->c:Lnet/i2p/crypto/eddsa/math/FieldElement;

    invoke-virtual {p1, v0}, Lnet/i2p/crypto/eddsa/math/FieldElement;->l(Lnet/i2p/crypto/eddsa/math/FieldElement;)Lnet/i2p/crypto/eddsa/math/FieldElement;

    move-result-object v4

    iget-object v5, p0, Lnet/i2p/crypto/eddsa/math/GroupElement;->e:Lnet/i2p/crypto/eddsa/math/FieldElement;

    iget-object p1, p0, Lnet/i2p/crypto/eddsa/math/GroupElement;->f:Lnet/i2p/crypto/eddsa/math/FieldElement;

    iget-object v0, p0, Lnet/i2p/crypto/eddsa/math/GroupElement;->a:Lnet/i2p/crypto/eddsa/math/Curve;

    .line 3
    iget-object v0, v0, Lnet/i2p/crypto/eddsa/math/Curve;->c:Lnet/i2p/crypto/eddsa/math/FieldElement;

    .line 4
    invoke-virtual {p1, v0}, Lnet/i2p/crypto/eddsa/math/FieldElement;->g(Lnet/i2p/crypto/eddsa/math/FieldElement;)Lnet/i2p/crypto/eddsa/math/FieldElement;

    move-result-object v6

    .line 5
    new-instance p1, Lnet/i2p/crypto/eddsa/math/GroupElement;

    move-object v0, p1

    invoke-direct/range {v0 .. v6}, Lnet/i2p/crypto/eddsa/math/GroupElement;-><init>(Lnet/i2p/crypto/eddsa/math/Curve;Lnet/i2p/crypto/eddsa/math/GroupElement$Representation;Lnet/i2p/crypto/eddsa/math/FieldElement;Lnet/i2p/crypto/eddsa/math/FieldElement;Lnet/i2p/crypto/eddsa/math/FieldElement;Lnet/i2p/crypto/eddsa/math/FieldElement;)V

    return-object p1

    .line 6
    :cond_a
    new-instance p1, Ljava/lang/IllegalArgumentException;

    invoke-direct {p1}, Ljava/lang/IllegalArgumentException;-><init>()V

    throw p1

    :cond_b
    iget-object v0, p0, Lnet/i2p/crypto/eddsa/math/GroupElement;->a:Lnet/i2p/crypto/eddsa/math/Curve;

    iget-object v1, p0, Lnet/i2p/crypto/eddsa/math/GroupElement;->c:Lnet/i2p/crypto/eddsa/math/FieldElement;

    iget-object v2, p0, Lnet/i2p/crypto/eddsa/math/GroupElement;->d:Lnet/i2p/crypto/eddsa/math/FieldElement;

    iget-object v3, p0, Lnet/i2p/crypto/eddsa/math/GroupElement;->e:Lnet/i2p/crypto/eddsa/math/FieldElement;

    iget-object v4, p0, Lnet/i2p/crypto/eddsa/math/GroupElement;->f:Lnet/i2p/crypto/eddsa/math/FieldElement;

    const/4 v5, 0x0

    .line 7
    invoke-static/range {v0 .. v5}, Lnet/i2p/crypto/eddsa/math/GroupElement;->h(Lnet/i2p/crypto/eddsa/math/Curve;Lnet/i2p/crypto/eddsa/math/FieldElement;Lnet/i2p/crypto/eddsa/math/FieldElement;Lnet/i2p/crypto/eddsa/math/FieldElement;Lnet/i2p/crypto/eddsa/math/FieldElement;Z)Lnet/i2p/crypto/eddsa/math/GroupElement;

    move-result-object p1

    return-object p1

    .line 8
    :cond_c
    iget-object p1, p0, Lnet/i2p/crypto/eddsa/math/GroupElement;->a:Lnet/i2p/crypto/eddsa/math/Curve;

    iget-object v0, p0, Lnet/i2p/crypto/eddsa/math/GroupElement;->c:Lnet/i2p/crypto/eddsa/math/FieldElement;

    iget-object v1, p0, Lnet/i2p/crypto/eddsa/math/GroupElement;->d:Lnet/i2p/crypto/eddsa/math/FieldElement;

    iget-object v2, p0, Lnet/i2p/crypto/eddsa/math/GroupElement;->e:Lnet/i2p/crypto/eddsa/math/FieldElement;

    invoke-static {p1, v0, v1, v2}, Lnet/i2p/crypto/eddsa/math/GroupElement;->g(Lnet/i2p/crypto/eddsa/math/Curve;Lnet/i2p/crypto/eddsa/math/FieldElement;Lnet/i2p/crypto/eddsa/math/FieldElement;Lnet/i2p/crypto/eddsa/math/FieldElement;)Lnet/i2p/crypto/eddsa/math/GroupElement;

    move-result-object p1

    return-object p1

    :cond_d
    invoke-virtual {p1}, Ljava/lang/Enum;->ordinal()I

    move-result p1

    if-nez p1, :cond_e

    iget-object p1, p0, Lnet/i2p/crypto/eddsa/math/GroupElement;->a:Lnet/i2p/crypto/eddsa/math/Curve;

    iget-object v0, p0, Lnet/i2p/crypto/eddsa/math/GroupElement;->c:Lnet/i2p/crypto/eddsa/math/FieldElement;

    iget-object v1, p0, Lnet/i2p/crypto/eddsa/math/GroupElement;->d:Lnet/i2p/crypto/eddsa/math/FieldElement;

    iget-object v2, p0, Lnet/i2p/crypto/eddsa/math/GroupElement;->e:Lnet/i2p/crypto/eddsa/math/FieldElement;

    invoke-static {p1, v0, v1, v2}, Lnet/i2p/crypto/eddsa/math/GroupElement;->g(Lnet/i2p/crypto/eddsa/math/Curve;Lnet/i2p/crypto/eddsa/math/FieldElement;Lnet/i2p/crypto/eddsa/math/FieldElement;Lnet/i2p/crypto/eddsa/math/FieldElement;)Lnet/i2p/crypto/eddsa/math/GroupElement;

    move-result-object p1

    return-object p1

    :cond_e
    new-instance p1, Ljava/lang/IllegalArgumentException;

    invoke-direct {p1}, Ljava/lang/IllegalArgumentException;-><init>()V

    throw p1
.end method

.method public final toString()Ljava/lang/String;
    .locals 2

    const-string v0, "[GroupElement\nX="

    .line 1
    invoke-static {v0}, Lcom/trilead/ssh2/crypto/digest/a;->e(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    .line 2
    iget-object v1, p0, Lnet/i2p/crypto/eddsa/math/GroupElement;->c:Lnet/i2p/crypto/eddsa/math/FieldElement;

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const-string v1, "\nY="

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object v1, p0, Lnet/i2p/crypto/eddsa/math/GroupElement;->d:Lnet/i2p/crypto/eddsa/math/FieldElement;

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const-string v1, "\nZ="

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object v1, p0, Lnet/i2p/crypto/eddsa/math/GroupElement;->e:Lnet/i2p/crypto/eddsa/math/FieldElement;

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const-string v1, "\nT="

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object v1, p0, Lnet/i2p/crypto/eddsa/math/GroupElement;->f:Lnet/i2p/crypto/eddsa/math/FieldElement;

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const-string v1, "\n]"

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method
