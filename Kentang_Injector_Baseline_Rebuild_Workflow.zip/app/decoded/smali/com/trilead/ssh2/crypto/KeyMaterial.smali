.class public Lcom/trilead/ssh2/crypto/KeyMaterial;
.super Ljava/lang/Object;
.source "SourceFile"


# instance fields
.field public a:[B

.field public b:[B

.field public c:[B

.field public d:[B

.field public e:[B

.field public f:[B


# direct methods
.method public constructor <init>()V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method public static a(Lcom/trilead/ssh2/crypto/digest/HashForSSH2Types;Ljava/math/BigInteger;[BB[BI)[B
    .locals 7

    new-array v0, p5, [B

    .line 1
    iget-object v1, p0, Lcom/trilead/ssh2/crypto/digest/HashForSSH2Types;->a:Lcom/trilead/ssh2/crypto/digest/Digest;

    invoke-interface {v1}, Lcom/trilead/ssh2/crypto/digest/Digest;->c()I

    move-result v1

    add-int v2, p5, v1

    const/4 v3, 0x1

    sub-int/2addr v2, v3

    .line 2
    div-int/2addr v2, v1

    new-array v4, v2, [[B

    .line 3
    iget-object v5, p0, Lcom/trilead/ssh2/crypto/digest/HashForSSH2Types;->a:Lcom/trilead/ssh2/crypto/digest/Digest;

    invoke-interface {v5}, Lcom/trilead/ssh2/crypto/digest/Digest;->a()V

    .line 4
    invoke-virtual {p1}, Ljava/math/BigInteger;->toByteArray()[B

    move-result-object v5

    invoke-virtual {p0, v5}, Lcom/trilead/ssh2/crypto/digest/HashForSSH2Types;->c([B)V

    .line 5
    invoke-virtual {p0, p2}, Lcom/trilead/ssh2/crypto/digest/HashForSSH2Types;->d([B)V

    new-array v5, v3, [B

    const/4 v6, 0x0

    aput-byte p3, v5, v6

    .line 6
    iget-object p3, p0, Lcom/trilead/ssh2/crypto/digest/HashForSSH2Types;->a:Lcom/trilead/ssh2/crypto/digest/Digest;

    invoke-interface {p3, v5}, Lcom/trilead/ssh2/crypto/digest/Digest;->g([B)V

    .line 7
    invoke-virtual {p0, p4}, Lcom/trilead/ssh2/crypto/digest/HashForSSH2Types;->d([B)V

    invoke-virtual {p0}, Lcom/trilead/ssh2/crypto/digest/HashForSSH2Types;->a()[B

    move-result-object p3

    aput-object p3, v4, v6

    invoke-static {v1, p5}, Ljava/lang/Math;->min(II)I

    move-result p3

    aget-object p4, v4, v6

    invoke-static {p4, v6, v0, v6, p3}, Ljava/lang/System;->arraycopy(Ljava/lang/Object;ILjava/lang/Object;II)V

    sub-int/2addr p5, p3

    add-int/2addr p3, v6

    :goto_0
    if-ge v3, v2, :cond_1

    .line 8
    invoke-virtual {p1}, Ljava/math/BigInteger;->toByteArray()[B

    move-result-object p4

    invoke-virtual {p0, p4}, Lcom/trilead/ssh2/crypto/digest/HashForSSH2Types;->c([B)V

    .line 9
    invoke-virtual {p0, p2}, Lcom/trilead/ssh2/crypto/digest/HashForSSH2Types;->d([B)V

    const/4 p4, 0x0

    :goto_1
    if-ge p4, v3, :cond_0

    aget-object v5, v4, p4

    invoke-virtual {p0, v5}, Lcom/trilead/ssh2/crypto/digest/HashForSSH2Types;->d([B)V

    add-int/lit8 p4, p4, 0x1

    goto :goto_1

    :cond_0
    invoke-virtual {p0}, Lcom/trilead/ssh2/crypto/digest/HashForSSH2Types;->a()[B

    move-result-object p4

    aput-object p4, v4, v3

    invoke-static {v1, p5}, Ljava/lang/Math;->min(II)I

    move-result p4

    aget-object v5, v4, v3

    invoke-static {v5, v6, v0, p3, p4}, Ljava/lang/System;->arraycopy(Ljava/lang/Object;ILjava/lang/Object;II)V

    sub-int/2addr p5, p4

    add-int/2addr p3, p4

    add-int/lit8 v3, v3, 0x1

    goto :goto_0

    :cond_1
    return-object v0
.end method

.method public static b(Ljava/lang/String;[BLjava/math/BigInteger;[BIIIIII)Lcom/trilead/ssh2/crypto/KeyMaterial;
    .locals 8

    new-instance v0, Lcom/trilead/ssh2/crypto/KeyMaterial;

    invoke-direct {v0}, Lcom/trilead/ssh2/crypto/KeyMaterial;-><init>()V

    new-instance v7, Lcom/trilead/ssh2/crypto/digest/HashForSSH2Types;

    move-object v1, p0

    invoke-direct {v7, p0}, Lcom/trilead/ssh2/crypto/digest/HashForSSH2Types;-><init>(Ljava/lang/String;)V

    const/16 v4, 0x41

    move-object v1, v7

    move-object v2, p2

    move-object v3, p1

    move-object v5, p3

    move v6, p5

    invoke-static/range {v1 .. v6}, Lcom/trilead/ssh2/crypto/KeyMaterial;->a(Lcom/trilead/ssh2/crypto/digest/HashForSSH2Types;Ljava/math/BigInteger;[BB[BI)[B

    move-result-object v1

    iput-object v1, v0, Lcom/trilead/ssh2/crypto/KeyMaterial;->a:[B

    const/16 v4, 0x42

    move-object v1, v7

    move/from16 v6, p8

    invoke-static/range {v1 .. v6}, Lcom/trilead/ssh2/crypto/KeyMaterial;->a(Lcom/trilead/ssh2/crypto/digest/HashForSSH2Types;Ljava/math/BigInteger;[BB[BI)[B

    move-result-object v1

    iput-object v1, v0, Lcom/trilead/ssh2/crypto/KeyMaterial;->b:[B

    const/16 v4, 0x43

    move-object v1, v7

    move v6, p4

    invoke-static/range {v1 .. v6}, Lcom/trilead/ssh2/crypto/KeyMaterial;->a(Lcom/trilead/ssh2/crypto/digest/HashForSSH2Types;Ljava/math/BigInteger;[BB[BI)[B

    move-result-object v1

    iput-object v1, v0, Lcom/trilead/ssh2/crypto/KeyMaterial;->c:[B

    const/16 v4, 0x44

    move-object v1, v7

    move v6, p7

    invoke-static/range {v1 .. v6}, Lcom/trilead/ssh2/crypto/KeyMaterial;->a(Lcom/trilead/ssh2/crypto/digest/HashForSSH2Types;Ljava/math/BigInteger;[BB[BI)[B

    move-result-object v1

    iput-object v1, v0, Lcom/trilead/ssh2/crypto/KeyMaterial;->d:[B

    const/16 v4, 0x45

    move-object v1, v7

    move v6, p6

    invoke-static/range {v1 .. v6}, Lcom/trilead/ssh2/crypto/KeyMaterial;->a(Lcom/trilead/ssh2/crypto/digest/HashForSSH2Types;Ljava/math/BigInteger;[BB[BI)[B

    move-result-object v1

    iput-object v1, v0, Lcom/trilead/ssh2/crypto/KeyMaterial;->e:[B

    const/16 v4, 0x46

    move-object v1, v7

    move/from16 v6, p9

    invoke-static/range {v1 .. v6}, Lcom/trilead/ssh2/crypto/KeyMaterial;->a(Lcom/trilead/ssh2/crypto/digest/HashForSSH2Types;Ljava/math/BigInteger;[BB[BI)[B

    move-result-object v1

    iput-object v1, v0, Lcom/trilead/ssh2/crypto/KeyMaterial;->f:[B

    return-object v0
.end method
