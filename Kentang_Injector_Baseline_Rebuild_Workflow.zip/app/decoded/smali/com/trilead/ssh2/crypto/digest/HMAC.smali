.class public final Lcom/trilead/ssh2/crypto/digest/HMAC;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lcom/trilead/ssh2/crypto/digest/Digest;


# annotations
.annotation runtime Ljava/lang/Deprecated;
.end annotation


# instance fields
.field public a:Lcom/trilead/ssh2/crypto/digest/Digest;

.field public b:[B

.field public c:[B

.field public d:[B

.field public e:I


# direct methods
.method public constructor <init>(Lcom/trilead/ssh2/crypto/digest/Digest;[BI)V
    .locals 3

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lcom/trilead/ssh2/crypto/digest/HMAC;->a:Lcom/trilead/ssh2/crypto/digest/Digest;

    iput p3, p0, Lcom/trilead/ssh2/crypto/digest/HMAC;->e:I

    invoke-interface {p1}, Lcom/trilead/ssh2/crypto/digest/Digest;->c()I

    move-result p3

    new-array p3, p3, [B

    iput-object p3, p0, Lcom/trilead/ssh2/crypto/digest/HMAC;->d:[B

    const/16 p3, 0x40

    new-array v0, p3, [B

    iput-object v0, p0, Lcom/trilead/ssh2/crypto/digest/HMAC;->b:[B

    new-array v0, p3, [B

    iput-object v0, p0, Lcom/trilead/ssh2/crypto/digest/HMAC;->c:[B

    array-length v0, p2

    if-le v0, p3, :cond_0

    invoke-interface {p1}, Lcom/trilead/ssh2/crypto/digest/Digest;->a()V

    invoke-interface {p1, p2}, Lcom/trilead/ssh2/crypto/digest/Digest;->g([B)V

    iget-object p2, p0, Lcom/trilead/ssh2/crypto/digest/HMAC;->d:[B

    invoke-interface {p1, p2}, Lcom/trilead/ssh2/crypto/digest/Digest;->e([B)V

    iget-object p2, p0, Lcom/trilead/ssh2/crypto/digest/HMAC;->d:[B

    :cond_0
    iget-object v0, p0, Lcom/trilead/ssh2/crypto/digest/HMAC;->b:[B

    array-length v1, p2

    const/4 v2, 0x0

    invoke-static {p2, v2, v0, v2, v1}, Ljava/lang/System;->arraycopy(Ljava/lang/Object;ILjava/lang/Object;II)V

    iget-object v0, p0, Lcom/trilead/ssh2/crypto/digest/HMAC;->c:[B

    array-length v1, p2

    invoke-static {p2, v2, v0, v2, v1}, Ljava/lang/System;->arraycopy(Ljava/lang/Object;ILjava/lang/Object;II)V

    :goto_0
    iget-object p2, p0, Lcom/trilead/ssh2/crypto/digest/HMAC;->b:[B

    if-ge v2, p3, :cond_1

    aget-byte v0, p2, v2

    xor-int/lit8 v0, v0, 0x36

    int-to-byte v0, v0

    aput-byte v0, p2, v2

    iget-object p2, p0, Lcom/trilead/ssh2/crypto/digest/HMAC;->c:[B

    aget-byte v0, p2, v2

    xor-int/lit8 v0, v0, 0x5c

    int-to-byte v0, v0

    aput-byte v0, p2, v2

    add-int/lit8 v2, v2, 0x1

    goto :goto_0

    :cond_1
    invoke-interface {p1, p2}, Lcom/trilead/ssh2/crypto/digest/Digest;->g([B)V

    return-void
.end method


# virtual methods
.method public final a()V
    .locals 2

    iget-object v0, p0, Lcom/trilead/ssh2/crypto/digest/HMAC;->a:Lcom/trilead/ssh2/crypto/digest/Digest;

    invoke-interface {v0}, Lcom/trilead/ssh2/crypto/digest/Digest;->a()V

    iget-object v0, p0, Lcom/trilead/ssh2/crypto/digest/HMAC;->a:Lcom/trilead/ssh2/crypto/digest/Digest;

    iget-object v1, p0, Lcom/trilead/ssh2/crypto/digest/HMAC;->b:[B

    invoke-interface {v0, v1}, Lcom/trilead/ssh2/crypto/digest/Digest;->g([B)V

    return-void
.end method

.method public final b([B)V
    .locals 3

    iget-object v0, p0, Lcom/trilead/ssh2/crypto/digest/HMAC;->a:Lcom/trilead/ssh2/crypto/digest/Digest;

    iget-object v1, p0, Lcom/trilead/ssh2/crypto/digest/HMAC;->d:[B

    invoke-interface {v0, v1}, Lcom/trilead/ssh2/crypto/digest/Digest;->e([B)V

    iget-object v0, p0, Lcom/trilead/ssh2/crypto/digest/HMAC;->a:Lcom/trilead/ssh2/crypto/digest/Digest;

    iget-object v1, p0, Lcom/trilead/ssh2/crypto/digest/HMAC;->c:[B

    invoke-interface {v0, v1}, Lcom/trilead/ssh2/crypto/digest/Digest;->g([B)V

    iget-object v0, p0, Lcom/trilead/ssh2/crypto/digest/HMAC;->a:Lcom/trilead/ssh2/crypto/digest/Digest;

    iget-object v1, p0, Lcom/trilead/ssh2/crypto/digest/HMAC;->d:[B

    invoke-interface {v0, v1}, Lcom/trilead/ssh2/crypto/digest/Digest;->g([B)V

    iget-object v0, p0, Lcom/trilead/ssh2/crypto/digest/HMAC;->a:Lcom/trilead/ssh2/crypto/digest/Digest;

    iget-object v1, p0, Lcom/trilead/ssh2/crypto/digest/HMAC;->d:[B

    invoke-interface {v0, v1}, Lcom/trilead/ssh2/crypto/digest/Digest;->e([B)V

    iget-object v0, p0, Lcom/trilead/ssh2/crypto/digest/HMAC;->d:[B

    iget v1, p0, Lcom/trilead/ssh2/crypto/digest/HMAC;->e:I

    const/4 v2, 0x0

    invoke-static {v0, v2, p1, v2, v1}, Ljava/lang/System;->arraycopy(Ljava/lang/Object;ILjava/lang/Object;II)V

    iget-object p1, p0, Lcom/trilead/ssh2/crypto/digest/HMAC;->a:Lcom/trilead/ssh2/crypto/digest/Digest;

    iget-object v0, p0, Lcom/trilead/ssh2/crypto/digest/HMAC;->b:[B

    invoke-interface {p1, v0}, Lcom/trilead/ssh2/crypto/digest/Digest;->g([B)V

    return-void
.end method

.method public final c()I
    .locals 1

    iget v0, p0, Lcom/trilead/ssh2/crypto/digest/HMAC;->e:I

    return v0
.end method

.method public final d([BI)V
    .locals 1

    iget-object v0, p0, Lcom/trilead/ssh2/crypto/digest/HMAC;->a:Lcom/trilead/ssh2/crypto/digest/Digest;

    invoke-interface {v0, p1, p2}, Lcom/trilead/ssh2/crypto/digest/Digest;->d([BI)V

    return-void
.end method

.method public final e([B)V
    .locals 0

    invoke-virtual {p0, p1}, Lcom/trilead/ssh2/crypto/digest/HMAC;->b([B)V

    return-void
.end method

.method public final f(B)V
    .locals 1

    iget-object v0, p0, Lcom/trilead/ssh2/crypto/digest/HMAC;->a:Lcom/trilead/ssh2/crypto/digest/Digest;

    invoke-interface {v0, p1}, Lcom/trilead/ssh2/crypto/digest/Digest;->f(B)V

    return-void
.end method

.method public final g([B)V
    .locals 1

    iget-object v0, p0, Lcom/trilead/ssh2/crypto/digest/HMAC;->a:Lcom/trilead/ssh2/crypto/digest/Digest;

    invoke-interface {v0, p1}, Lcom/trilead/ssh2/crypto/digest/Digest;->g([B)V

    return-void
.end method
