.class public final Lr/b$d;
.super Lcom/trilead/ssh2/crypto/CertificateDecoder;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lr/b;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x9
    name = "d"
.end annotation


# instance fields
.field public final a:Ljava/lang/String;

.field public final b:Ljava/security/spec/ECParameterSpec;


# direct methods
.method public constructor <init>(Ljava/lang/String;Ljava/security/spec/ECParameterSpec;)V
    .locals 0

    invoke-direct {p0}, Lcom/trilead/ssh2/crypto/CertificateDecoder;-><init>()V

    iput-object p1, p0, Lr/b$d;->a:Ljava/lang/String;

    iput-object p2, p0, Lr/b$d;->b:Ljava/security/spec/ECParameterSpec;

    return-void
.end method


# virtual methods
.method public final a(Lcom/trilead/ssh2/crypto/PEMStructure;)Ljava/security/KeyPair;
    .locals 13

    new-instance v0, Lcom/trilead/ssh2/crypto/SimpleDERReader;

    .line 1
    iget-object p1, p1, Lcom/trilead/ssh2/crypto/PEMStructure;->c:[B

    .line 2
    invoke-direct {v0, p1}, Lcom/trilead/ssh2/crypto/SimpleDERReader;-><init>([B)V

    invoke-virtual {v0}, Lcom/trilead/ssh2/crypto/SimpleDERReader;->f()[B

    move-result-object p1

    .line 3
    iget v0, v0, Lcom/trilead/ssh2/crypto/SimpleDERReader;->c:I

    if-nez v0, :cond_d

    .line 4
    new-instance v0, Lcom/trilead/ssh2/crypto/SimpleDERReader;

    invoke-direct {v0, p1}, Lcom/trilead/ssh2/crypto/SimpleDERReader;-><init>([B)V

    invoke-virtual {v0}, Lcom/trilead/ssh2/crypto/SimpleDERReader;->c()Ljava/math/BigInteger;

    move-result-object p1

    sget-object v1, Ljava/math/BigInteger;->ONE:Ljava/math/BigInteger;

    invoke-virtual {p1, v1}, Ljava/math/BigInteger;->compareTo(Ljava/math/BigInteger;)I

    move-result v1

    if-nez v1, :cond_c

    invoke-virtual {v0}, Lcom/trilead/ssh2/crypto/SimpleDERReader;->e()[B

    move-result-object p1

    const/4 v1, 0x0

    move-object v2, v1

    .line 5
    :goto_0
    iget v3, v0, Lcom/trilead/ssh2/crypto/SimpleDERReader;->c:I

    const/4 v4, 0x0

    const/4 v5, 0x1

    if-lez v3, :cond_a

    .line 6
    invoke-virtual {v0}, Lcom/trilead/ssh2/crypto/SimpleDERReader;->a()B

    move-result v3

    and-int/lit16 v3, v3, 0xff

    and-int/lit8 v6, v3, 0x20

    const/16 v7, 0x20

    if-ne v6, v7, :cond_9

    and-int/lit8 v3, v3, 0x1f

    .line 7
    invoke-virtual {v0}, Lcom/trilead/ssh2/crypto/SimpleDERReader;->d()I

    move-result v6

    const-string v7, ")"

    if-ltz v6, :cond_8

    .line 8
    iget v8, v0, Lcom/trilead/ssh2/crypto/SimpleDERReader;->c:I

    if-gt v6, v8, :cond_8

    .line 9
    new-instance v9, Lcom/trilead/ssh2/crypto/SimpleDERReader;

    iget-object v10, v0, Lcom/trilead/ssh2/crypto/SimpleDERReader;->a:[B

    iget v11, v0, Lcom/trilead/ssh2/crypto/SimpleDERReader;->b:I

    invoke-direct {v9, v10, v11, v6}, Lcom/trilead/ssh2/crypto/SimpleDERReader;-><init>([BII)V

    add-int/2addr v11, v6

    iput v11, v0, Lcom/trilead/ssh2/crypto/SimpleDERReader;->b:I

    sub-int/2addr v8, v6

    iput v8, v0, Lcom/trilead/ssh2/crypto/SimpleDERReader;->c:I

    if-eqz v3, :cond_1

    if-eq v3, v5, :cond_0

    goto :goto_0

    .line 10
    :cond_0
    invoke-virtual {v9}, Lcom/trilead/ssh2/crypto/SimpleDERReader;->e()[B

    move-result-object v2

    goto :goto_0

    .line 11
    :cond_1
    invoke-virtual {v9}, Lcom/trilead/ssh2/crypto/SimpleDERReader;->a()B

    move-result v1

    and-int/lit16 v1, v1, 0xff

    const/4 v3, 0x6

    if-ne v1, v3, :cond_7

    invoke-virtual {v9}, Lcom/trilead/ssh2/crypto/SimpleDERReader;->d()I

    move-result v1

    if-lt v1, v5, :cond_6

    .line 12
    iget v3, v9, Lcom/trilead/ssh2/crypto/SimpleDERReader;->c:I

    if-gt v1, v3, :cond_6

    .line 13
    invoke-virtual {v9, v1}, Lcom/trilead/ssh2/crypto/SimpleDERReader;->b(I)[B

    move-result-object v3

    new-instance v6, Ljava/lang/StringBuilder;

    const/16 v7, 0x40

    invoke-direct {v6, v7}, Ljava/lang/StringBuilder;-><init>(I)V

    aget-byte v7, v3, v4

    div-int/lit8 v7, v7, 0x28

    if-eqz v7, :cond_3

    if-eq v7, v5, :cond_2

    const/16 v5, 0x32

    invoke-virtual {v6, v5}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    aget-byte v5, v3, v4

    add-int/lit8 v5, v5, -0x50

    int-to-byte v5, v5

    aput-byte v5, v3, v4

    goto :goto_1

    :cond_2
    const/16 v5, 0x31

    invoke-virtual {v6, v5}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    aget-byte v5, v3, v4

    add-int/lit8 v5, v5, -0x28

    int-to-byte v5, v5

    aput-byte v5, v3, v4

    goto :goto_1

    :cond_3
    const/16 v5, 0x30

    invoke-virtual {v6, v5}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    :goto_1
    const-wide/16 v7, 0x0

    move-wide v9, v7

    :goto_2
    if-ge v4, v1, :cond_5

    const/4 v5, 0x7

    shl-long/2addr v9, v5

    aget-byte v5, v3, v4

    and-int/lit8 v5, v5, 0x7f

    int-to-long v11, v5

    add-long/2addr v9, v11

    aget-byte v5, v3, v4

    and-int/lit16 v5, v5, 0x80

    if-nez v5, :cond_4

    const/16 v5, 0x2e

    invoke-virtual {v6, v5}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    invoke-virtual {v6, v9, v10}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    move-wide v9, v7

    :cond_4
    add-int/lit8 v4, v4, 0x1

    goto :goto_2

    :cond_5
    invoke-virtual {v6}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    goto/16 :goto_0

    :cond_6
    new-instance p1, Ljava/io/IOException;

    const-string v0, "Illegal len in DER object ("

    .line 14
    invoke-static {v0, v1, v7}, Lcom/trilead/ssh2/crypto/digest/a;->d(Ljava/lang/String;ILjava/lang/String;)Ljava/lang/String;

    move-result-object v0

    .line 15
    invoke-direct {p1, v0}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    throw p1

    :cond_7
    new-instance p1, Ljava/io/IOException;

    const-string v0, "Expected DER OID, but found type "

    .line 16
    invoke-static {v0, v1}, Lcom/trilead/ssh2/crypto/digest/a;->c(Ljava/lang/String;I)Ljava/lang/String;

    move-result-object v0

    .line 17
    invoke-direct {p1, v0}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    throw p1

    .line 18
    :cond_8
    new-instance p1, Ljava/io/IOException;

    const-string v0, "Illegal length in DER object ("

    .line 19
    invoke-static {v0, v6, v7}, Lcom/trilead/ssh2/crypto/digest/a;->d(Ljava/lang/String;ILjava/lang/String;)Ljava/lang/String;

    move-result-object v0

    .line 20
    invoke-direct {p1, v0}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    throw p1

    .line 21
    :cond_9
    new-instance p1, Ljava/io/IOException;

    const-string v0, "Expected constructed type, but was "

    .line 22
    invoke-static {v0, v3}, Lcom/trilead/ssh2/crypto/digest/a;->c(Ljava/lang/String;I)Ljava/lang/String;

    move-result-object v0

    .line 23
    invoke-direct {p1, v0}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    throw p1

    .line 24
    :cond_a
    iget-object v0, p0, Lr/b$d;->a:Ljava/lang/String;

    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_b

    new-instance v0, Ljava/math/BigInteger;

    invoke-direct {v0, v5, p1}, Ljava/math/BigInteger;-><init>(I[B)V

    array-length p1, v2

    sub-int/2addr p1, v5

    new-array v1, p1, [B

    invoke-static {v2, v5, v1, v4, p1}, Ljava/lang/System;->arraycopy(Ljava/lang/Object;ILjava/lang/Object;II)V

    iget-object p1, p0, Lr/b$d;->b:Ljava/security/spec/ECParameterSpec;

    invoke-virtual {p1}, Ljava/security/spec/ECParameterSpec;->getCurve()Ljava/security/spec/EllipticCurve;

    move-result-object p1

    .line 25
    invoke-static {v1, p1}, Lr/b;->g([BLjava/security/spec/EllipticCurve;)Ljava/security/spec/ECPoint;

    move-result-object p1

    .line 26
    new-instance v1, Ljava/security/spec/ECPrivateKeySpec;

    iget-object v2, p0, Lr/b$d;->b:Ljava/security/spec/ECParameterSpec;

    invoke-direct {v1, v0, v2}, Ljava/security/spec/ECPrivateKeySpec;-><init>(Ljava/math/BigInteger;Ljava/security/spec/ECParameterSpec;)V

    new-instance v0, Ljava/security/spec/ECPublicKeySpec;

    iget-object v2, p0, Lr/b$d;->b:Ljava/security/spec/ECParameterSpec;

    invoke-direct {v0, p1, v2}, Ljava/security/spec/ECPublicKeySpec;-><init>(Ljava/security/spec/ECPoint;Ljava/security/spec/ECParameterSpec;)V

    :try_start_0
    const-string p1, "EC"

    invoke-static {p1}, Ljava/security/KeyFactory;->getInstance(Ljava/lang/String;)Ljava/security/KeyFactory;

    move-result-object p1

    invoke-virtual {p1, v0}, Ljava/security/KeyFactory;->generatePublic(Ljava/security/spec/KeySpec;)Ljava/security/PublicKey;

    move-result-object v0

    invoke-virtual {p1, v1}, Ljava/security/KeyFactory;->generatePrivate(Ljava/security/spec/KeySpec;)Ljava/security/PrivateKey;

    move-result-object p1

    new-instance v1, Ljava/security/KeyPair;

    invoke-direct {v1, v0, p1}, Ljava/security/KeyPair;-><init>(Ljava/security/PublicKey;Ljava/security/PrivateKey;)V
    :try_end_0
    .catch Ljava/security/GeneralSecurityException; {:try_start_0 .. :try_end_0} :catch_0

    return-object v1

    :catch_0
    new-instance p1, Ljava/io/IOException;

    const-string v0, "Could not generate EC key pair"

    invoke-direct {p1, v0}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    throw p1

    :cond_b
    new-instance p1, Ljava/io/IOException;

    const-string v0, "Incorrect OID for current curve"

    invoke-direct {p1, v0}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    throw p1

    :cond_c
    new-instance v0, Ljava/io/IOException;

    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const-string v2, "Unexpected version number in EC private key: "

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    invoke-direct {v0, p1}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    throw v0

    :cond_d
    new-instance p1, Ljava/io/IOException;

    const-string v0, "Unexpected padding in EC private key"

    invoke-direct {p1, v0}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    throw p1
.end method

.method public final c()Ljava/lang/String;
    .locals 1

    const-string v0, "-----END EC PRIVATE KEY-----"

    return-object v0
.end method

.method public final d()Ljava/lang/String;
    .locals 1

    const-string v0, "-----BEGIN EC PRIVATE KEY-----"

    return-object v0
.end method
