.class public final Lr/a;
.super Lr/d;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lr/a$b;
    }
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Lr/d<",
        "Ljava/security/interfaces/DSAPublicKey;",
        "Ljava/security/interfaces/DSAPrivateKey;",
        ">;"
    }
.end annotation


# direct methods
.method public constructor <init>()V
    .locals 3

    const-class v0, Ljava/security/interfaces/DSAPrivateKey;

    const-string v1, "SHA1WithDSA"

    const-string v2, "ssh-dss"

    invoke-direct {p0, v1, v2, v0}, Lr/d;-><init>(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Class;)V

    return-void
.end method


# virtual methods
.method public final a([B)Ljava/security/PublicKey;
    .locals 5

    .line 1
    new-instance v0, Lq/c;

    invoke-direct {v0, p1}, Lq/c;-><init>([B)V

    invoke-virtual {v0}, Lq/c;->g()Ljava/lang/String;

    move-result-object p1

    .line 2
    iget-object v1, p0, Lr/d;->b:Ljava/lang/String;

    .line 3
    invoke-virtual {p1, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_1

    invoke-virtual {v0}, Lq/c;->e()Ljava/math/BigInteger;

    move-result-object p1

    invoke-virtual {v0}, Lq/c;->e()Ljava/math/BigInteger;

    move-result-object v1

    invoke-virtual {v0}, Lq/c;->e()Ljava/math/BigInteger;

    move-result-object v2

    invoke-virtual {v0}, Lq/c;->e()Ljava/math/BigInteger;

    move-result-object v3

    .line 4
    iget v4, v0, Lq/c;->c:I

    iget v0, v0, Lq/c;->b:I

    sub-int/2addr v4, v0

    if-nez v4, :cond_0

    :try_start_0
    const-string v0, "DSA"

    .line 5
    invoke-static {v0}, Ljava/security/KeyFactory;->getInstance(Ljava/lang/String;)Ljava/security/KeyFactory;

    move-result-object v0

    new-instance v4, Ljava/security/spec/DSAPublicKeySpec;

    invoke-direct {v4, v3, p1, v1, v2}, Ljava/security/spec/DSAPublicKeySpec;-><init>(Ljava/math/BigInteger;Ljava/math/BigInteger;Ljava/math/BigInteger;Ljava/math/BigInteger;)V

    invoke-virtual {v0, v4}, Ljava/security/KeyFactory;->generatePublic(Ljava/security/spec/KeySpec;)Ljava/security/PublicKey;

    move-result-object p1

    check-cast p1, Ljava/security/interfaces/DSAPublicKey;
    :try_end_0
    .catch Ljava/security/GeneralSecurityException; {:try_start_0 .. :try_end_0} :catch_0

    return-object p1

    :catch_0
    move-exception p1

    new-instance v0, Ljava/io/IOException;

    const-string v1, "Could not generate DSA Key"

    invoke-direct {v0, v1, p1}, Ljava/io/IOException;-><init>(Ljava/lang/String;Ljava/lang/Throwable;)V

    throw v0

    :cond_0
    new-instance p1, Ljava/io/IOException;

    const-string v0, "Padding in DSA public key!"

    invoke-direct {p1, v0}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    throw p1

    :cond_1
    new-instance v0, Lm/g;

    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const-string v2, "Unsupported key format found \'"

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string p1, "\' while expecting "

    invoke-virtual {v1, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 6
    iget-object p1, p0, Lr/d;->b:Ljava/lang/String;

    .line 7
    invoke-virtual {v1, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    invoke-direct {v0, p1}, Lm/g;-><init>(Ljava/lang/String;)V

    throw v0
.end method

.method public final b([B)[B
    .locals 11

    array-length v0, p1

    const-string v1, "Peer sent corrupt signature"

    const/16 v2, 0x28

    if-ne v0, v2, :cond_0

    goto :goto_0

    :cond_0
    new-instance v0, Lq/c;

    invoke-direct {v0, p1}, Lq/c;-><init>([B)V

    invoke-virtual {v0}, Lq/c;->g()Ljava/lang/String;

    move-result-object p1

    .line 1
    iget-object v3, p0, Lr/d;->b:Ljava/lang/String;

    .line 2
    invoke-virtual {p1, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p1

    if-eqz p1, :cond_7

    invoke-virtual {v0}, Lq/c;->c()[B

    move-result-object p1

    array-length v3, p1

    if-ne v3, v2, :cond_6

    .line 3
    iget v3, v0, Lq/c;->c:I

    iget v0, v0, Lq/c;->b:I

    sub-int/2addr v3, v0

    if-nez v3, :cond_5

    :goto_0
    const/4 v0, 0x0

    .line 4
    aget-byte v3, p1, v0

    const/4 v4, 0x2

    const/4 v5, 0x3

    const/4 v6, 0x1

    if-nez v3, :cond_1

    aget-byte v3, p1, v6

    if-nez v3, :cond_1

    aget-byte v3, p1, v4

    if-nez v3, :cond_1

    aget-byte v3, p1, v0

    shl-int/lit8 v3, v3, 0x18

    const/high16 v7, -0x1000000

    and-int/2addr v3, v7

    aget-byte v8, p1, v6

    shl-int/lit8 v8, v8, 0x10

    const/high16 v9, 0xff0000

    and-int/2addr v8, v9

    or-int/2addr v3, v8

    aget-byte v8, p1, v4

    shl-int/lit8 v8, v8, 0x8

    const v10, 0xff00

    and-int/2addr v8, v10

    or-int/2addr v3, v8

    aget-byte v8, p1, v5

    and-int/lit16 v8, v8, 0xff

    or-int/2addr v3, v8

    add-int/lit8 v3, v3, 0x4

    add-int/lit8 v8, v3, 0x1

    aget-byte v3, p1, v3

    shl-int/lit8 v3, v3, 0x18

    and-int/2addr v3, v7

    add-int/lit8 v7, v8, 0x1

    aget-byte v8, p1, v8

    shl-int/lit8 v8, v8, 0x10

    and-int/2addr v8, v9

    or-int/2addr v3, v8

    add-int/lit8 v8, v7, 0x1

    aget-byte v7, p1, v7

    shl-int/lit8 v7, v7, 0x8

    and-int/2addr v7, v10

    or-int/2addr v3, v7

    add-int/lit8 v7, v8, 0x1

    aget-byte v8, p1, v8

    and-int/lit16 v8, v8, 0xff

    or-int/2addr v3, v8

    new-array v8, v3, [B

    invoke-static {p1, v7, v8, v0, v3}, Ljava/lang/System;->arraycopy(Ljava/lang/Object;ILjava/lang/Object;II)V

    move-object p1, v8

    :cond_1
    aget-byte v3, p1, v0

    and-int/lit16 v3, v3, 0x80

    if-eqz v3, :cond_2

    const/4 v3, 0x1

    goto :goto_1

    :cond_2
    const/4 v3, 0x0

    :goto_1
    const/16 v7, 0x14

    aget-byte v8, p1, v7

    and-int/lit16 v8, v8, 0x80

    if-eqz v8, :cond_3

    const/4 v8, 0x1

    goto :goto_2

    :cond_3
    const/4 v8, 0x0

    :goto_2
    array-length v9, p1

    const/4 v10, 0x6

    invoke-static {v9, v10, v3, v8}, Lcom/trilead/ssh2/crypto/digest/a;->a(IIII)I

    move-result v9

    new-array v9, v9, [B

    const/16 v10, 0x30

    aput-byte v10, v9, v0

    array-length v10, p1

    if-ne v10, v2, :cond_4

    const/16 v1, 0x2c

    aput-byte v1, v9, v6

    aget-byte v1, v9, v6

    add-int/2addr v1, v3

    int-to-byte v1, v1

    aput-byte v1, v9, v6

    aget-byte v1, v9, v6

    add-int/2addr v1, v8

    int-to-byte v1, v1

    aput-byte v1, v9, v6

    aput-byte v4, v9, v4

    aput-byte v7, v9, v5

    aget-byte v1, v9, v5

    add-int/2addr v1, v3

    int-to-byte v1, v1

    aput-byte v1, v9, v5

    add-int/lit8 v3, v3, 0x4

    invoke-static {p1, v0, v9, v3, v7}, Ljava/lang/System;->arraycopy(Ljava/lang/Object;ILjava/lang/Object;II)V

    aget-byte v0, v9, v5

    add-int/lit8 v0, v0, 0x4

    aput-byte v4, v9, v0

    aget-byte v0, v9, v5

    add-int/lit8 v0, v0, 0x5

    aput-byte v7, v9, v0

    aget-byte v0, v9, v5

    add-int/lit8 v0, v0, 0x5

    aget-byte v1, v9, v0

    add-int/2addr v1, v8

    int-to-byte v1, v1

    aput-byte v1, v9, v0

    aget-byte v0, v9, v5

    add-int/lit8 v0, v0, 0x6

    add-int/2addr v0, v8

    invoke-static {p1, v7, v9, v0, v7}, Ljava/lang/System;->arraycopy(Ljava/lang/Object;ILjava/lang/Object;II)V

    return-object v9

    :cond_4
    new-instance p1, Ljava/io/IOException;

    invoke-direct {p1, v1}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    throw p1

    :cond_5
    new-instance p1, Ljava/io/IOException;

    const-string v0, "Padding in DSA signature!"

    invoke-direct {p1, v0}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    throw p1

    :cond_6
    new-instance p1, Ljava/io/IOException;

    invoke-direct {p1, v1}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    throw p1

    :cond_7
    new-instance p1, Ljava/io/IOException;

    const-string v0, "Peer sent wrong signature format"

    invoke-direct {p1, v0}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    throw p1
.end method

.method public final c(Ljava/security/PublicKey;)[B
    .locals 3

    check-cast p1, Ljava/security/interfaces/DSAPublicKey;

    .line 1
    invoke-interface {p1}, Ljava/security/interfaces/DSAKey;->getParams()Ljava/security/interfaces/DSAParams;

    move-result-object v0

    new-instance v1, Lq/b;

    invoke-direct {v1}, Lq/b;-><init>()V

    .line 2
    iget-object v2, p0, Lr/d;->b:Ljava/lang/String;

    .line 3
    invoke-virtual {v1, v2}, Lq/b;->h(Ljava/lang/String;)V

    invoke-interface {v0}, Ljava/security/interfaces/DSAParams;->getP()Ljava/math/BigInteger;

    move-result-object v2

    invoke-virtual {v1, v2}, Lq/b;->f(Ljava/math/BigInteger;)V

    invoke-interface {v0}, Ljava/security/interfaces/DSAParams;->getQ()Ljava/math/BigInteger;

    move-result-object v2

    invoke-virtual {v1, v2}, Lq/b;->f(Ljava/math/BigInteger;)V

    invoke-interface {v0}, Ljava/security/interfaces/DSAParams;->getG()Ljava/math/BigInteger;

    move-result-object v0

    invoke-virtual {v1, v0}, Lq/b;->f(Ljava/math/BigInteger;)V

    invoke-interface {p1}, Ljava/security/interfaces/DSAPublicKey;->getY()Ljava/math/BigInteger;

    move-result-object p1

    invoke-virtual {v1, p1}, Lq/b;->f(Ljava/math/BigInteger;)V

    invoke-virtual {v1}, Lq/b;->a()[B

    move-result-object p1

    return-object p1
.end method

.method public final d([B)[B
    .locals 10

    new-instance v0, Lq/b;

    invoke-direct {v0}, Lq/b;-><init>()V

    .line 1
    iget-object v1, p0, Lr/d;->b:Ljava/lang/String;

    .line 2
    invoke-virtual {v0, v1}, Lq/b;->h(Ljava/lang/String;)V

    const/4 v1, 0x3

    const/4 v2, 0x4

    aget-byte v1, p1, v1

    and-int/lit16 v1, v1, 0xff

    new-array v3, v1, [B

    const/4 v4, 0x0

    invoke-static {p1, v2, v3, v4, v1}, Ljava/lang/System;->arraycopy(Ljava/lang/Object;ILjava/lang/Object;II)V

    add-int/lit8 v5, v1, 0x1

    add-int/2addr v5, v2

    add-int/lit8 v2, v5, 0x1

    aget-byte v5, p1, v5

    and-int/lit16 v5, v5, 0xff

    new-array v6, v5, [B

    invoke-static {p1, v2, v6, v4, v5}, Ljava/lang/System;->arraycopy(Ljava/lang/Object;ILjava/lang/Object;II)V

    const/16 p1, 0x28

    new-array v2, p1, [B

    const/16 v7, 0x14

    if-ge v1, v7, :cond_0

    move v8, v1

    goto :goto_0

    :cond_0
    const/16 v8, 0x14

    :goto_0
    if-ge v5, v7, :cond_1

    move v7, v5

    :cond_1
    sub-int/2addr v1, v8

    rsub-int/lit8 v9, v8, 0x14

    invoke-static {v3, v1, v2, v9, v8}, Ljava/lang/System;->arraycopy(Ljava/lang/Object;ILjava/lang/Object;II)V

    sub-int/2addr v5, v7

    rsub-int/lit8 v1, v7, 0x28

    invoke-static {v6, v5, v2, v1, v7}, Ljava/lang/System;->arraycopy(Ljava/lang/Object;ILjava/lang/Object;II)V

    invoke-virtual {v0, v2, v4, p1}, Lq/b;->i([BII)V

    invoke-virtual {v0}, Lq/b;->a()[B

    move-result-object p1

    return-object p1
.end method

.method public final e()Ljava/util/List;
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/List<",
            "Lcom/trilead/ssh2/crypto/CertificateDecoder;",
            ">;"
        }
    .end annotation

    const/4 v0, 0x2

    new-array v0, v0, [Lcom/trilead/ssh2/crypto/CertificateDecoder;

    new-instance v1, Lr/a$b;

    .line 1
    invoke-direct {v1}, Lr/a$b;-><init>()V

    const/4 v2, 0x0

    aput-object v1, v0, v2

    .line 2
    new-instance v1, Lr/a$a;

    .line 3
    iget-object v2, p0, Lr/d;->b:Ljava/lang/String;

    .line 4
    invoke-direct {v1, v2}, Lr/a$a;-><init>(Ljava/lang/String;)V

    const/4 v2, 0x1

    aput-object v1, v0, v2

    invoke-static {v0}, Ljava/util/Arrays;->asList([Ljava/lang/Object;)Ljava/util/List;

    move-result-object v0

    return-object v0
.end method
