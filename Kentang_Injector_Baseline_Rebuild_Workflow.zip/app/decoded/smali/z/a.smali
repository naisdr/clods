.class public final Lz/a;
.super Ljava/lang/Object;
.source "SourceFile"


# instance fields
.field public a:[B

.field public b:I

.field public c:La0/a;

.field public d:[B


# direct methods
.method public constructor <init>(Lx/a;)V
    .locals 1

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    new-instance v0, La0/a;

    invoke-direct {v0, p1}, La0/a;-><init>(Lx/a;)V

    iput-object v0, p0, Lz/a;->c:La0/a;

    .line 3
    iget p1, v0, La0/a;->b:I

    .line 4
    new-array p1, p1, [B

    iput-object p1, p0, Lz/a;->d:[B

    return-void
.end method
