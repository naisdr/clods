.class public final Lc0/f;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field public final synthetic a:Lg0/a;

.field public final synthetic b:Lc0/g;


# direct methods
.method public constructor <init>(Lc0/g;Lg0/a;)V
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()V"
        }
    .end annotation

    iput-object p1, p0, Lc0/f;->b:Lc0/g;

    iput-object p2, p0, Lc0/f;->a:Lg0/a;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final run()V
    .locals 3

    iget-object v0, p0, Lc0/f;->a:Lg0/a;

    sget-object v1, Lg0/a;->b:Lg0/a;

    invoke-virtual {v0, v1}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    move-result v0

    const/4 v1, 0x0

    if-eqz v0, :cond_0

    :goto_0
    iget-object v0, p0, Lc0/f;->b:Lc0/g;

    invoke-static {v0, v1}, Lc0/g;->b(Lc0/g;Z)V

    goto :goto_1

    :cond_0
    iget-object v0, p0, Lc0/f;->a:Lg0/a;

    sget-object v2, Lg0/a;->c:Lg0/a;

    invoke-virtual {v0, v2}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_1

    goto :goto_0

    :cond_1
    iget-object v0, p0, Lc0/f;->a:Lg0/a;

    sget-object v2, Lg0/a;->a:Lg0/a;

    invoke-virtual {v0, v2}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    move-result v0

    const/4 v2, 0x1

    if-eqz v0, :cond_2

    iget-object v0, p0, Lc0/f;->b:Lc0/g;

    .line 1
    iget-object v0, v0, Lc0/g;->p:Landroid/preference/SwitchPreference;

    .line 2
    invoke-virtual {v0, v2}, Landroid/preference/TwoStatePreference;->setChecked(Z)V

    goto :goto_0

    :cond_2
    iget-object v0, p0, Lc0/f;->b:Lc0/g;

    .line 3
    iget-object v0, v0, Lc0/g;->p:Landroid/preference/SwitchPreference;

    .line 4
    invoke-virtual {v0, v1}, Landroid/preference/TwoStatePreference;->setChecked(Z)V

    iget-object v0, p0, Lc0/f;->b:Lc0/g;

    invoke-static {v0, v2}, Lc0/g;->b(Lc0/g;Z)V

    :goto_1
    return-void
.end method
