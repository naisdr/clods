.class public abstract enum Lr/f$b;
.super Ljava/lang/Enum;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lr/f;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x4409
    name = "b"
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Enum<",
        "Lr/f$b;",
        ">;"
    }
.end annotation


# static fields
.field public static final enum d:Lr/f$b$a;

.field public static final enum e:Lr/f$b$b;

.field public static final enum f:Lr/f$b$c;

.field public static final enum g:Lr/f$b$d;

.field public static final enum h:Lr/f$b$e;

.field public static final enum i:Lr/f$b$f;

.field public static final synthetic j:[Lr/f$b;


# instance fields
.field public final a:[Ljava/lang/String;

.field public final b:I

.field public final c:I


# direct methods
.method public static constructor <clinit>()V
    .locals 8

    new-instance v0, Lr/f$b$a;

    const/4 v1, 0x0

    new-array v2, v1, [Ljava/lang/String;

    invoke-direct {v0, v2}, Lr/f$b$a;-><init>([Ljava/lang/String;)V

    sput-object v0, Lr/f$b;->d:Lr/f$b$a;

    new-instance v2, Lr/f$b$b;

    new-array v3, v1, [Ljava/lang/String;

    invoke-direct {v2, v3}, Lr/f$b$b;-><init>([Ljava/lang/String;)V

    sput-object v2, Lr/f$b;->e:Lr/f$b$b;

    new-instance v3, Lr/f$b$c;

    const-string v4, "aes128-cbc"

    filled-new-array {v4}, [Ljava/lang/String;

    move-result-object v4

    invoke-direct {v3, v4}, Lr/f$b$c;-><init>([Ljava/lang/String;)V

    sput-object v3, Lr/f$b;->f:Lr/f$b$c;

    new-instance v4, Lr/f$b$d;

    const-string v5, "aes192-cbc"

    filled-new-array {v5}, [Ljava/lang/String;

    move-result-object v5

    invoke-direct {v4, v5}, Lr/f$b$d;-><init>([Ljava/lang/String;)V

    sput-object v4, Lr/f$b;->g:Lr/f$b$d;

    new-instance v5, Lr/f$b$e;

    const-string v6, "aes256-cbc"

    filled-new-array {v6}, [Ljava/lang/String;

    move-result-object v6

    invoke-direct {v5, v6}, Lr/f$b$e;-><init>([Ljava/lang/String;)V

    sput-object v5, Lr/f$b;->h:Lr/f$b$e;

    new-instance v6, Lr/f$b$f;

    const-string v7, "aes256-ctr"

    filled-new-array {v7}, [Ljava/lang/String;

    move-result-object v7

    invoke-direct {v6, v7}, Lr/f$b$f;-><init>([Ljava/lang/String;)V

    sput-object v6, Lr/f$b;->i:Lr/f$b$f;

    const/4 v7, 0x6

    new-array v7, v7, [Lr/f$b;

    aput-object v0, v7, v1

    const/4 v0, 0x1

    aput-object v2, v7, v0

    const/4 v0, 0x2

    aput-object v3, v7, v0

    const/4 v0, 0x3

    aput-object v4, v7, v0

    const/4 v0, 0x4

    aput-object v5, v7, v0

    const/4 v0, 0x5

    aput-object v6, v7, v0

    sput-object v7, Lr/f$b;->j:[Lr/f$b;

    return-void
.end method

.method public constructor <init>(Ljava/lang/String;IIILjava/lang/String;[Ljava/lang/String;Lr/f$a;)V
    .locals 0

    invoke-direct {p0, p1, p2}, Ljava/lang/Enum;-><init>(Ljava/lang/String;I)V

    iput p3, p0, Lr/f$b;->b:I

    iput p4, p0, Lr/f$b;->c:I

    array-length p1, p6

    const/4 p2, 0x1

    add-int/2addr p1, p2

    new-array p1, p1, [Ljava/lang/String;

    const/4 p3, 0x0

    aput-object p5, p1, p3

    array-length p4, p6

    invoke-static {p6, p3, p1, p2, p4}, Ljava/lang/System;->arraycopy(Ljava/lang/Object;ILjava/lang/Object;II)V

    iput-object p1, p0, Lr/f$b;->a:[Ljava/lang/String;

    return-void
.end method

.method public static valueOf(Ljava/lang/String;)Lr/f$b;
    .locals 1

    const-class v0, Lr/f$b;

    invoke-static {v0, p0}, Ljava/lang/Enum;->valueOf(Ljava/lang/Class;Ljava/lang/String;)Ljava/lang/Enum;

    move-result-object p0

    check-cast p0, Lr/f$b;

    return-object p0
.end method

.method public static values()[Lr/f$b;
    .locals 1

    sget-object v0, Lr/f$b;->j:[Lr/f$b;

    invoke-virtual {v0}, [Lr/f$b;->clone()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, [Lr/f$b;

    return-object v0
.end method


# virtual methods
.method public abstract a([B[B)Lcom/trilead/ssh2/crypto/cipher/BlockCipher;
.end method
