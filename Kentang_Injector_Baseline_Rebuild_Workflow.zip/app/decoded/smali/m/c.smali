.class public final Lm/c;
.super Ljava/lang/Object;
.source "SourceFile"


# static fields
.field public static final o:La/b;


# instance fields
.field public a:Ljava/security/SecureRandom;

.field public b:Ln/a;

.field public c:Z

.field public d:Lo/c;

.field public e:Lcom/trilead/ssh2/crypto/CryptoWishList;

.field public f:La/b;

.field public final g:Ljava/lang/String;

.field public final h:Ljava/lang/String;

.field public final i:I

.field public j:Ls/i;

.field public k:Z

.field public l:Lm/j;

.field public m:Z

.field public n:Ljava/util/Vector;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/Vector<",
            "Lm/d;",
            ">;"
        }
    .end annotation
.end field


# direct methods
.method public static constructor <clinit>()V
    .locals 2

    const-class v0, Lm/c;

    .line 1
    new-instance v1, La/b;

    invoke-direct {v1, v0}, La/b;-><init>(Ljava/lang/Class;)V

    .line 2
    sput-object v1, Lm/c;->o:La/b;

    return-void
.end method

.method public constructor <init>(Ljava/lang/String;I)V
    .locals 2

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v0, 0x0

    iput-boolean v0, p0, Lm/c;->c:Z

    new-instance v1, Lcom/trilead/ssh2/crypto/CryptoWishList;

    invoke-direct {v1}, Lcom/trilead/ssh2/crypto/CryptoWishList;-><init>()V

    iput-object v1, p0, Lm/c;->e:Lcom/trilead/ssh2/crypto/CryptoWishList;

    new-instance v1, La/b;

    invoke-direct {v1}, La/b;-><init>()V

    iput-object v1, p0, Lm/c;->f:La/b;

    iput-boolean v0, p0, Lm/c;->k:Z

    const/4 v0, 0x0

    iput-object v0, p0, Lm/c;->l:Lm/j;

    new-instance v1, Ljava/util/Vector;

    invoke-direct {v1}, Ljava/util/Vector;-><init>()V

    iput-object v1, p0, Lm/c;->n:Ljava/util/Vector;

    iput-object p1, p0, Lm/c;->g:Ljava/lang/String;

    iput p2, p0, Lm/c;->i:I

    iput-object v0, p0, Lm/c;->h:Ljava/lang/String;

    return-void
.end method


# virtual methods
.method public final declared-synchronized a(Lm/d;)V
    .locals 1

    monitor-enter p0

    if-eqz p1, :cond_2

    :try_start_0
    iget-object v0, p0, Lm/c;->n:Ljava/util/Vector;

    invoke-virtual {v0, p1}, Ljava/util/Vector;->addElement(Ljava/lang/Object;)V

    iget-object p1, p0, Lm/c;->j:Ls/i;

    if-eqz p1, :cond_0

    iget-object v0, p0, Lm/c;->n:Ljava/util/Vector;

    .line 1
    monitor-enter p1
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_1

    :try_start_1
    invoke-virtual {v0}, Ljava/util/Vector;->clone()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/util/Vector;

    iput-object v0, p1, Ls/i;->o:Ljava/util/Vector;

    monitor-exit p1

    goto :goto_0

    :catchall_0
    move-exception v0

    monitor-exit p1
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    :try_start_2
    throw v0

    .line 2
    :cond_0
    :goto_0
    iget-object p1, p0, Lm/c;->b:Ln/a;

    if-eqz p1, :cond_1

    iget-object v0, p0, Lm/c;->n:Ljava/util/Vector;

    invoke-virtual {p1, v0}, Ln/a;->h(Ljava/util/Vector;)V
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_1

    :cond_1
    monitor-exit p0

    return-void

    :cond_2
    :try_start_3
    new-instance p1, Ljava/lang/IllegalArgumentException;

    const-string v0, "cmon argument is null"

    invoke-direct {p1, v0}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw p1
    :try_end_3
    .catchall {:try_start_3 .. :try_end_3} :catchall_1

    :catchall_1
    move-exception p1

    monitor-exit p0

    throw p1
.end method

.method public final declared-synchronized b(Ljava/lang/String;Ljava/lang/String;)Z
    .locals 2

    monitor-enter p0

    :try_start_0
    iget-object v0, p0, Lm/c;->j:Ls/i;

    if-eqz v0, :cond_5

    iget-boolean v0, p0, Lm/c;->c:Z

    if-nez v0, :cond_4

    iget-object v0, p0, Lm/c;->b:Ln/a;

    if-nez v0, :cond_0

    new-instance v0, Ln/a;

    iget-object v1, p0, Lm/c;->j:Ls/i;

    invoke-direct {v0, v1}, Ln/a;-><init>(Ls/i;)V

    iput-object v0, p0, Lm/c;->b:Ln/a;

    iget-object v1, p0, Lm/c;->n:Ljava/util/Vector;

    invoke-virtual {v0, v1}, Ln/a;->h(Ljava/util/Vector;)V

    :cond_0
    iget-object v0, p0, Lm/c;->d:Lo/c;

    if-nez v0, :cond_1

    new-instance v0, Lo/c;

    iget-object v1, p0, Lm/c;->j:Ls/i;

    invoke-direct {v0, v1}, Lo/c;-><init>(Ls/i;)V

    iput-object v0, p0, Lm/c;->d:Lo/c;

    :cond_1
    if-eqz p1, :cond_3

    if-eqz p2, :cond_2

    iget-object v0, p0, Lm/c;->b:Ln/a;

    invoke-virtual {v0, p1, p2}, Ln/a;->c(Ljava/lang/String;Ljava/lang/String;)Z

    move-result p1

    iput-boolean p1, p0, Lm/c;->c:Z
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    monitor-exit p0

    return p1

    :cond_2
    :try_start_1
    new-instance p1, Ljava/lang/IllegalArgumentException;

    const-string p2, "password argument is null"

    invoke-direct {p1, p2}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw p1

    :cond_3
    new-instance p1, Ljava/lang/IllegalArgumentException;

    const-string p2, "user argument is null"

    invoke-direct {p1, p2}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw p1

    :cond_4
    new-instance p1, Ljava/lang/IllegalStateException;

    const-string p2, "Connection is already authenticated!"

    invoke-direct {p1, p2}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    throw p1

    :cond_5
    new-instance p1, Ljava/lang/IllegalStateException;

    const-string p2, "Connection is not established!"

    invoke-direct {p1, p2}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    throw p1
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    :catchall_0
    move-exception p1

    monitor-exit p0

    throw p1
.end method

.method public final declared-synchronized c(Ljava/lang/String;Ljava/io/File;Ljava/lang/String;)Z
    .locals 4

    monitor-enter p0

    const/16 v0, 0x100

    :try_start_0
    new-array v0, v0, [C

    new-instance v1, Ljava/io/CharArrayWriter;

    invoke-direct {v1}, Ljava/io/CharArrayWriter;-><init>()V

    new-instance v2, Ljava/io/FileReader;

    invoke-direct {v2, p2}, Ljava/io/FileReader;-><init>(Ljava/io/File;)V

    :goto_0
    invoke-virtual {v2, v0}, Ljava/io/Reader;->read([C)I

    move-result p2

    if-gez p2, :cond_0

    invoke-virtual {v2}, Ljava/io/Reader;->close()V

    invoke-virtual {v1}, Ljava/io/CharArrayWriter;->toCharArray()[C

    move-result-object p2

    invoke-virtual {p0, p1, p2, p3}, Lm/c;->d(Ljava/lang/String;[CLjava/lang/String;)Z

    move-result p1
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    monitor-exit p0

    return p1

    :cond_0
    const/4 v3, 0x0

    :try_start_1
    invoke-virtual {v1, v0, v3, p2}, Ljava/io/CharArrayWriter;->write([CII)V
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    goto :goto_0

    :catchall_0
    move-exception p1

    monitor-exit p0

    throw p1
.end method

.method public final declared-synchronized d(Ljava/lang/String;[CLjava/lang/String;)Z
    .locals 2

    monitor-enter p0

    :try_start_0
    iget-object v0, p0, Lm/c;->j:Ls/i;

    if-eqz v0, :cond_5

    iget-boolean v0, p0, Lm/c;->c:Z

    if-nez v0, :cond_4

    iget-object v0, p0, Lm/c;->b:Ln/a;

    if-nez v0, :cond_0

    new-instance v0, Ln/a;

    iget-object v1, p0, Lm/c;->j:Ls/i;

    invoke-direct {v0, v1}, Ln/a;-><init>(Ls/i;)V

    iput-object v0, p0, Lm/c;->b:Ln/a;

    iget-object v1, p0, Lm/c;->n:Ljava/util/Vector;

    invoke-virtual {v0, v1}, Ln/a;->h(Ljava/util/Vector;)V

    :cond_0
    iget-object v0, p0, Lm/c;->d:Lo/c;

    if-nez v0, :cond_1

    new-instance v0, Lo/c;

    iget-object v1, p0, Lm/c;->j:Ls/i;

    invoke-direct {v0, v1}, Lo/c;-><init>(Ls/i;)V

    iput-object v0, p0, Lm/c;->d:Lo/c;

    :cond_1
    if-eqz p1, :cond_3

    if-eqz p2, :cond_2

    iget-object v0, p0, Lm/c;->b:Ln/a;

    invoke-virtual {p0}, Lm/c;->i()Ljava/security/SecureRandom;

    move-result-object v1

    invoke-virtual {v0, p1, p2, p3, v1}, Ln/a;->d(Ljava/lang/String;[CLjava/lang/String;Ljava/security/SecureRandom;)Z

    move-result p1

    iput-boolean p1, p0, Lm/c;->c:Z
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    monitor-exit p0

    return p1

    :cond_2
    :try_start_1
    new-instance p1, Ljava/lang/IllegalArgumentException;

    const-string p2, "pemPrivateKey argument is null"

    invoke-direct {p1, p2}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw p1

    :cond_3
    new-instance p1, Ljava/lang/IllegalArgumentException;

    const-string p2, "user argument is null"

    invoke-direct {p1, p2}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw p1

    :cond_4
    new-instance p1, Ljava/lang/IllegalStateException;

    const-string p2, "Connection is already authenticated!"

    invoke-direct {p1, p2}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    throw p1

    :cond_5
    new-instance p1, Ljava/lang/IllegalStateException;

    const-string p2, "Connection is not established!"

    invoke-direct {p1, p2}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    throw p1
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    :catchall_0
    move-exception p1

    monitor-exit p0

    throw p1
.end method

.method public final declared-synchronized e(Ljava/lang/Throwable;)V
    .locals 4

    monitor-enter p0

    :try_start_0
    iget-object v0, p0, Lm/c;->d:Lo/c;

    if-eqz v0, :cond_0

    invoke-virtual {v0}, Lo/c;->d()V

    :cond_0
    iget-object v0, p0, Lm/c;->j:Ls/i;

    const/4 v1, 0x0

    const/4 v2, 0x0

    if-eqz v0, :cond_1

    const/4 v3, 0x1

    invoke-virtual {v0, p1, v3}, Ls/i;->b(Ljava/lang/Throwable;Z)V

    iput-object v2, p0, Lm/c;->j:Ls/i;

    :cond_1
    iput-object v2, p0, Lm/c;->b:Ln/a;

    iput-object v2, p0, Lm/c;->d:Lo/c;

    iput-boolean v1, p0, Lm/c;->c:Z
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    monitor-exit p0

    return-void

    :catchall_0
    move-exception p1

    monitor-exit p0

    throw p1
.end method

.method public final f(Lm/k;)Ll/e;
    .locals 14

    .line 1
    iget-object v0, p0, Lm/c;->j:Ls/i;

    if-nez v0, :cond_7

    new-instance v0, Lm/b;

    invoke-direct {v0}, Lm/b;-><init>()V

    new-instance v1, Ls/i;

    iget-object v2, p0, Lm/c;->g:Ljava/lang/String;

    iget v3, p0, Lm/c;->i:I

    iget-object v4, p0, Lm/c;->h:Ljava/lang/String;

    invoke-direct {v1, v2, v3, v4}, Ls/i;-><init>(Ljava/lang/String;ILjava/lang/String;)V

    iput-object v1, p0, Lm/c;->j:Ls/i;

    iget-object v2, p0, Lm/c;->n:Ljava/util/Vector;

    .line 2
    monitor-enter v1

    :try_start_0
    invoke-virtual {v2}, Ljava/util/Vector;->clone()Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Ljava/util/Vector;

    iput-object v2, v1, Ls/i;->o:Ljava/util/Vector;

    monitor-exit v1
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_6

    .line 3
    iget-boolean v1, p0, Lm/c;->m:Z

    if-nez v1, :cond_0

    iget-object v1, p0, Lm/c;->e:Lcom/trilead/ssh2/crypto/CryptoWishList;

    invoke-static {v1}, Ljava/util/Objects;->requireNonNull(Ljava/lang/Object;)Ljava/lang/Object;

    iget-object v1, p0, Lm/c;->e:Lcom/trilead/ssh2/crypto/CryptoWishList;

    invoke-static {v1}, Ljava/util/Objects;->requireNonNull(Ljava/lang/Object;)Ljava/lang/Object;

    :cond_0
    iget-object v2, p0, Lm/c;->j:Ls/i;

    monitor-enter v2

    :try_start_1
    monitor-exit v2
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_5

    const/4 v1, 0x0

    const/4 v2, 0x1

    :try_start_2
    new-instance v3, Lm/a;

    invoke-direct {v3, p0, v0}, Lm/a;-><init>(Lm/c;Lm/b;)V

    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v4

    const/16 v6, 0x4e20

    int-to-long v6, v6

    add-long/2addr v4, v6

    sget-object v6, Lt/a;->a:Lt/a$a;

    .line 4
    new-instance v6, Lt/a$b;

    invoke-direct {v6}, Lt/a$b;-><init>()V

    .line 5
    iput-object v3, v6, Lt/a$b;->a:Ljava/lang/Runnable;

    .line 6
    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v7

    sub-long/2addr v4, v7

    const-wide/16 v7, 0x0

    cmp-long v3, v4, v7

    if-gez v3, :cond_1

    move-wide v4, v7

    :cond_1
    sget-object v3, Lt/a;->b:Ljava/util/concurrent/ScheduledExecutorService;

    sget-object v7, Ljava/util/concurrent/TimeUnit;->MILLISECONDS:Ljava/util/concurrent/TimeUnit;

    invoke-interface {v3, v6, v4, v5, v7}, Ljava/util/concurrent/ScheduledExecutorService;->schedule(Ljava/lang/Runnable;JLjava/util/concurrent/TimeUnit;)Ljava/util/concurrent/ScheduledFuture;
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_2

    .line 7
    :try_start_3
    iget-object v8, p0, Lm/c;->j:Ls/i;

    iget-object v9, p0, Lm/c;->e:Lcom/trilead/ssh2/crypto/CryptoWishList;

    iget-object v11, p0, Lm/c;->f:La/b;

    invoke-virtual {p0}, Lm/c;->i()Ljava/security/SecureRandom;

    move-result-object v12

    iget-object v13, p0, Lm/c;->l:Lm/j;

    move-object v10, p1

    invoke-virtual/range {v8 .. v13}, Ls/i;->g(Lcom/trilead/ssh2/crypto/CryptoWishList;Lm/k;La/b;Ljava/security/SecureRandom;Lm/j;)V
    :try_end_3
    .catch Ljava/net/SocketTimeoutException; {:try_start_3 .. :try_end_3} :catch_0
    .catchall {:try_start_3 .. :try_end_3} :catchall_1

    :try_start_4
    iget-object p1, p0, Lm/c;->j:Ls/i;

    iget-boolean v1, p0, Lm/c;->k:Z

    .line 8
    iget-object p1, p1, Ls/i;->f:Ljava/net/Socket;

    invoke-virtual {p1, v1}, Ljava/net/Socket;->setTcpNoDelay(Z)V

    .line 9
    iget-object p1, p0, Lm/c;->j:Ls/i;

    invoke-virtual {p1}, Ls/i;->e()Ll/e;

    move-result-object p1
    :try_end_4
    .catchall {:try_start_4 .. :try_end_4} :catchall_1

    .line 10
    :try_start_5
    iput-boolean v2, v6, Lt/a$b;->b:Z

    .line 11
    monitor-enter v0
    :try_end_5
    .catch Ljava/net/SocketTimeoutException; {:try_start_5 .. :try_end_5} :catch_2
    .catch Ljava/io/IOException; {:try_start_5 .. :try_end_5} :catch_1

    :try_start_6
    iget-boolean v1, v0, Lm/b;->b:Z

    if-nez v1, :cond_2

    iput-boolean v2, v0, Lm/b;->a:Z

    monitor-exit v0

    return-object p1

    :cond_2
    new-instance p1, Ljava/io/IOException;

    const-string v1, "This exception will be replaced by the one below =)"

    invoke-direct {p1, v1}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    throw p1

    :catchall_0
    move-exception p1

    monitor-exit v0
    :try_end_6
    .catchall {:try_start_6 .. :try_end_6} :catchall_0

    :try_start_7
    throw p1
    :try_end_7
    .catch Ljava/net/SocketTimeoutException; {:try_start_7 .. :try_end_7} :catch_2
    .catch Ljava/io/IOException; {:try_start_7 .. :try_end_7} :catch_1

    :catchall_1
    move-exception p1

    goto :goto_0

    :catch_0
    move-exception p1

    :try_start_8
    new-instance v1, Ljava/net/SocketTimeoutException;

    const-string v3, "The connect() operation on the socket timed out."

    invoke-direct {v1, v3}, Ljava/net/SocketTimeoutException;-><init>(Ljava/lang/String;)V

    invoke-virtual {v1, p1}, Ljava/lang/Throwable;->initCause(Ljava/lang/Throwable;)Ljava/lang/Throwable;

    move-result-object p1

    check-cast p1, Ljava/net/SocketTimeoutException;

    throw p1
    :try_end_8
    .catchall {:try_start_8 .. :try_end_8} :catchall_1

    :goto_0
    move-object v1, v6

    goto :goto_1

    :catchall_2
    move-exception p1

    :goto_1
    if-eqz v1, :cond_4

    :try_start_9
    sget-object v3, Lt/a;->a:Lt/a$a;

    .line 12
    iput-boolean v2, v1, Lt/a$b;->b:Z

    .line 13
    monitor-enter v0
    :try_end_9
    .catch Ljava/net/SocketTimeoutException; {:try_start_9 .. :try_end_9} :catch_2
    .catch Ljava/io/IOException; {:try_start_9 .. :try_end_9} :catch_1

    :try_start_a
    iget-boolean v1, v0, Lm/b;->b:Z

    if-eqz v1, :cond_3

    new-instance p1, Ljava/io/IOException;

    const-string v1, "This exception will be replaced by the one below =)"

    invoke-direct {p1, v1}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    throw p1

    :cond_3
    iput-boolean v2, v0, Lm/b;->a:Z

    monitor-exit v0

    goto :goto_2

    :catchall_3
    move-exception p1

    monitor-exit v0
    :try_end_a
    .catchall {:try_start_a .. :try_end_a} :catchall_3

    :try_start_b
    throw p1

    :cond_4
    :goto_2
    throw p1
    :try_end_b
    .catch Ljava/net/SocketTimeoutException; {:try_start_b .. :try_end_b} :catch_2
    .catch Ljava/io/IOException; {:try_start_b .. :try_end_b} :catch_1

    :catch_1
    move-exception p1

    new-instance v1, Ljava/lang/Throwable;

    const-string v2, "There was a problem during connect."

    invoke-direct {v1, v2}, Ljava/lang/Throwable;-><init>(Ljava/lang/String;)V

    invoke-virtual {v1, p1}, Ljava/lang/Throwable;->initCause(Ljava/lang/Throwable;)Ljava/lang/Throwable;

    move-result-object v1

    invoke-virtual {p0, v1}, Lm/c;->e(Ljava/lang/Throwable;)V

    monitor-enter v0

    :try_start_c
    iget-boolean v1, v0, Lm/b;->b:Z

    if-nez v1, :cond_6

    monitor-exit v0
    :try_end_c
    .catchall {:try_start_c .. :try_end_c} :catchall_4

    instance-of v0, p1, Lm/f;

    if-eqz v0, :cond_5

    throw p1

    :cond_5
    new-instance v0, Ljava/io/IOException;

    const-string v1, "There was a problem while connecting to "

    .line 14
    invoke-static {v1}, Lcom/trilead/ssh2/crypto/digest/a;->e(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    .line 15
    iget-object v2, p0, Lm/c;->g:Ljava/lang/String;

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v2, ":"

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget v2, p0, Lm/c;->i:I

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-direct {v0, v1}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    invoke-virtual {v0, p1}, Ljava/lang/Throwable;->initCause(Ljava/lang/Throwable;)Ljava/lang/Throwable;

    move-result-object p1

    check-cast p1, Ljava/io/IOException;

    throw p1

    :cond_6
    :try_start_d
    new-instance p1, Ljava/net/SocketTimeoutException;

    const-string v1, "The kexTimeout (20000 ms) expired."

    invoke-direct {p1, v1}, Ljava/net/SocketTimeoutException;-><init>(Ljava/lang/String;)V

    throw p1

    :catchall_4
    move-exception p1

    monitor-exit v0
    :try_end_d
    .catchall {:try_start_d .. :try_end_d} :catchall_4

    throw p1

    :catch_2
    move-exception p1

    throw p1

    :catchall_5
    move-exception p1

    :try_start_e
    monitor-exit v2
    :try_end_e
    .catchall {:try_start_e .. :try_end_e} :catchall_5

    throw p1

    :catchall_6
    move-exception p1

    .line 16
    :try_start_f
    monitor-exit v1
    :try_end_f
    .catchall {:try_start_f .. :try_end_f} :catchall_6

    throw p1

    .line 17
    :cond_7
    new-instance p1, Ljava/io/IOException;

    const-string v0, "Connection to "

    .line 18
    invoke-static {v0}, Lcom/trilead/ssh2/crypto/digest/a;->e(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    .line 19
    iget-object v1, p0, Lm/c;->g:Ljava/lang/String;

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v1, " is already in connected state!"

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-direct {p1, v0}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    throw p1
.end method

.method public final declared-synchronized g(II)Lm/e;
    .locals 2

    monitor-enter p0

    :try_start_0
    iget-object v0, p0, Lm/c;->j:Ls/i;

    if-eqz v0, :cond_1

    iget-boolean v0, p0, Lm/c;->c:Z

    if-eqz v0, :cond_0

    new-instance v0, Lm/e;

    iget-object v1, p0, Lm/c;->d:Lo/c;

    invoke-direct {v0, v1, p1, p2}, Lm/e;-><init>(Lo/c;II)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    monitor-exit p0

    return-object v0

    :cond_0
    :try_start_1
    new-instance p1, Ljava/lang/IllegalStateException;

    const-string p2, "Cannot forward ports, connection is not authenticated."

    invoke-direct {p1, p2}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    throw p1

    :cond_1
    new-instance p1, Ljava/lang/IllegalStateException;

    const-string p2, "Cannot forward ports, you need to establish a connection first."

    invoke-direct {p1, p2}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    throw p1
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    :catchall_0
    move-exception p1

    monitor-exit p0

    throw p1
.end method

.method public final declared-synchronized h(Ljava/lang/String;)Lm/i;
    .locals 2

    monitor-enter p0

    :try_start_0
    iget-object v0, p0, Lm/c;->j:Ls/i;

    if-eqz v0, :cond_1

    iget-boolean v0, p0, Lm/c;->c:Z

    if-eqz v0, :cond_0

    new-instance v0, Lm/i;

    iget-object v1, p0, Lm/c;->d:Lo/c;

    invoke-direct {v0, v1, p1}, Lm/i;-><init>(Lo/c;Ljava/lang/String;)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    monitor-exit p0

    return-object v0

    :cond_0
    :try_start_1
    new-instance p1, Ljava/lang/IllegalStateException;

    const-string v0, "Cannot forward ports, connection is not authenticated."

    invoke-direct {p1, v0}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    throw p1

    :cond_1
    new-instance p1, Ljava/lang/IllegalStateException;

    const-string v0, "Cannot forward ports, you need to establish a connection first."

    invoke-direct {p1, v0}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    throw p1
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    :catchall_0
    move-exception p1

    monitor-exit p0

    throw p1
.end method

.method public final i()Ljava/security/SecureRandom;
    .locals 1

    iget-object v0, p0, Lm/c;->a:Ljava/security/SecureRandom;

    if-nez v0, :cond_0

    :try_start_0
    const-string v0, "SHA1PRNG"

    .line 1
    invoke-static {v0}, Ljava/security/SecureRandom;->getInstance(Ljava/lang/String;)Ljava/security/SecureRandom;

    move-result-object v0
    :try_end_0
    .catch Ljava/security/NoSuchAlgorithmException; {:try_start_0 .. :try_end_0} :catch_0

    goto :goto_0

    :catch_0
    new-instance v0, Ljava/security/SecureRandom;

    invoke-direct {v0}, Ljava/security/SecureRandom;-><init>()V

    .line 2
    :goto_0
    iput-object v0, p0, Lm/c;->a:Ljava/security/SecureRandom;

    :cond_0
    iget-object v0, p0, Lm/c;->a:Ljava/security/SecureRandom;

    return-object v0
.end method

.method public final declared-synchronized j(Ljava/lang/String;)[Ljava/lang/String;
    .locals 2

    monitor-enter p0

    if-eqz p1, :cond_4

    :try_start_0
    iget-object v0, p0, Lm/c;->j:Ls/i;

    if-eqz v0, :cond_3

    iget-boolean v0, p0, Lm/c;->c:Z

    if-nez v0, :cond_2

    iget-object v0, p0, Lm/c;->b:Ln/a;

    if-nez v0, :cond_0

    new-instance v0, Ln/a;

    iget-object v1, p0, Lm/c;->j:Ls/i;

    invoke-direct {v0, v1}, Ln/a;-><init>(Ls/i;)V

    iput-object v0, p0, Lm/c;->b:Ln/a;

    iget-object v1, p0, Lm/c;->n:Ljava/util/Vector;

    invoke-virtual {v0, v1}, Ln/a;->h(Ljava/util/Vector;)V

    :cond_0
    iget-object v0, p0, Lm/c;->d:Lo/c;

    if-nez v0, :cond_1

    new-instance v0, Lo/c;

    iget-object v1, p0, Lm/c;->j:Ls/i;

    invoke-direct {v0, v1}, Lo/c;-><init>(Ls/i;)V

    iput-object v0, p0, Lm/c;->d:Lo/c;

    :cond_1
    iget-object v0, p0, Lm/c;->b:Ln/a;

    .line 1
    invoke-virtual {v0, p1}, Ln/a;->f(Ljava/lang/String;)Z

    iget-object p1, v0, Ln/a;->e:[Ljava/lang/String;
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 2
    monitor-exit p0

    return-object p1

    :cond_2
    :try_start_1
    new-instance p1, Ljava/lang/IllegalStateException;

    const-string v0, "Connection is already authenticated!"

    invoke-direct {p1, v0}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    throw p1

    :cond_3
    new-instance p1, Ljava/lang/IllegalStateException;

    const-string v0, "Connection is not established!"

    invoke-direct {p1, v0}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    throw p1

    :catchall_0
    move-exception p1

    goto :goto_0

    :cond_4
    new-instance p1, Ljava/lang/IllegalArgumentException;

    const-string v0, "user argument may not be NULL!"

    invoke-direct {p1, v0}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw p1
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    :goto_0
    monitor-exit p0

    throw p1
.end method

.method public final declared-synchronized k(Ljava/lang/String;Ljava/lang/String;)Z
    .locals 3

    monitor-enter p0

    :try_start_0
    invoke-virtual {p0, p1}, Lm/c;->j(Ljava/lang/String;)[Ljava/lang/String;

    move-result-object p1

    const/4 v0, 0x0

    const/4 v1, 0x0

    :goto_0
    array-length v2, p1

    if-ge v1, v2, :cond_1

    aget-object v2, p1, v1

    invoke-virtual {v2, p2}, Ljava/lang/String;->compareTo(Ljava/lang/String;)I

    move-result v2
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    if-nez v2, :cond_0

    monitor-exit p0

    const/4 p1, 0x1

    return p1

    :cond_0
    add-int/lit8 v1, v1, 0x1

    goto :goto_0

    :cond_1
    monitor-exit p0

    return v0

    :catchall_0
    move-exception p1

    monitor-exit p0

    throw p1
.end method

.method public final declared-synchronized l()V
    .locals 3

    monitor-enter p0

    :try_start_0
    iget-object v0, p0, Lm/c;->j:Ls/i;

    if-nez v0, :cond_0

    const/4 v0, 0x1

    iput-boolean v0, p0, Lm/c;->m:Z
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    monitor-exit p0

    return-void

    :cond_0
    :try_start_1
    new-instance v0, Ljava/io/IOException;

    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const-string v2, "Connection to "

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object v2, p0, Lm/c;->g:Ljava/lang/String;

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v2, " is already in connected state!"

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-direct {v0, v1}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    throw v0
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    :catchall_0
    move-exception v0

    monitor-exit p0

    throw v0
.end method

.method public final declared-synchronized m(Lm/j;)V
    .locals 0

    monitor-enter p0

    :try_start_0
    iput-object p1, p0, Lm/c;->l:Lm/j;
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    monitor-exit p0

    return-void

    :catchall_0
    move-exception p1

    monitor-exit p0

    throw p1
.end method
