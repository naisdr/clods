.class public final Lc0/g$b;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Landroid/content/DialogInterface$OnClickListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lc0/g;->f()V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1
    name = null
.end annotation


# instance fields
.field public final synthetic a:Lc0/g;


# direct methods
.method public constructor <init>(Lc0/g;)V
    .locals 0

    iput-object p1, p0, Lc0/g$b;->a:Lc0/g;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final onClick(Landroid/content/DialogInterface;I)V
    .locals 0

    iget-object p1, p0, Lc0/g$b;->a:Lc0/g;

    .line 1
    iget-object p1, p1, Lc0/g;->b:Ld0/c;

    .line 2
    invoke-static {p1}, Ljava/util/Objects;->requireNonNull(Ljava/lang/Object;)Ljava/lang/Object;

    .line 3
    invoke-static {}, Lg0/d;->b()V

    .line 4
    iget-object p1, p0, Lc0/g$b;->a:Lc0/g;

    .line 5
    invoke-virtual {p1}, Lc0/g;->f()V

    return-void
.end method
