.class public final Landroidx/recyclerview/widget/RecyclerView$x;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroidx/recyclerview/widget/RecyclerView;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1
    name = "x"
.end annotation


# instance fields
.field public a:I

.field public b:I

.field public c:Landroid/widget/OverScroller;

.field public d:Landroid/view/animation/Interpolator;

.field public e:Z

.field public f:Z

.field public final synthetic g:Landroidx/recyclerview/widget/RecyclerView;


# direct methods
.method public constructor <init>(Landroidx/recyclerview/widget/RecyclerView;)V
    .locals 2

    iput-object p1, p0, Landroidx/recyclerview/widget/RecyclerView$x;->g:Landroidx/recyclerview/widget/RecyclerView;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    sget-object v0, Landroidx/recyclerview/widget/RecyclerView;->x0:Landroidx/recyclerview/widget/RecyclerView$b;

    iput-object v0, p0, Landroidx/recyclerview/widget/RecyclerView$x;->d:Landroid/view/animation/Interpolator;

    const/4 v1, 0x0

    iput-boolean v1, p0, Landroidx/recyclerview/widget/RecyclerView$x;->e:Z

    iput-boolean v1, p0, Landroidx/recyclerview/widget/RecyclerView$x;->f:Z

    new-instance v1, Landroid/widget/OverScroller;

    invoke-virtual {p1}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object p1

    invoke-direct {v1, p1, v0}, Landroid/widget/OverScroller;-><init>(Landroid/content/Context;Landroid/view/animation/Interpolator;)V

    iput-object v1, p0, Landroidx/recyclerview/widget/RecyclerView$x;->c:Landroid/widget/OverScroller;

    return-void
.end method


# virtual methods
.method public final a()V
    .locals 2

    iget-boolean v0, p0, Landroidx/recyclerview/widget/RecyclerView$x;->e:Z

    if-eqz v0, :cond_0

    const/4 v0, 0x1

    iput-boolean v0, p0, Landroidx/recyclerview/widget/RecyclerView$x;->f:Z

    goto :goto_0

    .line 1
    :cond_0
    iget-object v0, p0, Landroidx/recyclerview/widget/RecyclerView$x;->g:Landroidx/recyclerview/widget/RecyclerView;

    invoke-virtual {v0, p0}, Landroid/view/View;->removeCallbacks(Ljava/lang/Runnable;)Z

    iget-object v0, p0, Landroidx/recyclerview/widget/RecyclerView$x;->g:Landroidx/recyclerview/widget/RecyclerView;

    sget-object v1, Le/e;->a:Ljava/lang/reflect/Field;

    .line 2
    invoke-virtual {v0, p0}, Landroid/view/View;->postOnAnimation(Ljava/lang/Runnable;)V

    :goto_0
    return-void
.end method

.method public final run()V
    .locals 15

    iget-object v0, p0, Landroidx/recyclerview/widget/RecyclerView$x;->g:Landroidx/recyclerview/widget/RecyclerView;

    iget-object v1, v0, Landroidx/recyclerview/widget/RecyclerView;->l:Landroidx/recyclerview/widget/RecyclerView$l;

    if-nez v1, :cond_0

    .line 1
    invoke-virtual {v0, p0}, Landroid/view/View;->removeCallbacks(Ljava/lang/Runnable;)Z

    iget-object v0, p0, Landroidx/recyclerview/widget/RecyclerView$x;->c:Landroid/widget/OverScroller;

    invoke-virtual {v0}, Landroid/widget/OverScroller;->abortAnimation()V

    return-void

    :cond_0
    const/4 v1, 0x0

    .line 2
    iput-boolean v1, p0, Landroidx/recyclerview/widget/RecyclerView$x;->f:Z

    const/4 v2, 0x1

    iput-boolean v2, p0, Landroidx/recyclerview/widget/RecyclerView$x;->e:Z

    invoke-virtual {v0}, Landroidx/recyclerview/widget/RecyclerView;->k()V

    iget-object v0, p0, Landroidx/recyclerview/widget/RecyclerView$x;->c:Landroid/widget/OverScroller;

    invoke-virtual {v0}, Landroid/widget/OverScroller;->computeScrollOffset()Z

    move-result v3

    if-eqz v3, :cond_19

    invoke-virtual {v0}, Landroid/widget/OverScroller;->getCurrX()I

    move-result v3

    invoke-virtual {v0}, Landroid/widget/OverScroller;->getCurrY()I

    move-result v4

    iget v5, p0, Landroidx/recyclerview/widget/RecyclerView$x;->a:I

    sub-int v5, v3, v5

    iget v6, p0, Landroidx/recyclerview/widget/RecyclerView$x;->b:I

    sub-int v6, v4, v6

    iput v3, p0, Landroidx/recyclerview/widget/RecyclerView$x;->a:I

    iput v4, p0, Landroidx/recyclerview/widget/RecyclerView$x;->b:I

    iget-object v3, p0, Landroidx/recyclerview/widget/RecyclerView$x;->g:Landroidx/recyclerview/widget/RecyclerView;

    iget-object v4, v3, Landroidx/recyclerview/widget/RecyclerView;->p0:[I

    aput v1, v4, v1

    aput v1, v4, v2

    invoke-virtual {v3, v5, v6, v4}, Landroidx/recyclerview/widget/RecyclerView;->q(II[I)Z

    move-result v3

    if-eqz v3, :cond_1

    iget-object v3, p0, Landroidx/recyclerview/widget/RecyclerView$x;->g:Landroidx/recyclerview/widget/RecyclerView;

    iget-object v3, v3, Landroidx/recyclerview/widget/RecyclerView;->p0:[I

    aget v4, v3, v1

    sub-int/2addr v5, v4

    aget v3, v3, v2

    sub-int/2addr v6, v3

    :cond_1
    iget-object v3, p0, Landroidx/recyclerview/widget/RecyclerView$x;->g:Landroidx/recyclerview/widget/RecyclerView;

    invoke-virtual {v3}, Landroid/view/View;->getOverScrollMode()I

    move-result v3

    const/4 v4, 0x2

    if-eq v3, v4, :cond_2

    iget-object v3, p0, Landroidx/recyclerview/widget/RecyclerView$x;->g:Landroidx/recyclerview/widget/RecyclerView;

    invoke-virtual {v3, v5, v6}, Landroidx/recyclerview/widget/RecyclerView;->j(II)V

    :cond_2
    iget-object v3, p0, Landroidx/recyclerview/widget/RecyclerView$x;->g:Landroidx/recyclerview/widget/RecyclerView;

    iget-object v7, v3, Landroidx/recyclerview/widget/RecyclerView;->k:Landroidx/recyclerview/widget/RecyclerView$d;

    if-eqz v7, :cond_3

    iget-object v7, v3, Landroidx/recyclerview/widget/RecyclerView;->p0:[I

    aput v1, v7, v1

    aput v1, v7, v2

    invoke-virtual {v3, v5, v6, v7}, Landroidx/recyclerview/widget/RecyclerView;->Z(II[I)V

    iget-object v3, p0, Landroidx/recyclerview/widget/RecyclerView$x;->g:Landroidx/recyclerview/widget/RecyclerView;

    iget-object v7, v3, Landroidx/recyclerview/widget/RecyclerView;->p0:[I

    aget v8, v7, v1

    aget v7, v7, v2

    sub-int/2addr v5, v8

    sub-int/2addr v6, v7

    iget-object v3, v3, Landroidx/recyclerview/widget/RecyclerView;->l:Landroidx/recyclerview/widget/RecyclerView$l;

    invoke-static {v3}, Ljava/util/Objects;->requireNonNull(Ljava/lang/Object;)Ljava/lang/Object;

    goto :goto_0

    :cond_3
    const/4 v7, 0x0

    const/4 v8, 0x0

    :goto_0
    iget-object v3, p0, Landroidx/recyclerview/widget/RecyclerView$x;->g:Landroidx/recyclerview/widget/RecyclerView;

    iget-object v3, v3, Landroidx/recyclerview/widget/RecyclerView;->n:Ljava/util/ArrayList;

    invoke-virtual {v3}, Ljava/util/ArrayList;->isEmpty()Z

    move-result v3

    if-nez v3, :cond_4

    iget-object v3, p0, Landroidx/recyclerview/widget/RecyclerView$x;->g:Landroidx/recyclerview/widget/RecyclerView;

    invoke-virtual {v3}, Landroid/view/View;->invalidate()V

    :cond_4
    iget-object v9, p0, Landroidx/recyclerview/widget/RecyclerView$x;->g:Landroidx/recyclerview/widget/RecyclerView;

    iget-object v14, v9, Landroidx/recyclerview/widget/RecyclerView;->p0:[I

    aput v1, v14, v1

    aput v1, v14, v2

    move v10, v8

    move v11, v7

    move v12, v5

    move v13, v6

    invoke-virtual/range {v9 .. v14}, Landroidx/recyclerview/widget/RecyclerView;->r(IIII[I)V

    iget-object v3, p0, Landroidx/recyclerview/widget/RecyclerView$x;->g:Landroidx/recyclerview/widget/RecyclerView;

    iget-object v9, v3, Landroidx/recyclerview/widget/RecyclerView;->p0:[I

    aget v10, v9, v1

    sub-int/2addr v5, v10

    aget v9, v9, v2

    sub-int/2addr v6, v9

    if-nez v8, :cond_5

    if-eqz v7, :cond_6

    :cond_5
    invoke-virtual {v3, v8, v7}, Landroidx/recyclerview/widget/RecyclerView;->s(II)V

    :cond_6
    iget-object v3, p0, Landroidx/recyclerview/widget/RecyclerView$x;->g:Landroidx/recyclerview/widget/RecyclerView;

    invoke-static {v3}, Landroidx/recyclerview/widget/RecyclerView;->c(Landroidx/recyclerview/widget/RecyclerView;)Z

    move-result v3

    if-nez v3, :cond_7

    iget-object v3, p0, Landroidx/recyclerview/widget/RecyclerView$x;->g:Landroidx/recyclerview/widget/RecyclerView;

    invoke-virtual {v3}, Landroid/view/View;->invalidate()V

    :cond_7
    invoke-virtual {v0}, Landroid/widget/OverScroller;->getCurrX()I

    move-result v3

    invoke-virtual {v0}, Landroid/widget/OverScroller;->getFinalX()I

    move-result v9

    if-ne v3, v9, :cond_8

    const/4 v3, 0x1

    goto :goto_1

    :cond_8
    const/4 v3, 0x0

    :goto_1
    invoke-virtual {v0}, Landroid/widget/OverScroller;->getCurrY()I

    move-result v9

    invoke-virtual {v0}, Landroid/widget/OverScroller;->getFinalY()I

    move-result v10

    if-ne v9, v10, :cond_9

    const/4 v9, 0x1

    goto :goto_2

    :cond_9
    const/4 v9, 0x0

    :goto_2
    invoke-virtual {v0}, Landroid/widget/OverScroller;->isFinished()Z

    move-result v10

    if-nez v10, :cond_c

    if-nez v3, :cond_a

    if-eqz v5, :cond_b

    :cond_a
    if-nez v9, :cond_c

    if-eqz v6, :cond_b

    goto :goto_3

    :cond_b
    const/4 v3, 0x0

    goto :goto_4

    :cond_c
    :goto_3
    const/4 v3, 0x1

    :goto_4
    iget-object v9, p0, Landroidx/recyclerview/widget/RecyclerView$x;->g:Landroidx/recyclerview/widget/RecyclerView;

    iget-object v9, v9, Landroidx/recyclerview/widget/RecyclerView;->l:Landroidx/recyclerview/widget/RecyclerView$l;

    invoke-static {v9}, Ljava/util/Objects;->requireNonNull(Ljava/lang/Object;)Ljava/lang/Object;

    if-eqz v3, :cond_18

    iget-object v3, p0, Landroidx/recyclerview/widget/RecyclerView$x;->g:Landroidx/recyclerview/widget/RecyclerView;

    invoke-virtual {v3}, Landroid/view/View;->getOverScrollMode()I

    move-result v3

    if-eq v3, v4, :cond_16

    invoke-virtual {v0}, Landroid/widget/OverScroller;->getCurrVelocity()F

    move-result v0

    float-to-int v0, v0

    if-gez v5, :cond_d

    neg-int v3, v0

    goto :goto_5

    :cond_d
    if-lez v5, :cond_e

    move v3, v0

    goto :goto_5

    :cond_e
    const/4 v3, 0x0

    :goto_5
    if-gez v6, :cond_f

    neg-int v0, v0

    goto :goto_6

    :cond_f
    if-lez v6, :cond_10

    goto :goto_6

    :cond_10
    const/4 v0, 0x0

    :goto_6
    iget-object v4, p0, Landroidx/recyclerview/widget/RecyclerView$x;->g:Landroidx/recyclerview/widget/RecyclerView;

    invoke-static {v4}, Ljava/util/Objects;->requireNonNull(Ljava/lang/Object;)Ljava/lang/Object;

    if-gez v3, :cond_11

    .line 3
    invoke-virtual {v4}, Landroidx/recyclerview/widget/RecyclerView;->u()V

    iget-object v5, v4, Landroidx/recyclerview/widget/RecyclerView;->E:Landroid/widget/EdgeEffect;

    invoke-virtual {v5}, Landroid/widget/EdgeEffect;->isFinished()Z

    move-result v5

    if-eqz v5, :cond_12

    iget-object v5, v4, Landroidx/recyclerview/widget/RecyclerView;->E:Landroid/widget/EdgeEffect;

    neg-int v6, v3

    invoke-virtual {v5, v6}, Landroid/widget/EdgeEffect;->onAbsorb(I)V

    goto :goto_7

    :cond_11
    if-lez v3, :cond_12

    invoke-virtual {v4}, Landroidx/recyclerview/widget/RecyclerView;->v()V

    iget-object v5, v4, Landroidx/recyclerview/widget/RecyclerView;->G:Landroid/widget/EdgeEffect;

    invoke-virtual {v5}, Landroid/widget/EdgeEffect;->isFinished()Z

    move-result v5

    if-eqz v5, :cond_12

    iget-object v5, v4, Landroidx/recyclerview/widget/RecyclerView;->G:Landroid/widget/EdgeEffect;

    invoke-virtual {v5, v3}, Landroid/widget/EdgeEffect;->onAbsorb(I)V

    :cond_12
    :goto_7
    if-gez v0, :cond_13

    invoke-virtual {v4}, Landroidx/recyclerview/widget/RecyclerView;->w()V

    iget-object v5, v4, Landroidx/recyclerview/widget/RecyclerView;->F:Landroid/widget/EdgeEffect;

    invoke-virtual {v5}, Landroid/widget/EdgeEffect;->isFinished()Z

    move-result v5

    if-eqz v5, :cond_14

    iget-object v5, v4, Landroidx/recyclerview/widget/RecyclerView;->F:Landroid/widget/EdgeEffect;

    neg-int v6, v0

    invoke-virtual {v5, v6}, Landroid/widget/EdgeEffect;->onAbsorb(I)V

    goto :goto_8

    :cond_13
    if-lez v0, :cond_14

    invoke-virtual {v4}, Landroidx/recyclerview/widget/RecyclerView;->t()V

    iget-object v5, v4, Landroidx/recyclerview/widget/RecyclerView;->H:Landroid/widget/EdgeEffect;

    invoke-virtual {v5}, Landroid/widget/EdgeEffect;->isFinished()Z

    move-result v5

    if-eqz v5, :cond_14

    iget-object v5, v4, Landroidx/recyclerview/widget/RecyclerView;->H:Landroid/widget/EdgeEffect;

    invoke-virtual {v5, v0}, Landroid/widget/EdgeEffect;->onAbsorb(I)V

    :cond_14
    :goto_8
    if-nez v3, :cond_15

    if-eqz v0, :cond_16

    :cond_15
    sget-object v0, Le/e;->a:Ljava/lang/reflect/Field;

    .line 4
    invoke-virtual {v4}, Landroid/view/View;->postInvalidateOnAnimation()V

    .line 5
    :cond_16
    sget-boolean v0, Landroidx/recyclerview/widget/RecyclerView;->v0:Z

    if-eqz v0, :cond_19

    iget-object v0, p0, Landroidx/recyclerview/widget/RecyclerView$x;->g:Landroidx/recyclerview/widget/RecyclerView;

    iget-object v0, v0, Landroidx/recyclerview/widget/RecyclerView;->b0:Landroidx/recyclerview/widget/m$b;

    .line 6
    iget-object v3, v0, Landroidx/recyclerview/widget/m$b;->c:[I

    if-eqz v3, :cond_17

    const/4 v4, -0x1

    invoke-static {v3, v4}, Ljava/util/Arrays;->fill([II)V

    :cond_17
    iput v1, v0, Landroidx/recyclerview/widget/m$b;->d:I

    goto :goto_9

    .line 7
    :cond_18
    invoke-virtual {p0}, Landroidx/recyclerview/widget/RecyclerView$x;->a()V

    iget-object v0, p0, Landroidx/recyclerview/widget/RecyclerView$x;->g:Landroidx/recyclerview/widget/RecyclerView;

    iget-object v3, v0, Landroidx/recyclerview/widget/RecyclerView;->a0:Landroidx/recyclerview/widget/m;

    if-eqz v3, :cond_19

    invoke-virtual {v3, v0, v8, v7}, Landroidx/recyclerview/widget/m;->a(Landroidx/recyclerview/widget/RecyclerView;II)V

    :cond_19
    :goto_9
    iget-object v0, p0, Landroidx/recyclerview/widget/RecyclerView$x;->g:Landroidx/recyclerview/widget/RecyclerView;

    iget-object v0, v0, Landroidx/recyclerview/widget/RecyclerView;->l:Landroidx/recyclerview/widget/RecyclerView$l;

    invoke-static {v0}, Ljava/util/Objects;->requireNonNull(Ljava/lang/Object;)Ljava/lang/Object;

    iput-boolean v1, p0, Landroidx/recyclerview/widget/RecyclerView$x;->e:Z

    iget-boolean v0, p0, Landroidx/recyclerview/widget/RecyclerView$x;->f:Z

    if-eqz v0, :cond_1a

    .line 8
    iget-object v0, p0, Landroidx/recyclerview/widget/RecyclerView$x;->g:Landroidx/recyclerview/widget/RecyclerView;

    invoke-virtual {v0, p0}, Landroid/view/View;->removeCallbacks(Ljava/lang/Runnable;)Z

    iget-object v0, p0, Landroidx/recyclerview/widget/RecyclerView$x;->g:Landroidx/recyclerview/widget/RecyclerView;

    sget-object v1, Le/e;->a:Ljava/lang/reflect/Field;

    .line 9
    invoke-virtual {v0, p0}, Landroid/view/View;->postOnAnimation(Ljava/lang/Runnable;)V

    goto :goto_a

    .line 10
    :cond_1a
    iget-object v0, p0, Landroidx/recyclerview/widget/RecyclerView$x;->g:Landroidx/recyclerview/widget/RecyclerView;

    invoke-virtual {v0, v1}, Landroidx/recyclerview/widget/RecyclerView;->setScrollState(I)V

    iget-object v0, p0, Landroidx/recyclerview/widget/RecyclerView$x;->g:Landroidx/recyclerview/widget/RecyclerView;

    invoke-virtual {v0, v2}, Landroidx/recyclerview/widget/RecyclerView;->f0(I)V

    :goto_a
    return-void
.end method
