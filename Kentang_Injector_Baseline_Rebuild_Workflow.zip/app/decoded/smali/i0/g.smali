.class public final Li0/g;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Li0/d$c;


# instance fields
.field public a:Lxyz/chz/injector/tunnel/vpn/TunnelVpnService;

.field public b:Ljava/util/concurrent/CountDownLatch;

.field public c:Ljava/lang/Thread;

.field public d:Ljava/util/concurrent/atomic/AtomicBoolean;

.field public e:Li0/d;

.field public f:Ljava/util/concurrent/atomic/AtomicBoolean;

.field public g:Li0/h;


# direct methods
.method public constructor <init>(Lxyz/chz/injector/tunnel/vpn/TunnelVpnService;)V
    .locals 1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v0, 0x0

    iput-object v0, p0, Li0/g;->e:Li0/d;

    iput-object p1, p0, Li0/g;->a:Lxyz/chz/injector/tunnel/vpn/TunnelVpnService;

    new-instance p1, Ljava/util/concurrent/atomic/AtomicBoolean;

    const/4 v0, 0x0

    invoke-direct {p1, v0}, Ljava/util/concurrent/atomic/AtomicBoolean;-><init>(Z)V

    iput-object p1, p0, Li0/g;->d:Ljava/util/concurrent/atomic/AtomicBoolean;

    new-instance p1, Ljava/util/concurrent/atomic/AtomicBoolean;

    invoke-direct {p1, v0}, Ljava/util/concurrent/atomic/AtomicBoolean;-><init>(Z)V

    iput-object p1, p0, Li0/g;->f:Ljava/util/concurrent/atomic/AtomicBoolean;

    .line 1
    const-class p1, Li0/d;

    monitor-enter p1

    :try_start_0
    sget-object v0, Li0/d;->i:Li0/d;

    if-eqz v0, :cond_0

    invoke-virtual {v0}, Li0/d;->c()V

    :cond_0
    new-instance v0, Li0/d;

    invoke-direct {v0, p0}, Li0/d;-><init>(Li0/d$c;)V

    sput-object v0, Li0/d;->i:Li0/d;
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    monitor-exit p1

    .line 2
    iput-object v0, p0, Li0/g;->e:Li0/d;

    return-void

    :catchall_0
    move-exception v0

    .line 3
    monitor-exit p1

    throw v0
.end method


# virtual methods
.method public final a()Ljava/lang/Object;
    .locals 2

    .line 1
    iget-object v0, p0, Li0/g;->a:Lxyz/chz/injector/tunnel/vpn/TunnelVpnService;

    invoke-static {v0}, Ljava/util/Objects;->requireNonNull(Ljava/lang/Object;)Ljava/lang/Object;

    .line 2
    new-instance v1, Landroid/net/VpnService$Builder;

    invoke-direct {v1, v0}, Landroid/net/VpnService$Builder;-><init>(Landroid/net/VpnService;)V

    return-object v1
.end method

.method public final b(Ljava/lang/String;)V
    .locals 5

    new-instance v0, Lf0/a;

    sget-object v1, Lxyz/chz/injector/MainActivity;->b:Lxyz/chz/injector/MainActivity;

    invoke-direct {v0, v1}, Lf0/a;-><init>(Landroid/content/Context;)V

    .line 1
    iget-object v0, v0, Lf0/a;->c:Lk0/a;

    const-string v1, "protegerConfig"

    const/4 v2, 0x0

    .line 2
    invoke-virtual {v0, v1, v2}, Lk0/a;->getBoolean(Ljava/lang/String;Z)Z

    move-result v0

    if-eqz v0, :cond_0

    iget-object v0, p0, Li0/g;->g:Li0/h;

    iget-object v0, v0, Li0/h;->e:[Ljava/lang/String;

    array-length v1, v0

    :goto_0
    if-ge v2, v1, :cond_0

    aget-object v3, v0, v2

    const-string v4, "********"

    invoke-virtual {p1, v3, v4}, Ljava/lang/String;->replace(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Ljava/lang/String;

    move-result-object p1

    add-int/lit8 v2, v2, 0x1

    goto :goto_0

    :cond_0
    invoke-static {p1}, Lg0/d;->h(Ljava/lang/String;)V

    return-void
.end method

.method public final c()V
    .locals 2
    .annotation build Landroid/annotation/TargetApi;
        value = 0x17
    .end annotation

    const-string v0, "<strong>VPN Established</strong>"

    invoke-static {v0}, Lg0/d;->h(Ljava/lang/String;)V

    new-instance v0, Ljava/util/concurrent/CountDownLatch;

    const/4 v1, 0x1

    invoke-direct {v0, v1}, Ljava/util/concurrent/CountDownLatch;-><init>(I)V

    iput-object v0, p0, Li0/g;->b:Ljava/util/concurrent/CountDownLatch;

    new-instance v0, Ljava/lang/Thread;

    new-instance v1, Li0/f;

    invoke-direct {v1, p0}, Li0/f;-><init>(Li0/g;)V

    invoke-direct {v0, v1}, Ljava/lang/Thread;-><init>(Ljava/lang/Runnable;)V

    iput-object v0, p0, Li0/g;->c:Ljava/lang/Thread;

    invoke-virtual {v0}, Ljava/lang/Thread;->start()V

    return-void
.end method

.method public final d()V
    .locals 1

    iget-object v0, p0, Li0/g;->b:Ljava/util/concurrent/CountDownLatch;

    if-eqz v0, :cond_0

    invoke-virtual {v0}, Ljava/util/concurrent/CountDownLatch;->countDown()V

    :cond_0
    return-void
.end method
