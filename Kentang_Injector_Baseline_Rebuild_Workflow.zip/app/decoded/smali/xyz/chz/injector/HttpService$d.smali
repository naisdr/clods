.class public final Lxyz/chz/injector/HttpService$d;
.super Landroid/net/ConnectivityManager$NetworkCallback;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lxyz/chz/injector/HttpService;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1
    name = null
.end annotation


# direct methods
.method public constructor <init>()V
    .locals 0

    invoke-direct {p0}, Landroid/net/ConnectivityManager$NetworkCallback;-><init>()V

    return-void
.end method


# virtual methods
.method public final onAvailable(Landroid/net/Network;)V
    .locals 0

    const-string p1, "network available"

    invoke-static {p1}, Lg0/d;->d(Ljava/lang/String;)V

    return-void
.end method

.method public final onLost(Landroid/net/Network;)V
    .locals 0

    const-string p1, ""

    invoke-static {p1}, Lg0/d;->d(Ljava/lang/String;)V

    return-void
.end method

.method public final onUnavailable()V
    .locals 1

    const-string v0, "network unavailable"

    invoke-static {v0}, Lg0/d;->d(Ljava/lang/String;)V

    return-void
.end method
