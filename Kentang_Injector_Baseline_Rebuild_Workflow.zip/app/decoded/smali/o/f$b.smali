.class public final Lo/f$b;
.super Ljava/lang/Object;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lo/f;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1
    name = "b"
.end annotation


# instance fields
.field public a:Lo/f$a;

.field public b:I

.field public final synthetic c:Lo/f;


# direct methods
.method public constructor <init>(Lo/f;Lo/f$a;)V
    .locals 0

    iput-object p1, p0, Lo/f$b;->c:Lo/f;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p2, p0, Lo/f$b;->a:Lo/f$a;

    const/4 p1, 0x0

    iput p1, p0, Lo/f$b;->b:I

    return-void
.end method


# virtual methods
.method public final a()I
    .locals 3

    iget-object v0, p0, Lo/f$b;->c:Lo/f;

    .line 1
    iget v0, v0, Lo/f;->d:I

    .line 2
    iget v1, p0, Lo/f$b;->b:I

    sub-int v1, v0, v1

    if-lez v1, :cond_0

    return v1

    :cond_0
    iget-object v1, p0, Lo/f$b;->a:Lo/f$a;

    iget-object v2, v1, Lo/f$a;->b:Lo/f$a;

    if-nez v2, :cond_1

    .line 3
    new-instance v2, Lo/f$a;

    invoke-direct {v2, v0}, Lo/f$a;-><init>(I)V

    .line 4
    iput-object v2, v1, Lo/f$a;->b:Lo/f$a;

    :cond_1
    iput-object v2, p0, Lo/f$b;->a:Lo/f$a;

    const/4 v0, 0x0

    iput v0, p0, Lo/f$b;->b:I

    iget-object v0, p0, Lo/f$b;->c:Lo/f;

    .line 5
    iget v0, v0, Lo/f;->d:I

    return v0
.end method
