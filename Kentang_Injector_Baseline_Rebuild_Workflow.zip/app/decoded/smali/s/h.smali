.class public final Ls/h;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field public final synthetic a:Ls/i;


# direct methods
.method public constructor <init>(Ls/i;)V
    .locals 0

    iput-object p1, p0, Ls/h;->a:Ls/i;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final run()V
    .locals 5

    :try_start_0
    iget-object v0, p0, Ls/h;->a:Ls/i;

    invoke-virtual {v0}, Ls/i;->h()V

    const/4 v0, 0x0

    throw v0
    :try_end_0
    .catch Ljava/io/IOException; {:try_start_0 .. :try_end_0} :catch_0

    :catch_0
    move-exception v0

    .line 1
    sget-object v1, Ls/i;->q:La/b;

    .line 2
    invoke-static {v1}, Ljava/util/Objects;->requireNonNull(Ljava/lang/Object;)Ljava/lang/Object;

    iget-object v2, p0, Ls/h;->a:Ls/i;

    const/4 v3, 0x0

    invoke-virtual {v2, v0, v3}, Ls/i;->b(Ljava/lang/Throwable;Z)V

    invoke-static {v1}, Ljava/util/Objects;->requireNonNull(Ljava/lang/Object;)Ljava/lang/Object;

    iget-object v1, p0, Ls/h;->a:Ls/i;

    iget-object v1, v1, Ls/i;->l:Ls/a;

    if-eqz v1, :cond_0

    .line 3
    :try_start_1
    iget-object v2, v1, Ls/a;->f:Ljava/lang/Object;

    monitor-enter v2
    :try_end_1
    .catch Ljava/io/IOException; {:try_start_1 .. :try_end_1} :catch_1

    const/4 v4, 0x1

    :try_start_2
    iput-boolean v4, v1, Ls/a;->h:Z

    iget-object v1, v1, Ls/a;->f:Ljava/lang/Object;

    invoke-virtual {v1}, Ljava/lang/Object;->notifyAll()V

    monitor-exit v2

    goto :goto_0

    :catchall_0
    move-exception v1

    monitor-exit v2
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_0

    :try_start_3
    throw v1
    :try_end_3
    .catch Ljava/io/IOException; {:try_start_3 .. :try_end_3} :catch_1

    :catch_1
    nop

    .line 4
    :cond_0
    :goto_0
    iget-object v1, p0, Ls/h;->a:Ls/i;

    iget-object v1, v1, Ls/i;->m:Ljava/util/Vector;

    invoke-virtual {v1}, Ljava/util/Vector;->size()I

    move-result v1

    if-ge v3, v1, :cond_1

    iget-object v1, p0, Ls/h;->a:Ls/i;

    iget-object v1, v1, Ls/i;->m:Ljava/util/Vector;

    invoke-virtual {v1, v3}, Ljava/util/Vector;->elementAt(I)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ls/i$b;

    :try_start_4
    iget-object v1, v1, Ls/i$b;->a:Ls/d;

    invoke-interface {v1, v0}, Ls/d;->a(Ljava/lang/Throwable;)V
    :try_end_4
    .catch Ljava/lang/Exception; {:try_start_4 .. :try_end_4} :catch_2

    :catch_2
    add-int/lit8 v3, v3, 0x1

    goto :goto_0

    :cond_1
    return-void
.end method
