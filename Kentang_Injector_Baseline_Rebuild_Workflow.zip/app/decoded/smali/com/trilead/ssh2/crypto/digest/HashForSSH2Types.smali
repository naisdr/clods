.class public Lcom/trilead/ssh2/crypto/digest/HashForSSH2Types;
.super Ljava/lang/Object;
.source "SourceFile"


# instance fields
.field public final a:Lcom/trilead/ssh2/crypto/digest/Digest;


# direct methods
.method public constructor <init>(Ljava/lang/String;)V
    .locals 2

    new-instance v0, Lcom/trilead/ssh2/crypto/digest/JreMessageDigestWrapper;

    .line 1
    :try_start_0
    invoke-static {p1}, Ljava/security/MessageDigest;->getInstance(Ljava/lang/String;)Ljava/security/MessageDigest;

    move-result-object p1
    :try_end_0
    .catch Ljava/security/GeneralSecurityException; {:try_start_0 .. :try_end_0} :catch_0

    .line 2
    invoke-direct {v0, p1}, Lcom/trilead/ssh2/crypto/digest/JreMessageDigestWrapper;-><init>(Ljava/security/MessageDigest;)V

    .line 3
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object v0, p0, Lcom/trilead/ssh2/crypto/digest/HashForSSH2Types;->a:Lcom/trilead/ssh2/crypto/digest/Digest;

    return-void

    :catch_0
    move-exception p1

    .line 4
    new-instance v0, Ljava/lang/IllegalArgumentException;

    const-string v1, "Could not get Message digest instance"

    invoke-direct {v0, v1, p1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;Ljava/lang/Throwable;)V

    throw v0
.end method


# virtual methods
.method public final a()[B
    .locals 2

    iget-object v0, p0, Lcom/trilead/ssh2/crypto/digest/HashForSSH2Types;->a:Lcom/trilead/ssh2/crypto/digest/Digest;

    invoke-interface {v0}, Lcom/trilead/ssh2/crypto/digest/Digest;->c()I

    move-result v0

    new-array v0, v0, [B

    iget-object v1, p0, Lcom/trilead/ssh2/crypto/digest/HashForSSH2Types;->a:Lcom/trilead/ssh2/crypto/digest/Digest;

    invoke-interface {v1, v0}, Lcom/trilead/ssh2/crypto/digest/Digest;->b([B)V

    return-object v0
.end method

.method public final b(Ljava/math/BigInteger;)V
    .locals 0

    invoke-virtual {p1}, Ljava/math/BigInteger;->toByteArray()[B

    move-result-object p1

    invoke-virtual {p0, p1}, Lcom/trilead/ssh2/crypto/digest/HashForSSH2Types;->c([B)V

    return-void
.end method

.method public final c([B)V
    .locals 1

    array-length v0, p1

    invoke-virtual {p0, v0}, Lcom/trilead/ssh2/crypto/digest/HashForSSH2Types;->e(I)V

    invoke-virtual {p0, p1}, Lcom/trilead/ssh2/crypto/digest/HashForSSH2Types;->d([B)V

    return-void
.end method

.method public final d([B)V
    .locals 1

    iget-object v0, p0, Lcom/trilead/ssh2/crypto/digest/HashForSSH2Types;->a:Lcom/trilead/ssh2/crypto/digest/Digest;

    invoke-interface {v0, p1}, Lcom/trilead/ssh2/crypto/digest/Digest;->g([B)V

    return-void
.end method

.method public final e(I)V
    .locals 2

    iget-object v0, p0, Lcom/trilead/ssh2/crypto/digest/HashForSSH2Types;->a:Lcom/trilead/ssh2/crypto/digest/Digest;

    shr-int/lit8 v1, p1, 0x18

    int-to-byte v1, v1

    invoke-interface {v0, v1}, Lcom/trilead/ssh2/crypto/digest/Digest;->f(B)V

    iget-object v0, p0, Lcom/trilead/ssh2/crypto/digest/HashForSSH2Types;->a:Lcom/trilead/ssh2/crypto/digest/Digest;

    shr-int/lit8 v1, p1, 0x10

    int-to-byte v1, v1

    invoke-interface {v0, v1}, Lcom/trilead/ssh2/crypto/digest/Digest;->f(B)V

    iget-object v0, p0, Lcom/trilead/ssh2/crypto/digest/HashForSSH2Types;->a:Lcom/trilead/ssh2/crypto/digest/Digest;

    shr-int/lit8 v1, p1, 0x8

    int-to-byte v1, v1

    invoke-interface {v0, v1}, Lcom/trilead/ssh2/crypto/digest/Digest;->f(B)V

    iget-object v0, p0, Lcom/trilead/ssh2/crypto/digest/HashForSSH2Types;->a:Lcom/trilead/ssh2/crypto/digest/Digest;

    int-to-byte p1, p1

    invoke-interface {v0, p1}, Lcom/trilead/ssh2/crypto/digest/Digest;->f(B)V

    return-void
.end method
