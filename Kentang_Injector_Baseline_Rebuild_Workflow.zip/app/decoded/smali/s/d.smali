.class public interface abstract Ls/d;
.super Ljava/lang/Object;
.source "SourceFile"


# virtual methods
.method public abstract a(Ljava/lang/Throwable;)V
.end method

.method public abstract b([BI)V
.end method
