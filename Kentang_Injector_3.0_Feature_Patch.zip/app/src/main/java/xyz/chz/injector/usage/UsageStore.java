package xyz.chz.injector.usage;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.net.TrafficStats;
import android.os.SystemClock;

import java.util.ArrayList;
import java.util.List;

/**
 * Persistent per-app traffic accumulator and per-session history.
 *
 * IMPORTANT: TrafficStats UID counters measure traffic attributed by Android to
 * this app UID. On some Android/VPN implementations this can include tunnel
 * transport traffic rather than exact inner VPN payload bytes. Validate against
 * the VPN interface before presenting it as exact VPN-only usage.
 */
public final class UsageStore extends SQLiteOpenHelper {
    private static final String DB = "kentang_usage.db";
    private static final int VERSION = 1;
    private static final String PREF = "kentang_usage_state";
    private static final String KEY_RX = "last_rx";
    private static final String KEY_TX = "last_tx";
    private static final String KEY_ACTIVE = "active_session";
    private static final String KEY_TOTAL_RX = "total_rx";
    private static final String KEY_TOTAL_TX = "total_tx";

    public static final class Snapshot {
        public final long downloadBytes, uploadBytes;
        public Snapshot(long rx, long tx) {
            downloadBytes = rx;
            uploadBytes = tx;
        }
        public long totalBytes() { return downloadBytes + uploadBytes; }
        public String downloadGb() { return format(downloadBytes); }
        public String uploadGb() { return format(uploadBytes); }
        public String totalGb() { return format(totalBytes()); }
    }

    public static final class Session {
        public final long id, startedAt, endedAt, rxBytes, txBytes;
        Session(long id, long start, long end, long rx, long tx) {
            this.id=id; startedAt=start; endedAt=end; rxBytes=rx; txBytes=tx;
        }
    }

    public UsageStore(Context context) {
        super(context.getApplicationContext(), DB, null, VERSION);
    }

    @Override public void onCreate(SQLiteDatabase db) {
        db.execSQL("CREATE TABLE sessions (" +
                "id INTEGER PRIMARY KEY AUTOINCREMENT," +
                "started_at INTEGER NOT NULL," +
                "ended_at INTEGER NOT NULL DEFAULT 0," +
                "rx_bytes INTEGER NOT NULL DEFAULT 0," +
                "tx_bytes INTEGER NOT NULL DEFAULT 0)");
    }

    @Override public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        // Keep existing usage history; add explicit migrations here for future versions.
    }

    /** Call immediately before starting the VPN session. */
    public synchronized void startSession(Context context) {
        android.content.SharedPreferences p = prefs(context);
        if (p.getLong(KEY_ACTIVE, 0L) != 0L) return;
        ContentValues row = new ContentValues();
        row.put("started_at", System.currentTimeMillis());
        long id = getWritableDatabase().insert("sessions", null, row);
        p.edit()
          .putLong(KEY_ACTIVE, id)
          .putLong(KEY_RX, safe(TrafficStats.getUidRxBytes(android.os.Process.myUid())))
          .putLong(KEY_TX, safe(TrafficStats.getUidTxBytes(android.os.Process.myUid())))
          .apply();
    }

    /** Call periodically while VPN is active (e.g. every 1 second). */
    public synchronized Snapshot sample(Context context) {
        android.content.SharedPreferences p = prefs(context);
        long nowRx = safe(TrafficStats.getUidRxBytes(android.os.Process.myUid()));
        long nowTx = safe(TrafficStats.getUidTxBytes(android.os.Process.myUid()));
        long oldRx = p.getLong(KEY_RX, nowRx);
        long oldTx = p.getLong(KEY_TX, nowTx);
        long deltaRx = nowRx >= oldRx ? nowRx - oldRx : 0L;
        long deltaTx = nowTx >= oldTx ? nowTx - oldTx : 0L;

        long active = p.getLong(KEY_ACTIVE, 0L);
        if (active != 0L && (deltaRx != 0L || deltaTx != 0L)) {
            SQLiteDatabase db = getWritableDatabase();
            db.execSQL("UPDATE sessions SET rx_bytes=rx_bytes+?, tx_bytes=tx_bytes+? WHERE id=?",
                    new Object[]{deltaRx, deltaTx, active});
            p.edit()
              .putLong(KEY_TOTAL_RX, p.getLong(KEY_TOTAL_RX, 0L) + deltaRx)
              .putLong(KEY_TOTAL_TX, p.getLong(KEY_TOTAL_TX, 0L) + deltaTx)
              .apply();
        }
        p.edit().putLong(KEY_RX, nowRx).putLong(KEY_TX, nowTx).apply();
        return totals(context);
    }

    /** Call after stopping the VPN, after a final sample(). */
    public synchronized void stopSession(Context context) {
        sample(context);
        android.content.SharedPreferences p = prefs(context);
        long id = p.getLong(KEY_ACTIVE, 0L);
        if (id != 0L) {
            ContentValues values = new ContentValues();
            values.put("ended_at", System.currentTimeMillis());
            getWritableDatabase().update("sessions", values, "id=?", new String[]{String.valueOf(id)});
        }
        p.edit().remove(KEY_ACTIVE).remove(KEY_RX).remove(KEY_TX).apply();
    }

    public Snapshot totals(Context context) {
        android.content.SharedPreferences p = prefs(context);
        return new Snapshot(p.getLong(KEY_TOTAL_RX, 0L), p.getLong(KEY_TOTAL_TX, 0L));
    }

    public List<Session> history(int limit) {
        List<Session> out = new ArrayList<>();
        Cursor c = getReadableDatabase().rawQuery(
                "SELECT id,started_at,ended_at,rx_bytes,tx_bytes FROM sessions ORDER BY id DESC LIMIT ?",
                new String[]{String.valueOf(Math.max(1, limit))});
        try {
            while (c.moveToNext()) out.add(new Session(c.getLong(0), c.getLong(1),
                    c.getLong(2), c.getLong(3), c.getLong(4)));
        } finally { c.close(); }
        return out;
    }

    private static android.content.SharedPreferences prefs(Context c) {
        return c.getSharedPreferences(PREF, Context.MODE_PRIVATE);
    }
    private static long safe(long n) { return n < 0 ? 0L : n; }
    private static String format(long bytes) {
        return String.format(java.util.Locale.US, "%.3f", bytes / 1073741824.0);
    }
}
