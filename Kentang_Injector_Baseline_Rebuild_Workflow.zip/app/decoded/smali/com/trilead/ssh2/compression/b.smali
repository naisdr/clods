.class public interface abstract Lcom/trilead/ssh2/compression/b;
.super Ljava/lang/Object;
.source "SourceFile"
