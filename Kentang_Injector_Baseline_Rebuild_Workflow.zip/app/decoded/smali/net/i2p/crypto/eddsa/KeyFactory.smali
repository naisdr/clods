.class public final Lnet/i2p/crypto/eddsa/KeyFactory;
.super Ljava/security/KeyFactorySpi;
.source "SourceFile"


# direct methods
.method public constructor <init>()V
    .locals 0

    invoke-direct {p0}, Ljava/security/KeyFactorySpi;-><init>()V

    return-void
.end method


# virtual methods
.method public final engineGeneratePrivate(Ljava/security/spec/KeySpec;)Ljava/security/PrivateKey;
    .locals 16

    move-object/from16 v0, p1

    instance-of v1, v0, Lnet/i2p/crypto/eddsa/spec/EdDSAPrivateKeySpec;

    if-eqz v1, :cond_0

    new-instance v1, Lnet/i2p/crypto/eddsa/EdDSAPrivateKey;

    check-cast v0, Lnet/i2p/crypto/eddsa/spec/EdDSAPrivateKeySpec;

    invoke-direct {v1, v0}, Lnet/i2p/crypto/eddsa/EdDSAPrivateKey;-><init>(Lnet/i2p/crypto/eddsa/spec/EdDSAPrivateKeySpec;)V

    return-object v1

    :cond_0
    instance-of v1, v0, Ljava/security/spec/PKCS8EncodedKeySpec;

    if-eqz v1, :cond_c

    new-instance v1, Lnet/i2p/crypto/eddsa/EdDSAPrivateKey;

    check-cast v0, Ljava/security/spec/PKCS8EncodedKeySpec;

    .line 1
    new-instance v2, Lnet/i2p/crypto/eddsa/spec/EdDSAPrivateKeySpec;

    invoke-virtual {v0}, Ljava/security/spec/PKCS8EncodedKeySpec;->getEncoded()[B

    move-result-object v0

    const/16 v3, 0xb

    .line 2
    :try_start_0
    aget-byte v3, v0, v3
    :try_end_0
    .catch Ljava/lang/IndexOutOfBoundsException; {:try_start_0 .. :try_end_0} :catch_0

    const/16 v4, 0x64

    const/4 v5, 0x6

    const-string v6, "unsupported key spec"

    const/16 v7, 0x8

    const/4 v8, 0x5

    const/16 v9, 0x30

    const/4 v10, 0x7

    if-ne v3, v4, :cond_1

    const/16 v11, 0x31

    const/16 v12, 0x8

    goto :goto_0

    :cond_1
    const/16 v11, 0x70

    if-ne v3, v11, :cond_b

    :try_start_1
    aget-byte v11, v0, v5

    if-ne v11, v10, :cond_2

    const/16 v11, 0x32

    const/4 v12, 0x7

    goto :goto_0

    :cond_2
    const/16 v11, 0x30

    const/4 v12, 0x5

    :goto_0
    array-length v13, v0

    if-ne v13, v11, :cond_a

    const/4 v13, 0x0

    aget-byte v13, v0, v13

    if-ne v13, v9, :cond_9

    const/4 v13, 0x1

    aget-byte v14, v0, v13

    const/4 v15, 0x2

    sub-int/2addr v11, v15

    if-ne v14, v11, :cond_9

    aget-byte v11, v0, v15

    if-ne v11, v15, :cond_9

    const/4 v11, 0x3

    aget-byte v14, v0, v11

    if-ne v14, v13, :cond_9

    const/4 v14, 0x4

    aget-byte v15, v0, v14

    if-nez v15, :cond_9

    aget-byte v15, v0, v8

    if-ne v15, v9, :cond_9

    aget-byte v9, v0, v5

    if-ne v9, v12, :cond_9

    aget-byte v9, v0, v10

    if-ne v9, v5, :cond_9

    const/16 v5, 0x9

    aget-byte v7, v0, v7

    if-ne v7, v11, :cond_9

    aget-byte v5, v0, v5

    const/16 v7, 0x2b

    if-ne v5, v7, :cond_9

    const/16 v5, 0xa

    aget-byte v7, v0, v5

    const/16 v9, 0x65

    if-ne v7, v9, :cond_9

    const/16 v7, 0xc

    const/16 v9, 0xd

    const/16 v11, 0xe

    if-ne v3, v4, :cond_4

    aget-byte v3, v0, v7

    if-ne v3, v5, :cond_3

    aget-byte v3, v0, v9

    if-ne v3, v13, :cond_3

    const/16 v3, 0xf

    aget-byte v4, v0, v11

    if-ne v4, v13, :cond_3

    goto :goto_2

    :cond_3
    new-instance v0, Ljava/security/spec/InvalidKeySpecException;

    invoke-direct {v0, v6}, Ljava/security/spec/InvalidKeySpecException;-><init>(Ljava/lang/String;)V

    throw v0

    :cond_4
    if-ne v12, v10, :cond_6

    aget-byte v3, v0, v7

    if-ne v3, v8, :cond_5

    aget-byte v3, v0, v9

    if-nez v3, :cond_5

    const/16 v7, 0xe

    goto :goto_1

    :cond_5
    new-instance v0, Ljava/security/spec/InvalidKeySpecException;

    invoke-direct {v0, v6}, Ljava/security/spec/InvalidKeySpecException;-><init>(Ljava/lang/String;)V

    throw v0

    :cond_6
    :goto_1
    add-int/lit8 v3, v7, 0x1

    aget-byte v4, v0, v7

    if-ne v4, v14, :cond_8

    add-int/lit8 v4, v3, 0x1

    aget-byte v3, v0, v3

    const/16 v5, 0x22

    if-ne v3, v5, :cond_8

    move v3, v4

    :goto_2
    add-int/lit8 v4, v3, 0x1

    aget-byte v3, v0, v3

    if-ne v3, v14, :cond_7

    add-int/lit8 v3, v4, 0x1

    aget-byte v4, v0, v4

    const/16 v5, 0x20

    if-ne v4, v5, :cond_7

    new-array v4, v5, [B

    const/4 v6, 0x0

    invoke-static {v0, v3, v4, v6, v5}, Ljava/lang/System;->arraycopy(Ljava/lang/Object;ILjava/lang/Object;II)V
    :try_end_1
    .catch Ljava/lang/IndexOutOfBoundsException; {:try_start_1 .. :try_end_1} :catch_0

    .line 3
    sget-object v0, Lnet/i2p/crypto/eddsa/spec/EdDSANamedCurveTable;->a:Lnet/i2p/crypto/eddsa/spec/EdDSANamedCurveSpec;

    invoke-direct {v2, v4, v0}, Lnet/i2p/crypto/eddsa/spec/EdDSAPrivateKeySpec;-><init>([BLnet/i2p/crypto/eddsa/spec/EdDSAParameterSpec;)V

    invoke-direct {v1, v2}, Lnet/i2p/crypto/eddsa/EdDSAPrivateKey;-><init>(Lnet/i2p/crypto/eddsa/spec/EdDSAPrivateKeySpec;)V

    return-object v1

    .line 4
    :cond_7
    :try_start_2
    new-instance v0, Ljava/security/spec/InvalidKeySpecException;

    invoke-direct {v0, v6}, Ljava/security/spec/InvalidKeySpecException;-><init>(Ljava/lang/String;)V

    throw v0

    :cond_8
    new-instance v0, Ljava/security/spec/InvalidKeySpecException;

    invoke-direct {v0, v6}, Ljava/security/spec/InvalidKeySpecException;-><init>(Ljava/lang/String;)V

    throw v0

    :cond_9
    new-instance v0, Ljava/security/spec/InvalidKeySpecException;

    invoke-direct {v0, v6}, Ljava/security/spec/InvalidKeySpecException;-><init>(Ljava/lang/String;)V

    throw v0

    :cond_a
    new-instance v0, Ljava/security/spec/InvalidKeySpecException;

    const-string v1, "invalid key spec length"

    invoke-direct {v0, v1}, Ljava/security/spec/InvalidKeySpecException;-><init>(Ljava/lang/String;)V

    throw v0

    :cond_b
    new-instance v0, Ljava/security/spec/InvalidKeySpecException;

    invoke-direct {v0, v6}, Ljava/security/spec/InvalidKeySpecException;-><init>(Ljava/lang/String;)V

    throw v0
    :try_end_2
    .catch Ljava/lang/IndexOutOfBoundsException; {:try_start_2 .. :try_end_2} :catch_0

    :catch_0
    move-exception v0

    new-instance v1, Ljava/security/spec/InvalidKeySpecException;

    invoke-direct {v1, v0}, Ljava/security/spec/InvalidKeySpecException;-><init>(Ljava/lang/Throwable;)V

    throw v1

    .line 5
    :cond_c
    new-instance v1, Ljava/security/spec/InvalidKeySpecException;

    const-string v2, "key spec not recognised: "

    .line 6
    invoke-static {v2}, Lcom/trilead/ssh2/crypto/digest/a;->e(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    .line 7
    invoke-virtual/range {p1 .. p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-result-object v0

    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-direct {v1, v0}, Ljava/security/spec/InvalidKeySpecException;-><init>(Ljava/lang/String;)V

    throw v1
.end method

.method public final engineGeneratePublic(Ljava/security/spec/KeySpec;)Ljava/security/PublicKey;
    .locals 2

    instance-of v0, p1, Lnet/i2p/crypto/eddsa/spec/EdDSAPublicKeySpec;

    if-eqz v0, :cond_0

    new-instance v0, Lnet/i2p/crypto/eddsa/EdDSAPublicKey;

    check-cast p1, Lnet/i2p/crypto/eddsa/spec/EdDSAPublicKeySpec;

    invoke-direct {v0, p1}, Lnet/i2p/crypto/eddsa/EdDSAPublicKey;-><init>(Lnet/i2p/crypto/eddsa/spec/EdDSAPublicKeySpec;)V

    return-object v0

    :cond_0
    instance-of v0, p1, Ljava/security/spec/X509EncodedKeySpec;

    if-eqz v0, :cond_1

    new-instance v0, Lnet/i2p/crypto/eddsa/EdDSAPublicKey;

    check-cast p1, Ljava/security/spec/X509EncodedKeySpec;

    invoke-direct {v0, p1}, Lnet/i2p/crypto/eddsa/EdDSAPublicKey;-><init>(Ljava/security/spec/X509EncodedKeySpec;)V

    return-object v0

    :cond_1
    new-instance v0, Ljava/security/spec/InvalidKeySpecException;

    const-string v1, "key spec not recognised: "

    .line 1
    invoke-static {v1}, Lcom/trilead/ssh2/crypto/digest/a;->e(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    .line 2
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-result-object p1

    invoke-virtual {v1, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    invoke-direct {v0, p1}, Ljava/security/spec/InvalidKeySpecException;-><init>(Ljava/lang/String;)V

    throw v0
.end method

.method public final engineGetKeySpec(Ljava/security/Key;Ljava/lang/Class;)Ljava/security/spec/KeySpec;
    .locals 7
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<T::",
            "Ljava/security/spec/KeySpec;",
            ">(",
            "Ljava/security/Key;",
            "Ljava/lang/Class<",
            "TT;>;)TT;"
        }
    .end annotation

    const-class v0, Lnet/i2p/crypto/eddsa/spec/EdDSAPublicKeySpec;

    invoke-virtual {p2, v0}, Ljava/lang/Class;->isAssignableFrom(Ljava/lang/Class;)Z

    move-result v0

    if-eqz v0, :cond_0

    instance-of v0, p1, Lnet/i2p/crypto/eddsa/EdDSAPublicKey;

    if-eqz v0, :cond_0

    move-object v0, p1

    check-cast v0, Lnet/i2p/crypto/eddsa/EdDSAPublicKey;

    .line 1
    iget-object v1, v0, Lnet/i2p/crypto/eddsa/EdDSAPublicKey;->d:Lnet/i2p/crypto/eddsa/spec/EdDSAParameterSpec;

    if-eqz v1, :cond_1

    .line 2
    new-instance p1, Lnet/i2p/crypto/eddsa/spec/EdDSAPublicKeySpec;

    .line 3
    iget-object p2, v0, Lnet/i2p/crypto/eddsa/EdDSAPublicKey;->a:Lnet/i2p/crypto/eddsa/math/GroupElement;

    .line 4
    invoke-direct {p1, p2, v1}, Lnet/i2p/crypto/eddsa/spec/EdDSAPublicKeySpec;-><init>(Lnet/i2p/crypto/eddsa/math/GroupElement;Lnet/i2p/crypto/eddsa/spec/EdDSAParameterSpec;)V

    return-object p1

    :cond_0
    const-class v0, Lnet/i2p/crypto/eddsa/spec/EdDSAPrivateKeySpec;

    invoke-virtual {p2, v0}, Ljava/lang/Class;->isAssignableFrom(Ljava/lang/Class;)Z

    move-result v0

    if-eqz v0, :cond_1

    instance-of v0, p1, Lnet/i2p/crypto/eddsa/EdDSAPrivateKey;

    if-eqz v0, :cond_1

    move-object v0, p1

    check-cast v0, Lnet/i2p/crypto/eddsa/EdDSAPrivateKey;

    .line 5
    iget-object v6, v0, Lnet/i2p/crypto/eddsa/EdDSAPrivateKey;->f:Lnet/i2p/crypto/eddsa/spec/EdDSAParameterSpec;

    if-eqz v6, :cond_1

    .line 6
    new-instance p1, Lnet/i2p/crypto/eddsa/spec/EdDSAPrivateKeySpec;

    .line 7
    iget-object v2, v0, Lnet/i2p/crypto/eddsa/EdDSAPrivateKey;->a:[B

    .line 8
    iget-object v3, v0, Lnet/i2p/crypto/eddsa/EdDSAPrivateKey;->b:[B

    .line 9
    iget-object v4, v0, Lnet/i2p/crypto/eddsa/EdDSAPrivateKey;->c:[B

    .line 10
    iget-object v5, v0, Lnet/i2p/crypto/eddsa/EdDSAPrivateKey;->d:Lnet/i2p/crypto/eddsa/math/GroupElement;

    move-object v1, p1

    .line 11
    invoke-direct/range {v1 .. v6}, Lnet/i2p/crypto/eddsa/spec/EdDSAPrivateKeySpec;-><init>([B[B[BLnet/i2p/crypto/eddsa/math/GroupElement;Lnet/i2p/crypto/eddsa/spec/EdDSAParameterSpec;)V

    return-object p1

    :cond_1
    new-instance v0, Ljava/security/spec/InvalidKeySpecException;

    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const-string v2, "not implemented yet "

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const-string p1, " "

    invoke-virtual {v1, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    invoke-direct {v0, p1}, Ljava/security/spec/InvalidKeySpecException;-><init>(Ljava/lang/String;)V

    throw v0
.end method

.method public final engineTranslateKey(Ljava/security/Key;)Ljava/security/Key;
    .locals 1

    new-instance p1, Ljava/security/InvalidKeyException;

    const-string v0, "No other EdDSA key providers known"

    invoke-direct {p1, v0}, Ljava/security/InvalidKeyException;-><init>(Ljava/lang/String;)V

    throw p1
.end method
