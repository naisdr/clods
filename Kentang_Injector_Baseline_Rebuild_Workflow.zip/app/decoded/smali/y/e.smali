.class public final Ly/e;
.super Ly/b;
.source "SourceFile"


# direct methods
.method public constructor <init>()V
    .locals 0

    invoke-direct {p0}, Ly/b;-><init>()V

    return-void
.end method

.method public constructor <init>(Ly/e;)V
    .locals 0

    invoke-direct {p0, p1}, Ly/b;-><init>(Ly/b;)V

    return-void
.end method


# virtual methods
.method public final a()V
    .locals 6

    const-wide/16 v0, 0x0

    .line 1
    iput-wide v0, p0, Ly/b;->c:J

    iput-wide v0, p0, Ly/b;->d:J

    const/4 v2, 0x0

    iput v2, p0, Ly/b;->b:I

    const/4 v3, 0x0

    :goto_0
    iget-object v4, p0, Ly/b;->a:[B

    array-length v5, v4

    if-ge v3, v5, :cond_0

    aput-byte v2, v4, v3

    add-int/lit8 v3, v3, 0x1

    goto :goto_0

    :cond_0
    iput v2, p0, Ly/b;->n:I

    :goto_1
    iget-object v3, p0, Ly/b;->m:[J

    array-length v4, v3

    if-eq v2, v4, :cond_1

    aput-wide v0, v3, v2

    add-int/lit8 v2, v2, 0x1

    goto :goto_1

    :cond_1
    const-wide v0, 0x6a09e667f3bcc908L    # 6.344059688352415E202

    .line 2
    iput-wide v0, p0, Ly/b;->e:J

    const-wide v0, -0x4498517a7b3558c5L    # -1.5671250923562117E-22

    iput-wide v0, p0, Ly/b;->f:J

    const-wide v0, 0x3c6ef372fe94f82bL    # 1.342284505169847E-17

    iput-wide v0, p0, Ly/b;->g:J

    const-wide v0, -0x5ab00ac5a0e2c90fL

    iput-wide v0, p0, Ly/b;->h:J

    const-wide v0, 0x510e527fade682d1L    # 2.876275032471325E82

    iput-wide v0, p0, Ly/b;->i:J

    const-wide v0, -0x64fa9773d4c193e1L

    iput-wide v0, p0, Ly/b;->j:J

    const-wide v0, 0x1f83d9abfb41bd6bL    # 7.229011495228878E-157

    iput-wide v0, p0, Ly/b;->k:J

    const-wide v0, 0x5be0cd19137e2179L    # 3.816167663240759E134

    iput-wide v0, p0, Ly/b;->l:J

    return-void
.end method

.method public final b(Lb0/a;)V
    .locals 0

    check-cast p1, Ly/e;

    invoke-virtual {p0, p1}, Ly/b;->m(Ly/b;)V

    return-void
.end method

.method public final c()I
    .locals 1

    const/16 v0, 0x40

    return v0
.end method

.method public final e()Lb0/a;
    .locals 1

    new-instance v0, Ly/e;

    invoke-direct {v0, p0}, Ly/e;-><init>(Ly/e;)V

    return-object v0
.end method

.method public final f([BI)I
    .locals 6

    .line 1
    invoke-virtual {p0}, Ly/b;->l()V

    iget-wide v0, p0, Ly/b;->c:J

    const/4 v2, 0x3

    shl-long/2addr v0, v2

    iget-wide v2, p0, Ly/b;->d:J

    const/16 v4, -0x80

    :goto_0
    invoke-virtual {p0, v4}, Ly/b;->p(B)V

    iget v4, p0, Ly/b;->b:I

    if-eqz v4, :cond_0

    const/4 v4, 0x0

    goto :goto_0

    .line 2
    :cond_0
    iget v4, p0, Ly/b;->n:I

    const/16 v5, 0xe

    if-le v4, v5, :cond_1

    invoke-virtual {p0}, Ly/b;->n()V

    :cond_1
    iget-object v4, p0, Ly/b;->m:[J

    aput-wide v2, v4, v5

    const/16 v2, 0xf

    aput-wide v0, v4, v2

    .line 3
    invoke-virtual {p0}, Ly/b;->n()V

    .line 4
    iget-wide v0, p0, Ly/b;->e:J

    invoke-static {v0, v1, p1, p2}, Lb0/b;->c(J[BI)V

    iget-wide v0, p0, Ly/b;->f:J

    add-int/lit8 v2, p2, 0x8

    invoke-static {v0, v1, p1, v2}, Lb0/b;->c(J[BI)V

    iget-wide v0, p0, Ly/b;->g:J

    add-int/lit8 v2, p2, 0x10

    invoke-static {v0, v1, p1, v2}, Lb0/b;->c(J[BI)V

    iget-wide v0, p0, Ly/b;->h:J

    add-int/lit8 v2, p2, 0x18

    invoke-static {v0, v1, p1, v2}, Lb0/b;->c(J[BI)V

    iget-wide v0, p0, Ly/b;->i:J

    add-int/lit8 v2, p2, 0x20

    invoke-static {v0, v1, p1, v2}, Lb0/b;->c(J[BI)V

    iget-wide v0, p0, Ly/b;->j:J

    add-int/lit8 v2, p2, 0x28

    invoke-static {v0, v1, p1, v2}, Lb0/b;->c(J[BI)V

    iget-wide v0, p0, Ly/b;->k:J

    add-int/lit8 v2, p2, 0x30

    invoke-static {v0, v1, p1, v2}, Lb0/b;->c(J[BI)V

    iget-wide v0, p0, Ly/b;->l:J

    add-int/lit8 p2, p2, 0x38

    invoke-static {v0, v1, p1, p2}, Lb0/b;->c(J[BI)V

    invoke-virtual {p0}, Ly/e;->a()V

    const/16 p1, 0x40

    return p1
.end method

.method public final g()Ljava/lang/String;
    .locals 1

    const-string v0, "SHA-512"

    return-object v0
.end method
