.class public Lcom/trilead/ssh2/compression/c;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lcom/trilead/ssh2/compression/b;


# instance fields
.field public a:Ll/f;

.field public b:Ll/f;


# direct methods
.method public constructor <init>()V
    .locals 6

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    new-instance v0, Ll/f;

    invoke-direct {v0}, Ll/f;-><init>()V

    iput-object v0, p0, Lcom/trilead/ssh2/compression/c;->a:Ll/f;

    new-instance v0, Ll/f;

    invoke-direct {v0}, Ll/f;-><init>()V

    iput-object v0, p0, Lcom/trilead/ssh2/compression/c;->b:Ll/f;

    iget-object v0, p0, Lcom/trilead/ssh2/compression/c;->a:Ll/f;

    invoke-static {v0}, Ljava/util/Objects;->requireNonNull(Ljava/lang/Object;)Ljava/lang/Object;

    .line 1
    new-instance v1, Ll/b;

    invoke-direct {v1, v0}, Ll/b;-><init>(Ll/f;)V

    const v2, 0x8000

    .line 2
    iput v2, v1, Ll/b;->e:I

    const/high16 v3, 0x10000

    new-array v3, v3, [B

    iput-object v3, v1, Ll/b;->b:[B

    new-array v3, v2, [S

    iput-object v3, v1, Ll/b;->c:[S

    new-array v3, v2, [S

    iput-object v3, v1, Ll/b;->d:[S

    const v3, 0xc000

    new-array v3, v3, [B

    iput-object v3, v1, Ll/b;->a:[B

    const/16 v3, 0x4000

    new-array v3, v3, [B

    iput-object v3, v1, Ll/b;->q:[B

    const/4 v3, 0x5

    iput v3, v1, Ll/b;->f:I

    .line 3
    iget-object v0, v0, Ll/f;->b:Ll/a;

    invoke-interface {v0}, Ll/a;->a()V

    .line 4
    iget-object v0, v1, Ll/b;->j:La/b;

    invoke-static {v0}, Ljava/util/Objects;->requireNonNull(Ljava/lang/Object;)Ljava/lang/Object;

    iget-object v0, v1, Ll/b;->j:La/b;

    invoke-static {v0}, Ljava/util/Objects;->requireNonNull(Ljava/lang/Object;)Ljava/lang/Object;

    iget-object v0, v1, Ll/b;->k:La/b;

    invoke-static {v0}, Ljava/util/Objects;->requireNonNull(Ljava/lang/Object;)Ljava/lang/Object;

    iget-object v0, v1, Ll/b;->k:La/b;

    invoke-static {v0}, Ljava/util/Objects;->requireNonNull(Ljava/lang/Object;)Ljava/lang/Object;

    iget-object v0, v1, Ll/b;->l:La/b;

    invoke-static {v0}, Ljava/util/Objects;->requireNonNull(Ljava/lang/Object;)Ljava/lang/Object;

    iget-object v0, v1, Ll/b;->l:La/b;

    invoke-static {v0}, Ljava/util/Objects;->requireNonNull(Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v0, 0x0

    const/4 v3, 0x0

    :goto_0
    const/16 v4, 0x11e

    if-ge v3, v4, :cond_0

    .line 5
    iget-object v4, v1, Ll/b;->g:[S

    mul-int/lit8 v5, v3, 0x2

    aput-short v0, v4, v5

    add-int/lit8 v3, v3, 0x1

    goto :goto_0

    :cond_0
    const/4 v3, 0x0

    :goto_1
    const/16 v4, 0x1e

    if-ge v3, v4, :cond_1

    iget-object v4, v1, Ll/b;->h:[S

    mul-int/lit8 v5, v3, 0x2

    aput-short v0, v4, v5

    add-int/lit8 v3, v3, 0x1

    goto :goto_1

    :cond_1
    const/4 v3, 0x0

    :goto_2
    const/16 v4, 0x13

    if-ge v3, v4, :cond_2

    iget-object v4, v1, Ll/b;->i:[S

    mul-int/lit8 v5, v3, 0x2

    aput-short v0, v4, v5

    add-int/lit8 v3, v3, 0x1

    goto :goto_2

    :cond_2
    iget-object v3, v1, Ll/b;->g:[S

    const/16 v4, 0x200

    const/4 v5, 0x1

    aput-short v5, v3, v4

    .line 6
    iget-object v3, v1, Ll/b;->d:[S

    iget v4, v1, Ll/b;->e:I

    add-int/lit8 v4, v4, -0x1

    aput-short v0, v3, v4

    const/4 v3, 0x0

    :goto_3
    iget v4, v1, Ll/b;->e:I

    add-int/lit8 v4, v4, -0x1

    if-ge v3, v4, :cond_3

    iget-object v4, v1, Ll/b;->d:[S

    aput-short v0, v4, v3

    add-int/lit8 v3, v3, 0x1

    goto :goto_3

    :cond_3
    sget-object v0, Ll/b;->s:[Ll/b$a;

    iget v1, v1, Ll/b;->f:I

    aget-object v3, v0, v1

    iget v3, v3, Ll/b$a;->b:I

    aget-object v3, v0, v1

    iget v3, v3, Ll/b$a;->a:I

    aget-object v3, v0, v1

    iget v3, v3, Ll/b$a;->c:I

    aget-object v0, v0, v1

    iget v0, v0, Ll/b$a;->d:I

    .line 7
    iget-object v0, p0, Lcom/trilead/ssh2/compression/c;->b:Ll/f;

    invoke-static {v0}, Ljava/util/Objects;->requireNonNull(Ljava/lang/Object;)Ljava/lang/Object;

    .line 8
    new-instance v1, Ll/e;

    invoke-direct {v1, v0}, Ll/e;-><init>(Ll/f;)V

    iput-object v1, v0, Ll/f;->a:Ll/e;

    .line 9
    iput v5, v1, Ll/e;->a:I

    new-instance v1, Ll/d;

    invoke-direct {v1, v0, v2}, Ll/d;-><init>(Ll/f;I)V

    .line 10
    invoke-virtual {v1}, Ll/d;->a()V

    return-void
.end method
