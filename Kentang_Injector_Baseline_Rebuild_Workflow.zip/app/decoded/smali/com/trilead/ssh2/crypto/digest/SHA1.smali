.class public final Lcom/trilead/ssh2/crypto/digest/SHA1;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lcom/trilead/ssh2/crypto/digest/Digest;


# annotations
.annotation runtime Ljava/lang/Deprecated;
.end annotation


# instance fields
.field public a:I

.field public b:I

.field public c:I

.field public d:I

.field public e:I

.field public final f:[I

.field public g:I

.field public h:J


# direct methods
.method public constructor <init>()V
    .locals 1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/16 v0, 0x50

    new-array v0, v0, [I

    iput-object v0, p0, Lcom/trilead/ssh2/crypto/digest/SHA1;->f:[I

    invoke-virtual {p0}, Lcom/trilead/ssh2/crypto/digest/SHA1;->a()V

    return-void
.end method


# virtual methods
.method public final a()V
    .locals 2

    const v0, 0x67452301

    iput v0, p0, Lcom/trilead/ssh2/crypto/digest/SHA1;->a:I

    const v0, -0x10325477

    iput v0, p0, Lcom/trilead/ssh2/crypto/digest/SHA1;->b:I

    const v0, -0x67452302

    iput v0, p0, Lcom/trilead/ssh2/crypto/digest/SHA1;->c:I

    const v0, 0x10325476

    iput v0, p0, Lcom/trilead/ssh2/crypto/digest/SHA1;->d:I

    const v0, -0x3c2d1e10

    iput v0, p0, Lcom/trilead/ssh2/crypto/digest/SHA1;->e:I

    const/4 v0, 0x0

    iput v0, p0, Lcom/trilead/ssh2/crypto/digest/SHA1;->g:I

    const-wide/16 v0, 0x0

    iput-wide v0, p0, Lcom/trilead/ssh2/crypto/digest/SHA1;->h:J

    return-void
.end method

.method public final b([B)V
    .locals 10

    iget v0, p0, Lcom/trilead/ssh2/crypto/digest/SHA1;->g:I

    shr-int/lit8 v1, v0, 0x2

    iget-object v2, p0, Lcom/trilead/ssh2/crypto/digest/SHA1;->f:[I

    aget v3, v2, v1

    const/16 v4, 0x8

    shl-int/2addr v3, v4

    or-int/lit16 v3, v3, 0x80

    and-int/lit8 v5, v0, 0x3

    rsub-int/lit8 v5, v5, 0x3

    shl-int/lit8 v5, v5, 0x3

    shl-int/2addr v3, v5

    aput v3, v2, v1

    and-int/lit8 v0, v0, -0x4

    const/4 v1, 0x4

    add-int/2addr v0, v1

    iput v0, p0, Lcom/trilead/ssh2/crypto/digest/SHA1;->g:I

    const/4 v3, 0x0

    const/16 v5, 0xf

    const/16 v6, 0x40

    if-ne v0, v6, :cond_0

    iput v3, p0, Lcom/trilead/ssh2/crypto/digest/SHA1;->g:I

    goto :goto_0

    :cond_0
    const/16 v6, 0x3c

    if-ne v0, v6, :cond_1

    iput v3, p0, Lcom/trilead/ssh2/crypto/digest/SHA1;->g:I

    aput v3, v2, v5

    :goto_0
    invoke-virtual {p0}, Lcom/trilead/ssh2/crypto/digest/SHA1;->h()V

    :cond_1
    iget v0, p0, Lcom/trilead/ssh2/crypto/digest/SHA1;->g:I

    shr-int/lit8 v0, v0, 0x2

    :goto_1
    const/16 v2, 0xe

    if-ge v0, v2, :cond_2

    iget-object v2, p0, Lcom/trilead/ssh2/crypto/digest/SHA1;->f:[I

    aput v3, v2, v0

    add-int/lit8 v0, v0, 0x1

    goto :goto_1

    :cond_2
    iget-object v0, p0, Lcom/trilead/ssh2/crypto/digest/SHA1;->f:[I

    iget-wide v6, p0, Lcom/trilead/ssh2/crypto/digest/SHA1;->h:J

    const/16 v8, 0x20

    shr-long v8, v6, v8

    long-to-int v9, v8

    aput v9, v0, v2

    long-to-int v2, v6

    aput v2, v0, v5

    invoke-virtual {p0}, Lcom/trilead/ssh2/crypto/digest/SHA1;->h()V

    iget v0, p0, Lcom/trilead/ssh2/crypto/digest/SHA1;->a:I

    invoke-virtual {p0, p1, v3, v0}, Lcom/trilead/ssh2/crypto/digest/SHA1;->i([BII)V

    iget v0, p0, Lcom/trilead/ssh2/crypto/digest/SHA1;->b:I

    invoke-virtual {p0, p1, v1, v0}, Lcom/trilead/ssh2/crypto/digest/SHA1;->i([BII)V

    iget v0, p0, Lcom/trilead/ssh2/crypto/digest/SHA1;->c:I

    invoke-virtual {p0, p1, v4, v0}, Lcom/trilead/ssh2/crypto/digest/SHA1;->i([BII)V

    const/16 v0, 0xc

    iget v1, p0, Lcom/trilead/ssh2/crypto/digest/SHA1;->d:I

    invoke-virtual {p0, p1, v0, v1}, Lcom/trilead/ssh2/crypto/digest/SHA1;->i([BII)V

    const/16 v0, 0x10

    iget v1, p0, Lcom/trilead/ssh2/crypto/digest/SHA1;->e:I

    invoke-virtual {p0, p1, v0, v1}, Lcom/trilead/ssh2/crypto/digest/SHA1;->i([BII)V

    invoke-virtual {p0}, Lcom/trilead/ssh2/crypto/digest/SHA1;->a()V

    return-void
.end method

.method public final c()I
    .locals 1

    const/16 v0, 0x14

    return v0
.end method

.method public final d([BI)V
    .locals 15

    move-object v0, p0

    move/from16 v1, p2

    const/4 v2, 0x4

    const/4 v3, 0x0

    const/4 v4, 0x1

    const-wide/16 v5, 0x8

    const/16 v7, 0x40

    const/16 v8, 0x8

    if-lt v1, v2, :cond_a

    iget v9, v0, Lcom/trilead/ssh2/crypto/digest/SHA1;->g:I

    shr-int/lit8 v10, v9, 0x2

    and-int/lit8 v11, v9, 0x3

    const/4 v13, 0x3

    const/4 v14, 0x2

    if-eqz v11, :cond_4

    if-eq v11, v4, :cond_3

    if-eq v11, v14, :cond_1

    if-eq v11, v13, :cond_0

    const/4 v13, 0x0

    goto/16 :goto_1

    :cond_0
    iget-object v11, v0, Lcom/trilead/ssh2/crypto/digest/SHA1;->f:[I

    aget v13, v11, v10

    shl-int/2addr v13, v8

    aget-byte v14, p1, v3

    and-int/lit16 v14, v14, 0xff

    or-int/2addr v13, v14

    aput v13, v11, v10

    add-int/lit8 v1, v1, -0x1

    add-int/2addr v9, v4

    iput v9, v0, Lcom/trilead/ssh2/crypto/digest/SHA1;->g:I

    iget-wide v10, v0, Lcom/trilead/ssh2/crypto/digest/SHA1;->h:J

    add-long/2addr v10, v5

    iput-wide v10, v0, Lcom/trilead/ssh2/crypto/digest/SHA1;->h:J

    const/4 v13, 0x1

    if-ne v9, v7, :cond_6

    goto :goto_0

    :cond_1
    iget-object v11, v0, Lcom/trilead/ssh2/crypto/digest/SHA1;->f:[I

    aget v13, v11, v10

    shl-int/lit8 v13, v13, 0x10

    aget-byte v5, p1, v3

    and-int/lit16 v5, v5, 0xff

    shl-int/2addr v5, v8

    aget-byte v6, p1, v4

    and-int/lit16 v6, v6, 0xff

    or-int/2addr v5, v6

    or-int/2addr v5, v13

    aput v5, v11, v10

    add-int/lit8 v1, v1, -0x2

    add-int/2addr v9, v14

    iput v9, v0, Lcom/trilead/ssh2/crypto/digest/SHA1;->g:I

    iget-wide v5, v0, Lcom/trilead/ssh2/crypto/digest/SHA1;->h:J

    const-wide/16 v10, 0x10

    add-long/2addr v5, v10

    iput-wide v5, v0, Lcom/trilead/ssh2/crypto/digest/SHA1;->h:J

    if-ne v9, v7, :cond_2

    invoke-virtual {p0}, Lcom/trilead/ssh2/crypto/digest/SHA1;->h()V

    iput v3, v0, Lcom/trilead/ssh2/crypto/digest/SHA1;->g:I

    :cond_2
    const/4 v13, 0x2

    goto :goto_1

    :cond_3
    iget-object v5, v0, Lcom/trilead/ssh2/crypto/digest/SHA1;->f:[I

    aget v6, v5, v10

    shl-int/lit8 v6, v6, 0x18

    aget-byte v11, p1, v3

    and-int/lit16 v11, v11, 0xff

    shl-int/lit8 v11, v11, 0x10

    aget-byte v12, p1, v4

    and-int/lit16 v12, v12, 0xff

    shl-int/2addr v12, v8

    or-int/2addr v11, v12

    aget-byte v12, p1, v14

    and-int/lit16 v12, v12, 0xff

    or-int/2addr v11, v12

    or-int/2addr v6, v11

    aput v6, v5, v10

    add-int/lit8 v1, v1, -0x3

    add-int/2addr v9, v13

    iput v9, v0, Lcom/trilead/ssh2/crypto/digest/SHA1;->g:I

    iget-wide v5, v0, Lcom/trilead/ssh2/crypto/digest/SHA1;->h:J

    const-wide/16 v10, 0x18

    add-long/2addr v5, v10

    iput-wide v5, v0, Lcom/trilead/ssh2/crypto/digest/SHA1;->h:J

    if-ne v9, v7, :cond_6

    :goto_0
    invoke-virtual {p0}, Lcom/trilead/ssh2/crypto/digest/SHA1;->h()V

    iput v3, v0, Lcom/trilead/ssh2/crypto/digest/SHA1;->g:I

    goto :goto_1

    :cond_4
    iget-object v5, v0, Lcom/trilead/ssh2/crypto/digest/SHA1;->f:[I

    aget-byte v6, p1, v3

    and-int/lit16 v6, v6, 0xff

    shl-int/lit8 v6, v6, 0x18

    aget-byte v11, p1, v4

    and-int/lit16 v11, v11, 0xff

    shl-int/lit8 v11, v11, 0x10

    or-int/2addr v6, v11

    aget-byte v11, p1, v14

    and-int/lit16 v11, v11, 0xff

    shl-int/2addr v11, v8

    or-int/2addr v6, v11

    aget-byte v11, p1, v13

    and-int/lit16 v11, v11, 0xff

    or-int/2addr v6, v11

    aput v6, v5, v10

    add-int/lit8 v1, v1, -0x4

    add-int/2addr v9, v2

    iput v9, v0, Lcom/trilead/ssh2/crypto/digest/SHA1;->g:I

    iget-wide v5, v0, Lcom/trilead/ssh2/crypto/digest/SHA1;->h:J

    const-wide/16 v10, 0x20

    add-long/2addr v5, v10

    iput-wide v5, v0, Lcom/trilead/ssh2/crypto/digest/SHA1;->h:J

    if-ne v9, v7, :cond_5

    invoke-virtual {p0}, Lcom/trilead/ssh2/crypto/digest/SHA1;->h()V

    iput v3, v0, Lcom/trilead/ssh2/crypto/digest/SHA1;->g:I

    :cond_5
    const/4 v13, 0x4

    :cond_6
    :goto_1
    if-lt v1, v8, :cond_9

    iget-object v5, v0, Lcom/trilead/ssh2/crypto/digest/SHA1;->f:[I

    iget v6, v0, Lcom/trilead/ssh2/crypto/digest/SHA1;->g:I

    shr-int/lit8 v9, v6, 0x2

    add-int/lit8 v10, v13, 0x1

    aget-byte v11, p1, v13

    and-int/lit16 v11, v11, 0xff

    shl-int/lit8 v11, v11, 0x18

    add-int/lit8 v12, v10, 0x1

    aget-byte v10, p1, v10

    and-int/lit16 v10, v10, 0xff

    shl-int/lit8 v10, v10, 0x10

    or-int/2addr v10, v11

    add-int/lit8 v11, v12, 0x1

    aget-byte v12, p1, v12

    and-int/lit16 v12, v12, 0xff

    shl-int/2addr v12, v8

    or-int/2addr v10, v12

    add-int/lit8 v12, v11, 0x1

    aget-byte v11, p1, v11

    and-int/lit16 v11, v11, 0xff

    or-int/2addr v10, v11

    aput v10, v5, v9

    add-int/2addr v6, v2

    iput v6, v0, Lcom/trilead/ssh2/crypto/digest/SHA1;->g:I

    if-ne v6, v7, :cond_7

    invoke-virtual {p0}, Lcom/trilead/ssh2/crypto/digest/SHA1;->h()V

    iput v3, v0, Lcom/trilead/ssh2/crypto/digest/SHA1;->g:I

    :cond_7
    iget-object v5, v0, Lcom/trilead/ssh2/crypto/digest/SHA1;->f:[I

    iget v6, v0, Lcom/trilead/ssh2/crypto/digest/SHA1;->g:I

    shr-int/lit8 v9, v6, 0x2

    add-int/lit8 v10, v12, 0x1

    aget-byte v11, p1, v12

    and-int/lit16 v11, v11, 0xff

    shl-int/lit8 v11, v11, 0x18

    add-int/lit8 v12, v10, 0x1

    aget-byte v10, p1, v10

    and-int/lit16 v10, v10, 0xff

    shl-int/lit8 v10, v10, 0x10

    or-int/2addr v10, v11

    add-int/lit8 v11, v12, 0x1

    aget-byte v12, p1, v12

    and-int/lit16 v12, v12, 0xff

    shl-int/2addr v12, v8

    or-int/2addr v10, v12

    add-int/lit8 v13, v11, 0x1

    aget-byte v11, p1, v11

    and-int/lit16 v11, v11, 0xff

    or-int/2addr v10, v11

    aput v10, v5, v9

    add-int/2addr v6, v2

    iput v6, v0, Lcom/trilead/ssh2/crypto/digest/SHA1;->g:I

    if-ne v6, v7, :cond_8

    invoke-virtual {p0}, Lcom/trilead/ssh2/crypto/digest/SHA1;->h()V

    iput v3, v0, Lcom/trilead/ssh2/crypto/digest/SHA1;->g:I

    :cond_8
    iget-wide v5, v0, Lcom/trilead/ssh2/crypto/digest/SHA1;->h:J

    const-wide/16 v9, 0x40

    add-long/2addr v5, v9

    iput-wide v5, v0, Lcom/trilead/ssh2/crypto/digest/SHA1;->h:J

    add-int/lit8 v1, v1, -0x8

    goto :goto_1

    :cond_9
    :goto_2
    if-gez v1, :cond_b

    iget-object v5, v0, Lcom/trilead/ssh2/crypto/digest/SHA1;->f:[I

    iget v6, v0, Lcom/trilead/ssh2/crypto/digest/SHA1;->g:I

    shr-int/lit8 v9, v6, 0x2

    add-int/lit8 v10, v13, 0x1

    aget-byte v11, p1, v13

    and-int/lit16 v11, v11, 0xff

    shl-int/lit8 v11, v11, 0x18

    add-int/lit8 v12, v10, 0x1

    aget-byte v10, p1, v10

    and-int/lit16 v10, v10, 0xff

    shl-int/lit8 v10, v10, 0x10

    or-int/2addr v10, v11

    add-int/lit8 v11, v12, 0x1

    aget-byte v12, p1, v12

    and-int/lit16 v12, v12, 0xff

    shl-int/2addr v12, v8

    or-int/2addr v10, v12

    add-int/lit8 v13, v11, 0x1

    aget-byte v11, p1, v11

    and-int/lit16 v11, v11, 0xff

    or-int/2addr v10, v11

    aput v10, v5, v9

    add-int/lit8 v1, v1, -0x4

    add-int/2addr v6, v2

    iput v6, v0, Lcom/trilead/ssh2/crypto/digest/SHA1;->g:I

    iget-wide v9, v0, Lcom/trilead/ssh2/crypto/digest/SHA1;->h:J

    const-wide/16 v11, 0x20

    add-long/2addr v9, v11

    iput-wide v9, v0, Lcom/trilead/ssh2/crypto/digest/SHA1;->h:J

    if-ne v6, v7, :cond_9

    invoke-virtual {p0}, Lcom/trilead/ssh2/crypto/digest/SHA1;->h()V

    iput v3, v0, Lcom/trilead/ssh2/crypto/digest/SHA1;->g:I

    goto :goto_2

    :cond_a
    const/4 v13, 0x0

    :cond_b
    :goto_3
    if-lez v1, :cond_d

    iget v2, v0, Lcom/trilead/ssh2/crypto/digest/SHA1;->g:I

    shr-int/lit8 v5, v2, 0x2

    iget-object v6, v0, Lcom/trilead/ssh2/crypto/digest/SHA1;->f:[I

    aget v9, v6, v5

    shl-int/2addr v9, v8

    add-int/lit8 v10, v13, 0x1

    aget-byte v11, p1, v13

    and-int/lit16 v11, v11, 0xff

    or-int/2addr v9, v11

    aput v9, v6, v5

    iget-wide v5, v0, Lcom/trilead/ssh2/crypto/digest/SHA1;->h:J

    const-wide/16 v11, 0x8

    add-long/2addr v5, v11

    iput-wide v5, v0, Lcom/trilead/ssh2/crypto/digest/SHA1;->h:J

    add-int/2addr v2, v4

    iput v2, v0, Lcom/trilead/ssh2/crypto/digest/SHA1;->g:I

    if-ne v2, v7, :cond_c

    invoke-virtual {p0}, Lcom/trilead/ssh2/crypto/digest/SHA1;->h()V

    iput v3, v0, Lcom/trilead/ssh2/crypto/digest/SHA1;->g:I

    :cond_c
    add-int/lit8 v1, v1, -0x1

    move v13, v10

    goto :goto_3

    :cond_d
    return-void
.end method

.method public final e([B)V
    .locals 0

    invoke-virtual {p0, p1}, Lcom/trilead/ssh2/crypto/digest/SHA1;->b([B)V

    return-void
.end method

.method public final f(B)V
    .locals 5

    iget v0, p0, Lcom/trilead/ssh2/crypto/digest/SHA1;->g:I

    shr-int/lit8 v1, v0, 0x2

    iget-object v2, p0, Lcom/trilead/ssh2/crypto/digest/SHA1;->f:[I

    aget v3, v2, v1

    shl-int/lit8 v3, v3, 0x8

    and-int/lit16 p1, p1, 0xff

    or-int/2addr p1, v3

    aput p1, v2, v1

    iget-wide v1, p0, Lcom/trilead/ssh2/crypto/digest/SHA1;->h:J

    const-wide/16 v3, 0x8

    add-long/2addr v1, v3

    iput-wide v1, p0, Lcom/trilead/ssh2/crypto/digest/SHA1;->h:J

    add-int/lit8 v0, v0, 0x1

    iput v0, p0, Lcom/trilead/ssh2/crypto/digest/SHA1;->g:I

    const/16 p1, 0x40

    if-ne v0, p1, :cond_0

    invoke-virtual {p0}, Lcom/trilead/ssh2/crypto/digest/SHA1;->h()V

    const/4 p1, 0x0

    iput p1, p0, Lcom/trilead/ssh2/crypto/digest/SHA1;->g:I

    :cond_0
    return-void
.end method

.method public final g([B)V
    .locals 1

    array-length v0, p1

    invoke-virtual {p0, p1, v0}, Lcom/trilead/ssh2/crypto/digest/SHA1;->d([BI)V

    return-void
.end method

.method public final h()V
    .locals 15

    const/16 v0, 0x10

    :goto_0
    const/16 v1, 0x50

    if-ge v0, v1, :cond_0

    iget-object v1, p0, Lcom/trilead/ssh2/crypto/digest/SHA1;->f:[I

    add-int/lit8 v2, v0, -0x3

    aget v2, v1, v2

    add-int/lit8 v3, v0, -0x8

    aget v3, v1, v3

    xor-int/2addr v2, v3

    add-int/lit8 v3, v0, -0xe

    aget v3, v1, v3

    xor-int/2addr v2, v3

    add-int/lit8 v3, v0, -0x10

    aget v3, v1, v3

    xor-int/2addr v2, v3

    shl-int/lit8 v3, v2, 0x1

    ushr-int/lit8 v2, v2, 0x1f

    or-int/2addr v2, v3

    aput v2, v1, v0

    add-int/lit8 v0, v0, 0x1

    goto :goto_0

    :cond_0
    iget v0, p0, Lcom/trilead/ssh2/crypto/digest/SHA1;->a:I

    iget v1, p0, Lcom/trilead/ssh2/crypto/digest/SHA1;->b:I

    iget v2, p0, Lcom/trilead/ssh2/crypto/digest/SHA1;->c:I

    iget v3, p0, Lcom/trilead/ssh2/crypto/digest/SHA1;->d:I

    iget v4, p0, Lcom/trilead/ssh2/crypto/digest/SHA1;->e:I

    shl-int/lit8 v5, v0, 0x5

    ushr-int/lit8 v6, v0, 0x1b

    or-int/2addr v5, v6

    and-int v6, v1, v2

    not-int v7, v1

    and-int/2addr v7, v3

    or-int/2addr v6, v7

    add-int/2addr v5, v6

    iget-object v6, p0, Lcom/trilead/ssh2/crypto/digest/SHA1;->f:[I

    const/4 v7, 0x0

    aget v7, v6, v7

    const v8, 0x5a827999

    invoke-static {v5, v7, v8, v4}, Lcom/trilead/ssh2/crypto/digest/a;->a(IIII)I

    move-result v5

    shl-int/lit8 v7, v1, 0x1e

    ushr-int/lit8 v9, v1, 0x2

    or-int/2addr v7, v9

    shl-int/lit8 v9, v5, 0x5

    ushr-int/lit8 v10, v5, 0x1b

    or-int/2addr v9, v10

    and-int v10, v0, v7

    not-int v11, v0

    and-int/2addr v11, v2

    or-int/2addr v10, v11

    add-int/2addr v9, v10

    const/4 v10, 0x1

    aget v10, v6, v10

    invoke-static {v9, v10, v8, v3}, Lcom/trilead/ssh2/crypto/digest/a;->a(IIII)I

    move-result v9

    shl-int/lit8 v10, v0, 0x1e

    ushr-int/lit8 v11, v0, 0x2

    or-int/2addr v10, v11

    shl-int/lit8 v11, v9, 0x5

    ushr-int/lit8 v12, v9, 0x1b

    or-int/2addr v11, v12

    and-int v12, v5, v10

    not-int v13, v5

    and-int/2addr v13, v7

    or-int/2addr v12, v13

    add-int/2addr v11, v12

    const/4 v12, 0x2

    aget v13, v6, v12

    invoke-static {v11, v13, v8, v2}, Lcom/trilead/ssh2/crypto/digest/a;->a(IIII)I

    move-result v11

    shl-int/lit8 v13, v5, 0x1e

    ushr-int/2addr v5, v12

    or-int/2addr v5, v13

    shl-int/lit8 v12, v11, 0x5

    ushr-int/lit8 v13, v11, 0x1b

    or-int/2addr v12, v13

    and-int v13, v9, v5

    not-int v14, v9

    and-int/2addr v14, v10

    or-int/2addr v13, v14

    add-int/2addr v12, v13

    const/4 v13, 0x3

    aget v13, v6, v13

    invoke-static {v12, v13, v8, v7}, Lcom/trilead/ssh2/crypto/digest/a;->a(IIII)I

    move-result v7

    shl-int/lit8 v12, v9, 0x1e

    ushr-int/lit8 v9, v9, 0x2

    or-int/2addr v9, v12

    shl-int/lit8 v12, v7, 0x5

    ushr-int/lit8 v13, v7, 0x1b

    or-int/2addr v12, v13

    and-int v13, v11, v9

    not-int v14, v11

    and-int/2addr v14, v5

    or-int/2addr v13, v14

    add-int/2addr v12, v13

    const/4 v13, 0x4

    aget v13, v6, v13

    invoke-static {v12, v13, v8, v10}, Lcom/trilead/ssh2/crypto/digest/a;->a(IIII)I

    move-result v10

    shl-int/lit8 v12, v11, 0x1e

    ushr-int/lit8 v11, v11, 0x2

    or-int/2addr v11, v12

    shl-int/lit8 v12, v10, 0x5

    ushr-int/lit8 v13, v10, 0x1b

    or-int/2addr v12, v13

    and-int v13, v7, v11

    not-int v14, v7

    and-int/2addr v14, v9

    or-int/2addr v13, v14

    add-int/2addr v12, v13

    const/4 v13, 0x5

    aget v13, v6, v13

    invoke-static {v12, v13, v8, v5}, Lcom/trilead/ssh2/crypto/digest/a;->a(IIII)I

    move-result v5

    shl-int/lit8 v12, v7, 0x1e

    ushr-int/lit8 v7, v7, 0x2

    or-int/2addr v7, v12

    shl-int/lit8 v12, v5, 0x5

    ushr-int/lit8 v13, v5, 0x1b

    or-int/2addr v12, v13

    and-int v13, v10, v7

    not-int v14, v10

    and-int/2addr v14, v11

    or-int/2addr v13, v14

    add-int/2addr v12, v13

    const/4 v13, 0x6

    aget v13, v6, v13

    invoke-static {v12, v13, v8, v9}, Lcom/trilead/ssh2/crypto/digest/a;->a(IIII)I

    move-result v9

    shl-int/lit8 v12, v10, 0x1e

    ushr-int/lit8 v10, v10, 0x2

    or-int/2addr v10, v12

    shl-int/lit8 v12, v9, 0x5

    ushr-int/lit8 v13, v9, 0x1b

    or-int/2addr v12, v13

    and-int v13, v5, v10

    not-int v14, v5

    and-int/2addr v14, v7

    or-int/2addr v13, v14

    add-int/2addr v12, v13

    const/4 v13, 0x7

    aget v13, v6, v13

    invoke-static {v12, v13, v8, v11}, Lcom/trilead/ssh2/crypto/digest/a;->a(IIII)I

    move-result v11

    shl-int/lit8 v12, v5, 0x1e

    ushr-int/lit8 v5, v5, 0x2

    or-int/2addr v5, v12

    shl-int/lit8 v12, v11, 0x5

    ushr-int/lit8 v13, v11, 0x1b

    or-int/2addr v12, v13

    and-int v13, v9, v5

    not-int v14, v9

    and-int/2addr v14, v10

    or-int/2addr v13, v14

    add-int/2addr v12, v13

    const/16 v13, 0x8

    aget v13, v6, v13

    invoke-static {v12, v13, v8, v7}, Lcom/trilead/ssh2/crypto/digest/a;->a(IIII)I

    move-result v7

    shl-int/lit8 v12, v9, 0x1e

    ushr-int/lit8 v9, v9, 0x2

    or-int/2addr v9, v12

    shl-int/lit8 v12, v7, 0x5

    ushr-int/lit8 v13, v7, 0x1b

    or-int/2addr v12, v13

    and-int v13, v11, v9

    not-int v14, v11

    and-int/2addr v14, v5

    or-int/2addr v13, v14

    add-int/2addr v12, v13

    const/16 v13, 0x9

    aget v13, v6, v13

    invoke-static {v12, v13, v8, v10}, Lcom/trilead/ssh2/crypto/digest/a;->a(IIII)I

    move-result v10

    shl-int/lit8 v12, v11, 0x1e

    ushr-int/lit8 v11, v11, 0x2

    or-int/2addr v11, v12

    shl-int/lit8 v12, v10, 0x5

    ushr-int/lit8 v13, v10, 0x1b

    or-int/2addr v12, v13

    and-int v13, v7, v11

    not-int v14, v7

    and-int/2addr v14, v9

    or-int/2addr v13, v14

    add-int/2addr v12, v13

    const/16 v13, 0xa

    aget v13, v6, v13

    invoke-static {v12, v13, v8, v5}, Lcom/trilead/ssh2/crypto/digest/a;->a(IIII)I

    move-result v5

    shl-int/lit8 v12, v7, 0x1e

    ushr-int/lit8 v7, v7, 0x2

    or-int/2addr v7, v12

    shl-int/lit8 v12, v5, 0x5

    ushr-int/lit8 v13, v5, 0x1b

    or-int/2addr v12, v13

    and-int v13, v10, v7

    not-int v14, v10

    and-int/2addr v14, v11

    or-int/2addr v13, v14

    add-int/2addr v12, v13

    const/16 v13, 0xb

    aget v13, v6, v13

    invoke-static {v12, v13, v8, v9}, Lcom/trilead/ssh2/crypto/digest/a;->a(IIII)I

    move-result v9

    shl-int/lit8 v12, v10, 0x1e

    ushr-int/lit8 v10, v10, 0x2

    or-int/2addr v10, v12

    shl-int/lit8 v12, v9, 0x5

    ushr-int/lit8 v13, v9, 0x1b

    or-int/2addr v12, v13

    and-int v13, v5, v10

    not-int v14, v5

    and-int/2addr v14, v7

    or-int/2addr v13, v14

    add-int/2addr v12, v13

    const/16 v13, 0xc

    aget v13, v6, v13

    invoke-static {v12, v13, v8, v11}, Lcom/trilead/ssh2/crypto/digest/a;->a(IIII)I

    move-result v11

    shl-int/lit8 v12, v5, 0x1e

    ushr-int/lit8 v5, v5, 0x2

    or-int/2addr v5, v12

    shl-int/lit8 v12, v11, 0x5

    ushr-int/lit8 v13, v11, 0x1b

    or-int/2addr v12, v13

    and-int v13, v9, v5

    not-int v14, v9

    and-int/2addr v14, v10

    or-int/2addr v13, v14

    add-int/2addr v12, v13

    const/16 v13, 0xd

    aget v13, v6, v13

    invoke-static {v12, v13, v8, v7}, Lcom/trilead/ssh2/crypto/digest/a;->a(IIII)I

    move-result v7

    shl-int/lit8 v12, v9, 0x1e

    ushr-int/lit8 v9, v9, 0x2

    or-int/2addr v9, v12

    shl-int/lit8 v12, v7, 0x5

    ushr-int/lit8 v13, v7, 0x1b

    or-int/2addr v12, v13

    and-int v13, v11, v9

    not-int v14, v11

    and-int/2addr v14, v5

    or-int/2addr v13, v14

    add-int/2addr v12, v13

    const/16 v13, 0xe

    aget v13, v6, v13

    invoke-static {v12, v13, v8, v10}, Lcom/trilead/ssh2/crypto/digest/a;->a(IIII)I

    move-result v10

    shl-int/lit8 v12, v11, 0x1e

    ushr-int/lit8 v11, v11, 0x2

    or-int/2addr v11, v12

    shl-int/lit8 v12, v10, 0x5

    ushr-int/lit8 v13, v10, 0x1b

    or-int/2addr v12, v13

    and-int v13, v7, v11

    not-int v14, v7

    and-int/2addr v14, v9

    or-int/2addr v13, v14

    add-int/2addr v12, v13

    const/16 v13, 0xf

    aget v13, v6, v13

    invoke-static {v12, v13, v8, v5}, Lcom/trilead/ssh2/crypto/digest/a;->a(IIII)I

    move-result v5

    shl-int/lit8 v12, v7, 0x1e

    ushr-int/lit8 v7, v7, 0x2

    or-int/2addr v7, v12

    shl-int/lit8 v12, v5, 0x5

    ushr-int/lit8 v13, v5, 0x1b

    or-int/2addr v12, v13

    and-int v13, v10, v7

    not-int v14, v10

    and-int/2addr v14, v11

    or-int/2addr v13, v14

    add-int/2addr v12, v13

    const/16 v13, 0x10

    aget v13, v6, v13

    invoke-static {v12, v13, v8, v9}, Lcom/trilead/ssh2/crypto/digest/a;->a(IIII)I

    move-result v9

    shl-int/lit8 v12, v10, 0x1e

    ushr-int/lit8 v10, v10, 0x2

    or-int/2addr v10, v12

    shl-int/lit8 v12, v9, 0x5

    ushr-int/lit8 v13, v9, 0x1b

    or-int/2addr v12, v13

    and-int v13, v5, v10

    not-int v14, v5

    and-int/2addr v14, v7

    or-int/2addr v13, v14

    add-int/2addr v12, v13

    const/16 v13, 0x11

    aget v13, v6, v13

    invoke-static {v12, v13, v8, v11}, Lcom/trilead/ssh2/crypto/digest/a;->a(IIII)I

    move-result v11

    shl-int/lit8 v12, v5, 0x1e

    ushr-int/lit8 v5, v5, 0x2

    or-int/2addr v5, v12

    shl-int/lit8 v12, v11, 0x5

    ushr-int/lit8 v13, v11, 0x1b

    or-int/2addr v12, v13

    and-int v13, v9, v5

    not-int v14, v9

    and-int/2addr v14, v10

    or-int/2addr v13, v14

    add-int/2addr v12, v13

    const/16 v13, 0x12

    aget v13, v6, v13

    invoke-static {v12, v13, v8, v7}, Lcom/trilead/ssh2/crypto/digest/a;->a(IIII)I

    move-result v7

    shl-int/lit8 v12, v9, 0x1e

    ushr-int/lit8 v9, v9, 0x2

    or-int/2addr v9, v12

    shl-int/lit8 v12, v7, 0x5

    ushr-int/lit8 v13, v7, 0x1b

    or-int/2addr v12, v13

    and-int v13, v11, v9

    not-int v14, v11

    and-int/2addr v14, v5

    or-int/2addr v13, v14

    add-int/2addr v12, v13

    const/16 v13, 0x13

    aget v13, v6, v13

    invoke-static {v12, v13, v8, v10}, Lcom/trilead/ssh2/crypto/digest/a;->a(IIII)I

    move-result v8

    shl-int/lit8 v10, v11, 0x1e

    ushr-int/lit8 v11, v11, 0x2

    or-int/2addr v10, v11

    shl-int/lit8 v11, v8, 0x5

    ushr-int/lit8 v12, v8, 0x1b

    or-int/2addr v11, v12

    xor-int v12, v7, v10

    xor-int/2addr v12, v9

    add-int/2addr v11, v12

    const/16 v12, 0x14

    aget v12, v6, v12

    const v13, 0x6ed9eba1

    invoke-static {v11, v12, v13, v5}, Lcom/trilead/ssh2/crypto/digest/a;->a(IIII)I

    move-result v5

    shl-int/lit8 v11, v7, 0x1e

    ushr-int/lit8 v7, v7, 0x2

    or-int/2addr v7, v11

    shl-int/lit8 v11, v5, 0x5

    ushr-int/lit8 v12, v5, 0x1b

    or-int/2addr v11, v12

    xor-int v12, v8, v7

    xor-int/2addr v12, v10

    add-int/2addr v11, v12

    const/16 v12, 0x15

    aget v12, v6, v12

    invoke-static {v11, v12, v13, v9}, Lcom/trilead/ssh2/crypto/digest/a;->a(IIII)I

    move-result v9

    shl-int/lit8 v11, v8, 0x1e

    ushr-int/lit8 v8, v8, 0x2

    or-int/2addr v8, v11

    shl-int/lit8 v11, v9, 0x5

    ushr-int/lit8 v12, v9, 0x1b

    or-int/2addr v11, v12

    xor-int v12, v5, v8

    xor-int/2addr v12, v7

    add-int/2addr v11, v12

    const/16 v12, 0x16

    aget v12, v6, v12

    invoke-static {v11, v12, v13, v10}, Lcom/trilead/ssh2/crypto/digest/a;->a(IIII)I

    move-result v10

    shl-int/lit8 v11, v5, 0x1e

    ushr-int/lit8 v5, v5, 0x2

    or-int/2addr v5, v11

    shl-int/lit8 v11, v10, 0x5

    ushr-int/lit8 v12, v10, 0x1b

    or-int/2addr v11, v12

    xor-int v12, v9, v5

    xor-int/2addr v12, v8

    add-int/2addr v11, v12

    const/16 v12, 0x17

    aget v12, v6, v12

    invoke-static {v11, v12, v13, v7}, Lcom/trilead/ssh2/crypto/digest/a;->a(IIII)I

    move-result v7

    shl-int/lit8 v11, v9, 0x1e

    ushr-int/lit8 v9, v9, 0x2

    or-int/2addr v9, v11

    shl-int/lit8 v11, v7, 0x5

    ushr-int/lit8 v12, v7, 0x1b

    or-int/2addr v11, v12

    xor-int v12, v10, v9

    xor-int/2addr v12, v5

    add-int/2addr v11, v12

    const/16 v12, 0x18

    aget v12, v6, v12

    invoke-static {v11, v12, v13, v8}, Lcom/trilead/ssh2/crypto/digest/a;->a(IIII)I

    move-result v8

    shl-int/lit8 v11, v10, 0x1e

    ushr-int/lit8 v10, v10, 0x2

    or-int/2addr v10, v11

    shl-int/lit8 v11, v8, 0x5

    ushr-int/lit8 v12, v8, 0x1b

    or-int/2addr v11, v12

    xor-int v12, v7, v10

    xor-int/2addr v12, v9

    add-int/2addr v11, v12

    const/16 v12, 0x19

    aget v12, v6, v12

    invoke-static {v11, v12, v13, v5}, Lcom/trilead/ssh2/crypto/digest/a;->a(IIII)I

    move-result v5

    shl-int/lit8 v11, v7, 0x1e

    ushr-int/lit8 v7, v7, 0x2

    or-int/2addr v7, v11

    shl-int/lit8 v11, v5, 0x5

    ushr-int/lit8 v12, v5, 0x1b

    or-int/2addr v11, v12

    xor-int v12, v8, v7

    xor-int/2addr v12, v10

    add-int/2addr v11, v12

    const/16 v12, 0x1a

    aget v12, v6, v12

    invoke-static {v11, v12, v13, v9}, Lcom/trilead/ssh2/crypto/digest/a;->a(IIII)I

    move-result v9

    shl-int/lit8 v11, v8, 0x1e

    ushr-int/lit8 v8, v8, 0x2

    or-int/2addr v8, v11

    shl-int/lit8 v11, v9, 0x5

    ushr-int/lit8 v12, v9, 0x1b

    or-int/2addr v11, v12

    xor-int v12, v5, v8

    xor-int/2addr v12, v7

    add-int/2addr v11, v12

    const/16 v12, 0x1b

    aget v12, v6, v12

    invoke-static {v11, v12, v13, v10}, Lcom/trilead/ssh2/crypto/digest/a;->a(IIII)I

    move-result v10

    shl-int/lit8 v11, v5, 0x1e

    ushr-int/lit8 v5, v5, 0x2

    or-int/2addr v5, v11

    shl-int/lit8 v11, v10, 0x5

    ushr-int/lit8 v12, v10, 0x1b

    or-int/2addr v11, v12

    xor-int v12, v9, v5

    xor-int/2addr v12, v8

    add-int/2addr v11, v12

    const/16 v12, 0x1c

    aget v12, v6, v12

    invoke-static {v11, v12, v13, v7}, Lcom/trilead/ssh2/crypto/digest/a;->a(IIII)I

    move-result v7

    shl-int/lit8 v11, v9, 0x1e

    ushr-int/lit8 v9, v9, 0x2

    or-int/2addr v9, v11

    shl-int/lit8 v11, v7, 0x5

    ushr-int/lit8 v12, v7, 0x1b

    or-int/2addr v11, v12

    xor-int v12, v10, v9

    xor-int/2addr v12, v5

    add-int/2addr v11, v12

    const/16 v12, 0x1d

    aget v12, v6, v12

    invoke-static {v11, v12, v13, v8}, Lcom/trilead/ssh2/crypto/digest/a;->a(IIII)I

    move-result v8

    shl-int/lit8 v11, v10, 0x1e

    ushr-int/lit8 v10, v10, 0x2

    or-int/2addr v10, v11

    shl-int/lit8 v11, v8, 0x5

    ushr-int/lit8 v12, v8, 0x1b

    or-int/2addr v11, v12

    xor-int v12, v7, v10

    xor-int/2addr v12, v9

    add-int/2addr v11, v12

    const/16 v12, 0x1e

    aget v12, v6, v12

    invoke-static {v11, v12, v13, v5}, Lcom/trilead/ssh2/crypto/digest/a;->a(IIII)I

    move-result v5

    shl-int/lit8 v11, v7, 0x1e

    ushr-int/lit8 v7, v7, 0x2

    or-int/2addr v7, v11

    shl-int/lit8 v11, v5, 0x5

    ushr-int/lit8 v12, v5, 0x1b

    or-int/2addr v11, v12

    xor-int v12, v8, v7

    xor-int/2addr v12, v10

    add-int/2addr v11, v12

    const/16 v12, 0x1f

    aget v12, v6, v12

    invoke-static {v11, v12, v13, v9}, Lcom/trilead/ssh2/crypto/digest/a;->a(IIII)I

    move-result v9

    shl-int/lit8 v11, v8, 0x1e

    ushr-int/lit8 v8, v8, 0x2

    or-int/2addr v8, v11

    shl-int/lit8 v11, v9, 0x5

    ushr-int/lit8 v12, v9, 0x1b

    or-int/2addr v11, v12

    xor-int v12, v5, v8

    xor-int/2addr v12, v7

    add-int/2addr v11, v12

    const/16 v12, 0x20

    aget v12, v6, v12

    invoke-static {v11, v12, v13, v10}, Lcom/trilead/ssh2/crypto/digest/a;->a(IIII)I

    move-result v10

    shl-int/lit8 v11, v5, 0x1e

    ushr-int/lit8 v5, v5, 0x2

    or-int/2addr v5, v11

    shl-int/lit8 v11, v10, 0x5

    ushr-int/lit8 v12, v10, 0x1b

    or-int/2addr v11, v12

    xor-int v12, v9, v5

    xor-int/2addr v12, v8

    add-int/2addr v11, v12

    const/16 v12, 0x21

    aget v12, v6, v12

    invoke-static {v11, v12, v13, v7}, Lcom/trilead/ssh2/crypto/digest/a;->a(IIII)I

    move-result v7

    shl-int/lit8 v11, v9, 0x1e

    ushr-int/lit8 v9, v9, 0x2

    or-int/2addr v9, v11

    shl-int/lit8 v11, v7, 0x5

    ushr-int/lit8 v12, v7, 0x1b

    or-int/2addr v11, v12

    xor-int v12, v10, v9

    xor-int/2addr v12, v5

    add-int/2addr v11, v12

    const/16 v12, 0x22

    aget v12, v6, v12

    invoke-static {v11, v12, v13, v8}, Lcom/trilead/ssh2/crypto/digest/a;->a(IIII)I

    move-result v8

    shl-int/lit8 v11, v10, 0x1e

    ushr-int/lit8 v10, v10, 0x2

    or-int/2addr v10, v11

    shl-int/lit8 v11, v8, 0x5

    ushr-int/lit8 v12, v8, 0x1b

    or-int/2addr v11, v12

    xor-int v12, v7, v10

    xor-int/2addr v12, v9

    add-int/2addr v11, v12

    const/16 v12, 0x23

    aget v12, v6, v12

    invoke-static {v11, v12, v13, v5}, Lcom/trilead/ssh2/crypto/digest/a;->a(IIII)I

    move-result v5

    shl-int/lit8 v11, v7, 0x1e

    ushr-int/lit8 v7, v7, 0x2

    or-int/2addr v7, v11

    shl-int/lit8 v11, v5, 0x5

    ushr-int/lit8 v12, v5, 0x1b

    or-int/2addr v11, v12

    xor-int v12, v8, v7

    xor-int/2addr v12, v10

    add-int/2addr v11, v12

    const/16 v12, 0x24

    aget v12, v6, v12

    invoke-static {v11, v12, v13, v9}, Lcom/trilead/ssh2/crypto/digest/a;->a(IIII)I

    move-result v9

    shl-int/lit8 v11, v8, 0x1e

    ushr-int/lit8 v8, v8, 0x2

    or-int/2addr v8, v11

    shl-int/lit8 v11, v9, 0x5

    ushr-int/lit8 v12, v9, 0x1b

    or-int/2addr v11, v12

    xor-int v12, v5, v8

    xor-int/2addr v12, v7

    add-int/2addr v11, v12

    const/16 v12, 0x25

    aget v12, v6, v12

    invoke-static {v11, v12, v13, v10}, Lcom/trilead/ssh2/crypto/digest/a;->a(IIII)I

    move-result v10

    shl-int/lit8 v11, v5, 0x1e

    ushr-int/lit8 v5, v5, 0x2

    or-int/2addr v5, v11

    shl-int/lit8 v11, v10, 0x5

    ushr-int/lit8 v12, v10, 0x1b

    or-int/2addr v11, v12

    xor-int v12, v9, v5

    xor-int/2addr v12, v8

    add-int/2addr v11, v12

    const/16 v12, 0x26

    aget v12, v6, v12

    invoke-static {v11, v12, v13, v7}, Lcom/trilead/ssh2/crypto/digest/a;->a(IIII)I

    move-result v7

    shl-int/lit8 v11, v9, 0x1e

    ushr-int/lit8 v9, v9, 0x2

    or-int/2addr v9, v11

    shl-int/lit8 v11, v7, 0x5

    ushr-int/lit8 v12, v7, 0x1b

    or-int/2addr v11, v12

    xor-int v12, v10, v9

    xor-int/2addr v12, v5

    add-int/2addr v11, v12

    const/16 v12, 0x27

    aget v12, v6, v12

    invoke-static {v11, v12, v13, v8}, Lcom/trilead/ssh2/crypto/digest/a;->a(IIII)I

    move-result v8

    shl-int/lit8 v11, v10, 0x1e

    ushr-int/lit8 v10, v10, 0x2

    or-int/2addr v10, v11

    shl-int/lit8 v11, v8, 0x5

    ushr-int/lit8 v12, v8, 0x1b

    or-int/2addr v11, v12

    and-int v12, v7, v10

    and-int v13, v7, v9

    or-int/2addr v12, v13

    and-int v13, v10, v9

    or-int/2addr v12, v13

    add-int/2addr v11, v12

    const/16 v12, 0x28

    aget v12, v6, v12

    const v13, -0x70e44324

    invoke-static {v11, v12, v13, v5}, Lcom/trilead/ssh2/crypto/digest/a;->a(IIII)I

    move-result v5

    shl-int/lit8 v11, v7, 0x1e

    ushr-int/lit8 v7, v7, 0x2

    or-int/2addr v7, v11

    shl-int/lit8 v11, v5, 0x5

    ushr-int/lit8 v12, v5, 0x1b

    or-int/2addr v11, v12

    and-int v12, v8, v7

    and-int v14, v8, v10

    or-int/2addr v12, v14

    and-int v14, v7, v10

    or-int/2addr v12, v14

    add-int/2addr v11, v12

    const/16 v12, 0x29

    aget v12, v6, v12

    invoke-static {v11, v12, v13, v9}, Lcom/trilead/ssh2/crypto/digest/a;->a(IIII)I

    move-result v9

    shl-int/lit8 v11, v8, 0x1e

    ushr-int/lit8 v8, v8, 0x2

    or-int/2addr v8, v11

    shl-int/lit8 v11, v9, 0x5

    ushr-int/lit8 v12, v9, 0x1b

    or-int/2addr v11, v12

    and-int v12, v5, v8

    and-int v14, v5, v7

    or-int/2addr v12, v14

    and-int v14, v8, v7

    or-int/2addr v12, v14

    add-int/2addr v11, v12

    const/16 v12, 0x2a

    aget v12, v6, v12

    invoke-static {v11, v12, v13, v10}, Lcom/trilead/ssh2/crypto/digest/a;->a(IIII)I

    move-result v10

    shl-int/lit8 v11, v5, 0x1e

    ushr-int/lit8 v5, v5, 0x2

    or-int/2addr v5, v11

    shl-int/lit8 v11, v10, 0x5

    ushr-int/lit8 v12, v10, 0x1b

    or-int/2addr v11, v12

    and-int v12, v9, v5

    and-int v14, v9, v8

    or-int/2addr v12, v14

    and-int v14, v5, v8

    or-int/2addr v12, v14

    add-int/2addr v11, v12

    const/16 v12, 0x2b

    aget v12, v6, v12

    invoke-static {v11, v12, v13, v7}, Lcom/trilead/ssh2/crypto/digest/a;->a(IIII)I

    move-result v7

    shl-int/lit8 v11, v9, 0x1e

    ushr-int/lit8 v9, v9, 0x2

    or-int/2addr v9, v11

    shl-int/lit8 v11, v7, 0x5

    ushr-int/lit8 v12, v7, 0x1b

    or-int/2addr v11, v12

    and-int v12, v10, v9

    and-int v14, v10, v5

    or-int/2addr v12, v14

    and-int v14, v9, v5

    or-int/2addr v12, v14

    add-int/2addr v11, v12

    const/16 v12, 0x2c

    aget v12, v6, v12

    invoke-static {v11, v12, v13, v8}, Lcom/trilead/ssh2/crypto/digest/a;->a(IIII)I

    move-result v8

    shl-int/lit8 v11, v10, 0x1e

    ushr-int/lit8 v10, v10, 0x2

    or-int/2addr v10, v11

    shl-int/lit8 v11, v8, 0x5

    ushr-int/lit8 v12, v8, 0x1b

    or-int/2addr v11, v12

    and-int v12, v7, v10

    and-int v14, v7, v9

    or-int/2addr v12, v14

    and-int v14, v10, v9

    or-int/2addr v12, v14

    add-int/2addr v11, v12

    const/16 v12, 0x2d

    aget v12, v6, v12

    invoke-static {v11, v12, v13, v5}, Lcom/trilead/ssh2/crypto/digest/a;->a(IIII)I

    move-result v5

    shl-int/lit8 v11, v7, 0x1e

    ushr-int/lit8 v7, v7, 0x2

    or-int/2addr v7, v11

    shl-int/lit8 v11, v5, 0x5

    ushr-int/lit8 v12, v5, 0x1b

    or-int/2addr v11, v12

    and-int v12, v8, v7

    and-int v14, v8, v10

    or-int/2addr v12, v14

    and-int v14, v7, v10

    or-int/2addr v12, v14

    add-int/2addr v11, v12

    const/16 v12, 0x2e

    aget v12, v6, v12

    invoke-static {v11, v12, v13, v9}, Lcom/trilead/ssh2/crypto/digest/a;->a(IIII)I

    move-result v9

    shl-int/lit8 v11, v8, 0x1e

    ushr-int/lit8 v8, v8, 0x2

    or-int/2addr v8, v11

    shl-int/lit8 v11, v9, 0x5

    ushr-int/lit8 v12, v9, 0x1b

    or-int/2addr v11, v12

    and-int v12, v5, v8

    and-int v14, v5, v7

    or-int/2addr v12, v14

    and-int v14, v8, v7

    or-int/2addr v12, v14

    add-int/2addr v11, v12

    const/16 v12, 0x2f

    aget v12, v6, v12

    invoke-static {v11, v12, v13, v10}, Lcom/trilead/ssh2/crypto/digest/a;->a(IIII)I

    move-result v10

    shl-int/lit8 v11, v5, 0x1e

    ushr-int/lit8 v5, v5, 0x2

    or-int/2addr v5, v11

    shl-int/lit8 v11, v10, 0x5

    ushr-int/lit8 v12, v10, 0x1b

    or-int/2addr v11, v12

    and-int v12, v9, v5

    and-int v14, v9, v8

    or-int/2addr v12, v14

    and-int v14, v5, v8

    or-int/2addr v12, v14

    add-int/2addr v11, v12

    const/16 v12, 0x30

    aget v12, v6, v12

    invoke-static {v11, v12, v13, v7}, Lcom/trilead/ssh2/crypto/digest/a;->a(IIII)I

    move-result v7

    shl-int/lit8 v11, v9, 0x1e

    ushr-int/lit8 v9, v9, 0x2

    or-int/2addr v9, v11

    shl-int/lit8 v11, v7, 0x5

    ushr-int/lit8 v12, v7, 0x1b

    or-int/2addr v11, v12

    and-int v12, v10, v9

    and-int v14, v10, v5

    or-int/2addr v12, v14

    and-int v14, v9, v5

    or-int/2addr v12, v14

    add-int/2addr v11, v12

    const/16 v12, 0x31

    aget v12, v6, v12

    invoke-static {v11, v12, v13, v8}, Lcom/trilead/ssh2/crypto/digest/a;->a(IIII)I

    move-result v8

    shl-int/lit8 v11, v10, 0x1e

    ushr-int/lit8 v10, v10, 0x2

    or-int/2addr v10, v11

    shl-int/lit8 v11, v8, 0x5

    ushr-int/lit8 v12, v8, 0x1b

    or-int/2addr v11, v12

    and-int v12, v7, v10

    and-int v14, v7, v9

    or-int/2addr v12, v14

    and-int v14, v10, v9

    or-int/2addr v12, v14

    add-int/2addr v11, v12

    const/16 v12, 0x32

    aget v12, v6, v12

    invoke-static {v11, v12, v13, v5}, Lcom/trilead/ssh2/crypto/digest/a;->a(IIII)I

    move-result v5

    shl-int/lit8 v11, v7, 0x1e

    ushr-int/lit8 v7, v7, 0x2

    or-int/2addr v7, v11

    shl-int/lit8 v11, v5, 0x5

    ushr-int/lit8 v12, v5, 0x1b

    or-int/2addr v11, v12

    and-int v12, v8, v7

    and-int v14, v8, v10

    or-int/2addr v12, v14

    and-int v14, v7, v10

    or-int/2addr v12, v14

    add-int/2addr v11, v12

    const/16 v12, 0x33

    aget v12, v6, v12

    invoke-static {v11, v12, v13, v9}, Lcom/trilead/ssh2/crypto/digest/a;->a(IIII)I

    move-result v9

    shl-int/lit8 v11, v8, 0x1e

    ushr-int/lit8 v8, v8, 0x2

    or-int/2addr v8, v11

    shl-int/lit8 v11, v9, 0x5

    ushr-int/lit8 v12, v9, 0x1b

    or-int/2addr v11, v12

    and-int v12, v5, v8

    and-int v14, v5, v7

    or-int/2addr v12, v14

    and-int v14, v8, v7

    or-int/2addr v12, v14

    add-int/2addr v11, v12

    const/16 v12, 0x34

    aget v12, v6, v12

    invoke-static {v11, v12, v13, v10}, Lcom/trilead/ssh2/crypto/digest/a;->a(IIII)I

    move-result v10

    shl-int/lit8 v11, v5, 0x1e

    ushr-int/lit8 v5, v5, 0x2

    or-int/2addr v5, v11

    shl-int/lit8 v11, v10, 0x5

    ushr-int/lit8 v12, v10, 0x1b

    or-int/2addr v11, v12

    and-int v12, v9, v5

    and-int v14, v9, v8

    or-int/2addr v12, v14

    and-int v14, v5, v8

    or-int/2addr v12, v14

    add-int/2addr v11, v12

    const/16 v12, 0x35

    aget v12, v6, v12

    invoke-static {v11, v12, v13, v7}, Lcom/trilead/ssh2/crypto/digest/a;->a(IIII)I

    move-result v7

    shl-int/lit8 v11, v9, 0x1e

    ushr-int/lit8 v9, v9, 0x2

    or-int/2addr v9, v11

    shl-int/lit8 v11, v7, 0x5

    ushr-int/lit8 v12, v7, 0x1b

    or-int/2addr v11, v12

    and-int v12, v10, v9

    and-int v14, v10, v5

    or-int/2addr v12, v14

    and-int v14, v9, v5

    or-int/2addr v12, v14

    add-int/2addr v11, v12

    const/16 v12, 0x36

    aget v12, v6, v12

    invoke-static {v11, v12, v13, v8}, Lcom/trilead/ssh2/crypto/digest/a;->a(IIII)I

    move-result v8

    shl-int/lit8 v11, v10, 0x1e

    ushr-int/lit8 v10, v10, 0x2

    or-int/2addr v10, v11

    shl-int/lit8 v11, v8, 0x5

    ushr-int/lit8 v12, v8, 0x1b

    or-int/2addr v11, v12

    add-int/2addr v5, v11

    and-int v11, v7, v10

    and-int v12, v7, v9

    or-int/2addr v11, v12

    and-int v12, v10, v9

    or-int/2addr v11, v12

    add-int/2addr v5, v11

    const/16 v11, 0x37

    aget v11, v6, v11

    add-int/2addr v5, v11

    add-int/2addr v5, v13

    shl-int/lit8 v11, v7, 0x1e

    ushr-int/lit8 v7, v7, 0x2

    or-int/2addr v7, v11

    shl-int/lit8 v11, v5, 0x5

    ushr-int/lit8 v12, v5, 0x1b

    or-int/2addr v11, v12

    and-int v12, v8, v7

    and-int v14, v8, v10

    or-int/2addr v12, v14

    and-int v14, v7, v10

    or-int/2addr v12, v14

    add-int/2addr v11, v12

    const/16 v12, 0x38

    aget v12, v6, v12

    invoke-static {v11, v12, v13, v9}, Lcom/trilead/ssh2/crypto/digest/a;->a(IIII)I

    move-result v9

    shl-int/lit8 v11, v8, 0x1e

    ushr-int/lit8 v8, v8, 0x2

    or-int/2addr v8, v11

    shl-int/lit8 v11, v9, 0x5

    ushr-int/lit8 v12, v9, 0x1b

    or-int/2addr v11, v12

    and-int v12, v5, v8

    and-int v14, v5, v7

    or-int/2addr v12, v14

    and-int v14, v8, v7

    or-int/2addr v12, v14

    add-int/2addr v11, v12

    const/16 v12, 0x39

    aget v12, v6, v12

    invoke-static {v11, v12, v13, v10}, Lcom/trilead/ssh2/crypto/digest/a;->a(IIII)I

    move-result v10

    shl-int/lit8 v11, v5, 0x1e

    ushr-int/lit8 v5, v5, 0x2

    or-int/2addr v5, v11

    shl-int/lit8 v11, v10, 0x5

    ushr-int/lit8 v12, v10, 0x1b

    or-int/2addr v11, v12

    and-int v12, v9, v5

    and-int v14, v9, v8

    or-int/2addr v12, v14

    and-int v14, v5, v8

    or-int/2addr v12, v14

    add-int/2addr v11, v12

    const/16 v12, 0x3a

    aget v12, v6, v12

    invoke-static {v11, v12, v13, v7}, Lcom/trilead/ssh2/crypto/digest/a;->a(IIII)I

    move-result v7

    shl-int/lit8 v11, v9, 0x1e

    ushr-int/lit8 v9, v9, 0x2

    or-int/2addr v9, v11

    shl-int/lit8 v11, v7, 0x5

    ushr-int/lit8 v12, v7, 0x1b

    or-int/2addr v11, v12

    and-int v12, v10, v9

    and-int v14, v10, v5

    or-int/2addr v12, v14

    and-int v14, v9, v5

    or-int/2addr v12, v14

    add-int/2addr v11, v12

    const/16 v12, 0x3b

    aget v12, v6, v12

    invoke-static {v11, v12, v13, v8}, Lcom/trilead/ssh2/crypto/digest/a;->a(IIII)I

    move-result v8

    shl-int/lit8 v11, v10, 0x1e

    ushr-int/lit8 v10, v10, 0x2

    or-int/2addr v10, v11

    shl-int/lit8 v11, v8, 0x5

    ushr-int/lit8 v12, v8, 0x1b

    or-int/2addr v11, v12

    xor-int v12, v7, v10

    xor-int/2addr v12, v9

    add-int/2addr v11, v12

    const/16 v12, 0x3c

    aget v12, v6, v12

    const v13, -0x359d3e2a    # -3715189.5f

    invoke-static {v11, v12, v13, v5}, Lcom/trilead/ssh2/crypto/digest/a;->a(IIII)I

    move-result v5

    shl-int/lit8 v11, v7, 0x1e

    ushr-int/lit8 v7, v7, 0x2

    or-int/2addr v7, v11

    shl-int/lit8 v11, v5, 0x5

    ushr-int/lit8 v12, v5, 0x1b

    or-int/2addr v11, v12

    xor-int v12, v8, v7

    xor-int/2addr v12, v10

    add-int/2addr v11, v12

    const/16 v12, 0x3d

    aget v12, v6, v12

    invoke-static {v11, v12, v13, v9}, Lcom/trilead/ssh2/crypto/digest/a;->a(IIII)I

    move-result v9

    shl-int/lit8 v11, v8, 0x1e

    ushr-int/lit8 v8, v8, 0x2

    or-int/2addr v8, v11

    shl-int/lit8 v11, v9, 0x5

    ushr-int/lit8 v12, v9, 0x1b

    or-int/2addr v11, v12

    xor-int v12, v5, v8

    xor-int/2addr v12, v7

    add-int/2addr v11, v12

    const/16 v12, 0x3e

    aget v12, v6, v12

    invoke-static {v11, v12, v13, v10}, Lcom/trilead/ssh2/crypto/digest/a;->a(IIII)I

    move-result v10

    shl-int/lit8 v11, v5, 0x1e

    ushr-int/lit8 v5, v5, 0x2

    or-int/2addr v5, v11

    shl-int/lit8 v11, v10, 0x5

    ushr-int/lit8 v12, v10, 0x1b

    or-int/2addr v11, v12

    xor-int v12, v9, v5

    xor-int/2addr v12, v8

    add-int/2addr v11, v12

    const/16 v12, 0x3f

    aget v12, v6, v12

    invoke-static {v11, v12, v13, v7}, Lcom/trilead/ssh2/crypto/digest/a;->a(IIII)I

    move-result v7

    shl-int/lit8 v11, v9, 0x1e

    ushr-int/lit8 v9, v9, 0x2

    or-int/2addr v9, v11

    shl-int/lit8 v11, v7, 0x5

    ushr-int/lit8 v12, v7, 0x1b

    or-int/2addr v11, v12

    xor-int v12, v10, v9

    xor-int/2addr v12, v5

    add-int/2addr v11, v12

    const/16 v12, 0x40

    aget v12, v6, v12

    invoke-static {v11, v12, v13, v8}, Lcom/trilead/ssh2/crypto/digest/a;->a(IIII)I

    move-result v8

    shl-int/lit8 v11, v10, 0x1e

    ushr-int/lit8 v10, v10, 0x2

    or-int/2addr v10, v11

    shl-int/lit8 v11, v8, 0x5

    ushr-int/lit8 v12, v8, 0x1b

    or-int/2addr v11, v12

    xor-int v12, v7, v10

    xor-int/2addr v12, v9

    add-int/2addr v11, v12

    const/16 v12, 0x41

    aget v12, v6, v12

    invoke-static {v11, v12, v13, v5}, Lcom/trilead/ssh2/crypto/digest/a;->a(IIII)I

    move-result v5

    shl-int/lit8 v11, v7, 0x1e

    ushr-int/lit8 v7, v7, 0x2

    or-int/2addr v7, v11

    shl-int/lit8 v11, v5, 0x5

    ushr-int/lit8 v12, v5, 0x1b

    or-int/2addr v11, v12

    xor-int v12, v8, v7

    xor-int/2addr v12, v10

    add-int/2addr v11, v12

    const/16 v12, 0x42

    aget v12, v6, v12

    invoke-static {v11, v12, v13, v9}, Lcom/trilead/ssh2/crypto/digest/a;->a(IIII)I

    move-result v9

    shl-int/lit8 v11, v8, 0x1e

    ushr-int/lit8 v8, v8, 0x2

    or-int/2addr v8, v11

    shl-int/lit8 v11, v9, 0x5

    ushr-int/lit8 v12, v9, 0x1b

    or-int/2addr v11, v12

    xor-int v12, v5, v8

    xor-int/2addr v12, v7

    add-int/2addr v11, v12

    const/16 v12, 0x43

    aget v12, v6, v12

    invoke-static {v11, v12, v13, v10}, Lcom/trilead/ssh2/crypto/digest/a;->a(IIII)I

    move-result v10

    shl-int/lit8 v11, v5, 0x1e

    ushr-int/lit8 v5, v5, 0x2

    or-int/2addr v5, v11

    shl-int/lit8 v11, v10, 0x5

    ushr-int/lit8 v12, v10, 0x1b

    or-int/2addr v11, v12

    xor-int v12, v9, v5

    xor-int/2addr v12, v8

    add-int/2addr v11, v12

    const/16 v12, 0x44

    aget v12, v6, v12

    invoke-static {v11, v12, v13, v7}, Lcom/trilead/ssh2/crypto/digest/a;->a(IIII)I

    move-result v7

    shl-int/lit8 v11, v9, 0x1e

    ushr-int/lit8 v9, v9, 0x2

    or-int/2addr v9, v11

    shl-int/lit8 v11, v7, 0x5

    ushr-int/lit8 v12, v7, 0x1b

    or-int/2addr v11, v12

    xor-int v12, v10, v9

    xor-int/2addr v12, v5

    add-int/2addr v11, v12

    const/16 v12, 0x45

    aget v12, v6, v12

    invoke-static {v11, v12, v13, v8}, Lcom/trilead/ssh2/crypto/digest/a;->a(IIII)I

    move-result v8

    shl-int/lit8 v11, v10, 0x1e

    ushr-int/lit8 v10, v10, 0x2

    or-int/2addr v10, v11

    shl-int/lit8 v11, v8, 0x5

    ushr-int/lit8 v12, v8, 0x1b

    or-int/2addr v11, v12

    xor-int v12, v7, v10

    xor-int/2addr v12, v9

    add-int/2addr v11, v12

    const/16 v12, 0x46

    aget v12, v6, v12

    invoke-static {v11, v12, v13, v5}, Lcom/trilead/ssh2/crypto/digest/a;->a(IIII)I

    move-result v5

    shl-int/lit8 v11, v7, 0x1e

    ushr-int/lit8 v7, v7, 0x2

    or-int/2addr v7, v11

    shl-int/lit8 v11, v5, 0x5

    ushr-int/lit8 v12, v5, 0x1b

    or-int/2addr v11, v12

    xor-int v12, v8, v7

    xor-int/2addr v12, v10

    add-int/2addr v11, v12

    const/16 v12, 0x47

    aget v12, v6, v12

    invoke-static {v11, v12, v13, v9}, Lcom/trilead/ssh2/crypto/digest/a;->a(IIII)I

    move-result v9

    shl-int/lit8 v11, v8, 0x1e

    ushr-int/lit8 v8, v8, 0x2

    or-int/2addr v8, v11

    shl-int/lit8 v11, v9, 0x5

    ushr-int/lit8 v12, v9, 0x1b

    or-int/2addr v11, v12

    xor-int v12, v5, v8

    xor-int/2addr v12, v7

    add-int/2addr v11, v12

    const/16 v12, 0x48

    aget v12, v6, v12

    invoke-static {v11, v12, v13, v10}, Lcom/trilead/ssh2/crypto/digest/a;->a(IIII)I

    move-result v10

    shl-int/lit8 v11, v5, 0x1e

    ushr-int/lit8 v5, v5, 0x2

    or-int/2addr v5, v11

    shl-int/lit8 v11, v10, 0x5

    ushr-int/lit8 v12, v10, 0x1b

    or-int/2addr v11, v12

    xor-int v12, v9, v5

    xor-int/2addr v12, v8

    add-int/2addr v11, v12

    const/16 v12, 0x49

    aget v12, v6, v12

    invoke-static {v11, v12, v13, v7}, Lcom/trilead/ssh2/crypto/digest/a;->a(IIII)I

    move-result v7

    shl-int/lit8 v11, v9, 0x1e

    ushr-int/lit8 v9, v9, 0x2

    or-int/2addr v9, v11

    shl-int/lit8 v11, v7, 0x5

    ushr-int/lit8 v12, v7, 0x1b

    or-int/2addr v11, v12

    xor-int v12, v10, v9

    xor-int/2addr v12, v5

    add-int/2addr v11, v12

    const/16 v12, 0x4a

    aget v12, v6, v12

    invoke-static {v11, v12, v13, v8}, Lcom/trilead/ssh2/crypto/digest/a;->a(IIII)I

    move-result v8

    shl-int/lit8 v11, v10, 0x1e

    ushr-int/lit8 v10, v10, 0x2

    or-int/2addr v10, v11

    shl-int/lit8 v11, v8, 0x5

    ushr-int/lit8 v12, v8, 0x1b

    or-int/2addr v11, v12

    xor-int v12, v7, v10

    xor-int/2addr v12, v9

    add-int/2addr v11, v12

    const/16 v12, 0x4b

    aget v12, v6, v12

    invoke-static {v11, v12, v13, v5}, Lcom/trilead/ssh2/crypto/digest/a;->a(IIII)I

    move-result v5

    shl-int/lit8 v11, v7, 0x1e

    ushr-int/lit8 v7, v7, 0x2

    or-int/2addr v7, v11

    shl-int/lit8 v11, v5, 0x5

    ushr-int/lit8 v12, v5, 0x1b

    or-int/2addr v11, v12

    xor-int v12, v8, v7

    xor-int/2addr v12, v10

    add-int/2addr v11, v12

    const/16 v12, 0x4c

    aget v12, v6, v12

    invoke-static {v11, v12, v13, v9}, Lcom/trilead/ssh2/crypto/digest/a;->a(IIII)I

    move-result v9

    shl-int/lit8 v11, v8, 0x1e

    ushr-int/lit8 v8, v8, 0x2

    or-int/2addr v8, v11

    shl-int/lit8 v11, v9, 0x5

    ushr-int/lit8 v12, v9, 0x1b

    or-int/2addr v11, v12

    xor-int v12, v5, v8

    xor-int/2addr v12, v7

    add-int/2addr v11, v12

    const/16 v12, 0x4d

    aget v12, v6, v12

    invoke-static {v11, v12, v13, v10}, Lcom/trilead/ssh2/crypto/digest/a;->a(IIII)I

    move-result v10

    shl-int/lit8 v11, v5, 0x1e

    ushr-int/lit8 v5, v5, 0x2

    or-int/2addr v5, v11

    shl-int/lit8 v11, v10, 0x5

    ushr-int/lit8 v12, v10, 0x1b

    or-int/2addr v11, v12

    xor-int v12, v9, v5

    xor-int/2addr v12, v8

    add-int/2addr v11, v12

    const/16 v12, 0x4e

    aget v12, v6, v12

    invoke-static {v11, v12, v13, v7}, Lcom/trilead/ssh2/crypto/digest/a;->a(IIII)I

    move-result v7

    shl-int/lit8 v11, v9, 0x1e

    ushr-int/lit8 v9, v9, 0x2

    or-int/2addr v9, v11

    shl-int/lit8 v11, v7, 0x5

    ushr-int/lit8 v12, v7, 0x1b

    or-int/2addr v11, v12

    xor-int v12, v10, v9

    xor-int/2addr v12, v5

    add-int/2addr v11, v12

    const/16 v12, 0x4f

    aget v6, v6, v12

    invoke-static {v11, v6, v13, v8}, Lcom/trilead/ssh2/crypto/digest/a;->a(IIII)I

    move-result v6

    shl-int/lit8 v8, v10, 0x1e

    ushr-int/lit8 v10, v10, 0x2

    or-int/2addr v8, v10

    add-int/2addr v0, v6

    iput v0, p0, Lcom/trilead/ssh2/crypto/digest/SHA1;->a:I

    add-int/2addr v1, v7

    iput v1, p0, Lcom/trilead/ssh2/crypto/digest/SHA1;->b:I

    add-int/2addr v2, v8

    iput v2, p0, Lcom/trilead/ssh2/crypto/digest/SHA1;->c:I

    add-int/2addr v3, v9

    iput v3, p0, Lcom/trilead/ssh2/crypto/digest/SHA1;->d:I

    add-int/2addr v4, v5

    iput v4, p0, Lcom/trilead/ssh2/crypto/digest/SHA1;->e:I

    return-void
.end method

.method public final i([BII)V
    .locals 2

    shr-int/lit8 v0, p3, 0x18

    int-to-byte v0, v0

    aput-byte v0, p1, p2

    add-int/lit8 v0, p2, 0x1

    shr-int/lit8 v1, p3, 0x10

    int-to-byte v1, v1

    aput-byte v1, p1, v0

    add-int/lit8 v0, p2, 0x2

    shr-int/lit8 v1, p3, 0x8

    int-to-byte v1, v1

    aput-byte v1, p1, v0

    add-int/lit8 p2, p2, 0x3

    int-to-byte p3, p3

    aput-byte p3, p1, p2

    return-void
.end method
