.class public Lcom/trilead/ssh2/crypto/digest/MAC;
.super Ljava/lang/Object;
.source "SourceFile"


# instance fields
.field public a:Lcom/trilead/ssh2/crypto/digest/HMAC;
    .annotation runtime Ljava/lang/Deprecated;
    .end annotation
.end field

.field public b:I
    .annotation runtime Ljava/lang/Deprecated;
    .end annotation
.end field


# direct methods
.method public constructor <init>(Ljava/lang/String;[B)V
    .locals 2

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const-string v0, "hmac-sha1"

    invoke-virtual {p1, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_0

    new-instance p1, Lcom/trilead/ssh2/crypto/digest/HMAC;

    new-instance v0, Lcom/trilead/ssh2/crypto/digest/SHA1;

    invoke-direct {v0}, Lcom/trilead/ssh2/crypto/digest/SHA1;-><init>()V

    const/16 v1, 0x14

    invoke-direct {p1, v0, p2, v1}, Lcom/trilead/ssh2/crypto/digest/HMAC;-><init>(Lcom/trilead/ssh2/crypto/digest/Digest;[BI)V

    goto :goto_0

    :cond_0
    const-string v0, "hmac-sha1-96"

    invoke-virtual {p1, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    const/16 v1, 0xc

    if-eqz v0, :cond_1

    new-instance p1, Lcom/trilead/ssh2/crypto/digest/HMAC;

    new-instance v0, Lcom/trilead/ssh2/crypto/digest/SHA1;

    invoke-direct {v0}, Lcom/trilead/ssh2/crypto/digest/SHA1;-><init>()V

    invoke-direct {p1, v0, p2, v1}, Lcom/trilead/ssh2/crypto/digest/HMAC;-><init>(Lcom/trilead/ssh2/crypto/digest/Digest;[BI)V

    goto :goto_0

    :cond_1
    const-string v0, "hmac-md5"

    invoke-virtual {p1, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_2

    new-instance p1, Lcom/trilead/ssh2/crypto/digest/HMAC;

    new-instance v0, Lcom/trilead/ssh2/crypto/digest/MD5;

    invoke-direct {v0}, Lcom/trilead/ssh2/crypto/digest/MD5;-><init>()V

    const/16 v1, 0x10

    invoke-direct {p1, v0, p2, v1}, Lcom/trilead/ssh2/crypto/digest/HMAC;-><init>(Lcom/trilead/ssh2/crypto/digest/Digest;[BI)V

    goto :goto_0

    :cond_2
    const-string v0, "hmac-md5-96"

    invoke-virtual {p1, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p1

    if-eqz p1, :cond_3

    new-instance p1, Lcom/trilead/ssh2/crypto/digest/HMAC;

    new-instance v0, Lcom/trilead/ssh2/crypto/digest/MD5;

    invoke-direct {v0}, Lcom/trilead/ssh2/crypto/digest/MD5;-><init>()V

    invoke-direct {p1, v0, p2, v1}, Lcom/trilead/ssh2/crypto/digest/HMAC;-><init>(Lcom/trilead/ssh2/crypto/digest/Digest;[BI)V

    :goto_0
    iput-object p1, p0, Lcom/trilead/ssh2/crypto/digest/MAC;->a:Lcom/trilead/ssh2/crypto/digest/HMAC;

    .line 1
    iget p1, p1, Lcom/trilead/ssh2/crypto/digest/HMAC;->e:I

    .line 2
    iput p1, p0, Lcom/trilead/ssh2/crypto/digest/MAC;->b:I

    :cond_3
    return-void
.end method


# virtual methods
.method public a([B)V
    .locals 1

    iget-object v0, p0, Lcom/trilead/ssh2/crypto/digest/MAC;->a:Lcom/trilead/ssh2/crypto/digest/HMAC;

    invoke-virtual {v0, p1}, Lcom/trilead/ssh2/crypto/digest/HMAC;->b([B)V

    return-void
.end method

.method public b(I)V
    .locals 2

    iget-object v0, p0, Lcom/trilead/ssh2/crypto/digest/MAC;->a:Lcom/trilead/ssh2/crypto/digest/HMAC;

    invoke-virtual {v0}, Lcom/trilead/ssh2/crypto/digest/HMAC;->a()V

    iget-object v0, p0, Lcom/trilead/ssh2/crypto/digest/MAC;->a:Lcom/trilead/ssh2/crypto/digest/HMAC;

    shr-int/lit8 v1, p1, 0x18

    int-to-byte v1, v1

    invoke-virtual {v0, v1}, Lcom/trilead/ssh2/crypto/digest/HMAC;->f(B)V

    iget-object v0, p0, Lcom/trilead/ssh2/crypto/digest/MAC;->a:Lcom/trilead/ssh2/crypto/digest/HMAC;

    shr-int/lit8 v1, p1, 0x10

    int-to-byte v1, v1

    invoke-virtual {v0, v1}, Lcom/trilead/ssh2/crypto/digest/HMAC;->f(B)V

    iget-object v0, p0, Lcom/trilead/ssh2/crypto/digest/MAC;->a:Lcom/trilead/ssh2/crypto/digest/HMAC;

    shr-int/lit8 v1, p1, 0x8

    int-to-byte v1, v1

    invoke-virtual {v0, v1}, Lcom/trilead/ssh2/crypto/digest/HMAC;->f(B)V

    iget-object v0, p0, Lcom/trilead/ssh2/crypto/digest/MAC;->a:Lcom/trilead/ssh2/crypto/digest/HMAC;

    int-to-byte p1, p1

    invoke-virtual {v0, p1}, Lcom/trilead/ssh2/crypto/digest/HMAC;->f(B)V

    return-void
.end method

.method public c()I
    .locals 1

    iget v0, p0, Lcom/trilead/ssh2/crypto/digest/MAC;->b:I

    return v0
.end method

.method public d([BI)V
    .locals 1

    iget-object v0, p0, Lcom/trilead/ssh2/crypto/digest/MAC;->a:Lcom/trilead/ssh2/crypto/digest/HMAC;

    iget-object v0, v0, Lcom/trilead/ssh2/crypto/digest/HMAC;->a:Lcom/trilead/ssh2/crypto/digest/Digest;

    invoke-interface {v0, p1, p2}, Lcom/trilead/ssh2/crypto/digest/Digest;->d([BI)V

    return-void
.end method
