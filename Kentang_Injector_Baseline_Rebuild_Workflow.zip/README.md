# Kentang Injector 2.7.0 — baseline rebuild project

This package is the APKTool-decoded project from the uploaded decompilation artifact.

## What is included
- `app/decoded/AndroidManifest.xml`
- `app/decoded/apktool.yml`
- `app/decoded/smali/` — DEX instructions in Smali form
- `app/decoded/res/` — decoded Android resources
- `app/decoded/lib/arm64-v8a/` — original ARM64 native libraries
- `.github/workflows/build.yml` — one-click GitHub Actions baseline rebuild

## Run it
1. Extract this ZIP.
2. Upload the contents (including the hidden `.github` directory) to the root of a new or existing GitHub repository.
3. Open **Actions**.
4. Select **Build Kentang Injector Baseline**.
5. Press **Run workflow**.
6. Download artifact `kentang-injector-baseline-rebuilt`.

## Important
This workflow rebuilds and signs a baseline APK from the decoded original. It does NOT yet add the requested redesigned UI, START/STOP UI changes, or permanent traffic history. This baseline is a validation step to confirm the decoded Smali/resources/native libraries can be repackaged before changing connection-critical code.

The output is signed with a temporary debug key generated during the workflow. It will not update-install over the original signed app; uninstall the original first if you want to test the rebuilt APK. The app's original connection behavior must be tested before feature modifications. The APK's source project does not contain the original Gradle project or original signing key.
