.class public final Lr/a$a;
.super Lr/f;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lr/a;->e()Ljava/util/List;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1
    name = null
.end annotation


# direct methods
.method public constructor <init>(Ljava/lang/String;)V
    .locals 0

    invoke-direct {p0, p1}, Lr/f;-><init>(Ljava/lang/String;)V

    return-void
.end method


# virtual methods
.method public final e(Lq/c;)Ljava/security/KeyPair;
    .locals 5

    invoke-virtual {p1}, Lq/c;->e()Ljava/math/BigInteger;

    move-result-object v0

    invoke-virtual {p1}, Lq/c;->e()Ljava/math/BigInteger;

    move-result-object v1

    invoke-virtual {p1}, Lq/c;->e()Ljava/math/BigInteger;

    move-result-object v2

    invoke-virtual {p1}, Lq/c;->e()Ljava/math/BigInteger;

    move-result-object v3

    invoke-virtual {p1}, Lq/c;->e()Ljava/math/BigInteger;

    move-result-object p1

    new-instance v4, Ljava/security/spec/DSAPrivateKeySpec;

    invoke-direct {v4, p1, v0, v1, v2}, Ljava/security/spec/DSAPrivateKeySpec;-><init>(Ljava/math/BigInteger;Ljava/math/BigInteger;Ljava/math/BigInteger;Ljava/math/BigInteger;)V

    new-instance p1, Ljava/security/spec/DSAPublicKeySpec;

    invoke-direct {p1, v3, v0, v1, v2}, Ljava/security/spec/DSAPublicKeySpec;-><init>(Ljava/math/BigInteger;Ljava/math/BigInteger;Ljava/math/BigInteger;Ljava/math/BigInteger;)V

    const-string v0, "DSA"

    invoke-static {v0}, Ljava/security/KeyFactory;->getInstance(Ljava/lang/String;)Ljava/security/KeyFactory;

    move-result-object v0

    invoke-virtual {v0, v4}, Ljava/security/KeyFactory;->generatePrivate(Ljava/security/spec/KeySpec;)Ljava/security/PrivateKey;

    move-result-object v1

    invoke-virtual {v0, p1}, Ljava/security/KeyFactory;->generatePublic(Ljava/security/spec/KeySpec;)Ljava/security/PublicKey;

    move-result-object p1

    new-instance v0, Ljava/security/KeyPair;

    invoke-direct {v0, p1, v1}, Ljava/security/KeyPair;-><init>(Ljava/security/PublicKey;Ljava/security/PrivateKey;)V

    return-object v0
.end method
