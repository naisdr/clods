.class public final Lc0/h;
.super Ljava/lang/Object;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lc0/h$a;
    }
.end annotation


# static fields
.field public static b:Lc0/h;


# instance fields
.field public a:Lc0/h$a;


# direct methods
.method public constructor <init>()V
    .locals 1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    new-instance v0, Lc0/h$a;

    invoke-direct {v0}, Lc0/h$a;-><init>()V

    iput-object v0, p0, Lc0/h;->a:Lc0/h$a;

    return-void
.end method
