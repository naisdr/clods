.class public final Ll0/c;
.super Ljava/lang/Object;
.source "SourceFile"


# instance fields
.field public final a:Lm0/b;

.field public final b:[B

.field public final c:[B

.field public final d:Ll0/b;


# direct methods
.method public constructor <init>(Lm0/b;)V
    .locals 5

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Ll0/c;->a:Lm0/b;

    .line 1
    iget-object v0, p1, Lm0/b;->e:Lm0/a;

    .line 2
    invoke-virtual {v0}, Ljava/lang/Enum;->ordinal()I

    move-result v0

    if-eqz v0, :cond_1

    const/4 v1, 0x1

    if-ne v0, v1, :cond_0

    new-instance v0, Ll0/b;

    const/16 v1, 0x8

    const-string v2, "DESede"

    const-string v3, "CBC"

    const-string v4, "PKCS5Padding"

    invoke-direct {v0, v2, v3, v4, v1}, Ll0/b;-><init>(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;I)V

    goto :goto_0

    :cond_0
    new-instance p1, Ljava/lang/IllegalArgumentException;

    const-string v0, "Unknown Algorithm"

    invoke-direct {p1, v0}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw p1

    :cond_1
    new-instance v0, Ll0/b;

    const/16 v1, 0xc

    const-string v2, "AES"

    const-string v3, "GCM"

    const-string v4, "NoPadding"

    invoke-direct {v0, v2, v3, v4, v1}, Ll0/b;-><init>(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;I)V

    .line 3
    :goto_0
    iput-object v0, p0, Ll0/c;->d:Ll0/b;

    .line 4
    iget p1, p1, Lm0/b;->c:I

    .line 5
    new-array p1, p1, [B

    iput-object p1, p0, Ll0/c;->b:[B

    new-instance v0, Ljava/security/SecureRandom;

    invoke-direct {v0}, Ljava/security/SecureRandom;-><init>()V

    invoke-virtual {v0, p1}, Ljava/security/SecureRandom;->nextBytes([B)V

    invoke-virtual {p0, p1}, Ll0/c;->c([B)[B

    move-result-object p1

    iput-object p1, p0, Ll0/c;->c:[B

    return-void
.end method


# virtual methods
.method public final a(Ljava/lang/String;)[B
    .locals 9

    const-string v0, "\\."

    invoke-virtual {p1, v0}, Ljava/lang/String;->split(Ljava/lang/String;)[Ljava/lang/String;

    move-result-object p1

    array-length v0, p1

    const/4 v1, 0x3

    if-ne v0, v1, :cond_0

    const/4 v0, 0x0

    aget-object v1, p1, v0

    const/4 v2, 0x2

    .line 1
    invoke-static {v1, v2}, Landroid/util/Base64;->decode(Ljava/lang/String;I)[B

    move-result-object v1

    const/4 v3, 0x1

    .line 2
    aget-object v4, p1, v3

    .line 3
    invoke-static {v4, v2}, Landroid/util/Base64;->decode(Ljava/lang/String;I)[B

    move-result-object v4

    .line 4
    aget-object p1, p1, v2

    .line 5
    invoke-static {p1, v2}, Landroid/util/Base64;->decode(Ljava/lang/String;I)[B

    move-result-object p1

    .line 6
    iget-object v5, p0, Ll0/c;->d:Ll0/b;

    invoke-virtual {p0, v1}, Ll0/c;->c([B)[B

    move-result-object v1

    .line 7
    iget-object v6, v5, Ll0/b;->d:Ljavax/crypto/Cipher;

    monitor-enter v6

    :try_start_0
    iget-object v7, v5, Ll0/b;->d:Ljavax/crypto/Cipher;

    invoke-virtual {v5, v1}, Ll0/b;->a([B)Ljavax/crypto/SecretKey;

    move-result-object v1

    .line 8
    new-instance v8, Ljavax/crypto/spec/IvParameterSpec;

    invoke-direct {v8, v4}, Ljavax/crypto/spec/IvParameterSpec;-><init>([B)V

    .line 9
    invoke-virtual {v7, v2, v1, v8}, Ljavax/crypto/Cipher;->init(ILjava/security/Key;Ljava/security/spec/AlgorithmParameterSpec;)V

    iget-object v1, v5, Ll0/b;->d:Ljavax/crypto/Cipher;

    invoke-virtual {v1, p1}, Ljavax/crypto/Cipher;->doFinal([B)[B

    move-result-object p1
    :try_end_0
    .catch Ljava/security/InvalidAlgorithmParameterException; {:try_start_0 .. :try_end_0} :catch_3
    .catch Ljava/security/InvalidKeyException; {:try_start_0 .. :try_end_0} :catch_2
    .catch Ljavax/crypto/BadPaddingException; {:try_start_0 .. :try_end_0} :catch_1
    .catch Ljavax/crypto/IllegalBlockSizeException; {:try_start_0 .. :try_end_0} :catch_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    :try_start_1
    monitor-exit v6

    return-object p1

    :catchall_0
    move-exception p1

    goto :goto_1

    :catch_0
    move-exception p1

    goto :goto_0

    :catch_1
    move-exception p1

    goto :goto_0

    :catch_2
    move-exception p1

    goto :goto_0

    :catch_3
    move-exception p1

    :goto_0
    iget-object v1, v5, Ll0/b;->a:Ljava/util/logging/Logger;

    sget-object v4, Ljava/util/logging/Level;->SEVERE:Ljava/util/logging/Level;

    const-string v5, "method: decrypt()"

    invoke-virtual {v1, v4, v5, p1}, Ljava/util/logging/Logger;->log(Ljava/util/logging/Level;Ljava/lang/String;Ljava/lang/Throwable;)V

    new-instance v1, Ljava/lang/IllegalStateException;

    const-string v4, "%s: %s"

    new-array v2, v2, [Ljava/lang/Object;

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-result-object v5

    invoke-virtual {v5}, Ljava/lang/Class;->getName()Ljava/lang/String;

    move-result-object v5

    aput-object v5, v2, v0

    invoke-virtual {p1}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    move-result-object p1

    aput-object p1, v2, v3

    invoke-static {v4, v2}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object p1

    invoke-direct {v1, p1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    throw v1

    :goto_1
    monitor-exit v6
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    throw p1

    .line 10
    :cond_0
    new-instance p1, Ljava/lang/IllegalArgumentException;

    const-string v0, "Malformed data string"

    invoke-direct {p1, v0}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw p1
.end method

.method public final b([B)Ljava/lang/String;
    .locals 9

    new-instance v0, Ljava/security/SecureRandom;

    invoke-direct {v0}, Ljava/security/SecureRandom;-><init>()V

    iget-object v1, p0, Ll0/c;->d:Ll0/b;

    .line 1
    iget v1, v1, Ll0/b;->c:I

    .line 2
    new-array v1, v1, [B

    invoke-virtual {v0, v1}, Ljava/security/SecureRandom;->nextBytes([B)V

    iget-object v0, p0, Ll0/c;->d:Ll0/b;

    iget-object v2, p0, Ll0/c;->c:[B

    .line 3
    iget-object v3, v0, Ll0/b;->d:Ljavax/crypto/Cipher;

    monitor-enter v3

    const/4 v4, 0x0

    const/4 v5, 0x1

    const/4 v6, 0x2

    :try_start_0
    iget-object v7, v0, Ll0/b;->d:Ljavax/crypto/Cipher;

    invoke-virtual {v0, v2}, Ll0/b;->a([B)Ljavax/crypto/SecretKey;

    move-result-object v2

    .line 4
    new-instance v8, Ljavax/crypto/spec/IvParameterSpec;

    invoke-direct {v8, v1}, Ljavax/crypto/spec/IvParameterSpec;-><init>([B)V

    .line 5
    invoke-virtual {v7, v5, v2, v8}, Ljavax/crypto/Cipher;->init(ILjava/security/Key;Ljava/security/spec/AlgorithmParameterSpec;)V

    iget-object v2, v0, Ll0/b;->d:Ljavax/crypto/Cipher;

    invoke-virtual {v2, p1}, Ljavax/crypto/Cipher;->doFinal([B)[B

    move-result-object p1
    :try_end_0
    .catch Ljava/security/InvalidAlgorithmParameterException; {:try_start_0 .. :try_end_0} :catch_3
    .catch Ljava/security/InvalidKeyException; {:try_start_0 .. :try_end_0} :catch_2
    .catch Ljavax/crypto/BadPaddingException; {:try_start_0 .. :try_end_0} :catch_1
    .catch Ljavax/crypto/IllegalBlockSizeException; {:try_start_0 .. :try_end_0} :catch_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    :try_start_1
    monitor-exit v3
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    const-string v0, "%s.%s.%s"

    const/4 v2, 0x3

    new-array v2, v2, [Ljava/lang/Object;

    .line 6
    iget-object v3, p0, Ll0/c;->b:[B

    .line 7
    invoke-static {v3, v6}, Landroid/util/Base64;->encodeToString([BI)Ljava/lang/String;

    move-result-object v3

    aput-object v3, v2, v4

    invoke-static {v1, v6}, Landroid/util/Base64;->encodeToString([BI)Ljava/lang/String;

    move-result-object v1

    aput-object v1, v2, v5

    invoke-static {p1, v6}, Landroid/util/Base64;->encodeToString([BI)Ljava/lang/String;

    move-result-object p1

    aput-object p1, v2, v6

    .line 8
    invoke-static {v0, v2}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object p1

    return-object p1

    :catchall_0
    move-exception p1

    goto :goto_1

    :catch_0
    move-exception p1

    goto :goto_0

    :catch_1
    move-exception p1

    goto :goto_0

    :catch_2
    move-exception p1

    goto :goto_0

    :catch_3
    move-exception p1

    .line 9
    :goto_0
    :try_start_2
    iget-object v0, v0, Ll0/b;->a:Ljava/util/logging/Logger;

    sget-object v1, Ljava/util/logging/Level;->SEVERE:Ljava/util/logging/Level;

    const-string v2, "method: encrypt()"

    invoke-virtual {v0, v1, v2, p1}, Ljava/util/logging/Logger;->log(Ljava/util/logging/Level;Ljava/lang/String;Ljava/lang/Throwable;)V

    new-instance v0, Ljava/lang/IllegalStateException;

    const-string v1, "%s: %s"

    new-array v2, v6, [Ljava/lang/Object;

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-result-object v6

    invoke-virtual {v6}, Ljava/lang/Class;->getName()Ljava/lang/String;

    move-result-object v6

    aput-object v6, v2, v4

    invoke-virtual {p1}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    move-result-object p1

    aput-object p1, v2, v5

    invoke-static {v1, v2}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object p1

    invoke-direct {v0, p1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    throw v0

    :goto_1
    monitor-exit v3
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_0

    throw p1
.end method

.method public final c([B)[B
    .locals 17

    move-object/from16 v0, p0

    iget-object v1, v0, Ll0/c;->a:Lm0/b;

    .line 1
    iget-object v1, v1, Lm0/b;->a:[C

    const/4 v2, 0x0

    if-eqz v1, :cond_0

    .line 2
    sget v3, Lb0/c;->a:I

    .line 3
    new-instance v3, Ljava/io/ByteArrayOutputStream;

    invoke-direct {v3}, Ljava/io/ByteArrayOutputStream;-><init>()V

    :try_start_0
    invoke-static {v1, v3}, Lb0/c;->a([CLjava/io/OutputStream;)V
    :try_end_0
    .catch Ljava/io/IOException; {:try_start_0 .. :try_end_0} :catch_0

    invoke-virtual {v3}, Ljava/io/ByteArrayOutputStream;->toByteArray()[B

    move-result-object v1

    goto :goto_0

    :catch_0
    new-instance v1, Ljava/lang/IllegalStateException;

    const-string v2, "cannot encode string to byte array!"

    invoke-direct {v1, v2}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    throw v1

    :cond_0
    new-array v1, v2, [B

    .line 4
    :goto_0
    iget-object v3, v0, Ll0/c;->a:Lm0/b;

    .line 5
    iget v3, v3, Lm0/b;->d:I

    .line 6
    invoke-static {v3}, Lg0/c;->b(I)I

    move-result v3

    const/4 v4, 0x1

    if-eqz v3, :cond_3

    if-eq v3, v4, :cond_2

    const/4 v5, 0x2

    if-ne v3, v5, :cond_1

    new-instance v3, Lz/a;

    new-instance v5, Ly/e;

    invoke-direct {v5}, Ly/e;-><init>()V

    invoke-direct {v3, v5}, Lz/a;-><init>(Lx/a;)V

    goto :goto_1

    :cond_1
    new-instance v1, Ljava/lang/IllegalStateException;

    const-string v2, "Unknown Digest!"

    invoke-direct {v1, v2}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    throw v1

    :cond_2
    new-instance v3, Lz/a;

    new-instance v5, Ly/d;

    invoke-direct {v5}, Ly/d;-><init>()V

    invoke-direct {v3, v5}, Lz/a;-><init>(Lx/a;)V

    goto :goto_1

    :cond_3
    new-instance v3, Lz/a;

    new-instance v5, Ly/c;

    invoke-direct {v5}, Ly/c;-><init>()V

    invoke-direct {v3, v5}, Lz/a;-><init>(Lx/a;)V

    :goto_1
    iget-object v5, v0, Ll0/c;->a:Lm0/b;

    .line 7
    iget v6, v5, Lm0/b;->b:I

    move-object/from16 v7, p1

    .line 8
    iput-object v7, v3, Lz/a;->a:[B

    iput v6, v3, Lz/a;->b:I

    .line 9
    iget v5, v5, Lm0/b;->f:I

    .line 10
    div-int/lit8 v5, v5, 0x8

    .line 11
    iget-object v6, v3, Lz/a;->c:La0/a;

    .line 12
    iget v6, v6, La0/a;->b:I

    add-int v7, v5, v6

    sub-int/2addr v7, v4

    .line 13
    div-int/2addr v7, v6

    const/4 v8, 0x4

    new-array v9, v8, [B

    mul-int v10, v7, v6

    new-array v11, v10, [B

    .line 14
    array-length v12, v1

    .line 15
    new-array v13, v12, [B

    invoke-static {v1, v2, v13, v2, v12}, Ljava/lang/System;->arraycopy(Ljava/lang/Object;ILjava/lang/Object;II)V

    .line 16
    iget-object v1, v3, Lz/a;->c:La0/a;

    .line 17
    iget-object v14, v1, La0/a;->a:Lx/a;

    invoke-interface {v14}, Lx/a;->a()V

    iget v14, v1, La0/a;->c:I

    if-le v12, v14, :cond_4

    iget-object v14, v1, La0/a;->a:Lx/a;

    invoke-interface {v14, v13, v2, v12}, Lx/a;->d([BII)V

    iget-object v12, v1, La0/a;->a:Lx/a;

    iget-object v13, v1, La0/a;->f:[B

    invoke-interface {v12, v13, v2}, Lx/a;->f([BI)I

    iget v12, v1, La0/a;->b:I

    goto :goto_2

    :cond_4
    iget-object v14, v1, La0/a;->f:[B

    invoke-static {v13, v2, v14, v2, v12}, Ljava/lang/System;->arraycopy(Ljava/lang/Object;ILjava/lang/Object;II)V

    :goto_2
    iget-object v13, v1, La0/a;->f:[B

    array-length v14, v13

    if-ge v12, v14, :cond_5

    aput-byte v2, v13, v12

    add-int/lit8 v12, v12, 0x1

    goto :goto_2

    :cond_5
    iget-object v12, v1, La0/a;->g:[B

    iget v14, v1, La0/a;->c:I

    invoke-static {v13, v2, v12, v2, v14}, Ljava/lang/System;->arraycopy(Ljava/lang/Object;ILjava/lang/Object;II)V

    iget-object v12, v1, La0/a;->f:[B

    iget v13, v1, La0/a;->c:I

    const/4 v14, 0x0

    :goto_3
    if-ge v14, v13, :cond_6

    .line 18
    aget-byte v15, v12, v14

    xor-int/lit8 v15, v15, 0x36

    int-to-byte v15, v15

    aput-byte v15, v12, v14

    add-int/lit8 v14, v14, 0x1

    goto :goto_3

    .line 19
    :cond_6
    iget-object v12, v1, La0/a;->g:[B

    iget v13, v1, La0/a;->c:I

    const/4 v14, 0x0

    :goto_4
    if-ge v14, v13, :cond_7

    .line 20
    aget-byte v15, v12, v14

    xor-int/lit8 v15, v15, 0x5c

    int-to-byte v15, v15

    aput-byte v15, v12, v14

    add-int/lit8 v14, v14, 0x1

    goto :goto_4

    .line 21
    :cond_7
    iget-object v12, v1, La0/a;->a:Lx/a;

    instance-of v13, v12, Lb0/a;

    if-eqz v13, :cond_8

    check-cast v12, Lb0/a;

    invoke-interface {v12}, Lb0/a;->e()Lb0/a;

    move-result-object v12

    iput-object v12, v1, La0/a;->e:Lb0/a;

    check-cast v12, Lx/a;

    iget-object v13, v1, La0/a;->g:[B

    iget v14, v1, La0/a;->c:I

    invoke-interface {v12, v13, v2, v14}, Lx/a;->d([BII)V

    :cond_8
    iget-object v12, v1, La0/a;->a:Lx/a;

    iget-object v13, v1, La0/a;->f:[B

    array-length v14, v13

    invoke-interface {v12, v13, v2, v14}, Lx/a;->d([BII)V

    iget-object v12, v1, La0/a;->a:Lx/a;

    instance-of v13, v12, Lb0/a;

    if-eqz v13, :cond_9

    check-cast v12, Lb0/a;

    invoke-interface {v12}, Lb0/a;->e()Lb0/a;

    move-result-object v12

    iput-object v12, v1, La0/a;->d:Lb0/a;

    :cond_9
    const/4 v1, 0x1

    const/4 v12, 0x0

    :goto_5
    if-gt v1, v7, :cond_f

    const/4 v13, 0x3

    .line 22
    :goto_6
    aget-byte v14, v9, v13

    add-int/2addr v14, v4

    int-to-byte v14, v14

    aput-byte v14, v9, v13

    if-nez v14, :cond_a

    add-int/lit8 v13, v13, -0x1

    goto :goto_6

    :cond_a
    iget-object v13, v3, Lz/a;->a:[B

    iget v14, v3, Lz/a;->b:I

    if-eqz v14, :cond_e

    if-eqz v13, :cond_b

    .line 23
    iget-object v15, v3, Lz/a;->c:La0/a;

    array-length v4, v13

    invoke-virtual {v15, v13, v4}, La0/a;->b([BI)V

    :cond_b
    iget-object v4, v3, Lz/a;->c:La0/a;

    invoke-virtual {v4, v9, v8}, La0/a;->b([BI)V

    iget-object v4, v3, Lz/a;->c:La0/a;

    iget-object v13, v3, Lz/a;->d:[B

    invoke-virtual {v4, v13}, La0/a;->a([B)I

    iget-object v4, v3, Lz/a;->d:[B

    array-length v13, v4

    invoke-static {v4, v2, v11, v12, v13}, Ljava/lang/System;->arraycopy(Ljava/lang/Object;ILjava/lang/Object;II)V

    const/4 v4, 0x1

    :goto_7
    if-ge v4, v14, :cond_d

    iget-object v13, v3, Lz/a;->c:La0/a;

    iget-object v15, v3, Lz/a;->d:[B

    array-length v8, v15

    invoke-virtual {v13, v15, v8}, La0/a;->b([BI)V

    iget-object v8, v3, Lz/a;->c:La0/a;

    iget-object v13, v3, Lz/a;->d:[B

    invoke-virtual {v8, v13}, La0/a;->a([B)I

    const/4 v8, 0x0

    :goto_8
    iget-object v13, v3, Lz/a;->d:[B

    array-length v15, v13

    if-eq v8, v15, :cond_c

    add-int v15, v12, v8

    aget-byte v16, v11, v15

    aget-byte v13, v13, v8

    xor-int v13, v13, v16

    int-to-byte v13, v13

    aput-byte v13, v11, v15

    add-int/lit8 v8, v8, 0x1

    goto :goto_8

    :cond_c
    add-int/lit8 v4, v4, 0x1

    const/4 v8, 0x4

    goto :goto_7

    :cond_d
    add-int/2addr v12, v6

    add-int/lit8 v1, v1, 0x1

    const/4 v4, 0x1

    const/4 v8, 0x4

    goto :goto_5

    :cond_e
    new-instance v1, Ljava/lang/IllegalArgumentException;

    const-string v2, "iteration count must be at least 1."

    invoke-direct {v1, v2}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw v1

    :cond_f
    add-int/lit8 v1, v5, 0x0

    if-ltz v1, :cond_11

    .line 24
    new-array v3, v1, [B

    sub-int/2addr v10, v2

    if-ge v10, v1, :cond_10

    move v1, v10

    :cond_10
    invoke-static {v11, v2, v3, v2, v1}, Ljava/lang/System;->arraycopy(Ljava/lang/Object;ILjava/lang/Object;II)V

    .line 25
    new-array v1, v5, [B

    invoke-static {v3, v2, v1, v2, v5}, Ljava/lang/System;->arraycopy(Ljava/lang/Object;ILjava/lang/Object;II)V

    return-object v1

    .line 26
    :cond_11
    new-instance v1, Ljava/lang/StringBuffer;

    invoke-direct {v1, v2}, Ljava/lang/StringBuffer;-><init>(I)V

    const-string v2, " > "

    invoke-virtual {v1, v2}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    invoke-virtual {v1, v5}, Ljava/lang/StringBuffer;->append(I)Ljava/lang/StringBuffer;

    new-instance v2, Ljava/lang/IllegalArgumentException;

    invoke-virtual {v1}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-direct {v2, v1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw v2
.end method
