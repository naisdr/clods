.class public Lcom/trilead/ssh2/crypto/digest/JreMessageDigestWrapper;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lcom/trilead/ssh2/crypto/digest/Digest;


# instance fields
.field public final a:Ljava/security/MessageDigest;


# direct methods
.method public constructor <init>(Ljava/security/MessageDigest;)V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lcom/trilead/ssh2/crypto/digest/JreMessageDigestWrapper;->a:Ljava/security/MessageDigest;

    return-void
.end method


# virtual methods
.method public final a()V
    .locals 1

    iget-object v0, p0, Lcom/trilead/ssh2/crypto/digest/JreMessageDigestWrapper;->a:Ljava/security/MessageDigest;

    invoke-virtual {v0}, Ljava/security/MessageDigest;->reset()V

    return-void
.end method

.method public final b([B)V
    .locals 3

    iget-object v0, p0, Lcom/trilead/ssh2/crypto/digest/JreMessageDigestWrapper;->a:Ljava/security/MessageDigest;

    invoke-virtual {v0}, Ljava/security/MessageDigest;->digest()[B

    move-result-object v0

    array-length v1, p1

    const/4 v2, 0x0

    invoke-static {v0, v2, p1, v2, v1}, Ljava/lang/System;->arraycopy(Ljava/lang/Object;ILjava/lang/Object;II)V

    return-void
.end method

.method public final c()I
    .locals 1

    iget-object v0, p0, Lcom/trilead/ssh2/crypto/digest/JreMessageDigestWrapper;->a:Ljava/security/MessageDigest;

    invoke-virtual {v0}, Ljava/security/MessageDigest;->getDigestLength()I

    move-result v0

    return v0
.end method

.method public final d([BI)V
    .locals 2

    iget-object v0, p0, Lcom/trilead/ssh2/crypto/digest/JreMessageDigestWrapper;->a:Ljava/security/MessageDigest;

    const/4 v1, 0x0

    invoke-virtual {v0, p1, v1, p2}, Ljava/security/MessageDigest;->update([BII)V

    return-void
.end method

.method public final e([B)V
    .locals 3

    iget-object v0, p0, Lcom/trilead/ssh2/crypto/digest/JreMessageDigestWrapper;->a:Ljava/security/MessageDigest;

    invoke-virtual {v0}, Ljava/security/MessageDigest;->digest()[B

    move-result-object v0

    array-length v1, p1

    const/4 v2, 0x0

    invoke-static {v0, v2, p1, v2, v1}, Ljava/lang/System;->arraycopy(Ljava/lang/Object;ILjava/lang/Object;II)V

    return-void
.end method

.method public final f(B)V
    .locals 1

    iget-object v0, p0, Lcom/trilead/ssh2/crypto/digest/JreMessageDigestWrapper;->a:Ljava/security/MessageDigest;

    invoke-virtual {v0, p1}, Ljava/security/MessageDigest;->update(B)V

    return-void
.end method

.method public final g([B)V
    .locals 1

    iget-object v0, p0, Lcom/trilead/ssh2/crypto/digest/JreMessageDigestWrapper;->a:Ljava/security/MessageDigest;

    invoke-virtual {v0, p1}, Ljava/security/MessageDigest;->update([B)V

    return-void
.end method
