.class public final Ls/c;
.super Ljava/lang/Object;
.source "SourceFile"


# instance fields
.field public a:Lm/e;

.field public b:Lm/e;

.field public c:Ls/f;

.field public d:I

.field public e:Ljava/math/BigInteger;

.field public f:[B

.field public g:[B

.field public h:Lcom/trilead/ssh2/crypto/dh/DhExchange;

.field public i:Lcom/trilead/ssh2/crypto/dh/DhGroupExchange;

.field public j:La/b;

.field public k:Ljava/lang/String;


# direct methods
.method public constructor <init>()V
    .locals 1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v0, 0x0

    iput v0, p0, Ls/c;->d:I

    return-void
.end method


# virtual methods
.method public final a()Ljava/lang/String;
    .locals 1

    iget-object v0, p0, Ls/c;->k:Ljava/lang/String;

    return-object v0
.end method

.method public final b(Ljava/lang/String;)V
    .locals 0

    iput-object p1, p0, Ls/c;->k:Ljava/lang/String;

    return-void
.end method
