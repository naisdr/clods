.class public Lcom/trilead/ssh2/crypto/PEMDecoder;
.super Ljava/lang/Object;
.source "SourceFile"


# static fields
.field public static final a:Ljava/util/logging/Logger;


# direct methods
.method public static constructor <clinit>()V
    .locals 1

    const-class v0, Lcom/trilead/ssh2/crypto/PEMDecoder;

    invoke-virtual {v0}, Ljava/lang/Class;->getName()Ljava/lang/String;

    move-result-object v0

    invoke-static {v0}, Ljava/util/logging/Logger;->getLogger(Ljava/lang/String;)Ljava/util/logging/Logger;

    move-result-object v0

    sput-object v0, Lcom/trilead/ssh2/crypto/PEMDecoder;->a:Ljava/util/logging/Logger;

    return-void
.end method

.method public constructor <init>()V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method public static a([CLjava/lang/String;)Ljava/security/KeyPair;
    .locals 7

    .line 1
    sget-object v0, Lr/e;->a:Ljava/util/Collection;

    .line 2
    invoke-interface {v0}, Ljava/util/Collection;->iterator()Ljava/util/Iterator;

    move-result-object v0

    :cond_0
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v1

    if-eqz v1, :cond_3

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Lr/d;

    invoke-virtual {v1}, Lr/d;->e()Ljava/util/List;

    move-result-object v1

    invoke-interface {v1}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v1

    :goto_0
    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    move-result v2

    if-eqz v2, :cond_0

    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Lcom/trilead/ssh2/crypto/CertificateDecoder;

    :try_start_0
    invoke-static {p0, v2}, Lcom/trilead/ssh2/crypto/PEMDecoder;->f([CLcom/trilead/ssh2/crypto/CertificateDecoder;)Lcom/trilead/ssh2/crypto/PEMStructure;

    move-result-object v3

    invoke-static {v3}, Lcom/trilead/ssh2/crypto/PEMDecoder;->e(Lcom/trilead/ssh2/crypto/PEMStructure;)Z

    move-result v4

    if-eqz v4, :cond_2

    if-eqz p1, :cond_1

    const-string v4, "ISO-8859-1"

    invoke-virtual {p1, v4}, Ljava/lang/String;->getBytes(Ljava/lang/String;)[B

    move-result-object v4

    invoke-static {v3, v4}, Lcom/trilead/ssh2/crypto/PEMDecoder;->b(Lcom/trilead/ssh2/crypto/PEMStructure;[B)V

    goto :goto_1

    :cond_1
    new-instance v3, Ljava/io/IOException;

    const-string v4, "PEM is encrypted, but no password was specified"

    invoke-direct {v3, v4}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    throw v3

    :cond_2
    :goto_1
    invoke-virtual {v2, v3, p1}, Lcom/trilead/ssh2/crypto/CertificateDecoder;->b(Lcom/trilead/ssh2/crypto/PEMStructure;Ljava/lang/String;)Ljava/security/KeyPair;

    move-result-object p0
    :try_end_0
    .catch Ljava/io/IOException; {:try_start_0 .. :try_end_0} :catch_0

    return-object p0

    :catch_0
    move-exception v3

    sget-object v4, Lcom/trilead/ssh2/crypto/PEMDecoder;->a:Ljava/util/logging/Logger;

    sget-object v5, Ljava/util/logging/Level;->FINE:Ljava/util/logging/Level;

    const-string v6, "Could not decode PEM Key using current decoder: "

    .line 3
    invoke-static {v6}, Lcom/trilead/ssh2/crypto/digest/a;->e(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v6

    .line 4
    invoke-virtual {v2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/Class;->getName()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v6, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v6}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v4, v5, v2, v3}, Ljava/util/logging/Logger;->log(Ljava/util/logging/Level;Ljava/lang/String;Ljava/lang/Throwable;)V

    goto :goto_0

    :cond_3
    new-instance p0, Ljava/io/IOException;

    const-string p1, "PEM problem: it is of unknown type"

    invoke-direct {p0, p1}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    throw p0
.end method

.method public static b(Lcom/trilead/ssh2/crypto/PEMStructure;[B)V
    .locals 10

    iget-object v0, p0, Lcom/trilead/ssh2/crypto/PEMStructure;->a:[Ljava/lang/String;

    if-eqz v0, :cond_e

    array-length v1, v0

    const/4 v2, 0x2

    if-ne v1, v2, :cond_d

    const/4 v1, 0x0

    aget-object v3, v0, v1

    const/4 v4, 0x1

    aget-object v0, v0, v4

    if-eqz v0, :cond_c

    .line 1
    invoke-virtual {v0}, Ljava/lang/String;->length()I

    move-result v5

    rem-int/2addr v5, v2

    if-nez v5, :cond_b

    invoke-virtual {v0}, Ljava/lang/String;->length()I

    move-result v5

    div-int/2addr v5, v2

    new-array v6, v5, [B

    const/4 v7, 0x0

    :goto_0
    const/16 v8, 0x10

    if-ge v7, v5, :cond_0

    mul-int/lit8 v8, v7, 0x2

    invoke-virtual {v0, v8}, Ljava/lang/String;->charAt(I)C

    move-result v9

    invoke-static {v9}, Lcom/trilead/ssh2/crypto/PEMDecoder;->d(C)I

    move-result v9

    add-int/2addr v8, v4

    invoke-virtual {v0, v8}, Ljava/lang/String;->charAt(I)C

    move-result v8

    invoke-static {v8}, Lcom/trilead/ssh2/crypto/PEMDecoder;->d(C)I

    move-result v8

    mul-int/lit8 v9, v9, 0x10

    add-int/2addr v9, v8

    int-to-byte v8, v9

    aput-byte v8, v6, v7

    add-int/lit8 v7, v7, 0x1

    goto :goto_0

    :cond_0
    const-string v0, "DES-EDE3-CBC"

    .line 2
    invoke-virtual {v3, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    const/16 v5, 0x18

    if-eqz v0, :cond_1

    new-instance v0, Lcom/trilead/ssh2/crypto/cipher/DESede;

    invoke-direct {v0}, Lcom/trilead/ssh2/crypto/cipher/DESede;-><init>()V

    invoke-static {p1, v6, v5}, Lcom/trilead/ssh2/crypto/PEMDecoder;->c([B[BI)[B

    move-result-object p1

    invoke-virtual {v0, v1, p1}, Lcom/trilead/ssh2/crypto/cipher/DESede;->b(Z[B)V

    new-instance p1, Lcom/trilead/ssh2/crypto/cipher/CBCMode;

    invoke-direct {p1, v0, v6, v1}, Lcom/trilead/ssh2/crypto/cipher/CBCMode;-><init>(Lcom/trilead/ssh2/crypto/cipher/BlockCipher;[BZ)V

    goto :goto_1

    :cond_1
    const-string v0, "DES-CBC"

    invoke-virtual {v3, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_2

    new-instance v0, Lcom/trilead/ssh2/crypto/cipher/DES;

    invoke-direct {v0}, Lcom/trilead/ssh2/crypto/cipher/DES;-><init>()V

    const/16 v3, 0x8

    invoke-static {p1, v6, v3}, Lcom/trilead/ssh2/crypto/PEMDecoder;->c([B[BI)[B

    move-result-object p1

    invoke-virtual {v0, v1, p1}, Lcom/trilead/ssh2/crypto/cipher/DES;->b(Z[B)V

    new-instance p1, Lcom/trilead/ssh2/crypto/cipher/CBCMode;

    invoke-direct {p1, v0, v6, v1}, Lcom/trilead/ssh2/crypto/cipher/CBCMode;-><init>(Lcom/trilead/ssh2/crypto/cipher/BlockCipher;[BZ)V

    goto :goto_1

    :cond_2
    const-string v0, "AES-128-CBC"

    invoke-virtual {v3, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_3

    new-instance v0, Lcom/trilead/ssh2/crypto/cipher/AES;

    invoke-direct {v0}, Lcom/trilead/ssh2/crypto/cipher/AES;-><init>()V

    invoke-static {p1, v6, v8}, Lcom/trilead/ssh2/crypto/PEMDecoder;->c([B[BI)[B

    move-result-object p1

    invoke-virtual {v0, v1, p1}, Lcom/trilead/ssh2/crypto/cipher/AES;->b(Z[B)V

    new-instance p1, Lcom/trilead/ssh2/crypto/cipher/CBCMode;

    invoke-direct {p1, v0, v6, v1}, Lcom/trilead/ssh2/crypto/cipher/CBCMode;-><init>(Lcom/trilead/ssh2/crypto/cipher/BlockCipher;[BZ)V

    goto :goto_1

    :cond_3
    const-string v0, "AES-192-CBC"

    invoke-virtual {v3, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_4

    new-instance v0, Lcom/trilead/ssh2/crypto/cipher/AES;

    invoke-direct {v0}, Lcom/trilead/ssh2/crypto/cipher/AES;-><init>()V

    invoke-static {p1, v6, v5}, Lcom/trilead/ssh2/crypto/PEMDecoder;->c([B[BI)[B

    move-result-object p1

    invoke-virtual {v0, v1, p1}, Lcom/trilead/ssh2/crypto/cipher/AES;->b(Z[B)V

    new-instance p1, Lcom/trilead/ssh2/crypto/cipher/CBCMode;

    invoke-direct {p1, v0, v6, v1}, Lcom/trilead/ssh2/crypto/cipher/CBCMode;-><init>(Lcom/trilead/ssh2/crypto/cipher/BlockCipher;[BZ)V

    goto :goto_1

    :cond_4
    const-string v0, "AES-256-CBC"

    invoke-virtual {v3, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_a

    new-instance v0, Lcom/trilead/ssh2/crypto/cipher/AES;

    invoke-direct {v0}, Lcom/trilead/ssh2/crypto/cipher/AES;-><init>()V

    const/16 v3, 0x20

    invoke-static {p1, v6, v3}, Lcom/trilead/ssh2/crypto/PEMDecoder;->c([B[BI)[B

    move-result-object p1

    invoke-virtual {v0, v1, p1}, Lcom/trilead/ssh2/crypto/cipher/AES;->b(Z[B)V

    new-instance p1, Lcom/trilead/ssh2/crypto/cipher/CBCMode;

    invoke-direct {p1, v0, v6, v1}, Lcom/trilead/ssh2/crypto/cipher/CBCMode;-><init>(Lcom/trilead/ssh2/crypto/cipher/BlockCipher;[BZ)V

    :goto_1
    iget-object v0, p0, Lcom/trilead/ssh2/crypto/PEMStructure;->c:[B

    array-length v3, v0

    .line 3
    iget v5, p1, Lcom/trilead/ssh2/crypto/cipher/CBCMode;->b:I

    .line 4
    rem-int/2addr v3, v5

    if-nez v3, :cond_9

    array-length v0, v0

    new-array v3, v0, [B

    const/4 v5, 0x0

    :goto_2
    iget-object v6, p0, Lcom/trilead/ssh2/crypto/PEMStructure;->c:[B

    array-length v7, v6

    .line 5
    iget v8, p1, Lcom/trilead/ssh2/crypto/cipher/CBCMode;->b:I

    .line 6
    div-int/2addr v7, v8

    if-ge v5, v7, :cond_5

    mul-int v8, v8, v5

    invoke-virtual {p1, v6, v8, v3, v8}, Lcom/trilead/ssh2/crypto/cipher/CBCMode;->c([BI[BI)V

    add-int/lit8 v5, v5, 0x1

    goto :goto_2

    :cond_5
    add-int/lit8 p1, v0, -0x1

    .line 7
    aget-byte p1, v3, p1

    and-int/lit16 p1, p1, 0xff

    const-string v5, "Decrypted PEM has wrong padding, did you specify the correct password?"

    if-lt p1, v4, :cond_8

    if-gt p1, v8, :cond_8

    :goto_3
    if-gt v2, p1, :cond_7

    sub-int v4, v0, v2

    aget-byte v4, v3, v4

    if-ne v4, p1, :cond_6

    add-int/lit8 v2, v2, 0x1

    goto :goto_3

    :cond_6
    new-instance p0, Ljava/io/IOException;

    invoke-direct {p0, v5}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    throw p0

    :cond_7
    sub-int/2addr v0, p1

    new-array p1, v0, [B

    invoke-static {v3, v1, p1, v1, v0}, Ljava/lang/System;->arraycopy(Ljava/lang/Object;ILjava/lang/Object;II)V

    .line 8
    iput-object p1, p0, Lcom/trilead/ssh2/crypto/PEMStructure;->c:[B

    const/4 p1, 0x0

    iput-object p1, p0, Lcom/trilead/ssh2/crypto/PEMStructure;->a:[Ljava/lang/String;

    iput-object p1, p0, Lcom/trilead/ssh2/crypto/PEMStructure;->b:[Ljava/lang/String;

    return-void

    .line 9
    :cond_8
    new-instance p0, Ljava/io/IOException;

    invoke-direct {p0, v5}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    throw p0

    .line 10
    :cond_9
    new-instance p0, Ljava/io/IOException;

    const-string v0, "Invalid PEM structure, size of encrypted block is not a multiple of "

    .line 11
    invoke-static {v0}, Lcom/trilead/ssh2/crypto/digest/a;->e(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    .line 12
    iget p1, p1, Lcom/trilead/ssh2/crypto/cipher/CBCMode;->b:I

    .line 13
    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    invoke-direct {p0, p1}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    throw p0

    :cond_a
    new-instance p0, Ljava/io/IOException;

    new-instance p1, Ljava/lang/StringBuilder;

    invoke-direct {p1}, Ljava/lang/StringBuilder;-><init>()V

    const-string v0, "Cannot decrypt PEM structure, unknown cipher "

    invoke-virtual {p1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p1, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    invoke-direct {p0, p1}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    throw p0

    .line 14
    :cond_b
    new-instance p0, Ljava/lang/IllegalArgumentException;

    const-string p1, "Uneven string length in hex encoding."

    invoke-direct {p0, p1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw p0

    :cond_c
    new-instance p0, Ljava/lang/IllegalArgumentException;

    const-string p1, "null argument"

    invoke-direct {p0, p1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw p0

    .line 15
    :cond_d
    new-instance p0, Ljava/io/IOException;

    const-string p1, "Broken PEM, DEK-Info is incomplete!"

    invoke-direct {p0, p1}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    throw p0

    :cond_e
    new-instance p0, Ljava/io/IOException;

    const-string p1, "Broken PEM, no mode and salt given, but encryption enabled"

    invoke-direct {p0, p1}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    throw p0
.end method

.method public static c([B[BI)[B
    .locals 9

    array-length v0, p1

    const/16 v1, 0x8

    if-lt v0, v1, :cond_2

    new-instance v0, Lcom/trilead/ssh2/crypto/digest/MD5;

    invoke-direct {v0}, Lcom/trilead/ssh2/crypto/digest/MD5;-><init>()V

    new-array v2, p2, [B

    const/16 v3, 0x10

    new-array v4, v3, [B

    move v5, p2

    :goto_0
    array-length v6, p0

    const/4 v7, 0x0

    invoke-virtual {v0, p0, v6}, Lcom/trilead/ssh2/crypto/digest/MD5;->d([BI)V

    invoke-virtual {v0, p1, v1}, Lcom/trilead/ssh2/crypto/digest/MD5;->d([BI)V

    if-ge v5, v3, :cond_0

    move v6, v5

    goto :goto_1

    :cond_0
    const/16 v6, 0x10

    :goto_1
    invoke-virtual {v0, v4}, Lcom/trilead/ssh2/crypto/digest/MD5;->b([B)V

    sub-int v8, p2, v5

    invoke-static {v4, v7, v2, v8, v6}, Ljava/lang/System;->arraycopy(Ljava/lang/Object;ILjava/lang/Object;II)V

    sub-int/2addr v5, v6

    if-nez v5, :cond_1

    return-object v2

    :cond_1
    invoke-virtual {v0, v4, v3}, Lcom/trilead/ssh2/crypto/digest/MD5;->d([BI)V

    goto :goto_0

    :cond_2
    new-instance p0, Ljava/lang/IllegalArgumentException;

    const-string p1, "Salt needs to be at least 8 bytes for key generation."

    invoke-direct {p0, p1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw p0
.end method

.method public static d(C)I
    .locals 2

    const/16 v0, 0x61

    if-lt p0, v0, :cond_0

    const/16 v1, 0x66

    if-gt p0, v1, :cond_0

    :goto_0
    sub-int/2addr p0, v0

    add-int/lit8 p0, p0, 0xa

    return p0

    :cond_0
    const/16 v0, 0x41

    if-lt p0, v0, :cond_1

    const/16 v1, 0x46

    if-gt p0, v1, :cond_1

    goto :goto_0

    :cond_1
    const/16 v0, 0x30

    if-lt p0, v0, :cond_2

    const/16 v1, 0x39

    if-gt p0, v1, :cond_2

    sub-int/2addr p0, v0

    return p0

    :cond_2
    new-instance p0, Ljava/lang/IllegalArgumentException;

    const-string v0, "Need hex char"

    invoke-direct {p0, v0}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw p0
.end method

.method public static e(Lcom/trilead/ssh2/crypto/PEMStructure;)Z
    .locals 4

    iget-object v0, p0, Lcom/trilead/ssh2/crypto/PEMStructure;->b:[Ljava/lang/String;

    const/4 v1, 0x0

    if-nez v0, :cond_0

    return v1

    :cond_0
    array-length v2, v0

    const/4 v3, 0x2

    if-ne v2, v3, :cond_2

    aget-object v0, v0, v1

    const-string v2, "4"

    invoke-virtual {v2, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_1

    iget-object p0, p0, Lcom/trilead/ssh2/crypto/PEMStructure;->b:[Ljava/lang/String;

    const/4 v0, 0x1

    aget-object p0, p0, v0

    const-string v0, "ENCRYPTED"

    invoke-virtual {v0, p0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p0

    return p0

    :cond_1
    new-instance v0, Ljava/io/IOException;

    const-string v2, "Unknown Proc-Type field ("

    .line 1
    invoke-static {v2}, Lcom/trilead/ssh2/crypto/digest/a;->e(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    .line 2
    iget-object p0, p0, Lcom/trilead/ssh2/crypto/PEMStructure;->b:[Ljava/lang/String;

    aget-object p0, p0, v1

    invoke-virtual {v2, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string p0, ")"

    invoke-virtual {v2, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    invoke-direct {v0, p0}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    throw v0

    :cond_2
    new-instance p0, Ljava/io/IOException;

    const-string v0, "Unknown Proc-Type field."

    invoke-direct {p0, v0}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    throw p0
.end method

.method public static f([CLcom/trilead/ssh2/crypto/CertificateDecoder;)Lcom/trilead/ssh2/crypto/PEMStructure;
    .locals 13

    new-instance v0, Lcom/trilead/ssh2/crypto/PEMStructure;

    invoke-direct {v0}, Lcom/trilead/ssh2/crypto/PEMStructure;-><init>()V

    new-instance v1, Ljava/io/BufferedReader;

    new-instance v2, Ljava/io/CharArrayReader;

    invoke-direct {v2, p0}, Ljava/io/CharArrayReader;-><init>([C)V

    invoke-direct {v1, v2}, Ljava/io/BufferedReader;-><init>(Ljava/io/Reader;)V

    :cond_0
    invoke-virtual {v1}, Ljava/io/BufferedReader;->readLine()Ljava/lang/String;

    move-result-object p0

    if-eqz p0, :cond_16

    invoke-virtual {p0}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object p0

    invoke-virtual {p1}, Lcom/trilead/ssh2/crypto/CertificateDecoder;->d()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {p0, v2}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result p0

    if-eqz p0, :cond_0

    invoke-virtual {p1}, Lcom/trilead/ssh2/crypto/CertificateDecoder;->c()Ljava/lang/String;

    move-result-object p0

    :cond_1
    :goto_0
    invoke-virtual {v1}, Ljava/io/BufferedReader;->readLine()Ljava/lang/String;

    move-result-object p1

    const-string v2, " missing"

    const-string v3, "Invalid PEM structure, "

    if-eqz p1, :cond_15

    invoke-virtual {p1}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object p1

    const/16 v4, 0x3a

    invoke-virtual {p1, v4}, Ljava/lang/String;->indexOf(I)I

    move-result v4

    const/4 v5, -0x1

    const/4 v6, 0x0

    if-ne v4, v5, :cond_12

    new-instance v4, Ljava/lang/StringBuilder;

    invoke-direct {v4}, Ljava/lang/StringBuilder;-><init>()V

    :goto_1
    if-eqz p1, :cond_11

    invoke-virtual {p1}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object p1

    invoke-virtual {p1, p0}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result v5

    if-eqz v5, :cond_10

    invoke-virtual {v4}, Ljava/lang/StringBuilder;->length()I

    move-result p0

    new-array p1, p0, [C

    invoke-virtual {v4, v6, p0, p1, v6}, Ljava/lang/StringBuilder;->getChars(II[CI)V

    sget-object v1, Lcom/trilead/ssh2/crypto/Base64;->a:[C

    const/4 v1, 0x4

    new-array v2, v1, [B

    .line 1
    new-array v3, p0, [B

    const/4 v4, 0x0

    const/4 v5, 0x0

    const/4 v7, 0x0

    :goto_2
    if-ge v4, p0, :cond_e

    aget-char v8, p1, v4

    const/16 v9, 0xa

    if-eq v8, v9, :cond_d

    const/16 v9, 0xd

    if-eq v8, v9, :cond_d

    const/16 v9, 0x20

    if-eq v8, v9, :cond_d

    const/16 v9, 0x9

    if-ne v8, v9, :cond_2

    goto/16 :goto_6

    :cond_2
    const/16 v9, 0x41

    const/16 v10, 0x40

    const/16 v11, 0x3f

    if-lt v8, v9, :cond_3

    const/16 v9, 0x5a

    if-gt v8, v9, :cond_3

    add-int/lit8 v9, v5, 0x1

    add-int/lit8 v8, v8, -0x41

    int-to-byte v8, v8

    aput-byte v8, v2, v5

    goto :goto_3

    :cond_3
    const/16 v9, 0x61

    if-lt v8, v9, :cond_4

    const/16 v9, 0x7a

    if-gt v8, v9, :cond_4

    add-int/lit8 v9, v5, 0x1

    add-int/lit8 v8, v8, -0x61

    add-int/lit8 v8, v8, 0x1a

    int-to-byte v8, v8

    aput-byte v8, v2, v5

    goto :goto_3

    :cond_4
    const/16 v9, 0x30

    if-lt v8, v9, :cond_5

    const/16 v9, 0x39

    if-gt v8, v9, :cond_5

    add-int/lit8 v9, v5, 0x1

    add-int/lit8 v8, v8, -0x30

    add-int/lit8 v8, v8, 0x34

    int-to-byte v8, v8

    aput-byte v8, v2, v5

    :goto_3
    move v5, v9

    goto :goto_5

    :cond_5
    const/16 v9, 0x2b

    if-ne v8, v9, :cond_6

    add-int/lit8 v8, v5, 0x1

    const/16 v9, 0x3e

    aput-byte v9, v2, v5

    goto :goto_4

    :cond_6
    const/16 v9, 0x2f

    if-ne v8, v9, :cond_7

    add-int/lit8 v8, v5, 0x1

    aput-byte v11, v2, v5

    goto :goto_4

    :cond_7
    const/16 v9, 0x3d

    if-ne v8, v9, :cond_c

    add-int/lit8 v8, v5, 0x1

    aput-byte v10, v2, v5

    :goto_4
    move v5, v8

    :goto_5
    if-ne v5, v1, :cond_d

    aget-byte v5, v2, v6

    if-ne v5, v10, :cond_8

    goto/16 :goto_7

    :cond_8
    const/4 v5, 0x1

    aget-byte v8, v2, v5

    if-eq v8, v10, :cond_b

    const/4 v8, 0x2

    aget-byte v9, v2, v8

    if-ne v9, v10, :cond_9

    aget-byte p0, v2, v6

    and-int/2addr p0, v11

    shl-int/lit8 p0, p0, 0x6

    aget-byte p1, v2, v5

    and-int/2addr p1, v11

    or-int/2addr p0, p1

    add-int/lit8 p1, v7, 0x1

    shr-int/2addr p0, v1

    int-to-byte p0, p0

    aput-byte p0, v3, v7

    move v7, p1

    goto :goto_7

    :cond_9
    const/4 v9, 0x3

    aget-byte v12, v2, v9

    if-ne v12, v10, :cond_a

    aget-byte p0, v2, v6

    and-int/2addr p0, v11

    shl-int/lit8 p0, p0, 0xc

    aget-byte p1, v2, v5

    and-int/2addr p1, v11

    shl-int/lit8 p1, p1, 0x6

    or-int/2addr p0, p1

    aget-byte p1, v2, v8

    and-int/2addr p1, v11

    or-int/2addr p0, p1

    add-int/lit8 p1, v7, 0x1

    shr-int/lit8 v1, p0, 0xa

    int-to-byte v1, v1

    aput-byte v1, v3, v7

    add-int/lit8 v7, p1, 0x1

    shr-int/2addr p0, v8

    int-to-byte p0, p0

    aput-byte p0, v3, p1

    goto :goto_7

    :cond_a
    aget-byte v10, v2, v6

    and-int/2addr v10, v11

    shl-int/lit8 v10, v10, 0x12

    aget-byte v5, v2, v5

    and-int/2addr v5, v11

    shl-int/lit8 v5, v5, 0xc

    or-int/2addr v5, v10

    aget-byte v8, v2, v8

    and-int/2addr v8, v11

    shl-int/lit8 v8, v8, 0x6

    or-int/2addr v5, v8

    aget-byte v8, v2, v9

    and-int/2addr v8, v11

    or-int/2addr v5, v8

    add-int/lit8 v8, v7, 0x1

    shr-int/lit8 v9, v5, 0x10

    int-to-byte v9, v9

    aput-byte v9, v3, v7

    add-int/lit8 v7, v8, 0x1

    shr-int/lit8 v9, v5, 0x8

    int-to-byte v9, v9

    aput-byte v9, v3, v8

    add-int/lit8 v8, v7, 0x1

    int-to-byte v5, v5

    aput-byte v5, v3, v7

    move v7, v8

    const/4 v5, 0x0

    goto :goto_6

    :cond_b
    new-instance p0, Ljava/io/IOException;

    const-string p1, "Unexpected \'=\' in base64 code."

    invoke-direct {p0, p1}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    throw p0

    :cond_c
    new-instance p0, Ljava/io/IOException;

    const-string p1, "Illegal char in base64 code."

    invoke-direct {p0, p1}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    throw p0

    :cond_d
    :goto_6
    add-int/lit8 v4, v4, 0x1

    goto/16 :goto_2

    :cond_e
    :goto_7
    new-array p0, v7, [B

    invoke-static {v3, v6, p0, v6, v7}, Ljava/lang/System;->arraycopy(Ljava/lang/Object;ILjava/lang/Object;II)V

    .line 2
    iput-object p0, v0, Lcom/trilead/ssh2/crypto/PEMStructure;->c:[B

    array-length p0, p0

    if-eqz p0, :cond_f

    return-object v0

    :cond_f
    new-instance p0, Ljava/io/IOException;

    const-string p1, "Invalid PEM structure, no data available"

    invoke-direct {p0, p1}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    throw p0

    :cond_10
    invoke-virtual {v4, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/io/BufferedReader;->readLine()Ljava/lang/String;

    move-result-object p1

    goto/16 :goto_1

    :cond_11
    new-instance p1, Ljava/io/IOException;

    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v0, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    invoke-direct {p1, p0}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    throw p1

    :cond_12
    add-int/lit8 v4, v4, 0x1

    invoke-virtual {p1, v6, v4}, Ljava/lang/String;->substring(II)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {p1, v4}, Ljava/lang/String;->substring(I)Ljava/lang/String;

    move-result-object p1

    const-string v3, ","

    invoke-virtual {p1, v3}, Ljava/lang/String;->split(Ljava/lang/String;)[Ljava/lang/String;

    move-result-object p1

    :goto_8
    array-length v3, p1

    if-ge v6, v3, :cond_13

    aget-object v3, p1, v6

    invoke-virtual {v3}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object v3

    aput-object v3, p1, v6

    add-int/lit8 v6, v6, 0x1

    goto :goto_8

    :cond_13
    const-string v3, "Proc-Type:"

    invoke-virtual {v3, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v3

    if-eqz v3, :cond_14

    iput-object p1, v0, Lcom/trilead/ssh2/crypto/PEMStructure;->b:[Ljava/lang/String;

    goto/16 :goto_0

    :cond_14
    const-string v3, "DEK-Info:"

    invoke-virtual {v3, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v2

    if-eqz v2, :cond_1

    iput-object p1, v0, Lcom/trilead/ssh2/crypto/PEMStructure;->a:[Ljava/lang/String;

    goto/16 :goto_0

    :cond_15
    new-instance p1, Ljava/io/IOException;

    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v0, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    invoke-direct {p1, p0}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    throw p1

    :cond_16
    new-instance p0, Ljava/io/IOException;

    const-string p1, "Invalid PEM structure, \'-----BEGIN...\' missing"

    invoke-direct {p0, p1}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    throw p0
.end method
