.class public final Ls/i;
.super Ljava/lang/Object;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Ls/i$b;,
        Ls/i$a;
    }
.end annotation


# static fields
.field public static final q:La/b;

.field public static final r:I


# instance fields
.field public final a:Ljava/util/Vector;

.field public b:Ljava/lang/Thread;

.field public final c:Ljava/lang/String;

.field public d:Ljava/lang/String;

.field public e:I

.field public f:Ljava/net/Socket;

.field public g:Lm/j;

.field public final h:Ljava/lang/Object;

.field public i:Z

.field public j:Ljava/lang/Throwable;

.field public k:Ls/g;

.field public l:Ls/a;

.field public m:Ljava/util/Vector;

.field public n:Ljava/lang/Thread;

.field public o:Ljava/util/Vector;

.field public p:Z


# direct methods
.method public static constructor <clinit>()V
    .locals 2

    const-class v0, Ls/i;

    .line 1
    new-instance v1, La/b;

    invoke-direct {v1, v0}, La/b;-><init>(Ljava/lang/Class;)V

    .line 2
    sput-object v1, Ls/i;->q:La/b;

    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v0}, Ljava/lang/Class;->getName()Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v0, ".maxPacketSize"

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const/high16 v1, 0x10000

    invoke-static {v0, v1}, Ljava/lang/Integer;->getInteger(Ljava/lang/String;I)Ljava/lang/Integer;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/Integer;->intValue()I

    move-result v0

    sput v0, Ls/i;->r:I

    return-void
.end method

.method public constructor <init>(Ljava/lang/String;ILjava/lang/String;)V
    .locals 2

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    new-instance v0, Ljava/util/Vector;

    invoke-direct {v0}, Ljava/util/Vector;-><init>()V

    iput-object v0, p0, Ls/i;->a:Ljava/util/Vector;

    const/4 v0, 0x0

    iput-object v0, p0, Ls/i;->b:Ljava/lang/Thread;

    new-instance v1, Ljava/lang/Object;

    invoke-direct {v1}, Ljava/lang/Object;-><init>()V

    iput-object v1, p0, Ls/i;->h:Ljava/lang/Object;

    const/4 v1, 0x0

    iput-boolean v1, p0, Ls/i;->i:Z

    iput-object v0, p0, Ls/i;->j:Ljava/lang/Throwable;

    new-instance v0, Ljava/util/Vector;

    invoke-direct {v0}, Ljava/util/Vector;-><init>()V

    iput-object v0, p0, Ls/i;->m:Ljava/util/Vector;

    new-instance v0, Ljava/util/Vector;

    invoke-direct {v0}, Ljava/util/Vector;-><init>()V

    iput-object v0, p0, Ls/i;->o:Ljava/util/Vector;

    iput-boolean v1, p0, Ls/i;->p:Z

    iput-object p1, p0, Ls/i;->d:Ljava/lang/String;

    iput p2, p0, Ls/i;->e:I

    iput-object p3, p0, Ls/i;->c:Ljava/lang/String;

    return-void
.end method

.method public static c(Ljava/lang/String;)Ljava/net/InetAddress;
    .locals 10

    const/4 v0, 0x0

    if-nez p0, :cond_0

    goto :goto_2

    :cond_0
    const/16 v1, 0x2e

    .line 1
    invoke-static {p0, v1}, La/b;->e(Ljava/lang/String;C)[Ljava/lang/String;

    move-result-object v1

    array-length v2, v1

    const/4 v3, 0x4

    if-eq v2, v3, :cond_1

    goto :goto_2

    :cond_1
    new-array v2, v3, [B

    const/4 v4, 0x0

    const/4 v5, 0x0

    :goto_0
    if-ge v5, v3, :cond_6

    aget-object v6, v1, v5

    invoke-virtual {v6}, Ljava/lang/String;->length()I

    move-result v6

    if-eqz v6, :cond_7

    aget-object v6, v1, v5

    invoke-virtual {v6}, Ljava/lang/String;->length()I

    move-result v6

    const/4 v7, 0x3

    if-le v6, v7, :cond_2

    goto :goto_2

    :cond_2
    const/4 v6, 0x0

    const/4 v7, 0x0

    :goto_1
    aget-object v8, v1, v5

    invoke-virtual {v8}, Ljava/lang/String;->length()I

    move-result v8

    if-ge v6, v8, :cond_4

    aget-object v8, v1, v5

    invoke-virtual {v8, v6}, Ljava/lang/String;->charAt(I)C

    move-result v8

    const/16 v9, 0x30

    if-lt v8, v9, :cond_7

    const/16 v9, 0x39

    if-le v8, v9, :cond_3

    goto :goto_2

    :cond_3
    mul-int/lit8 v7, v7, 0xa

    add-int/lit8 v8, v8, -0x30

    add-int/2addr v7, v8

    add-int/lit8 v6, v6, 0x1

    goto :goto_1

    :cond_4
    const/16 v6, 0xff

    if-le v7, v6, :cond_5

    goto :goto_2

    :cond_5
    int-to-byte v6, v7

    aput-byte v6, v2, v5

    add-int/lit8 v5, v5, 0x1

    goto :goto_0

    :cond_6
    invoke-static {p0, v2}, Ljava/net/InetAddress;->getByAddress(Ljava/lang/String;[B)Ljava/net/InetAddress;

    move-result-object v0

    :cond_7
    :goto_2
    if-eqz v0, :cond_8

    return-object v0

    .line 2
    :cond_8
    invoke-static {p0}, Ljava/net/InetAddress;->getByName(Ljava/lang/String;)Ljava/net/InetAddress;

    move-result-object p0

    return-object p0
.end method


# virtual methods
.method public final a(Lcom/trilead/ssh2/crypto/cipher/BlockCipher;Lcom/trilead/ssh2/crypto/digest/MAC;)V
    .locals 4

    iget-object v0, p0, Ls/i;->k:Ls/g;

    .line 1
    iget-object v1, v0, Ls/g;->c:Lcom/trilead/ssh2/crypto/cipher/CipherInputStream;

    .line 2
    iput-object p1, v1, Lcom/trilead/ssh2/crypto/cipher/CipherInputStream;->a:Lcom/trilead/ssh2/crypto/cipher/BlockCipher;

    invoke-interface {p1}, Lcom/trilead/ssh2/crypto/cipher/BlockCipher;->a()I

    move-result v2

    iput v2, v1, Lcom/trilead/ssh2/crypto/cipher/CipherInputStream;->e:I

    new-array v3, v2, [B

    iput-object v3, v1, Lcom/trilead/ssh2/crypto/cipher/CipherInputStream;->c:[B

    new-array v3, v2, [B

    iput-object v3, v1, Lcom/trilead/ssh2/crypto/cipher/CipherInputStream;->d:[B

    iput v2, v1, Lcom/trilead/ssh2/crypto/cipher/CipherInputStream;->f:I

    .line 3
    iput-object p2, v0, Ls/g;->i:Lcom/trilead/ssh2/crypto/digest/MAC;

    invoke-virtual {p2}, Lcom/trilead/ssh2/crypto/digest/MAC;->c()I

    move-result v1

    new-array v1, v1, [B

    iput-object v1, v0, Ls/g;->j:[B

    invoke-virtual {p2}, Lcom/trilead/ssh2/crypto/digest/MAC;->c()I

    move-result p2

    new-array p2, p2, [B

    iput-object p2, v0, Ls/g;->k:[B

    invoke-interface {p1}, Lcom/trilead/ssh2/crypto/cipher/BlockCipher;->a()I

    return-void
.end method

.method public final b(Ljava/lang/Throwable;Z)V
    .locals 5

    sget-object v0, Ls/i;->q:La/b;

    invoke-static {v0}, Ljava/util/Objects;->requireNonNull(Ljava/lang/Object;)Ljava/lang/Object;

    if-nez p2, :cond_1

    :try_start_0
    iget-object v0, p0, Ls/i;->g:Lm/j;

    if-eqz v0, :cond_0

    invoke-interface {v0}, Lm/j;->close()V

    :cond_0
    iget-object v0, p0, Ls/i;->f:Ljava/net/Socket;

    if-eqz v0, :cond_1

    invoke-virtual {v0}, Ljava/net/Socket;->close()V
    :try_end_0
    .catch Ljava/io/IOException; {:try_start_0 .. :try_end_0} :catch_0

    :catch_0
    :cond_1
    iget-object v0, p0, Ls/i;->h:Ljava/lang/Object;

    monitor-enter v0

    :try_start_1
    iget-object v1, p0, Ls/i;->j:Ljava/lang/Throwable;
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_1

    const/4 v2, 0x1

    if-nez v1, :cond_6

    if-ne p2, v2, :cond_4

    const/16 p2, 0xb

    :try_start_2
    invoke-virtual {p1}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    move-result-object v1

    const-string v3, ""

    .line 1
    new-instance v4, Lq/b;

    invoke-direct {v4}, Lq/b;-><init>()V

    invoke-virtual {v4, v2}, Lq/b;->d(I)V

    invoke-virtual {v4, p2}, Lq/b;->j(I)V

    invoke-virtual {v4, v1}, Lq/b;->h(Ljava/lang/String;)V

    invoke-virtual {v4, v3}, Lq/b;->h(Ljava/lang/String;)V

    invoke-virtual {v4}, Lq/b;->a()[B

    move-result-object p2

    .line 2
    iget-object v1, p0, Ls/i;->k:Ls/g;

    if-eqz v1, :cond_2

    invoke-virtual {v1, p2}, Ls/g;->a([B)V
    :try_end_2
    .catch Ljava/io/IOException; {:try_start_2 .. :try_end_2} :catch_1
    .catchall {:try_start_2 .. :try_end_2} :catchall_1

    :catch_1
    :cond_2
    :try_start_3
    iget-object p2, p0, Ls/i;->g:Lm/j;

    if-eqz p2, :cond_3

    invoke-interface {p2}, Lm/j;->close()V

    :cond_3
    iget-object p2, p0, Ls/i;->f:Ljava/net/Socket;

    if-eqz p2, :cond_4

    invoke-virtual {p2}, Ljava/net/Socket;->close()V
    :try_end_3
    .catch Ljava/io/IOException; {:try_start_3 .. :try_end_3} :catch_2
    .catchall {:try_start_3 .. :try_end_3} :catchall_1

    goto :goto_0

    :catch_2
    nop

    :cond_4
    :goto_0
    if-nez p1, :cond_5

    :try_start_4
    new-instance p1, Ljava/lang/Exception;

    const-string p2, "Unknown cause"

    invoke-direct {p1, p2}, Ljava/lang/Exception;-><init>(Ljava/lang/String;)V

    :cond_5
    iput-object p1, p0, Ls/i;->j:Ljava/lang/Throwable;

    :cond_6
    iget-object p1, p0, Ls/i;->h:Ljava/lang/Object;

    invoke-virtual {p1}, Ljava/lang/Object;->notifyAll()V

    monitor-exit v0
    :try_end_4
    .catchall {:try_start_4 .. :try_end_4} :catchall_1

    monitor-enter p0

    :try_start_5
    iget-boolean p1, p0, Ls/i;->p:Z

    if-nez p1, :cond_7

    iput-boolean v2, p0, Ls/i;->p:Z

    iget-object p1, p0, Ls/i;->o:Ljava/util/Vector;

    invoke-virtual {p1}, Ljava/util/Vector;->clone()Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Ljava/util/Vector;

    goto :goto_1

    :cond_7
    const/4 p1, 0x0

    :goto_1
    monitor-exit p0
    :try_end_5
    .catchall {:try_start_5 .. :try_end_5} :catchall_0

    if-eqz p1, :cond_8

    const/4 p2, 0x0

    :goto_2
    invoke-virtual {p1}, Ljava/util/Vector;->size()I

    move-result v0

    if-ge p2, v0, :cond_8

    :try_start_6
    invoke-virtual {p1, p2}, Ljava/util/Vector;->elementAt(I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lm/d;

    invoke-interface {v0}, Lm/d;->a()V
    :try_end_6
    .catch Ljava/lang/Exception; {:try_start_6 .. :try_end_6} :catch_3

    :catch_3
    add-int/lit8 p2, p2, 0x1

    goto :goto_2

    :cond_8
    return-void

    :catchall_0
    move-exception p1

    :try_start_7
    monitor-exit p0
    :try_end_7
    .catchall {:try_start_7 .. :try_end_7} :catchall_0

    throw p1

    :catchall_1
    move-exception p1

    :try_start_8
    monitor-exit v0
    :try_end_8
    .catchall {:try_start_8 .. :try_end_8} :catchall_1

    throw p1
.end method

.method public final d()V
    .locals 2

    iget-object v0, p0, Ls/i;->j:Ljava/lang/Throwable;

    if-nez v0, :cond_0

    return-void

    :cond_0
    new-instance v0, Ljava/io/IOException;

    const-string v1, "Sorry, this connection is closed."

    invoke-direct {v0, v1}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    iget-object v1, p0, Ls/i;->j:Ljava/lang/Throwable;

    invoke-virtual {v0, v1}, Ljava/lang/Throwable;->initCause(Ljava/lang/Throwable;)Ljava/lang/Throwable;

    move-result-object v0

    check-cast v0, Ljava/io/IOException;

    throw v0
.end method

.method public final e()Ll/e;
    .locals 5

    iget-object v0, p0, Ls/i;->l:Ls/a;

    iget-object v1, v0, Ls/a;->f:Ljava/lang/Object;

    monitor-enter v1

    :goto_0
    :try_start_0
    iget-object v2, v0, Ls/a;->g:Ll/e;

    if-eqz v2, :cond_0

    iget v3, v2, Ll/e;->a:I

    const/4 v4, 0x1

    if-lt v3, v4, :cond_0

    monitor-exit v1

    return-object v2

    :cond_0
    iget-boolean v2, v0, Ls/a;->h:Z
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    if-nez v2, :cond_1

    :try_start_1
    iget-object v2, v0, Ls/a;->f:Ljava/lang/Object;

    invoke-virtual {v2}, Ljava/lang/Object;->wait()V
    :try_end_1
    .catch Ljava/lang/InterruptedException; {:try_start_1 .. :try_end_1} :catch_0
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    goto :goto_0

    :catch_0
    :try_start_2
    new-instance v0, Ljava/io/InterruptedIOException;

    invoke-direct {v0}, Ljava/io/InterruptedIOException;-><init>()V

    throw v0

    :cond_1
    new-instance v2, Ljava/io/IOException;

    const-string v3, "Key exchange was not finished, connection is closed."

    iget-object v0, v0, Ls/a;->j:Ls/i;

    invoke-virtual {v0}, Ls/i;->f()Ljava/lang/Throwable;

    move-result-object v0

    invoke-direct {v2, v3, v0}, Ljava/io/IOException;-><init>(Ljava/lang/String;Ljava/lang/Throwable;)V

    throw v2

    :catchall_0
    move-exception v0

    monitor-exit v1
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_0

    throw v0
.end method

.method public final f()Ljava/lang/Throwable;
    .locals 2

    iget-object v0, p0, Ls/i;->h:Ljava/lang/Object;

    monitor-enter v0

    :try_start_0
    iget-object v1, p0, Ls/i;->j:Ljava/lang/Throwable;

    monitor-exit v0

    return-object v1

    :catchall_0
    move-exception v1

    monitor-exit v0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    throw v1
.end method

.method public final g(Lcom/trilead/ssh2/crypto/CryptoWishList;Lm/k;La/b;Ljava/security/SecureRandom;Lm/j;)V
    .locals 8

    iput-object p5, p0, Ls/i;->g:Lm/j;

    if-nez p5, :cond_1

    .line 1
    iget-object p5, p0, Ls/i;->d:Ljava/lang/String;

    iget v0, p0, Ls/i;->e:I

    .line 2
    new-instance v1, Ljava/net/Socket;

    invoke-direct {v1}, Ljava/net/Socket;-><init>()V

    iget-object v2, p0, Ls/i;->c:Ljava/lang/String;

    const/4 v3, 0x0

    if-eqz v2, :cond_0

    invoke-static {v2}, Ls/i;->c(Ljava/lang/String;)Ljava/net/InetAddress;

    move-result-object v2

    new-instance v4, Ljava/net/InetSocketAddress;

    invoke-direct {v4, v2, v3}, Ljava/net/InetSocketAddress;-><init>(Ljava/net/InetAddress;I)V

    invoke-virtual {v1, v4}, Ljava/net/Socket;->bind(Ljava/net/SocketAddress;)V

    :cond_0
    invoke-static {p5}, Ls/i;->c(Ljava/lang/String;)Ljava/net/InetAddress;

    move-result-object p5

    new-instance v2, Ljava/net/InetSocketAddress;

    invoke-direct {v2, p5, v0}, Ljava/net/InetSocketAddress;-><init>(Ljava/net/InetAddress;I)V

    const/16 p5, 0x2710

    invoke-virtual {v1, v2, p5}, Ljava/net/Socket;->connect(Ljava/net/SocketAddress;I)V

    invoke-virtual {v1, v3}, Ljava/net/Socket;->setSoTimeout(I)V

    .line 3
    iput-object v1, p0, Ls/i;->f:Ljava/net/Socket;

    goto :goto_0

    :cond_1
    iget-object v0, p0, Ls/i;->d:Ljava/lang/String;

    iget v1, p0, Ls/i;->e:I

    invoke-interface {p5, v0, v1}, Lm/j;->a(Ljava/lang/String;I)Ljava/net/Socket;

    move-result-object p5

    iput-object p5, p0, Ls/i;->f:Ljava/net/Socket;

    .line 4
    :goto_0
    new-instance v2, Lq/a;

    iget-object p5, p0, Ls/i;->f:Ljava/net/Socket;

    invoke-virtual {p5}, Ljava/net/Socket;->getInputStream()Ljava/io/InputStream;

    move-result-object p5

    iget-object v0, p0, Ls/i;->f:Ljava/net/Socket;

    invoke-virtual {v0}, Ljava/net/Socket;->getOutputStream()Ljava/io/OutputStream;

    move-result-object v0

    invoke-direct {v2, p5, v0}, Lq/a;-><init>(Ljava/io/InputStream;Ljava/io/OutputStream;)V

    new-instance p5, Ls/g;

    iget-object v0, p0, Ls/i;->f:Ljava/net/Socket;

    invoke-virtual {v0}, Ljava/net/Socket;->getInputStream()Ljava/io/InputStream;

    move-result-object v0

    iget-object v1, p0, Ls/i;->f:Ljava/net/Socket;

    invoke-virtual {v1}, Ljava/net/Socket;->getOutputStream()Ljava/io/OutputStream;

    move-result-object v1

    invoke-direct {p5, v0, v1, p4}, Ls/g;-><init>(Ljava/io/InputStream;Ljava/io/OutputStream;Ljava/security/SecureRandom;)V

    iput-object p5, p0, Ls/i;->k:Ls/g;

    new-instance p5, Ls/a;

    iget-object v4, p0, Ls/i;->d:Ljava/lang/String;

    iget v5, p0, Ls/i;->e:I

    move-object v0, p5

    move-object v1, p0

    move-object v3, p1

    move-object v6, p2

    move-object v7, p4

    invoke-direct/range {v0 .. v7}, Ls/a;-><init>(Ls/i;Lq/a;Lcom/trilead/ssh2/crypto/CryptoWishList;Ljava/lang/String;ILm/k;Ljava/security/SecureRandom;)V

    iput-object p5, p0, Ls/i;->l:Ls/a;

    .line 5
    monitor-enter p5

    :try_start_0
    iput-object p1, p5, Ls/a;->k:Lcom/trilead/ssh2/crypto/CryptoWishList;

    iput-object p3, p5, Ls/a;->l:La/b;

    iget-object p2, p5, Ls/a;->a:Ls/c;

    if-nez p2, :cond_2

    new-instance p2, Ls/c;

    invoke-direct {p2}, Ls/c;-><init>()V

    iput-object p2, p5, Ls/a;->a:Ls/c;

    iput-object p3, p2, Ls/c;->j:La/b;

    new-instance p2, Lm/e;

    invoke-direct {p2, p1, p4}, Lm/e;-><init>(Lcom/trilead/ssh2/crypto/CryptoWishList;Ljava/security/SecureRandom;)V

    iget-object p1, p5, Ls/a;->a:Ls/c;

    iput-object p2, p1, Ls/c;->a:Lm/e;

    invoke-virtual {p2}, Lm/e;->b()[B

    move-result-object p1

    invoke-virtual {p0, p1}, Ls/i;->l([B)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    :cond_2
    monitor-exit p5

    .line 6
    new-instance p1, Ljava/lang/Thread;

    new-instance p2, Ls/h;

    invoke-direct {p2, p0}, Ls/h;-><init>(Ls/i;)V

    invoke-direct {p1, p2}, Ljava/lang/Thread;-><init>(Ljava/lang/Runnable;)V

    iput-object p1, p0, Ls/i;->n:Ljava/lang/Thread;

    const/4 p2, 0x1

    invoke-virtual {p1, p2}, Ljava/lang/Thread;->setDaemon(Z)V

    iget-object p1, p0, Ls/i;->n:Ljava/lang/Thread;

    invoke-virtual {p1}, Ljava/lang/Thread;->start()V

    return-void

    :catchall_0
    move-exception p1

    .line 7
    monitor-exit p5

    throw p1
.end method

.method public final h()V
    .locals 15

    sget v0, Ls/i;->r:I

    new-array v1, v0, [B

    :goto_0
    iget-object v2, p0, Ls/i;->k:Ls/g;

    .line 1
    invoke-static {v2}, Ljava/util/Objects;->requireNonNull(Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v3, 0x5

    iget-object v4, v2, Ls/g;->c:Lcom/trilead/ssh2/crypto/cipher/CipherInputStream;

    iget-object v5, v2, Ls/g;->o:[B

    invoke-virtual {v4, v5, v3}, Lcom/trilead/ssh2/crypto/cipher/CipherInputStream;->b([BI)I

    iget-object v4, v2, Ls/g;->o:[B

    const/4 v5, 0x0

    aget-byte v6, v4, v5

    const/16 v7, 0xff

    and-int/2addr v6, v7

    shl-int/lit8 v6, v6, 0x18

    const/4 v8, 0x1

    aget-byte v9, v4, v8

    and-int/2addr v9, v7

    shl-int/lit8 v9, v9, 0x10

    or-int/2addr v6, v9

    const/4 v9, 0x2

    aget-byte v9, v4, v9

    and-int/2addr v9, v7

    shl-int/lit8 v9, v9, 0x8

    or-int/2addr v6, v9

    const/4 v9, 0x3

    aget-byte v9, v4, v9

    and-int/2addr v9, v7

    or-int/2addr v6, v9

    const/4 v9, 0x4

    aget-byte v4, v4, v9

    and-int/2addr v4, v7

    sget v9, Ls/i;->r:I

    if-gt v6, v9, :cond_13

    const/16 v9, 0xc

    if-lt v6, v9, :cond_13

    sub-int/2addr v6, v4

    sub-int/2addr v6, v8

    if-ltz v6, :cond_12

    if-ge v6, v0, :cond_11

    iget-object v9, v2, Ls/g;->c:Lcom/trilead/ssh2/crypto/cipher/CipherInputStream;

    invoke-virtual {v9, v1, v6}, Lcom/trilead/ssh2/crypto/cipher/CipherInputStream;->b([BI)I

    iget-object v9, v2, Ls/g;->c:Lcom/trilead/ssh2/crypto/cipher/CipherInputStream;

    iget-object v10, v2, Ls/g;->n:[B

    invoke-virtual {v9, v10, v4}, Lcom/trilead/ssh2/crypto/cipher/CipherInputStream;->b([BI)I

    iget-object v9, v2, Ls/g;->i:Lcom/trilead/ssh2/crypto/digest/MAC;

    if-eqz v9, :cond_4

    iget-object v9, v2, Ls/g;->c:Lcom/trilead/ssh2/crypto/cipher/CipherInputStream;

    iget-object v10, v2, Ls/g;->j:[B

    array-length v11, v10

    .line 2
    iget v12, v9, Lcom/trilead/ssh2/crypto/cipher/CipherInputStream;->f:I

    iget v13, v9, Lcom/trilead/ssh2/crypto/cipher/CipherInputStream;->e:I

    if-ne v12, v13, :cond_3

    const/4 v12, 0x0

    :goto_1
    if-ge v12, v11, :cond_1

    add-int v13, v5, v12

    sub-int v14, v11, v12

    invoke-virtual {v9, v10, v13, v14}, Lcom/trilead/ssh2/crypto/cipher/CipherInputStream;->a([BII)I

    move-result v13

    if-ltz v13, :cond_0

    add-int/2addr v12, v13

    goto :goto_1

    :cond_0
    new-instance v0, Ljava/io/IOException;

    const-string v1, "Cannot fill buffer, EOF reached."

    invoke-direct {v0, v1}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    throw v0

    .line 3
    :cond_1
    iget-object v9, v2, Ls/g;->i:Lcom/trilead/ssh2/crypto/digest/MAC;

    iget v10, v2, Ls/g;->b:I

    invoke-virtual {v9, v10}, Lcom/trilead/ssh2/crypto/digest/MAC;->b(I)V

    iget-object v9, v2, Ls/g;->i:Lcom/trilead/ssh2/crypto/digest/MAC;

    iget-object v10, v2, Ls/g;->o:[B

    invoke-virtual {v9, v10, v3}, Lcom/trilead/ssh2/crypto/digest/MAC;->d([BI)V

    iget-object v3, v2, Ls/g;->i:Lcom/trilead/ssh2/crypto/digest/MAC;

    invoke-virtual {v3, v1, v6}, Lcom/trilead/ssh2/crypto/digest/MAC;->d([BI)V

    iget-object v3, v2, Ls/g;->i:Lcom/trilead/ssh2/crypto/digest/MAC;

    iget-object v9, v2, Ls/g;->n:[B

    invoke-virtual {v3, v9, v4}, Lcom/trilead/ssh2/crypto/digest/MAC;->d([BI)V

    iget-object v3, v2, Ls/g;->i:Lcom/trilead/ssh2/crypto/digest/MAC;

    iget-object v4, v2, Ls/g;->k:[B

    invoke-virtual {v3, v4}, Lcom/trilead/ssh2/crypto/digest/MAC;->a([B)V

    const/4 v3, 0x0

    :goto_2
    iget-object v4, v2, Ls/g;->j:[B

    array-length v9, v4

    if-ge v3, v9, :cond_4

    aget-byte v4, v4, v3

    iget-object v9, v2, Ls/g;->k:[B

    aget-byte v9, v9, v3

    if-ne v4, v9, :cond_2

    add-int/lit8 v3, v3, 0x1

    goto :goto_2

    :cond_2
    new-instance v0, Ljava/io/IOException;

    const-string v1, "Remote sent corrupt MAC."

    invoke-direct {v0, v1}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    throw v0

    .line 4
    :cond_3
    new-instance v0, Ljava/io/IOException;

    const-string v1, "Cannot read plain since crypto buffer is not aligned."

    invoke-direct {v0, v1}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    throw v0

    .line 5
    :cond_4
    iget v3, v2, Ls/g;->b:I

    add-int/2addr v3, v8

    iput v3, v2, Ls/g;->b:I

    sget-object v3, Ls/g;->r:La/b;

    invoke-static {v3}, Ljava/util/Objects;->requireNonNull(Ljava/lang/Object;)Ljava/lang/Object;

    iget-object v2, v2, Ls/g;->q:Lc0/h$a;

    .line 6
    monitor-enter v2

    :try_start_0
    invoke-virtual {v2}, Lc0/h$a;->a()V

    .line 7
    iget-object v3, v2, Lc0/h$a;->a:Ljava/util/ArrayList;

    invoke-virtual {v3}, Ljava/util/ArrayList;->size()I

    move-result v4

    add-int/lit8 v4, v4, -0x1

    invoke-virtual {v3, v4}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Lc0/h$a$a;

    invoke-static {v3}, Ljava/util/Objects;->requireNonNull(Ljava/lang/Object;)Ljava/lang/Object;

    iget-object v3, v2, Lc0/h$a;->c:Ljava/util/ArrayList;

    invoke-virtual {v3}, Ljava/util/ArrayList;->size()I

    move-result v4

    add-int/lit8 v4, v4, -0x1

    invoke-virtual {v3, v4}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Lc0/h$a$a;

    invoke-static {v3}, Ljava/util/Objects;->requireNonNull(Ljava/lang/Object;)Ljava/lang/Object;
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 8
    monitor-exit v2

    .line 9
    aget-byte v2, v1, v5

    and-int/2addr v2, v7

    const/4 v3, 0x2

    if-ne v2, v3, :cond_5

    goto/16 :goto_0

    :cond_5
    const/4 v3, 0x4

    if-ne v2, v3, :cond_6

    sget-object v2, Ls/i;->q:La/b;

    invoke-static {v2}, Ljava/util/Objects;->requireNonNull(Ljava/lang/Object;)Ljava/lang/Object;

    goto/16 :goto_0

    :cond_6
    const/4 v3, 0x3

    if-eq v2, v3, :cond_10

    if-ne v2, v8, :cond_a

    new-instance v0, Lq/c;

    invoke-direct {v0, v1, v6}, Lq/c;-><init>([BI)V

    invoke-virtual {v0}, Lq/c;->b()I

    invoke-virtual {v0}, Lq/c;->i()I

    move-result v1

    new-instance v2, Ljava/lang/StringBuffer;

    invoke-direct {v2}, Ljava/lang/StringBuffer;-><init>()V

    const-string v3, "UTF-8"

    invoke-virtual {v0, v3}, Lq/c;->h(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v2, v0}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    invoke-virtual {v2}, Ljava/lang/StringBuffer;->length()I

    move-result v0

    if-le v0, v7, :cond_7

    invoke-virtual {v2, v7}, Ljava/lang/StringBuffer;->setLength(I)V

    const/16 v0, 0xfe

    const/16 v3, 0x2e

    invoke-virtual {v2, v0, v3}, Ljava/lang/StringBuffer;->setCharAt(IC)V

    const/16 v0, 0xfd

    invoke-virtual {v2, v0, v3}, Ljava/lang/StringBuffer;->setCharAt(IC)V

    const/16 v0, 0xfc

    invoke-virtual {v2, v0, v3}, Ljava/lang/StringBuffer;->setCharAt(IC)V

    :cond_7
    :goto_3
    invoke-virtual {v2}, Ljava/lang/StringBuffer;->length()I

    move-result v0

    if-ge v5, v0, :cond_9

    invoke-virtual {v2, v5}, Ljava/lang/StringBuffer;->charAt(I)C

    move-result v0

    const/16 v3, 0x20

    if-lt v0, v3, :cond_8

    const/16 v3, 0x7e

    if-gt v0, v3, :cond_8

    goto :goto_4

    :cond_8
    const v0, 0xfffd

    invoke-virtual {v2, v5, v0}, Ljava/lang/StringBuffer;->setCharAt(IC)V

    :goto_4
    add-int/lit8 v5, v5, 0x1

    goto :goto_3

    :cond_9
    new-instance v0, Ljava/io/IOException;

    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    const-string v4, "Peer sent DISCONNECT message (reason code "

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v3, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string v1, "): "

    invoke-virtual {v3, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v3, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-direct {v0, v1}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    throw v0

    :cond_a
    const/16 v3, 0x14

    if-eq v2, v3, :cond_f

    const/16 v3, 0x15

    if-eq v2, v3, :cond_f

    const/16 v3, 0x1e

    if-lt v2, v3, :cond_b

    const/16 v3, 0x31

    if-gt v2, v3, :cond_b

    goto :goto_7

    :cond_b
    const/4 v3, 0x0

    :goto_5
    iget-object v4, p0, Ls/i;->m:Ljava/util/Vector;

    invoke-virtual {v4}, Ljava/util/Vector;->size()I

    move-result v4

    if-ge v5, v4, :cond_d

    iget-object v4, p0, Ls/i;->m:Ljava/util/Vector;

    invoke-virtual {v4, v5}, Ljava/util/Vector;->elementAt(I)Ljava/lang/Object;

    move-result-object v4

    check-cast v4, Ls/i$b;

    iget v7, v4, Ls/i$b;->b:I

    if-gt v7, v2, :cond_c

    iget v7, v4, Ls/i$b;->c:I

    if-gt v2, v7, :cond_c

    iget-object v3, v4, Ls/i$b;->a:Ls/d;

    goto :goto_6

    :cond_c
    add-int/lit8 v5, v5, 0x1

    goto :goto_5

    :cond_d
    :goto_6
    if-eqz v3, :cond_e

    invoke-interface {v3, v1, v6}, Ls/d;->b([BI)V

    goto/16 :goto_0

    :cond_e
    new-instance v0, Ljava/io/IOException;

    const-string v1, "Unexpected SSH message (type "

    const-string v3, ")"

    .line 10
    invoke-static {v1, v2, v3}, Lcom/trilead/ssh2/crypto/digest/a;->d(Ljava/lang/String;ILjava/lang/String;)Ljava/lang/String;

    move-result-object v1

    .line 11
    invoke-direct {v0, v1}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    throw v0

    :cond_f
    :goto_7
    iget-object v2, p0, Ls/i;->l:Ls/a;

    invoke-virtual {v2, v1, v6}, Ls/a;->b([BI)V

    goto/16 :goto_0

    :cond_10
    new-instance v0, Ljava/io/IOException;

    const-string v1, "Peer sent UNIMPLEMENTED message, that should not happen."

    invoke-direct {v0, v1}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    throw v0

    :catchall_0
    move-exception v0

    .line 12
    monitor-exit v2

    throw v0

    .line 13
    :cond_11
    new-instance v1, Ljava/io/IOException;

    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const-string v3, "Receive buffer too small ("

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string v0, ", need "

    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2, v6}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string v0, ")"

    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-direct {v1, v0}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    throw v1

    :cond_12
    new-instance v0, Ljava/io/IOException;

    const-string v1, "Illegal padding_length in packet from remote ("

    const-string v2, ")"

    .line 14
    invoke-static {v1, v4, v2}, Lcom/trilead/ssh2/crypto/digest/a;->d(Ljava/lang/String;ILjava/lang/String;)Ljava/lang/String;

    move-result-object v1

    .line 15
    invoke-direct {v0, v1}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    throw v0

    :cond_13
    new-instance v0, Ljava/io/IOException;

    const-string v1, "Illegal packet size! ("

    const-string v2, ")"

    .line 16
    invoke-static {v1, v6, v2}, Lcom/trilead/ssh2/crypto/digest/a;->d(Ljava/lang/String;ILjava/lang/String;)Ljava/lang/String;

    move-result-object v1

    .line 17
    invoke-direct {v0, v1}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    throw v0
.end method

.method public final i(Ls/d;II)V
    .locals 1

    new-instance v0, Ls/i$b;

    invoke-direct {v0}, Ls/i$b;-><init>()V

    iput-object p1, v0, Ls/i$b;->a:Ls/d;

    iput p2, v0, Ls/i$b;->b:I

    iput p3, v0, Ls/i$b;->c:I

    iget-object p1, p0, Ls/i;->m:Ljava/util/Vector;

    monitor-enter p1

    :try_start_0
    iget-object p2, p0, Ls/i;->m:Ljava/util/Vector;

    invoke-virtual {p2, v0}, Ljava/util/Vector;->addElement(Ljava/lang/Object;)V

    monitor-exit p1

    return-void

    :catchall_0
    move-exception p2

    monitor-exit p1
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    throw p2
.end method

.method public final j(Ls/d;)V
    .locals 4

    iget-object v0, p0, Ls/i;->m:Ljava/util/Vector;

    monitor-enter v0

    const/4 v1, 0x0

    :goto_0
    :try_start_0
    iget-object v2, p0, Ls/i;->m:Ljava/util/Vector;

    invoke-virtual {v2}, Ljava/util/Vector;->size()I

    move-result v2

    if-ge v1, v2, :cond_1

    iget-object v2, p0, Ls/i;->m:Ljava/util/Vector;

    invoke-virtual {v2, v1}, Ljava/util/Vector;->elementAt(I)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Ls/i$b;

    iget-object v3, v2, Ls/i$b;->a:Ls/d;

    if-ne v3, p1, :cond_0

    iget v3, v2, Ls/i$b;->b:I

    if-nez v3, :cond_0

    iget v2, v2, Ls/i$b;->c:I

    const/16 v3, 0xff

    if-ne v2, v3, :cond_0

    iget-object p1, p0, Ls/i;->m:Ljava/util/Vector;

    invoke-virtual {p1, v1}, Ljava/util/Vector;->removeElementAt(I)V

    goto :goto_1

    :cond_0
    add-int/lit8 v1, v1, 0x1

    goto :goto_0

    :cond_1
    :goto_1
    monitor-exit v0

    return-void

    :catchall_0
    move-exception p1

    monitor-exit v0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    throw p1
.end method

.method public final k([B)V
    .locals 2

    iget-object v0, p0, Ls/i;->a:Ljava/util/Vector;

    monitor-enter v0

    :try_start_0
    iget-object v1, p0, Ls/i;->a:Ljava/util/Vector;

    invoke-virtual {v1, p1}, Ljava/util/Vector;->addElement(Ljava/lang/Object;)V

    iget-object p1, p0, Ls/i;->a:Ljava/util/Vector;

    invoke-virtual {p1}, Ljava/util/Vector;->size()I

    move-result p1

    const/16 v1, 0x64

    if-gt p1, v1, :cond_1

    iget-object p1, p0, Ls/i;->b:Ljava/lang/Thread;

    if-nez p1, :cond_0

    new-instance p1, Ls/i$a;

    invoke-direct {p1, p0}, Ls/i$a;-><init>(Ls/i;)V

    iput-object p1, p0, Ls/i;->b:Ljava/lang/Thread;

    const/4 v1, 0x1

    invoke-virtual {p1, v1}, Ljava/lang/Thread;->setDaemon(Z)V

    iget-object p1, p0, Ls/i;->b:Ljava/lang/Thread;

    invoke-virtual {p1}, Ljava/lang/Thread;->start()V

    :cond_0
    monitor-exit v0

    return-void

    :cond_1
    new-instance p1, Ljava/io/IOException;

    const-string v1, "Error: the peer is not consuming our asynchronous replies."

    invoke-direct {p1, v1}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    throw p1

    :catchall_0
    move-exception p1

    monitor-exit v0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    throw p1
.end method

.method public final l([B)V
    .locals 2

    iget-object v0, p0, Ls/i;->h:Ljava/lang/Object;

    monitor-enter v0

    :try_start_0
    invoke-virtual {p0}, Ls/i;->d()V

    const/4 v1, 0x1

    iput-boolean v1, p0, Ls/i;->i:Z
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    :try_start_1
    iget-object v1, p0, Ls/i;->k:Ls/g;

    invoke-virtual {v1, p1}, Ls/g;->a([B)V
    :try_end_1
    .catch Ljava/io/IOException; {:try_start_1 .. :try_end_1} :catch_0
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    :try_start_2
    monitor-exit v0

    return-void

    :catch_0
    move-exception p1

    const/4 v1, 0x0

    invoke-virtual {p0, p1, v1}, Ls/i;->b(Ljava/lang/Throwable;Z)V

    throw p1

    :catchall_0
    move-exception p1

    monitor-exit v0
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_0

    throw p1
.end method

.method public final m([B)V
    .locals 2

    invoke-static {}, Ljava/lang/Thread;->currentThread()Ljava/lang/Thread;

    move-result-object v0

    iget-object v1, p0, Ls/i;->n:Ljava/lang/Thread;

    if-eq v0, v1, :cond_1

    iget-object v0, p0, Ls/i;->h:Ljava/lang/Object;

    monitor-enter v0

    :goto_0
    :try_start_0
    invoke-virtual {p0}, Ls/i;->d()V

    iget-boolean v1, p0, Ls/i;->i:Z
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    if-nez v1, :cond_0

    :try_start_1
    iget-object v1, p0, Ls/i;->k:Ls/g;

    invoke-virtual {v1, p1}, Ls/g;->a([B)V
    :try_end_1
    .catch Ljava/io/IOException; {:try_start_1 .. :try_end_1} :catch_0
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    :try_start_2
    monitor-exit v0

    return-void

    :catch_0
    move-exception p1

    const/4 v1, 0x0

    invoke-virtual {p0, p1, v1}, Ls/i;->b(Ljava/lang/Throwable;Z)V

    throw p1
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_0

    :cond_0
    :try_start_3
    iget-object v1, p0, Ls/i;->h:Ljava/lang/Object;

    invoke-virtual {v1}, Ljava/lang/Object;->wait()V
    :try_end_3
    .catch Ljava/lang/InterruptedException; {:try_start_3 .. :try_end_3} :catch_1
    .catchall {:try_start_3 .. :try_end_3} :catchall_0

    goto :goto_0

    :catch_1
    :try_start_4
    new-instance p1, Ljava/io/InterruptedIOException;

    invoke-direct {p1}, Ljava/io/InterruptedIOException;-><init>()V

    throw p1

    :catchall_0
    move-exception p1

    monitor-exit v0
    :try_end_4
    .catchall {:try_start_4 .. :try_end_4} :catchall_0

    throw p1

    :cond_1
    new-instance p1, Ljava/io/IOException;

    const-string v0, "Assertion error: sendMessage may never be invoked by the receiver thread!"

    invoke-direct {p1, v0}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    throw p1
.end method
