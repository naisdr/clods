.class public final Lxyz/chz/injector/HttpService$a;
.super Le0/a;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lxyz/chz/injector/HttpService;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1
    name = null
.end annotation


# instance fields
.field public final synthetic a:Lxyz/chz/injector/HttpService;


# direct methods
.method public constructor <init>(Lxyz/chz/injector/HttpService;)V
    .locals 0

    iput-object p1, p0, Lxyz/chz/injector/HttpService$a;->a:Lxyz/chz/injector/HttpService;

    invoke-direct {p0}, Le0/a;-><init>()V

    return-void
.end method
