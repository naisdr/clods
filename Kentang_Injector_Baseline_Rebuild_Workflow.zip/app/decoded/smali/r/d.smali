.class public abstract Lr/d;
.super Ljava/lang/Object;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "<U::",
        "Ljava/security/PublicKey;",
        "R::",
        "Ljava/security/PrivateKey;",
        ">",
        "Ljava/lang/Object;"
    }
.end annotation


# instance fields
.field public final a:Ljava/lang/String;

.field public final b:Ljava/lang/String;

.field public final c:Ljava/lang/Class;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/lang/Class<",
            "TR;>;"
        }
    .end annotation
.end field

.field public final d:Ljava/security/Provider;


# direct methods
.method public constructor <init>(Ljava/lang/Class;Ljava/security/Provider;)V
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            "Ljava/lang/Class<",
            "TR;>;",
            "Ljava/security/Provider;",
            ")V"
        }
    .end annotation

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const-string v0, "NoneWithEdDSA"

    iput-object v0, p0, Lr/d;->a:Ljava/lang/String;

    const-string v0, "ssh-ed25519"

    iput-object v0, p0, Lr/d;->b:Ljava/lang/String;

    iput-object p1, p0, Lr/d;->c:Ljava/lang/Class;

    iput-object p2, p0, Lr/d;->d:Ljava/security/Provider;

    return-void
.end method

.method public constructor <init>(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Class;)V
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            "Ljava/lang/Class<",
            "TR;>;)V"
        }
    .end annotation

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lr/d;->a:Ljava/lang/String;

    iput-object p2, p0, Lr/d;->b:Ljava/lang/String;

    iput-object p3, p0, Lr/d;->c:Ljava/lang/Class;

    const/4 p1, 0x0

    iput-object p1, p0, Lr/d;->d:Ljava/security/Provider;

    return-void
.end method


# virtual methods
.method public abstract a([B)Ljava/security/PublicKey;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "([B)TU;"
        }
    .end annotation
.end method

.method public abstract b([B)[B
.end method

.method public abstract c(Ljava/security/PublicKey;)[B
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(TU;)[B"
        }
    .end annotation
.end method

.method public abstract d([B)[B
.end method

.method public abstract e()Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/List<",
            "Lcom/trilead/ssh2/crypto/CertificateDecoder;",
            ">;"
        }
    .end annotation
.end method

.method public f(Ljava/security/PrivateKey;)Z
    .locals 1

    iget-object v0, p0, Lr/d;->c:Ljava/lang/Class;

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-result-object p1

    invoke-virtual {v0, p1}, Ljava/lang/Class;->isAssignableFrom(Ljava/lang/Class;)Z

    move-result p1

    return p1
.end method
