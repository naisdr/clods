.class public interface abstract Lx/b;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lx/a;


# virtual methods
.method public abstract h()I
.end method
