.class public interface abstract Lcom/trilead/ssh2/crypto/digest/Digest;
.super Ljava/lang/Object;
.source "SourceFile"


# virtual methods
.method public abstract a()V
.end method

.method public abstract b([B)V
.end method

.method public abstract c()I
.end method

.method public abstract d([BI)V
.end method

.method public abstract e([B)V
.end method

.method public abstract f(B)V
.end method

.method public abstract g([B)V
.end method
