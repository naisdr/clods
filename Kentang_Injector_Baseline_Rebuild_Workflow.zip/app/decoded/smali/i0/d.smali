.class public final Li0/d;
.super Ljava/lang/Object;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Li0/d$c;
    }
.end annotation


# static fields
.field public static i:Li0/d;


# instance fields
.field public final a:Li0/d$c;

.field public b:Li0/i$a;

.field public c:Ljava/util/concurrent/atomic/AtomicReference;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/concurrent/atomic/AtomicReference<",
            "Landroid/os/ParcelFileDescriptor;",
            ">;"
        }
    .end annotation
.end field

.field public d:Ljava/util/concurrent/atomic/AtomicBoolean;

.field public e:Li0/c;

.field public f:Li0/b;

.field public g:Li0/a;

.field public h:I


# direct methods
.method public constructor <init>(Li0/d$c;)V
    .locals 1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/16 v0, 0x5dc

    iput v0, p0, Li0/d;->h:I

    iput-object p1, p0, Li0/d;->a:Li0/d$c;

    new-instance p1, Ljava/util/concurrent/atomic/AtomicReference;

    invoke-direct {p1}, Ljava/util/concurrent/atomic/AtomicReference;-><init>()V

    iput-object p1, p0, Li0/d;->c:Ljava/util/concurrent/atomic/AtomicReference;

    new-instance p1, Ljava/util/concurrent/atomic/AtomicBoolean;

    const/4 v0, 0x0

    invoke-direct {p1, v0}, Ljava/util/concurrent/atomic/AtomicBoolean;-><init>(Z)V

    iput-object p1, p0, Li0/d;->d:Ljava/util/concurrent/atomic/AtomicBoolean;

    new-instance p1, Li0/a;

    invoke-direct {p1}, Li0/a;-><init>()V

    iput-object p1, p0, Li0/d;->g:Li0/a;

    return-void
.end method


# virtual methods
.method public final a(Ljava/lang/String;[Ljava/lang/String;ZLjava/lang/String;Z)Z
    .locals 13

    move-object v1, p0

    iget-object v0, v1, Li0/d;->d:Ljava/util/concurrent/atomic/AtomicBoolean;

    const/4 v2, 0x0

    const/4 v3, 0x1

    invoke-virtual {v0, v2, v3}, Ljava/util/concurrent/atomic/AtomicBoolean;->compareAndSet(ZZ)Z

    move-result v0

    if-nez v0, :cond_0

    return v2

    :cond_0
    iget-object v0, v1, Li0/d;->c:Ljava/util/concurrent/atomic/AtomicReference;

    invoke-virtual {v0}, Ljava/util/concurrent/atomic/AtomicReference;->get()Ljava/lang/Object;

    move-result-object v0

    move-object v6, v0

    check-cast v6, Landroid/os/ParcelFileDescriptor;

    if-nez v6, :cond_1

    return v2

    :cond_1
    const/4 v0, 0x0

    if-eqz p3, :cond_4

    const/16 v0, 0x1f9b

    sget v4, Li0/i;->a:I

    :goto_0
    const/16 v4, 0x1fa5

    if-ge v0, v4, :cond_3

    .line 1
    new-instance v4, Ljava/net/Socket;

    invoke-direct {v4}, Ljava/net/Socket;-><init>()V

    new-instance v5, Ljava/net/InetSocketAddress;

    const-string v7, "127.0.0.1"

    invoke-direct {v5, v7, v0}, Ljava/net/InetSocketAddress;-><init>(Ljava/lang/String;I)V

    const/16 v7, 0x3e8

    :try_start_0
    invoke-virtual {v4, v5, v7}, Ljava/net/Socket;->connect(Ljava/net/SocketAddress;I)V
    :try_end_0
    .catch Ljava/net/SocketTimeoutException; {:try_start_0 .. :try_end_0} :catch_3
    .catch Ljava/io/IOException; {:try_start_0 .. :try_end_0} :catch_1
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    goto :goto_1

    :catchall_0
    move-exception v0

    move-object v2, v0

    :try_start_1
    invoke-virtual {v4}, Ljava/net/Socket;->close()V
    :try_end_1
    .catch Ljava/io/IOException; {:try_start_1 .. :try_end_1} :catch_0

    :catch_0
    throw v2

    :catch_1
    :try_start_2
    invoke-virtual {v4}, Ljava/net/Socket;->close()V
    :try_end_2
    .catch Ljava/io/IOException; {:try_start_2 .. :try_end_2} :catch_2

    :catch_2
    const/4 v4, 0x1

    goto :goto_2

    :catch_3
    :goto_1
    :try_start_3
    invoke-virtual {v4}, Ljava/net/Socket;->close()V
    :try_end_3
    .catch Ljava/io/IOException; {:try_start_3 .. :try_end_3} :catch_4

    :catch_4
    const/4 v4, 0x0

    :goto_2
    if-eqz v4, :cond_2

    goto :goto_3

    :cond_2
    add-int/lit8 v0, v0, 0x1

    goto :goto_0

    :cond_3
    const/4 v0, 0x0

    :goto_3
    const/4 v4, 0x2

    new-array v4, v4, [Ljava/lang/Object;

    .line 2
    iget-object v5, v1, Li0/d;->b:Li0/i$a;

    iget-object v5, v5, Li0/i$a;->a:Ljava/lang/String;

    aput-object v5, v4, v2

    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v2

    aput-object v2, v4, v3

    const-string v2, "%s:%d"

    invoke-static {v2, v4}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v2

    new-instance v4, Li0/b;

    sget-object v5, Lxyz/chz/injector/MainActivity;->b:Lxyz/chz/injector/MainActivity;

    iget-object v7, v1, Li0/d;->b:Li0/i$a;

    iget-object v7, v7, Li0/i$a;->a:Ljava/lang/String;

    move-object v8, p2

    invoke-direct {v4, v5, p2, v7, v0}, Li0/b;-><init>(Landroid/content/Context;[Ljava/lang/String;Ljava/lang/String;I)V

    iput-object v4, v1, Li0/d;->f:Li0/b;

    new-instance v0, Li0/d$a;

    invoke-direct {v0, p0}, Li0/d$a;-><init>(Li0/d;)V

    .line 3
    iput-object v0, v4, Li0/b;->a:Li0/b$b;

    .line 4
    invoke-virtual {v4}, Ljava/lang/Thread;->start()V

    move-object v11, v2

    goto :goto_4

    :cond_4
    move-object v11, v0

    :goto_4
    new-instance v0, Li0/c;

    sget-object v5, Lxyz/chz/injector/MainActivity;->b:Lxyz/chz/injector/MainActivity;

    iget v7, v1, Li0/d;->h:I

    iget-object v2, v1, Li0/d;->b:Li0/i$a;

    iget-object v8, v2, Li0/i$a;->d:Ljava/lang/String;

    move-object v4, v0

    move-object v9, p1

    move-object/from16 v10, p4

    move/from16 v12, p5

    invoke-direct/range {v4 .. v12}, Li0/c;-><init>(Landroid/content/Context;Landroid/os/ParcelFileDescriptor;ILjava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Z)V

    iput-object v0, v1, Li0/d;->e:Li0/c;

    new-instance v2, Li0/d$b;

    invoke-direct {v2, p0}, Li0/d$b;-><init>(Li0/d;)V

    .line 5
    iput-object v2, v0, Li0/c;->a:Li0/c$a;

    .line 6
    invoke-virtual {v0}, Ljava/lang/Thread;->start()V

    iget-object v0, v1, Li0/d;->a:Li0/d$c;

    check-cast v0, Li0/g;

    invoke-static {v0}, Ljava/util/Objects;->requireNonNull(Ljava/lang/Object;)Ljava/lang/Object;

    const-string v0, "<strong>Tunnel Connected</strong>"

    .line 7
    invoke-static {v0}, Lg0/d;->h(Ljava/lang/String;)V

    return v3
.end method

.method public final b(Z[Ljava/lang/String;[Ljava/lang/String;ZZ[Ljava/lang/String;Z)Z
    .locals 16

    move-object/from16 v1, p0

    move-object/from16 v2, p2

    move-object/from16 v3, p3

    move-object/from16 v4, p6

    const-string v5, "startVpn failed"

    invoke-static {}, Li0/i;->c()Li0/i$a;

    move-result-object v6

    iput-object v6, v1, Li0/d;->b:Li0/i$a;

    array-length v6, v3

    const/4 v7, 0x0

    const/4 v8, 0x0

    :goto_0
    const/16 v9, 0x20

    if-ge v8, v6, :cond_0

    aget-object v10, v3, v8

    iget-object v11, v1, Li0/d;->g:Li0/a;

    new-instance v12, Ld/a;

    invoke-direct {v12, v10, v9}, Ld/a;-><init>(Ljava/lang/String;I)V

    invoke-virtual {v11, v12, v7}, Li0/a;->a(Ld/a;Z)V

    add-int/lit8 v8, v8, 0x1

    goto :goto_0

    :cond_0
    invoke-static {}, Ljava/util/Locale;->getDefault()Ljava/util/Locale;

    move-result-object v3

    :try_start_0
    new-instance v6, Ljava/util/Locale;

    const-string v8, "en"

    invoke-direct {v6, v8}, Ljava/util/Locale;-><init>(Ljava/lang/String;)V

    invoke-static {v6}, Ljava/util/Locale;->setDefault(Ljava/util/Locale;)V

    iget-object v6, v1, Li0/d;->a:Li0/d$c;

    check-cast v6, Li0/g;

    invoke-virtual {v6}, Li0/g;->a()Ljava/lang/Object;

    move-result-object v6

    check-cast v6, Landroid/net/VpnService$Builder;

    iget-object v8, v1, Li0/d;->b:Li0/i$a;

    iget-object v10, v8, Li0/i$a;->a:Ljava/lang/String;

    iget v8, v8, Li0/i$a;->c:I

    invoke-virtual {v6, v10, v8}, Landroid/net/VpnService$Builder;->addAddress(Ljava/lang/String;I)Landroid/net/VpnService$Builder;

    move-result-object v6

    iget-object v8, v1, Li0/d;->g:Li0/a;

    new-instance v10, Ld/a;

    const-string v11, "0.0.0.0"

    invoke-direct {v10, v11, v7}, Ld/a;-><init>(Ljava/lang/String;I)V

    const/4 v11, 0x1

    invoke-virtual {v8, v10, v11}, Li0/a;->a(Ld/a;Z)V

    iget-object v8, v1, Li0/d;->g:Li0/a;

    new-instance v10, Ld/a;

    const-string v12, "10.0.0.0"

    const/16 v13, 0x8

    invoke-direct {v10, v12, v13}, Ld/a;-><init>(Ljava/lang/String;I)V

    invoke-virtual {v8, v10, v7}, Li0/a;->a(Ld/a;Z)V

    iget-object v8, v1, Li0/d;->g:Li0/a;

    new-instance v10, Ld/a;

    iget-object v12, v1, Li0/d;->b:Li0/i$a;

    iget-object v13, v12, Li0/i$a;->b:Ljava/lang/String;

    iget v12, v12, Li0/i$a;->c:I

    invoke-direct {v10, v13, v12}, Ld/a;-><init>(Ljava/lang/String;I)V

    invoke-virtual {v8, v10, v7}, Li0/a;->a(Ld/a;Z)V

    if-eqz p7, :cond_1

    iget-object v8, v1, Li0/d;->g:Li0/a;

    new-instance v10, Ld/a;

    const-string v12, "192.168.42.0"

    const/16 v13, 0x17

    invoke-direct {v10, v12, v13}, Ld/a;-><init>(Ljava/lang/String;I)V

    invoke-virtual {v8, v10, v7}, Li0/a;->a(Ld/a;Z)V

    iget-object v8, v1, Li0/d;->g:Li0/a;

    new-instance v10, Ld/a;

    const-string v12, "192.168.44.0"

    const/16 v13, 0x18

    invoke-direct {v10, v12, v13}, Ld/a;-><init>(Ljava/lang/String;I)V

    invoke-virtual {v8, v10, v7}, Li0/a;->a(Ld/a;Z)V

    iget-object v8, v1, Li0/d;->g:Li0/a;

    new-instance v10, Ld/a;

    const-string v12, "192.168.49.0"

    invoke-direct {v10, v12, v13}, Ld/a;-><init>(Ljava/lang/String;I)V

    invoke-virtual {v8, v10, v7}, Li0/a;->a(Ld/a;Z)V

    :cond_1
    array-length v8, v2

    const/4 v10, 0x0

    :goto_1
    if-ge v10, v8, :cond_2

    aget-object v12, v2, v10
    :try_end_0
    .catch Ljava/lang/IllegalArgumentException; {:try_start_0 .. :try_end_0} :catch_6
    .catch Ljava/lang/SecurityException; {:try_start_0 .. :try_end_0} :catch_5
    .catch Ljava/lang/IllegalStateException; {:try_start_0 .. :try_end_0} :catch_4
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    :try_start_1
    invoke-virtual {v6, v12}, Landroid/net/VpnService$Builder;->addDnsServer(Ljava/lang/String;)Landroid/net/VpnService$Builder;

    iget-object v13, v1, Li0/d;->g:Li0/a;

    new-instance v14, Ld/a;

    invoke-direct {v14, v12, v9}, Ld/a;-><init>(Ljava/lang/String;I)V
    :try_end_1
    .catch Ljava/lang/IllegalArgumentException; {:try_start_1 .. :try_end_1} :catch_1
    .catch Ljava/lang/SecurityException; {:try_start_1 .. :try_end_1} :catch_5
    .catch Ljava/lang/IllegalStateException; {:try_start_1 .. :try_end_1} :catch_4
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    move/from16 v15, p1

    :try_start_2
    invoke-virtual {v13, v14, v15}, Li0/a;->a(Ld/a;Z)V
    :try_end_2
    .catch Ljava/lang/IllegalArgumentException; {:try_start_2 .. :try_end_2} :catch_0
    .catch Ljava/lang/SecurityException; {:try_start_2 .. :try_end_2} :catch_5
    .catch Ljava/lang/IllegalStateException; {:try_start_2 .. :try_end_2} :catch_4
    .catchall {:try_start_2 .. :try_end_2} :catchall_0

    goto :goto_3

    :catch_0
    move-exception v0

    goto :goto_2

    :catch_1
    move-exception v0

    move/from16 v15, p1

    :goto_2
    move-object v13, v0

    :try_start_3
    iget-object v14, v1, Li0/d;->a:Li0/d$c;

    const-string v9, "Error adding dns %s, %s"

    const/4 v11, 0x2

    new-array v11, v11, [Ljava/lang/Object;

    aput-object v12, v11, v7

    invoke-virtual {v13}, Ljava/lang/Throwable;->getLocalizedMessage()Ljava/lang/String;

    move-result-object v12

    const/4 v13, 0x1

    aput-object v12, v11, v13

    invoke-static {v9, v11}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v9

    check-cast v14, Li0/g;

    invoke-virtual {v14, v9}, Li0/g;->b(Ljava/lang/String;)V

    :goto_3
    add-int/lit8 v10, v10, 0x1

    const/16 v9, 0x20

    const/4 v11, 0x1

    goto :goto_1

    :cond_2
    sget-object v2, Landroid/os/Build$VERSION;->RELEASE:Ljava/lang/String;

    iget v2, v1, Li0/d;->h:I

    invoke-virtual {v6, v2}, Landroid/net/VpnService$Builder;->setMtu(I)Landroid/net/VpnService$Builder;

    iget-object v2, v1, Li0/d;->g:Li0/a;

    const/4 v8, 0x1

    invoke-virtual {v2, v8}, Li0/a;->c(Z)Ljava/util/Collection;

    move-result-object v2

    check-cast v2, Ljava/util/Vector;

    invoke-virtual {v2}, Ljava/util/Vector;->iterator()Ljava/util/Iterator;

    move-result-object v2

    :goto_4
    invoke-interface {v2}, Ljava/util/Iterator;->hasNext()Z

    move-result v8

    if-eqz v8, :cond_3

    invoke-interface {v2}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v8

    check-cast v8, Li0/a$a;

    goto :goto_4

    :cond_3
    iget-object v2, v1, Li0/d;->g:Li0/a;

    invoke-virtual {v2, v7}, Li0/a;->c(Z)Ljava/util/Collection;

    move-result-object v2

    check-cast v2, Ljava/util/Vector;

    invoke-virtual {v2}, Ljava/util/Vector;->iterator()Ljava/util/Iterator;

    move-result-object v2

    :goto_5
    invoke-interface {v2}, Ljava/util/Iterator;->hasNext()Z

    move-result v8

    if-eqz v8, :cond_4

    invoke-interface {v2}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v8

    check-cast v8, Li0/a$a;

    goto :goto_5

    :cond_4
    new-instance v2, Li0/a$a;

    new-instance v8, Ld/a;

    const-string v9, "224.0.0.0"

    const/4 v10, 0x3

    invoke-direct {v8, v9, v10}, Ld/a;-><init>(Ljava/lang/String;I)V

    const/4 v9, 0x1

    invoke-direct {v2, v8, v9}, Li0/a$a;-><init>(Ld/a;Z)V

    iget-object v8, v1, Li0/d;->g:Li0/a;

    invoke-virtual {v8}, Li0/a;->d()Ljava/util/Collection;

    move-result-object v8

    check-cast v8, Ljava/util/Vector;

    invoke-virtual {v8}, Ljava/util/Vector;->iterator()Ljava/util/Iterator;

    move-result-object v8

    :goto_6
    invoke-interface {v8}, Ljava/util/Iterator;->hasNext()Z

    move-result v9

    if-eqz v9, :cond_6

    invoke-interface {v8}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v9

    check-cast v9, Li0/a$a;
    :try_end_3
    .catch Ljava/lang/IllegalArgumentException; {:try_start_3 .. :try_end_3} :catch_6
    .catch Ljava/lang/SecurityException; {:try_start_3 .. :try_end_3} :catch_5
    .catch Ljava/lang/IllegalStateException; {:try_start_3 .. :try_end_3} :catch_4
    .catchall {:try_start_3 .. :try_end_3} :catchall_0

    :try_start_4
    invoke-virtual {v2, v9}, Li0/a$a;->a(Li0/a$a;)Z

    move-result v10

    if-eqz v10, :cond_5

    new-instance v10, Ljava/lang/StringBuilder;

    invoke-direct {v10}, Ljava/lang/StringBuilder;-><init>()V

    const-string v11, "VPN: Ignoring multicast route: "

    invoke-virtual {v10, v11}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v9}, Li0/a$a;->toString()Ljava/lang/String;

    move-result-object v11

    invoke-virtual {v10, v11}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v10}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v10

    invoke-static {v10}, Lg0/d;->d(Ljava/lang/String;)V

    goto :goto_6

    :cond_5
    invoke-virtual {v9}, Li0/a$a;->c()Ljava/lang/String;

    move-result-object v10

    iget v11, v9, Li0/a$a;->b:I

    invoke-virtual {v6, v10, v11}, Landroid/net/VpnService$Builder;->addRoute(Ljava/lang/String;I)Landroid/net/VpnService$Builder;
    :try_end_4
    .catch Ljava/lang/IllegalArgumentException; {:try_start_4 .. :try_end_4} :catch_2
    .catch Ljava/lang/SecurityException; {:try_start_4 .. :try_end_4} :catch_5
    .catch Ljava/lang/IllegalStateException; {:try_start_4 .. :try_end_4} :catch_4
    .catchall {:try_start_4 .. :try_end_4} :catchall_0

    goto :goto_6

    :catch_2
    move-exception v0

    move-object v10, v0

    :try_start_5
    iget-object v11, v1, Li0/d;->a:Li0/d$c;

    new-instance v12, Ljava/lang/StringBuilder;

    invoke-direct {v12}, Ljava/lang/StringBuilder;-><init>()V

    const-string v13, "Route rejected: "

    invoke-virtual {v12, v13}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v12, v9}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const-string v9, " "

    invoke-virtual {v12, v9}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v10}, Ljava/lang/Throwable;->getLocalizedMessage()Ljava/lang/String;

    move-result-object v9

    invoke-virtual {v12, v9}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v12}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v9

    check-cast v11, Li0/g;

    invoke-virtual {v11, v9}, Li0/g;->b(Ljava/lang/String;)V

    goto :goto_6

    :cond_6
    if-eqz p4, :cond_8

    array-length v2, v4

    const/4 v8, 0x0

    :goto_7
    if-ge v8, v2, :cond_8

    aget-object v9, v4, v8
    :try_end_5
    .catch Ljava/lang/IllegalArgumentException; {:try_start_5 .. :try_end_5} :catch_6
    .catch Ljava/lang/SecurityException; {:try_start_5 .. :try_end_5} :catch_5
    .catch Ljava/lang/IllegalStateException; {:try_start_5 .. :try_end_5} :catch_4
    .catchall {:try_start_5 .. :try_end_5} :catchall_0

    if-eqz p5, :cond_7

    :try_start_6
    invoke-virtual {v6, v9}, Landroid/net/VpnService$Builder;->addDisallowedApplication(Ljava/lang/String;)Landroid/net/VpnService$Builder;

    iget-object v10, v1, Li0/d;->a:Li0/d$c;

    const-string v11, "App Filter: VPN disabled for \"%s\""

    const/4 v12, 0x1

    new-array v13, v12, [Ljava/lang/Object;

    aput-object v9, v13, v7

    invoke-static {v11, v13}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v11

    :goto_8
    check-cast v10, Li0/g;

    goto :goto_9

    :cond_7
    invoke-virtual {v6, v9}, Landroid/net/VpnService$Builder;->addAllowedApplication(Ljava/lang/String;)Landroid/net/VpnService$Builder;

    iget-object v10, v1, Li0/d;->a:Li0/d$c;

    const-string v11, "App Filter: VPN enabled for \"%s\""

    const/4 v12, 0x1

    new-array v13, v12, [Ljava/lang/Object;

    aput-object v9, v13, v7

    invoke-static {v11, v13}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v11

    goto :goto_8

    :goto_9
    invoke-virtual {v10, v11}, Li0/g;->b(Ljava/lang/String;)V
    :try_end_6
    .catch Landroid/content/pm/PackageManager$NameNotFoundException; {:try_start_6 .. :try_end_6} :catch_3
    .catch Ljava/lang/IllegalArgumentException; {:try_start_6 .. :try_end_6} :catch_6
    .catch Ljava/lang/SecurityException; {:try_start_6 .. :try_end_6} :catch_5
    .catch Ljava/lang/IllegalStateException; {:try_start_6 .. :try_end_6} :catch_4
    .catchall {:try_start_6 .. :try_end_6} :catchall_0

    goto :goto_a

    :catch_3
    :try_start_7
    iget-object v10, v1, Li0/d;->a:Li0/d$c;

    new-instance v11, Ljava/lang/StringBuilder;

    invoke-direct {v11}, Ljava/lang/StringBuilder;-><init>()V

    const-string v12, "Application \""

    invoke-virtual {v11, v12}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v11, v9}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v9, "\" not found. App filter won\'t work, check settings."

    invoke-virtual {v11, v9}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v11}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v9

    check-cast v10, Li0/g;

    invoke-virtual {v10, v9}, Li0/g;->b(Ljava/lang/String;)V

    :goto_a
    add-int/lit8 v8, v8, 0x1

    goto :goto_7

    :cond_8
    iget-object v2, v1, Li0/d;->a:Li0/d$c;

    invoke-static {v2}, Ljava/util/Objects;->requireNonNull(Ljava/lang/Object;)Ljava/lang/Object;

    const-string v2, "KENTANG-INJECTOR"

    invoke-virtual {v6, v2}, Landroid/net/VpnService$Builder;->setSession(Ljava/lang/String;)Landroid/net/VpnService$Builder;

    move-result-object v2

    sget-object v4, Lxyz/chz/injector/MainActivity;->b:Lxyz/chz/injector/MainActivity;

    invoke-static {v4}, Lxyz/chz/injector/HttpService;->c(Landroid/content/Context;)Landroid/app/PendingIntent;

    move-result-object v4

    invoke-virtual {v2, v4}, Landroid/net/VpnService$Builder;->setConfigureIntent(Landroid/app/PendingIntent;)Landroid/net/VpnService$Builder;

    move-result-object v2

    invoke-virtual {v2}, Landroid/net/VpnService$Builder;->establish()Landroid/os/ParcelFileDescriptor;

    move-result-object v2
    :try_end_7
    .catch Ljava/lang/IllegalArgumentException; {:try_start_7 .. :try_end_7} :catch_6
    .catch Ljava/lang/SecurityException; {:try_start_7 .. :try_end_7} :catch_5
    .catch Ljava/lang/IllegalStateException; {:try_start_7 .. :try_end_7} :catch_4
    .catchall {:try_start_7 .. :try_end_7} :catchall_0

    if-nez v2, :cond_9

    invoke-static {v3}, Ljava/util/Locale;->setDefault(Ljava/util/Locale;)V

    return v7

    :cond_9
    :try_start_8
    iget-object v4, v1, Li0/d;->c:Ljava/util/concurrent/atomic/AtomicReference;

    invoke-virtual {v4, v2}, Ljava/util/concurrent/atomic/AtomicReference;->set(Ljava/lang/Object;)V

    iget-object v2, v1, Li0/d;->d:Ljava/util/concurrent/atomic/AtomicBoolean;

    invoke-virtual {v2, v7}, Ljava/util/concurrent/atomic/AtomicBoolean;->set(Z)V

    iget-object v2, v1, Li0/d;->a:Li0/d$c;

    check-cast v2, Li0/g;

    invoke-virtual {v2}, Li0/g;->c()V

    iget-object v2, v1, Li0/d;->g:Li0/a;

    invoke-virtual {v2}, Li0/a;->b()V
    :try_end_8
    .catch Ljava/lang/IllegalArgumentException; {:try_start_8 .. :try_end_8} :catch_6
    .catch Ljava/lang/SecurityException; {:try_start_8 .. :try_end_8} :catch_5
    .catch Ljava/lang/IllegalStateException; {:try_start_8 .. :try_end_8} :catch_4
    .catchall {:try_start_8 .. :try_end_8} :catchall_0

    invoke-static {v3}, Ljava/util/Locale;->setDefault(Ljava/util/Locale;)V

    const/4 v2, 0x1

    return v2

    :catchall_0
    move-exception v0

    move-object v2, v0

    goto :goto_b

    :catch_4
    move-exception v0

    move-object v2, v0

    :try_start_9
    new-instance v4, Ljava/lang/Exception;

    invoke-direct {v4, v5, v2}, Ljava/lang/Exception;-><init>(Ljava/lang/String;Ljava/lang/Throwable;)V

    throw v4

    :catch_5
    move-exception v0

    move-object v2, v0

    new-instance v4, Ljava/lang/Exception;

    invoke-direct {v4, v5, v2}, Ljava/lang/Exception;-><init>(Ljava/lang/String;Ljava/lang/Throwable;)V

    throw v4

    :catch_6
    move-exception v0

    move-object v2, v0

    new-instance v4, Ljava/lang/Exception;

    invoke-direct {v4, v5, v2}, Ljava/lang/Exception;-><init>(Ljava/lang/String;Ljava/lang/Throwable;)V

    throw v4
    :try_end_9
    .catchall {:try_start_9 .. :try_end_9} :catchall_0

    :goto_b
    invoke-static {v3}, Ljava/util/Locale;->setDefault(Ljava/util/Locale;)V

    throw v2
.end method

.method public final declared-synchronized c()V
    .locals 2

    monitor-enter p0

    .line 1
    :try_start_0
    invoke-virtual {p0}, Li0/d;->d()V

    iget-object v0, p0, Li0/d;->c:Ljava/util/concurrent/atomic/AtomicReference;

    const/4 v1, 0x0

    invoke-virtual {v0, v1}, Ljava/util/concurrent/atomic/AtomicReference;->getAndSet(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Landroid/os/ParcelFileDescriptor;
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    if-eqz v0, :cond_0

    :try_start_1
    invoke-virtual {v0}, Landroid/os/ParcelFileDescriptor;->close()V
    :try_end_1
    .catch Ljava/io/IOException; {:try_start_1 .. :try_end_1} :catch_0
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    goto :goto_0

    :catchall_0
    move-exception v0

    goto :goto_1

    .line 2
    :catch_0
    :cond_0
    :goto_0
    monitor-exit p0

    return-void

    :goto_1
    monitor-exit p0

    throw v0
.end method

.method public final clone()Ljava/lang/Object;
    .locals 1

    new-instance v0, Ljava/lang/CloneNotSupportedException;

    invoke-direct {v0}, Ljava/lang/CloneNotSupportedException;-><init>()V

    throw v0
.end method

.method public final d()V
    .locals 2

    iget-object v0, p0, Li0/d;->e:Li0/c;

    if-eqz v0, :cond_0

    invoke-virtual {v0}, Ljava/lang/Thread;->isAlive()Z

    move-result v0

    if-eqz v0, :cond_0

    iget-object v0, p0, Li0/d;->e:Li0/c;

    invoke-virtual {v0}, Li0/c;->interrupt()V

    :cond_0
    const/4 v0, 0x0

    iput-object v0, p0, Li0/d;->e:Li0/c;

    iget-object v1, p0, Li0/d;->f:Li0/b;

    if-eqz v1, :cond_1

    invoke-virtual {v1}, Ljava/lang/Thread;->isAlive()Z

    move-result v1

    if-eqz v1, :cond_1

    iget-object v1, p0, Li0/d;->f:Li0/b;

    invoke-virtual {v1}, Li0/b;->interrupt()V

    :cond_1
    iput-object v0, p0, Li0/d;->f:Li0/b;

    return-void
.end method

.method public final declared-synchronized e()V
    .locals 1

    monitor-enter p0

    :try_start_0
    invoke-virtual {p0}, Li0/d;->d()V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    monitor-exit p0

    return-void

    :catchall_0
    move-exception v0

    monitor-exit p0

    throw v0
.end method
