.class public final Lh0/h;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ljava/lang/Runnable;
.implements Lm/d;
.implements Lm/k;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lh0/h$d;
    }
.end annotation


# instance fields
.field public a:Lh0/h$d;

.field public b:Landroid/content/Context;

.field public c:Landroid/os/Handler;

.field public d:Lf0/a;

.field public e:Z

.field public f:Z

.field public g:Lh0/b;

.field public h:Ljava/util/concurrent/CountDownLatch;

.field public i:Lm/c;

.field public j:Z

.field public k:Z

.field public l:Lm/e;

.field public m:Z

.field public n:Lh0/h$c;


# direct methods
.method public constructor <init>(Landroid/os/Handler;Landroid/content/Context;)V
    .locals 1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v0, 0x0

    iput-boolean v0, p0, Lh0/h;->e:Z

    iput-boolean v0, p0, Lh0/h;->f:Z

    iput-boolean v0, p0, Lh0/h;->j:Z

    iput-boolean v0, p0, Lh0/h;->k:Z

    iput-boolean v0, p0, Lh0/h;->m:Z

    new-instance v0, Lh0/h$c;

    invoke-direct {v0, p0}, Lh0/h$c;-><init>(Lh0/h;)V

    iput-object v0, p0, Lh0/h;->n:Lh0/h$c;

    iput-object p2, p0, Lh0/h;->b:Landroid/content/Context;

    iput-object p1, p0, Lh0/h;->c:Landroid/os/Handler;

    new-instance p1, Lf0/a;

    invoke-direct {p1, p2}, Lf0/a;-><init>(Landroid/content/Context;)V

    iput-object p1, p0, Lh0/h;->d:Lf0/a;

    return-void
.end method

.method public static g()Z
    .locals 2

    invoke-static {}, Li0/e;->b()Li0/e;

    move-result-object v0

    .line 1
    monitor-enter v0

    :try_start_0
    iget-boolean v1, v0, Li0/e;->b:Z
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    monitor-exit v0

    if-nez v1, :cond_1

    .line 2
    invoke-virtual {v0}, Li0/e;->a()Li0/g;

    move-result-object v0

    if-eqz v0, :cond_0

    goto :goto_0

    :cond_0
    const/4 v0, 0x0

    goto :goto_1

    :cond_1
    :goto_0
    const/4 v0, 0x1

    :goto_1
    return v0

    :catchall_0
    move-exception v1

    .line 3
    monitor-exit v0

    throw v1
.end method


# virtual methods
.method public final a()V
    .locals 3

    iget-boolean v0, p0, Lh0/h;->f:Z

    if-nez v0, :cond_1

    iget-boolean v0, p0, Lh0/h;->e:Z

    if-nez v0, :cond_1

    iget-boolean v0, p0, Lh0/h;->m:Z

    if-eqz v0, :cond_0

    goto :goto_0

    :cond_0
    const-string v0, "<strong>"

    .line 1
    invoke-static {v0}, Lcom/trilead/ssh2/crypto/digest/a;->e(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    .line 2
    iget-object v1, p0, Lh0/h;->b:Landroid/content/Context;

    const v2, 0x7f0b0019

    invoke-virtual {v1, v2}, Landroid/content/Context;->getString(I)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v1, "</strong>"

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-static {v0}, Lg0/d;->k(Ljava/lang/String;)V

    invoke-virtual {p0}, Lh0/h;->h()V

    :cond_1
    :goto_0
    return-void
.end method

.method public final b(Ljava/lang/String;)V
    .locals 3

    const-string v0, "<strong>"

    .line 1
    invoke-static {v0}, Lcom/trilead/ssh2/crypto/digest/a;->e(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    .line 2
    iget-object v1, p0, Lh0/h;->b:Landroid/content/Context;

    const v2, 0x7f0b001a

    invoke-virtual {v1, v2}, Landroid/content/Context;->getString(I)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v1, "</strong><br>"

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    invoke-static {p1}, Lg0/d;->k(Ljava/lang/String;)V

    return-void
.end method

.method public final c(ILjava/lang/String;Ljava/lang/String;Lm/c;)V
    .locals 13

    move-object v1, p0

    move v0, p1

    move-object v5, p2

    move-object/from16 v2, p3

    move-object/from16 v8, p4

    if-eqz v0, :cond_6

    const/4 v3, 0x1

    iput-boolean v3, v1, Lh0/h;->k:Z

    const v9, 0x7f0b0013

    const/4 v4, 0x0

    const-string v6, "sshPort"

    const-string v7, "sshServer"

    if-eq v0, v3, :cond_4

    const/4 v3, 0x2

    const-string v10, "proxyRemotoPorta"

    const-string v11, "proxyRemoto"

    const-string v12, "added proxy"

    if-eq v0, v3, :cond_3

    const/4 v3, 0x3

    if-eq v0, v3, :cond_2

    const/4 v3, 0x4

    if-eq v0, v3, :cond_1

    const/4 v3, 0x5

    if-eq v0, v3, :cond_0

    goto/16 :goto_1

    :cond_0
    :try_start_0
    invoke-static {v12}, Lg0/d;->k(Ljava/lang/String;)V

    iget-object v0, v1, Lh0/h;->d:Lf0/a;

    invoke-virtual {v0, v11}, Lf0/a;->b(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    iget-object v3, v1, Lh0/h;->d:Lf0/a;

    invoke-virtual {v3, v10}, Lf0/a;->b(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    invoke-static {v3}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I

    move-result v3

    new-instance v4, Lh0/e;

    invoke-direct {v4, v0, v3, v2, p2}, Lh0/e;-><init>(Ljava/lang/String;ILjava/lang/String;Ljava/lang/String;)V

    invoke-virtual {v8, v4}, Lm/c;->m(Lm/j;)V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    goto/16 :goto_2

    :catch_0
    move-exception v0

    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const-string v3, "TMH err :"

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    goto :goto_0

    :cond_1
    iget-object v0, v1, Lh0/h;->d:Lf0/a;

    invoke-virtual {v0, v7}, Lf0/a;->b(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    iget-object v3, v1, Lh0/h;->d:Lf0/a;

    invoke-virtual {v3, v6}, Lf0/a;->b(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    invoke-static {v3}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I

    move-result v3

    :try_start_1
    new-instance v4, Lh0/e;

    invoke-direct {v4, v0, v3, v2, p2}, Lh0/e;-><init>(Ljava/lang/String;ILjava/lang/String;Ljava/lang/String;)V

    invoke-virtual {v8, v4}, Lm/c;->m(Lm/j;)V
    :try_end_1
    .catch Ljava/lang/Exception; {:try_start_1 .. :try_end_1} :catch_1

    goto/16 :goto_2

    :catch_1
    move-exception v0

    invoke-virtual {v0}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    move-result-object v0

    invoke-static {v0}, Lg0/d;->k(Ljava/lang/String;)V

    goto/16 :goto_2

    :cond_2
    iget-object v0, v1, Lh0/h;->d:Lf0/a;

    invoke-virtual {v0, v7}, Lf0/a;->b(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    iget-object v3, v1, Lh0/h;->d:Lf0/a;

    invoke-virtual {v3, v6}, Lf0/a;->b(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    invoke-static {v3}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I

    move-result v3

    :try_start_2
    const-string v4, "ssl test"

    invoke-static {v4}, Lg0/d;->h(Ljava/lang/String;)V

    new-instance v4, Lh0/d;

    invoke-direct {v4, v0, v3, v2}, Lh0/d;-><init>(Ljava/lang/String;ILjava/lang/String;)V

    invoke-virtual {v8, v4}, Lm/c;->m(Lm/j;)V
    :try_end_2
    .catch Ljava/lang/Exception; {:try_start_2 .. :try_end_2} :catch_2

    goto/16 :goto_2

    :catch_2
    move-exception v0

    invoke-virtual {v0}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    move-result-object v0

    :goto_0
    invoke-static {v0}, Lg0/d;->h(Ljava/lang/String;)V

    goto :goto_2

    :cond_3
    invoke-static {v12}, Lg0/d;->k(Ljava/lang/String;)V

    if-eqz v5, :cond_5

    iget-object v0, v1, Lh0/h;->d:Lf0/a;

    invoke-virtual {v0, v11}, Lf0/a;->b(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    iget-object v0, v1, Lh0/h;->d:Lf0/a;

    invoke-virtual {v0, v10}, Lf0/a;->b(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    invoke-static {v0}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I

    move-result v4

    :try_start_3
    new-instance v0, Lh0/a;

    const/4 v6, 0x0

    iget-object v7, v1, Lh0/h;->b:Landroid/content/Context;

    move-object v2, v0

    move-object v5, p2

    invoke-direct/range {v2 .. v7}, Lh0/a;-><init>(Ljava/lang/String;ILjava/lang/String;ZLandroid/content/Context;)V

    invoke-virtual {v8, v0}, Lm/c;->m(Lm/j;)V
    :try_end_3
    .catch Ljava/lang/Exception; {:try_start_3 .. :try_end_3} :catch_3

    goto :goto_2

    .line 1
    :catch_3
    new-instance v0, Lg0/b;

    invoke-direct {v0, v9}, Lg0/b;-><init>(I)V

    invoke-static {v0}, Lg0/d;->l(Lg0/b;)V

    .line 2
    new-instance v0, Ljava/lang/Exception;

    iget-object v2, v1, Lh0/h;->b:Landroid/content/Context;

    invoke-virtual {v2, v9}, Landroid/content/Context;->getString(I)Ljava/lang/String;

    move-result-object v2

    invoke-direct {v0, v2}, Ljava/lang/Exception;-><init>(Ljava/lang/String;)V

    throw v0

    :cond_4
    const-string v0, "Direct SSH"

    invoke-static {v0}, Lg0/d;->k(Ljava/lang/String;)V

    if-eqz v5, :cond_5

    :try_start_4
    new-instance v0, Lh0/a;

    iget-object v2, v1, Lh0/h;->d:Lf0/a;

    invoke-virtual {v2, v7}, Lf0/a;->b(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    iget-object v2, v1, Lh0/h;->d:Lf0/a;

    invoke-virtual {v2, v6}, Lf0/a;->b(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    invoke-static {v2}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I

    move-result v4

    const/4 v6, 0x1

    iget-object v7, v1, Lh0/h;->b:Landroid/content/Context;

    move-object v2, v0

    move-object v5, p2

    invoke-direct/range {v2 .. v7}, Lh0/a;-><init>(Ljava/lang/String;ILjava/lang/String;ZLandroid/content/Context;)V

    invoke-virtual {v8, v0}, Lm/c;->m(Lm/j;)V
    :try_end_4
    .catch Ljava/lang/Exception; {:try_start_4 .. :try_end_4} :catch_4

    goto :goto_2

    :catch_4
    new-instance v0, Ljava/lang/Exception;

    iget-object v2, v1, Lh0/h;->b:Landroid/content/Context;

    invoke-virtual {v2, v9}, Landroid/content/Context;->getString(I)Ljava/lang/String;

    move-result-object v2

    invoke-direct {v0, v2}, Ljava/lang/Exception;-><init>(Ljava/lang/String;)V

    throw v0

    .line 3
    :cond_5
    :goto_1
    iput-boolean v4, v1, Lh0/h;->k:Z

    :cond_6
    :goto_2
    return-void
.end method

.method public final d(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V
    .locals 4

    iget-boolean v0, p0, Lh0/h;->j:Z

    if-eqz v0, :cond_4

    const-string v0, "AUTENTICANDO"

    iget-object v1, p0, Lh0/h;->b:Landroid/content/Context;

    const v2, 0x7f0b002c

    invoke-virtual {v1, v2}, Landroid/content/Context;->getString(I)Ljava/lang/String;

    move-result-object v1

    invoke-static {v0, v1}, Lg0/d;->n(Ljava/lang/String;Ljava/lang/String;)V

    const v0, 0x7f0b002f

    :try_start_0
    iget-object v1, p0, Lh0/h;->i:Lm/c;

    const-string v2, "password"

    invoke-virtual {v1, p1, v2}, Lm/c;->k(Ljava/lang/String;Ljava/lang/String;)Z

    move-result v1

    if-eqz v1, :cond_0

    iget-object v1, p0, Lh0/h;->i:Lm/c;

    invoke-virtual {v1, p1, p2}, Lm/c;->b(Ljava/lang/String;Ljava/lang/String;)Z

    move-result v1

    if-eqz v1, :cond_0

    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const-string v2, "<strong>"

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object v2, p0, Lh0/h;->b:Landroid/content/Context;

    invoke-virtual {v2, v0}, Landroid/content/Context;->getString(I)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v2, "</strong>"

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-static {v1}, Lg0/d;->k(Ljava/lang/String;)V
    :try_end_0
    .catch Ljava/lang/IllegalStateException; {:try_start_0 .. :try_end_0} :catch_1
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    goto :goto_1

    :catch_0
    move-exception v1

    const-string v2, "TMH err :"

    const-string v3, "Problem during handleAuthentication()"

    goto :goto_0

    :catch_1
    move-exception v1

    const-string v2, "TMH err :"

    const-string v3, "Connection went away while we were trying to authenticate"

    :goto_0
    invoke-static {v2, v3, v1}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I

    :cond_0
    :goto_1
    :try_start_1
    iget-object v1, p0, Lh0/h;->i:Lm/c;

    const-string v2, "publickey"

    invoke-virtual {v1, p1, v2}, Lm/c;->k(Ljava/lang/String;Ljava/lang/String;)Z

    move-result v1

    if-eqz v1, :cond_2

    if-eqz p3, :cond_2

    invoke-virtual {p3}, Ljava/lang/String;->isEmpty()Z

    move-result v1

    if-nez v1, :cond_2

    new-instance v1, Ljava/io/File;

    invoke-direct {v1, p3}, Ljava/io/File;-><init>(Ljava/lang/String;)V

    invoke-virtual {v1}, Ljava/io/File;->exists()Z

    move-result p3

    if-eqz p3, :cond_2

    const-string p3, ""

    invoke-virtual {p2, p3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p3

    if-eqz p3, :cond_1

    const/4 p2, 0x0

    :cond_1
    const-string p3, "Authenticating com public key"

    invoke-static {p3}, Lg0/d;->k(Ljava/lang/String;)V

    iget-object p3, p0, Lh0/h;->i:Lm/c;

    invoke-virtual {p3, p1, v1, p2}, Lm/c;->c(Ljava/lang/String;Ljava/io/File;Ljava/lang/String;)Z

    move-result p1

    if-eqz p1, :cond_2

    new-instance p1, Ljava/lang/StringBuilder;

    invoke-direct {p1}, Ljava/lang/StringBuilder;-><init>()V

    const-string p2, "<strong>"

    invoke-virtual {p1, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object p2, p0, Lh0/h;->b:Landroid/content/Context;

    invoke-virtual {p2, v0}, Landroid/content/Context;->getString(I)Ljava/lang/String;

    move-result-object p2

    invoke-virtual {p1, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string p2, "</strong>"

    invoke-virtual {p1, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    invoke-static {p1}, Lg0/d;->k(Ljava/lang/String;)V
    :try_end_1
    .catch Ljava/lang/Exception; {:try_start_1 .. :try_end_1} :catch_2

    goto :goto_2

    :catch_2
    const-string p1, "TMH err :"

    const-string p2, "Host does not support \'Public key\' authentication."

    invoke-static {p1, p2}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    :cond_2
    :goto_2
    iget-object p1, p0, Lh0/h;->i:Lm/c;

    .line 1
    monitor-enter p1

    :try_start_2
    iget-boolean p2, p1, Lm/c;->c:Z
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_0

    monitor-exit p1

    if-eqz p2, :cond_3

    return-void

    :cond_3
    const-string p1, "<font color = #C01C47> Failed to authenticate, User or Password Expired"

    .line 2
    invoke-static {p1}, Lg0/d;->k(Ljava/lang/String;)V

    invoke-virtual {p0}, Lh0/h;->k()V

    new-instance p1, Ljava/io/IOException;

    const-string p2, "It was not possible to authenticate with the data provided"

    invoke-direct {p1, p2}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    throw p1

    :catchall_0
    move-exception p2

    .line 3
    monitor-exit p1

    throw p2

    .line 4
    :cond_4
    new-instance p1, Ljava/io/IOException;

    invoke-direct {p1}, Ljava/io/IOException;-><init>()V

    throw p1
.end method

.method public final declared-synchronized e()V
    .locals 3

    monitor-enter p0

    :try_start_0
    invoke-virtual {p0}, Lh0/h;->l()V

    .line 1
    monitor-enter p0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_2

    :try_start_1
    iget-object v0, p0, Lh0/h;->g:Lh0/b;

    if-eqz v0, :cond_0

    invoke-virtual {v0}, Ljava/lang/Thread;->isAlive()Z

    move-result v0

    if-eqz v0, :cond_0

    iget-object v0, p0, Lh0/h;->g:Lh0/b;

    invoke-virtual {v0}, Ljava/lang/Thread;->interrupt()V
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_1

    :cond_0
    :try_start_2
    monitor-exit p0

    .line 2
    iget-object v0, p0, Lh0/h;->i:Lm/c;

    if-eqz v0, :cond_1

    const-string v0, "Stopping SSH"

    invoke-static {v0}, Lg0/d;->d(Ljava/lang/String;)V

    iget-object v0, p0, Lh0/h;->i:Lm/c;

    .line 3
    monitor-enter v0
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_2

    :try_start_3
    sget-object v1, Lm/c;->o:La/b;

    invoke-static {v1}, Ljava/util/Objects;->requireNonNull(Ljava/lang/Object;)Ljava/lang/Object;

    new-instance v1, Ljava/lang/Throwable;

    const-string v2, "Closed due to user request."

    invoke-direct {v1, v2}, Ljava/lang/Throwable;-><init>(Ljava/lang/String;)V

    invoke-virtual {v0, v1}, Lm/c;->e(Ljava/lang/Throwable;)V
    :try_end_3
    .catchall {:try_start_3 .. :try_end_3} :catchall_0

    :try_start_4
    monitor-exit v0

    goto :goto_0

    :catchall_0
    move-exception v1

    monitor-exit v0

    throw v1
    :try_end_4
    .catchall {:try_start_4 .. :try_end_4} :catchall_2

    .line 4
    :cond_1
    :goto_0
    monitor-exit p0

    return-void

    :catchall_1
    move-exception v0

    .line 5
    :try_start_5
    monitor-exit p0

    throw v0
    :try_end_5
    .catchall {:try_start_5 .. :try_end_5} :catchall_2

    :catchall_2
    move-exception v0

    monitor-exit p0

    throw v0
.end method

.method public final f(Ljava/lang/String;I)V
    .locals 5

    iget-boolean v0, p0, Lh0/h;->f:Z

    if-eqz v0, :cond_6

    iget-object v0, p0, Lh0/h;->d:Lf0/a;

    .line 1
    iget-object v0, v0, Lf0/a;->c:Lk0/a;

    .line 2
    :try_start_0
    new-instance v1, Lm/c;

    invoke-direct {v1, p1, p2}, Lm/c;-><init>(Ljava/lang/String;I)V

    iput-object v1, p0, Lh0/h;->i:Lm/c;

    iget-object p1, p0, Lh0/h;->d:Lf0/a;

    .line 3
    iget-object p1, p1, Lf0/a;->b:Landroid/content/SharedPreferences;

    const-string p2, "modeDebug"

    const/4 v1, 0x0

    invoke-interface {p1, p2, v1}, Landroid/content/SharedPreferences;->getBoolean(Ljava/lang/String;Z)Z

    move-result p1

    if-eqz p1, :cond_0

    const-string p1, "protegerConfig"

    .line 4
    invoke-virtual {v0, p1, v1}, Lk0/a;->getBoolean(Ljava/lang/String;Z)Z

    move-result p1

    if-nez p1, :cond_0

    iget-object p1, p0, Lh0/h;->c:Landroid/os/Handler;

    new-instance p2, Lh0/h$b;

    invoke-direct {p2, p0}, Lh0/h$b;-><init>(Lh0/h;)V

    invoke-virtual {p1, p2}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    :cond_0
    iget-object p1, p0, Lh0/h;->i:Lm/c;

    .line 5
    monitor-enter p1
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    const/4 p2, 0x1

    :try_start_1
    iput-boolean p2, p1, Lm/c;->k:Z

    iget-object v2, p1, Lm/c;->j:Ls/i;

    if-eqz v2, :cond_1

    .line 6
    iget-object v2, v2, Ls/i;->f:Ljava/net/Socket;

    invoke-virtual {v2, p2}, Ljava/net/Socket;->setTcpNoDelay(Z)V
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    .line 7
    :cond_1
    :try_start_2
    monitor-exit p1

    .line 8
    iget-object p1, p0, Lh0/h;->d:Lf0/a;

    .line 9
    iget-object p1, p1, Lf0/a;->b:Landroid/content/SharedPreferences;

    const-string v2, "data_compression"

    invoke-interface {p1, v2, p2}, Landroid/content/SharedPreferences;->getBoolean(Ljava/lang/String;Z)Z

    move-result p1

    if-eqz p1, :cond_2

    .line 10
    iget-object p1, p0, Lh0/h;->i:Lm/c;

    invoke-virtual {p1}, Lm/c;->l()V

    const-string p1, "<strong>SSH Compression Enabled</strong>"

    invoke-static {p1}, Lg0/d;->k(Ljava/lang/String;)V

    :cond_2
    const-string p1, "protegerConfig"

    invoke-virtual {v0, p1, v1}, Lk0/a;->getBoolean(Ljava/lang/String;Z)Z

    const-string p1, "tunnelType"

    invoke-virtual {v0, p1, p2}, Lk0/a;->getInt(Ljava/lang/String;I)I

    move-result p1

    const-string v2, "usarDefaultPayload"

    invoke-virtual {v0, v2, p2}, Lk0/a;->getBoolean(Ljava/lang/String;Z)Z

    move-result v0

    if-nez v0, :cond_3

    iget-object v0, p0, Lh0/h;->d:Lf0/a;

    const-string v2, "proxyPayload"

    invoke-virtual {v0, v2}, Lf0/a;->b(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    goto :goto_0

    :cond_3
    const/4 v0, 0x0

    :goto_0
    iget-object v2, p0, Lh0/h;->d:Lf0/a;

    const-string v3, "wsPayload"

    invoke-virtual {v2, v3}, Lf0/a;->b(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    iget-object v3, p0, Lh0/h;->i:Lm/c;

    invoke-virtual {p0, p1, v0, v2, v3}, Lh0/h;->c(ILjava/lang/String;Ljava/lang/String;Lm/c;)V

    iget-object p1, p0, Lh0/h;->i:Lm/c;

    invoke-virtual {p1, p0}, Lm/c;->a(Lm/d;)V

    sget p1, Landroid/os/Build$VERSION;->SDK_INT:I

    const/16 v0, 0x17

    if-lt p1, v0, :cond_4

    iget-object p1, p0, Lh0/h;->b:Landroid/content/Context;

    const-string v0, "connectivity"

    invoke-virtual {p1, v0}, Landroid/content/Context;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Landroid/net/ConnectivityManager;

    invoke-virtual {p1}, Landroid/net/ConnectivityManager;->getDefaultProxy()Landroid/net/ProxyInfo;

    move-result-object p1

    if-eqz p1, :cond_4

    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const-string v2, "<strong>Network Proxy:</strong> "

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v2, "%s:%d"

    const/4 v3, 0x2

    new-array v3, v3, [Ljava/lang/Object;

    invoke-virtual {p1}, Landroid/net/ProxyInfo;->getHost()Ljava/lang/String;

    move-result-object v4

    aput-object v4, v3, v1

    invoke-virtual {p1}, Landroid/net/ProxyInfo;->getPort()I

    move-result p1

    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p1

    aput-object p1, v3, p2

    invoke-static {v2, v3}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object p1

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    invoke-static {p1}, Lg0/d;->k(Ljava/lang/String;)V

    :cond_4
    const-string p1, "CONECTANDO"

    iget-object v0, p0, Lh0/h;->b:Landroid/content/Context;

    const v2, 0x7f0b0031

    invoke-virtual {v0, v2}, Landroid/content/Context;->getString(I)Ljava/lang/String;

    move-result-object v0

    invoke-static {p1, v0}, Lg0/d;->n(Ljava/lang/String;Ljava/lang/String;)V

    new-array p1, v1, [Ljava/lang/Object;

    invoke-static {v2, p1}, Lg0/d;->j(I[Ljava/lang/Object;)V

    iget-object p1, p0, Lh0/h;->i:Lm/c;

    invoke-virtual {p1, p0}, Lm/c;->f(Lm/k;)Ll/e;

    iput-boolean p2, p0, Lh0/h;->j:Z

    return-void

    :catchall_0
    move-exception p2

    .line 11
    monitor-exit p1

    throw p2
    :try_end_2
    .catch Ljava/lang/Exception; {:try_start_2 .. :try_end_2} :catch_0

    :catch_0
    move-exception p1

    .line 12
    new-instance p2, Ljava/io/StringWriter;

    invoke-direct {p2}, Ljava/io/StringWriter;-><init>()V

    new-instance v0, Ljava/io/PrintWriter;

    invoke-direct {v0, p2}, Ljava/io/PrintWriter;-><init>(Ljava/io/Writer;)V

    invoke-virtual {p1, v0}, Ljava/lang/Throwable;->printStackTrace(Ljava/io/PrintWriter;)V

    invoke-virtual {p1}, Ljava/lang/Throwable;->getCause()Ljava/lang/Throwable;

    move-result-object p2

    invoke-virtual {p2}, Ljava/lang/Throwable;->toString()Ljava/lang/String;

    move-result-object p2

    iget-boolean v0, p0, Lh0/h;->k:Z

    if-eqz v0, :cond_5

    const-string v0, "Key exchange was not finished"

    invoke-virtual {p2, v0}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v0

    if-eqz v0, :cond_5

    invoke-static {p2}, Lg0/d;->k(Ljava/lang/String;)V

    :cond_5
    new-instance p2, Ljava/lang/Exception;

    invoke-direct {p2, p1}, Ljava/lang/Exception;-><init>(Ljava/lang/Throwable;)V

    throw p2

    :cond_6
    new-instance p1, Ljava/lang/Exception;

    invoke-direct {p1}, Ljava/lang/Exception;-><init>()V

    throw p1
.end method

.method public final h()V
    .locals 8

    iget-boolean v0, p0, Lh0/h;->f:Z

    if-nez v0, :cond_3

    iget-boolean v0, p0, Lh0/h;->e:Z

    if-nez v0, :cond_3

    iget-boolean v0, p0, Lh0/h;->m:Z

    if-eqz v0, :cond_0

    goto/16 :goto_2

    :cond_0
    const/4 v0, 0x1

    iput-boolean v0, p0, Lh0/h;->m:Z

    invoke-virtual {p0}, Lh0/h;->e()V

    const-string v1, "RECONECTANDO"

    const-string v2, "Reconnecting.."

    invoke-static {v1, v2}, Lg0/d;->n(Ljava/lang/String;Ljava/lang/String;)V

    const-wide/16 v3, 0x3e8

    const/4 v5, 0x0

    :try_start_0
    invoke-static {v3, v4}, Ljava/lang/Thread;->sleep(J)V
    :try_end_0
    .catch Ljava/lang/InterruptedException; {:try_start_0 .. :try_end_0} :catch_2

    invoke-static {}, Lg0/d;->b()V

    :goto_0
    iget-boolean v3, p0, Lh0/h;->e:Z

    if-eqz v3, :cond_1

    iput-boolean v5, p0, Lh0/h;->m:Z

    return-void

    :cond_1
    const/4 v3, 0x5

    iget-object v4, p0, Lh0/h;->b:Landroid/content/Context;

    invoke-static {v4}, Lh0/i;->e(Landroid/content/Context;)Z

    move-result v4

    if-nez v4, :cond_2

    const-string v4, "AGUARDANDO"

    const-string v6, "Waiting for network .."

    invoke-static {v4, v6}, Lg0/d;->n(Ljava/lang/String;Ljava/lang/String;)V

    const v4, 0x7f0b0034

    new-array v6, v5, [Ljava/lang/Object;

    invoke-static {v4, v6}, Lg0/d;->j(I[Ljava/lang/Object;)V

    goto :goto_1

    :cond_2
    const/4 v3, 0x3

    iput-boolean v0, p0, Lh0/h;->f:Z

    invoke-static {v1, v2}, Lg0/d;->n(Ljava/lang/String;Ljava/lang/String;)V

    new-instance v4, Ljava/lang/StringBuilder;

    invoke-direct {v4}, Ljava/lang/StringBuilder;-><init>()V

    const-string v6, "<strong>"

    invoke-virtual {v4, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object v6, p0, Lh0/h;->b:Landroid/content/Context;

    const v7, 0x7f0b0038

    invoke-virtual {v6, v7}, Landroid/content/Context;->getString(I)Ljava/lang/String;

    move-result-object v6

    invoke-virtual {v4, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v6, "</strong>"

    invoke-virtual {v4, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v4

    invoke-static {v4}, Lg0/d;->k(Ljava/lang/String;)V

    :try_start_1
    invoke-virtual {p0}, Lh0/h;->i()V

    iput-boolean v5, p0, Lh0/h;->f:Z

    iput-boolean v5, p0, Lh0/h;->m:Z
    :try_end_1
    .catch Ljava/lang/Exception; {:try_start_1 .. :try_end_1} :catch_0

    return-void

    :catch_0
    const-string v4, "<strong><html><font color=\"red\">"

    .line 1
    invoke-static {v4}, Lcom/trilead/ssh2/crypto/digest/a;->e(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v4

    .line 2
    iget-object v6, p0, Lh0/h;->b:Landroid/content/Context;

    const v7, 0x7f0b0032

    invoke-virtual {v6, v7}, Landroid/content/Context;->getString(I)Ljava/lang/String;

    move-result-object v6

    invoke-virtual {v4, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v6, "</font></html></strong>"

    invoke-virtual {v4, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v4

    invoke-static {v4}, Lg0/d;->k(Ljava/lang/String;)V

    iput-boolean v5, p0, Lh0/h;->f:Z

    :goto_1
    mul-int/lit16 v3, v3, 0x3e8

    int-to-long v3, v3

    :try_start_2
    invoke-static {v3, v4}, Ljava/lang/Thread;->sleep(J)V
    :try_end_2
    .catch Ljava/lang/InterruptedException; {:try_start_2 .. :try_end_2} :catch_1

    goto :goto_0

    :catch_1
    iput-boolean v5, p0, Lh0/h;->m:Z

    return-void

    :catch_2
    iput-boolean v5, p0, Lh0/h;->m:Z

    :cond_3
    :goto_2
    return-void
.end method

.method public final i()V
    .locals 8

    const/4 v0, 0x0

    iput-boolean v0, p0, Lh0/h;->e:Z

    iget-object v1, p0, Lh0/h;->d:Lf0/a;

    const-string v2, "sshServer"

    invoke-virtual {v1, v2}, Lf0/a;->b(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    iget-object v2, p0, Lh0/h;->d:Lf0/a;

    const-string v3, "sshPort"

    invoke-virtual {v2, v3}, Lf0/a;->b(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    invoke-static {v2}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I

    move-result v2

    iget-object v3, p0, Lh0/h;->d:Lf0/a;

    const-string v4, "sshUser"

    invoke-virtual {v3, v4}, Lf0/a;->b(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    iget-object v4, p0, Lh0/h;->d:Lf0/a;

    const-string v5, "sshPass"

    invoke-virtual {v4, v5}, Lf0/a;->b(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    iget-object v5, p0, Lh0/h;->d:Lf0/a;

    .line 1
    iget-object v5, v5, Lf0/a;->b:Landroid/content/SharedPreferences;

    const-string v6, "keyPath"

    const-string v7, ""

    invoke-interface {v5, v6, v7}, Landroid/content/SharedPreferences;->getString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v5

    .line 2
    iget-object v6, p0, Lh0/h;->d:Lf0/a;

    const-string v7, "sshPortaLocal"

    invoke-virtual {v6, v7}, Lf0/a;->b(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v6

    invoke-static {v6}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I

    move-result v6

    :try_start_0
    invoke-virtual {p0, v1, v2}, Lh0/h;->f(Ljava/lang/String;I)V

    iget-boolean v1, p0, Lh0/h;->e:Z
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_1

    if-eqz v1, :cond_0

    return-void

    :cond_0
    :try_start_1
    invoke-virtual {p0, v3, v4, v5}, Lh0/h;->d(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V
    :try_end_1
    .catch Ljava/io/IOException; {:try_start_1 .. :try_end_1} :catch_0
    .catch Ljava/lang/Exception; {:try_start_1 .. :try_end_1} :catch_1

    :try_start_2
    const-string v1, "CONECTADO"

    const-string v2, "SSH Connection Established"

    invoke-static {v1, v2}, Lg0/d;->n(Ljava/lang/String;Ljava/lang/String;)V

    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const-string v2, "<strong><font color=\'green\'>"

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object v2, p0, Lh0/h;->b:Landroid/content/Context;

    const v3, 0x7f0b0030

    invoke-virtual {v2, v3}, Landroid/content/Context;->getString(I)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v2, "</font></strong>"

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-static {v1}, Lg0/d;->e(Ljava/lang/String;)V

    invoke-virtual {p0, v6}, Lh0/h;->j(I)V

    return-void

    :catch_0
    new-instance v1, Ljava/io/IOException;

    const-string v2, "Authentication failed"

    invoke-direct {v1, v2}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    throw v1
    :try_end_2
    .catch Ljava/lang/Exception; {:try_start_2 .. :try_end_2} :catch_1

    :catch_1
    move-exception v1

    iput-boolean v0, p0, Lh0/h;->j:Z

    throw v1
.end method

.method public final j(I)V
    .locals 19

    move-object/from16 v1, p0

    move/from16 v0, p1

    iget-boolean v2, v1, Lh0/h;->j:Z

    if-eqz v2, :cond_11

    .line 1
    monitor-enter p0

    :try_start_0
    iget-boolean v2, v1, Lh0/h;->j:Z
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_2

    if-eqz v2, :cond_10

    :try_start_1
    iget-object v2, v1, Lh0/h;->d:Lf0/a;

    invoke-virtual {v2}, Lf0/a;->a()I

    move-result v2

    const/4 v3, 0x0

    if-lez v2, :cond_0

    iget-object v4, v1, Lh0/h;->i:Lm/c;

    invoke-virtual {v4, v0, v2}, Lm/c;->g(II)Lm/e;

    move-result-object v0

    iput-object v0, v1, Lh0/h;->l:Lm/e;

    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const-string v4, "socks local number threads: "

    invoke-virtual {v0, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-static {v2}, Ljava/lang/Integer;->toString(I)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-static {v0}, Lg0/d;->d(Ljava/lang/String;)V

    goto :goto_0

    :cond_0
    iget-object v2, v1, Lh0/h;->i:Lm/c;

    .line 2
    monitor-enter v2
    :try_end_1
    .catch Ljava/lang/Exception; {:try_start_1 .. :try_end_1} :catch_4
    .catchall {:try_start_1 .. :try_end_1} :catchall_2

    :try_start_2
    new-instance v4, Lm/e;

    iget-object v5, v2, Lm/c;->d:Lo/c;

    invoke-direct {v4, v5, v0, v3}, Lm/e;-><init>(Lo/c;II)V
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_1

    :try_start_3
    monitor-exit v2

    .line 3
    iput-object v4, v1, Lh0/h;->l:Lm/e;
    :try_end_3
    .catch Ljava/lang/Exception; {:try_start_3 .. :try_end_3} :catch_4
    .catchall {:try_start_3 .. :try_end_3} :catchall_2

    :goto_0
    monitor-exit p0

    .line 4
    iget-boolean v0, v1, Lh0/h;->j:Z

    if-eqz v0, :cond_f

    iget-object v0, v1, Lh0/h;->b:Landroid/content/Context;

    invoke-static {v0}, Landroid/preference/PreferenceManager;->getDefaultSharedPreferences(Landroid/content/Context;)Landroid/content/SharedPreferences;

    move-result-object v0

    iget-object v2, v1, Lh0/h;->d:Lf0/a;

    .line 5
    iget-object v2, v2, Lf0/a;->c:Lk0/a;

    .line 6
    new-instance v4, Landroid/content/IntentFilter;

    const-string v5, "tunnelVpnDisconnectBroadcast"

    invoke-direct {v4, v5}, Landroid/content/IntentFilter;-><init>(Ljava/lang/String;)V

    const-string v5, "tunnelVpnStartBroadcast"

    invoke-virtual {v4, v5}, Landroid/content/IntentFilter;->addAction(Ljava/lang/String;)V

    iget-object v5, v1, Lh0/h;->b:Landroid/content/Context;

    invoke-static {v5}, Lh/a;->a(Landroid/content/Context;)Lh/a;

    move-result-object v5

    iget-object v6, v1, Lh0/h;->n:Lh0/h$c;

    invoke-virtual {v5, v6, v4}, Lh/a;->b(Landroid/content/BroadcastReceiver;Landroid/content/IntentFilter;)V

    const-string v4, "127.0.0.1:%s"

    const/4 v5, 0x1

    new-array v6, v5, [Ljava/lang/Object;

    iget-object v7, v1, Lh0/h;->d:Lf0/a;

    const-string v8, "sshPortaLocal"

    invoke-virtual {v7, v8}, Lf0/a;->b(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v7

    aput-object v7, v6, v3

    invoke-static {v4, v6}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v9

    iget-object v4, v1, Lh0/h;->d:Lf0/a;

    .line 7
    iget-object v4, v4, Lf0/a;->b:Landroid/content/SharedPreferences;

    const-string v6, "dnsForward"

    invoke-interface {v4, v6, v5}, Landroid/content/SharedPreferences;->getBoolean(Ljava/lang/String;Z)Z

    move-result v10

    .line 8
    iget-object v4, v1, Lh0/h;->d:Lf0/a;

    .line 9
    iget-object v4, v4, Lf0/a;->b:Landroid/content/SharedPreferences;

    const-string v6, "auto_ping"

    invoke-interface {v4, v6, v5}, Landroid/content/SharedPreferences;->getBoolean(Ljava/lang/String;Z)Z

    .line 10
    iget-object v4, v1, Lh0/h;->d:Lf0/a;

    .line 11
    iget-object v4, v4, Lf0/a;->b:Landroid/content/SharedPreferences;

    const-string v6, "udpForward"

    invoke-interface {v4, v6, v5}, Landroid/content/SharedPreferences;->getBoolean(Ljava/lang/String;Z)Z

    .line 12
    iget-object v4, v1, Lh0/h;->d:Lf0/a;

    .line 13
    iget-object v4, v4, Lf0/a;->b:Landroid/content/SharedPreferences;

    const-string v6, "udpForward"

    invoke-interface {v4, v6, v5}, Landroid/content/SharedPreferences;->getBoolean(Ljava/lang/String;Z)Z

    move-result v4

    if-eqz v4, :cond_1

    .line 14
    iget-object v4, v1, Lh0/h;->d:Lf0/a;

    .line 15
    iget-object v4, v4, Lf0/a;->b:Landroid/content/SharedPreferences;

    const-string v6, "udpResolver"

    const-string v7, "127.0.0.1:7300"

    invoke-interface {v4, v6, v7}, Landroid/content/SharedPreferences;->getString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    goto :goto_1

    :cond_1
    const/4 v4, 0x0

    :goto_1
    move-object v13, v4

    .line 16
    iget-object v4, v1, Lh0/h;->d:Lf0/a;

    const-string v6, "sshServer"

    invoke-virtual {v4, v6}, Lf0/a;->b(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    const-string v6, "tunnelType"

    invoke-virtual {v2, v6, v5}, Lk0/a;->getInt(Ljava/lang/String;I)I

    move-result v2

    const/4 v6, 0x2

    if-ne v2, v6, :cond_2

    :try_start_4
    iget-object v2, v1, Lh0/h;->d:Lf0/a;

    const-string v4, "proxyRemoto"

    invoke-virtual {v2, v4}, Lf0/a;->b(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4
    :try_end_4
    .catch Ljava/lang/Exception; {:try_start_4 .. :try_end_4} :catch_0

    goto :goto_2

    :catch_0
    new-array v0, v3, [Ljava/lang/Object;

    const v2, 0x7f0b0013

    invoke-static {v2, v0}, Lg0/d;->j(I[Ljava/lang/Object;)V

    new-instance v0, Ljava/io/IOException;

    iget-object v3, v1, Lh0/h;->b:Landroid/content/Context;

    invoke-virtual {v3, v2}, Landroid/content/Context;->getString(I)Ljava/lang/String;

    move-result-object v2

    invoke-direct {v0, v2}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    throw v0

    :cond_2
    :goto_2
    :try_start_5
    invoke-static {v4}, Ls/i;->c(Ljava/lang/String;)Ljava/net/InetAddress;

    move-result-object v2

    invoke-virtual {v2}, Ljava/net/InetAddress;->getHostAddress()Ljava/lang/String;

    move-result-object v2
    :try_end_5
    .catch Ljava/lang/Exception; {:try_start_5 .. :try_end_5} :catch_3

    new-array v14, v5, [Ljava/lang/String;

    aput-object v2, v14, v3

    if-eqz v10, :cond_4

    iget-object v2, v1, Lh0/h;->d:Lf0/a;

    .line 17
    iget-object v2, v2, Lf0/a;->b:Landroid/content/SharedPreferences;

    const-string v4, "dnsResolver2"

    const-string v7, "8.8.4.4"

    invoke-interface {v2, v4, v7}, Landroid/content/SharedPreferences;->getString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    .line 18
    invoke-virtual {v2}, Ljava/lang/String;->isEmpty()Z

    move-result v2

    if-eqz v2, :cond_3

    new-array v2, v5, [Ljava/lang/String;

    iget-object v4, v1, Lh0/h;->d:Lf0/a;

    .line 19
    iget-object v4, v4, Lf0/a;->b:Landroid/content/SharedPreferences;

    const-string v6, "dnsResolver1"

    const-string v7, "8.8.8.8"

    invoke-interface {v4, v6, v7}, Landroid/content/SharedPreferences;->getString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    aput-object v4, v2, v3

    goto :goto_3

    :cond_3
    new-array v2, v6, [Ljava/lang/String;

    .line 20
    iget-object v4, v1, Lh0/h;->d:Lf0/a;

    .line 21
    iget-object v4, v4, Lf0/a;->b:Landroid/content/SharedPreferences;

    const-string v6, "dnsResolver1"

    const-string v7, "8.8.8.8"

    invoke-interface {v4, v6, v7}, Landroid/content/SharedPreferences;->getString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    aput-object v4, v2, v3

    .line 22
    iget-object v4, v1, Lh0/h;->d:Lf0/a;

    .line 23
    iget-object v4, v4, Lf0/a;->b:Landroid/content/SharedPreferences;

    const-string v6, "dnsResolver2"

    const-string v7, "8.8.4.4"

    invoke-interface {v4, v6, v7}, Landroid/content/SharedPreferences;->getString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    aput-object v4, v2, v5

    :goto_3
    move-object v11, v2

    goto :goto_5

    .line 24
    :cond_4
    iget-object v2, v1, Lh0/h;->b:Landroid/content/Context;

    sget v4, Li0/i;->a:I

    .line 25
    new-instance v4, Ljava/util/ArrayList;

    invoke-direct {v4}, Ljava/util/ArrayList;-><init>()V

    :try_start_6
    invoke-static {v2}, Li0/i;->a(Landroid/content/Context;)Ljava/util/List;

    move-result-object v4
    :try_end_6
    .catch Ljava/lang/Exception; {:try_start_6 .. :try_end_6} :catch_1

    goto :goto_4

    :catch_1
    const-string v2, "8.8.8.8"

    invoke-virtual {v4, v2}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    const-string v2, "8.8.4.4"

    invoke-virtual {v4, v2}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    :goto_4
    new-array v2, v5, [Ljava/lang/String;

    .line 26
    invoke-interface {v4, v3}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v4

    check-cast v4, Ljava/lang/String;

    aput-object v4, v2, v3

    goto :goto_3

    :goto_5
    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const-string v4, "set UDPGW: <strong>"

    invoke-virtual {v2, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2, v13}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v4, "</strong>"

    invoke-virtual {v2, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-static {v2}, Lg0/d;->k(Ljava/lang/String;)V

    const-string v2, "dnsResolver1"

    const-string v4, ""

    invoke-interface {v0, v2, v4}, Landroid/content/SharedPreferences;->getString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    const-string v4, "dnsResolver2"

    const-string v6, ""

    invoke-interface {v0, v4, v6}, Landroid/content/SharedPreferences;->getString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    new-instance v4, Ljava/lang/StringBuilder;

    invoke-direct {v4}, Ljava/lang/StringBuilder;-><init>()V

    const-string v6, "set Primary Dns: "

    invoke-virtual {v4, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v4, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-static {v2}, Lg0/d;->k(Ljava/lang/String;)V

    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const-string v4, "set Secondary Dns: "

    invoke-virtual {v2, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-static {v0}, Lg0/d;->k(Ljava/lang/String;)V

    invoke-static {}, Lh0/h;->g()Z

    move-result v0

    if-eqz v0, :cond_7

    const-string v0, "TMH err :"

    const-string v2, "already running service"

    invoke-static {v0, v2}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    invoke-static {}, Li0/e;->b()Li0/e;

    move-result-object v0

    invoke-virtual {v0}, Li0/e;->a()Li0/g;

    move-result-object v0

    if-eqz v0, :cond_c

    const-string v2, "TunnelManager"

    const-string v4, "Restarting tunnel."

    .line 27
    invoke-static {v2, v4}, Landroid/util/Log;->i(Ljava/lang/String;Ljava/lang/String;)I

    if-eqz v9, :cond_6

    iget-object v2, v0, Li0/g;->g:Li0/h;

    iget-object v2, v2, Li0/h;->a:Ljava/lang/String;

    invoke-virtual {v9, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v2

    if-eqz v2, :cond_5

    goto :goto_6

    :cond_5
    iget-object v2, v0, Li0/g;->g:Li0/h;

    iput-object v9, v2, Li0/h;->a:Ljava/lang/String;

    iget-object v2, v0, Li0/g;->f:Ljava/util/concurrent/atomic/AtomicBoolean;

    invoke-virtual {v2, v5}, Ljava/util/concurrent/atomic/AtomicBoolean;->set(Z)V

    invoke-virtual {v0}, Li0/g;->d()V

    goto/16 :goto_9

    :cond_6
    :goto_6
    iget-object v0, v0, Li0/g;->a:Lxyz/chz/injector/tunnel/vpn/TunnelVpnService;

    invoke-virtual {v0, v5}, Lxyz/chz/injector/tunnel/vpn/TunnelVpnService;->a(Z)V

    goto :goto_9

    .line 28
    :cond_7
    new-instance v0, Landroid/content/Intent;

    iget-object v2, v1, Lh0/h;->b:Landroid/content/Context;

    const-class v4, Lxyz/chz/injector/tunnel/vpn/TunnelVpnService;

    invoke-direct {v0, v2, v4}, Landroid/content/Intent;-><init>(Landroid/content/Context;Ljava/lang/Class;)V

    const/high16 v2, 0x10000000

    invoke-virtual {v0, v2}, Landroid/content/Intent;->setFlags(I)Landroid/content/Intent;

    new-instance v2, Li0/h;

    if-eqz v10, :cond_8

    if-eqz v13, :cond_9

    :cond_8
    if-nez v10, :cond_a

    if-eqz v13, :cond_a

    :cond_9
    const/4 v12, 0x1

    goto :goto_7

    :cond_a
    const/4 v12, 0x0

    :goto_7
    iget-object v4, v1, Lh0/h;->d:Lf0/a;

    .line 29
    iget-object v4, v4, Lf0/a;->b:Landroid/content/SharedPreferences;

    const-string v6, "filterApps"

    invoke-interface {v4, v6, v3}, Landroid/content/SharedPreferences;->getBoolean(Ljava/lang/String;Z)Z

    move-result v15

    .line 30
    iget-object v4, v1, Lh0/h;->d:Lf0/a;

    .line 31
    iget-object v4, v4, Lf0/a;->b:Landroid/content/SharedPreferences;

    const-string v6, "filterBypassMode"

    invoke-interface {v4, v6, v3}, Landroid/content/SharedPreferences;->getBoolean(Ljava/lang/String;Z)Z

    move-result v16

    .line 32
    iget-object v4, v1, Lh0/h;->d:Lf0/a;

    .line 33
    iget-object v4, v4, Lf0/a;->b:Landroid/content/SharedPreferences;

    const-string v6, "filterAppsList"

    const-string v7, ""

    invoke-interface {v4, v6, v7}, Landroid/content/SharedPreferences;->getString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v4}, Ljava/lang/String;->isEmpty()Z

    move-result v6

    if-eqz v6, :cond_b

    new-array v4, v3, [Ljava/lang/String;

    goto :goto_8

    :cond_b
    const-string v6, "\n"

    invoke-virtual {v4, v6}, Ljava/lang/String;->split(Ljava/lang/String;)[Ljava/lang/String;

    move-result-object v4

    :goto_8
    move-object/from16 v17, v4

    .line 34
    iget-object v4, v1, Lh0/h;->d:Lf0/a;

    .line 35
    iget-object v4, v4, Lf0/a;->b:Landroid/content/SharedPreferences;

    const-string v6, "tetherSubnet"

    invoke-interface {v4, v6, v3}, Landroid/content/SharedPreferences;->getBoolean(Ljava/lang/String;Z)Z

    move-result v18

    move-object v8, v2

    .line 36
    invoke-direct/range {v8 .. v18}, Li0/h;-><init>(Ljava/lang/String;Z[Ljava/lang/String;ZLjava/lang/String;[Ljava/lang/String;ZZ[Ljava/lang/String;Z)V

    const-string v4, "vpnSettings"

    invoke-virtual {v0, v4, v2}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Landroid/os/Parcelable;)Landroid/content/Intent;

    iget-object v2, v1, Lh0/h;->b:Landroid/content/Context;

    invoke-virtual {v2, v0}, Landroid/content/Context;->startService(Landroid/content/Intent;)Landroid/content/ComponentName;

    move-result-object v0

    if-eqz v0, :cond_e

    invoke-static {}, Li0/e;->b()Li0/e;

    move-result-object v2

    .line 37
    monitor-enter v2

    :try_start_7
    iput-boolean v5, v2, Li0/e;->b:Z
    :try_end_7
    .catchall {:try_start_7 .. :try_end_7} :catchall_0

    monitor-exit v2

    :cond_c
    :goto_9
    const-wide/16 v4, 0xbb8

    .line 38
    :try_start_8
    invoke-static {v4, v5}, Ljava/lang/Thread;->sleep(J)V
    :try_end_8
    .catch Ljava/lang/Exception; {:try_start_8 .. :try_end_8} :catch_2

    goto :goto_a

    :catch_2
    nop

    :goto_a
    iget-object v0, v1, Lh0/h;->d:Lf0/a;

    .line 39
    iget-object v0, v0, Lf0/a;->c:Lk0/a;

    const-string v2, "cbPinger"

    .line 40
    invoke-virtual {v0, v2, v3}, Lk0/a;->getBoolean(Ljava/lang/String;Z)Z

    move-result v0

    if-eqz v0, :cond_d

    new-instance v0, Lh0/b;

    iget-object v2, v1, Lh0/h;->i:Lm/c;

    invoke-direct {v0, v2}, Lh0/b;-><init>(Lm/c;)V

    iput-object v0, v1, Lh0/h;->g:Lh0/b;

    invoke-virtual {v0}, Ljava/lang/Thread;->start()V

    :cond_d
    return-void

    :catchall_0
    move-exception v0

    move-object v3, v0

    .line 41
    monitor-exit v2

    throw v3

    :cond_e
    const-string v0, "failed to start tunnel vpn service"

    .line 42
    invoke-static {v0}, Lg0/d;->k(Ljava/lang/String;)V

    new-instance v0, Ljava/io/IOException;

    const-string v2, "Vpn Service failed to start"

    invoke-direct {v0, v2}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    throw v0

    :catch_3
    new-instance v0, Ljava/io/IOException;

    iget-object v2, v1, Lh0/h;->b:Landroid/content/Context;

    const v3, 0x7f0b0016

    invoke-virtual {v2, v3}, Landroid/content/Context;->getString(I)Ljava/lang/String;

    move-result-object v2

    invoke-direct {v0, v2}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    throw v0

    :cond_f
    new-instance v0, Ljava/io/IOException;

    invoke-direct {v0}, Ljava/io/IOException;-><init>()V

    throw v0

    :catchall_1
    move-exception v0

    .line 43
    :try_start_9
    monitor-exit v2

    throw v0
    :try_end_9
    .catch Ljava/lang/Exception; {:try_start_9 .. :try_end_9} :catch_4
    .catchall {:try_start_9 .. :try_end_9} :catchall_2

    :catch_4
    move-exception v0

    .line 44
    :try_start_a
    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const-string v3, "Socks Local: "

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/Throwable;->getCause()Ljava/lang/Throwable;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/Throwable;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-static {v0}, Lg0/d;->e(Ljava/lang/String;)V

    new-instance v0, Ljava/lang/Exception;

    invoke-direct {v0}, Ljava/lang/Exception;-><init>()V

    throw v0

    :cond_10
    new-instance v0, Ljava/lang/Exception;

    invoke-direct {v0}, Ljava/lang/Exception;-><init>()V

    throw v0
    :try_end_a
    .catchall {:try_start_a .. :try_end_a} :catchall_2

    :catchall_2
    move-exception v0

    monitor-exit p0

    throw v0

    .line 45
    :cond_11
    new-instance v0, Ljava/lang/Exception;

    invoke-direct {v0}, Ljava/lang/Exception;-><init>()V

    throw v0
.end method

.method public final k()V
    .locals 3

    iget-boolean v0, p0, Lh0/h;->e:Z

    if-eqz v0, :cond_0

    return-void

    :cond_0
    iget-object v0, p0, Lh0/h;->b:Landroid/content/Context;

    const v1, 0x7f0b0045

    invoke-virtual {v0, v1}, Landroid/content/Context;->getString(I)Ljava/lang/String;

    move-result-object v0

    const-string v2, "PARANDO"

    invoke-static {v2, v0}, Lg0/d;->n(Ljava/lang/String;Ljava/lang/String;)V

    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const-string v2, "<strong>"

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object v2, p0, Lh0/h;->b:Landroid/content/Context;

    invoke-virtual {v2, v1}, Landroid/content/Context;->getString(I)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v1, "</strong>"

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-static {v0}, Lg0/d;->k(Ljava/lang/String;)V

    new-instance v0, Ljava/lang/Thread;

    new-instance v1, Lh0/h$a;

    invoke-direct {v1, p0}, Lh0/h$a;-><init>(Lh0/h;)V

    invoke-direct {v0, v1}, Ljava/lang/Thread;-><init>(Ljava/lang/Runnable;)V

    invoke-virtual {v0}, Ljava/lang/Thread;->start()V

    return-void
.end method

.method public final l()V
    .locals 2

    .line 1
    monitor-enter p0

    :try_start_0
    invoke-static {}, Lh0/h;->g()Z

    move-result v0

    if-nez v0, :cond_0

    goto :goto_0

    :cond_0
    invoke-static {}, Li0/e;->b()Li0/e;

    move-result-object v0

    invoke-virtual {v0}, Li0/e;->a()Li0/g;

    move-result-object v0

    if-eqz v0, :cond_1

    invoke-virtual {v0}, Li0/g;->d()V

    :cond_1
    iget-object v0, p0, Lh0/h;->b:Landroid/content/Context;

    invoke-static {v0}, Lh/a;->a(Landroid/content/Context;)Lh/a;

    move-result-object v0

    iget-object v1, p0, Lh0/h;->n:Lh0/h$c;

    invoke-virtual {v0, v1}, Lh/a;->d(Landroid/content/BroadcastReceiver;)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_1

    :goto_0
    monitor-exit p0

    .line 2
    monitor-enter p0

    :try_start_1
    iget-object v0, p0, Lh0/h;->l:Lm/e;
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    if-eqz v0, :cond_2

    .line 3
    :try_start_2
    iget-object v0, v0, Lm/e;->b:Ljava/lang/Object;

    check-cast v0, Lo/e;

    invoke-virtual {v0}, Lo/e;->a()V
    :try_end_2
    .catch Ljava/io/IOException; {:try_start_2 .. :try_end_2} :catch_0
    .catchall {:try_start_2 .. :try_end_2} :catchall_0

    :catch_0
    const/4 v0, 0x0

    .line 4
    :try_start_3
    iput-object v0, p0, Lh0/h;->l:Lm/e;
    :try_end_3
    .catchall {:try_start_3 .. :try_end_3} :catchall_0

    :cond_2
    monitor-exit p0

    return-void

    :catchall_0
    move-exception v0

    monitor-exit p0

    throw v0

    :catchall_1
    move-exception v0

    .line 5
    monitor-exit p0

    throw v0
.end method

.method public final m(Ljava/lang/String;Ljava/lang/String;[B)V
    .locals 8

    const-string v0, "md5"

    .line 1
    invoke-static {v0, p2, p3}, Lm/h;->a(Ljava/lang/String;Ljava/lang/String;[B)[B

    move-result-object v0

    const-string v1, "0123456789abcdef"

    .line 2
    invoke-virtual {v1}, Ljava/lang/String;->toCharArray()[C

    move-result-object v1

    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v3, 0x0

    const/4 v4, 0x0

    :goto_0
    array-length v5, v0

    if-ge v4, v5, :cond_1

    if-eqz v4, :cond_0

    const/16 v5, 0x3a

    invoke-virtual {v2, v5}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    :cond_0
    aget-byte v5, v0, v4

    and-int/lit16 v5, v5, 0xff

    shr-int/lit8 v6, v5, 0x4

    aget-char v6, v1, v6

    invoke-virtual {v2, v6}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    and-int/lit8 v5, v5, 0xf

    aget-char v5, v1, v5

    invoke-virtual {v2, v5}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    add-int/lit8 v4, v4, 0x1

    goto :goto_0

    :cond_1
    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    .line 3
    new-instance v1, Lcom/trilead/ssh2/crypto/digest/SHA1;

    invoke-direct {v1}, Lcom/trilead/ssh2/crypto/digest/SHA1;-><init>()V

    const/16 v1, 0x14

    new-array v2, v1, [B

    sget-object v4, Lm/h;->a:Ljava/security/SecureRandom;

    invoke-virtual {v4, v2}, Ljava/security/SecureRandom;->nextBytes([B)V

    .line 4
    new-instance v4, Lcom/trilead/ssh2/crypto/digest/MessageMac;

    const-string v5, "hmac-sha1"

    invoke-direct {v4, v5, v2}, Lcom/trilead/ssh2/crypto/digest/MessageMac;-><init>(Ljava/lang/String;[B)V

    :try_start_0
    const-string v5, "ISO-8859-1"

    invoke-virtual {p1, v5}, Ljava/lang/String;->getBytes(Ljava/lang/String;)[B

    move-result-object v5

    array-length v6, v5

    invoke-virtual {v4, v5, v6}, Lcom/trilead/ssh2/crypto/digest/MessageMac;->d([BI)V
    :try_end_0
    .catch Ljava/io/UnsupportedEncodingException; {:try_start_0 .. :try_end_0} :catch_0

    goto :goto_1

    :catch_0
    invoke-virtual {p1}, Ljava/lang/String;->getBytes()[B

    move-result-object p1

    array-length v5, p1

    invoke-virtual {v4, p1, v5}, Lcom/trilead/ssh2/crypto/digest/MessageMac;->d([BI)V

    :goto_1
    new-array p1, v1, [B

    invoke-virtual {v4, p1}, Lcom/trilead/ssh2/crypto/digest/MessageMac;->a([B)V

    .line 5
    new-instance v1, Ljava/lang/String;

    invoke-static {v2}, Lcom/trilead/ssh2/crypto/Base64;->a([B)[C

    move-result-object v2

    invoke-direct {v1, v2}, Ljava/lang/String;-><init>([C)V

    new-instance v1, Ljava/lang/String;

    invoke-static {p1}, Lcom/trilead/ssh2/crypto/Base64;->a([B)[C

    move-result-object p1

    invoke-direct {v1, p1}, Ljava/lang/String;-><init>([C)V

    const-string p1, "sha1"

    .line 6
    invoke-static {p1, p2, p3}, Lm/h;->a(Ljava/lang/String;Ljava/lang/String;[B)[B

    move-result-object p1

    const-string p3, "aeiouy"

    .line 7
    invoke-virtual {p3}, Ljava/lang/String;->toCharArray()[C

    move-result-object p3

    const-string v1, "bcdfghklmnprstvzx"

    invoke-virtual {v1}, Ljava/lang/String;->toCharArray()[C

    move-result-object v1

    array-length v2, p1

    div-int/lit8 v2, v2, 0x2

    const/4 v4, 0x1

    add-int/2addr v2, v4

    :goto_2
    if-ge v3, v2, :cond_5

    add-int/lit8 v5, v3, 0x1

    if-lt v5, v2, :cond_3

    array-length v6, p1

    rem-int/lit8 v6, v6, 0x2

    if-eqz v6, :cond_2

    goto :goto_3

    :cond_2
    rem-int/lit8 v3, v4, 0x6

    aget-char v3, p3, v3

    div-int/lit8 v3, v4, 0x6

    aget-char v3, p3, v3

    goto :goto_4

    :cond_3
    :goto_3
    mul-int/lit8 v3, v3, 0x2

    aget-byte v6, p1, v3

    shr-int/lit8 v6, v6, 0x6

    and-int/lit8 v6, v6, 0x3

    add-int/2addr v6, v4

    rem-int/lit8 v6, v6, 0x6

    aget-char v6, p3, v6

    aget-byte v6, p1, v3

    shr-int/lit8 v6, v6, 0x2

    and-int/lit8 v6, v6, 0xf

    aget-char v6, v1, v6

    aget-byte v6, p1, v3

    and-int/lit8 v6, v6, 0x3

    div-int/lit8 v7, v4, 0x6

    add-int/2addr v7, v6

    rem-int/lit8 v7, v7, 0x6

    aget-char v6, p3, v7

    if-ge v5, v2, :cond_4

    add-int/lit8 v6, v3, 0x1

    aget-byte v7, p1, v6

    shr-int/lit8 v7, v7, 0x4

    and-int/lit8 v7, v7, 0xf

    aget-char v7, v1, v7

    aget-byte v7, p1, v6

    and-int/lit8 v7, v7, 0xf

    aget-char v7, v1, v7

    mul-int/lit8 v4, v4, 0x5

    aget-byte v3, p1, v3

    and-int/lit16 v3, v3, 0xff

    mul-int/lit8 v3, v3, 0x7

    aget-byte v6, p1, v6

    and-int/lit16 v6, v6, 0xff

    add-int/2addr v3, v6

    add-int/2addr v3, v4

    rem-int/lit8 v3, v3, 0x24

    move v4, v3

    :cond_4
    :goto_4
    move v3, v5

    goto :goto_2

    .line 8
    :cond_5
    new-instance p1, Ljava/lang/StringBuffer;

    invoke-direct {p1}, Ljava/lang/StringBuffer;-><init>()V

    const-string p3, "Using algorithm: "

    invoke-virtual {p1, p3}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    invoke-virtual {p1, p2}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    const-string p2, " fingerprint: "

    invoke-virtual {p1, p2}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    invoke-virtual {p1, v0}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    invoke-virtual {p1}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object p1

    invoke-static {p1}, Lg0/d;->k(Ljava/lang/String;)V

    return-void
.end method

.method public final run()V
    .locals 9

    const/4 v0, 0x1

    iput-boolean v0, p0, Lh0/h;->f:Z

    new-instance v1, Ljava/util/concurrent/CountDownLatch;

    invoke-direct {v1, v0}, Ljava/util/concurrent/CountDownLatch;-><init>(I)V

    iput-object v1, p0, Lh0/h;->h:Ljava/util/concurrent/CountDownLatch;

    const-string v0, "<strong>"

    .line 1
    invoke-static {v0}, Lcom/trilead/ssh2/crypto/digest/a;->e(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    .line 2
    iget-object v2, p0, Lh0/h;->b:Landroid/content/Context;

    const v3, 0x7f0b0028

    invoke-virtual {v2, v3}, Landroid/content/Context;->getString(I)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v2, "</strong>"

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-static {v1}, Lg0/d;->k(Ljava/lang/String;)V

    const/4 v1, 0x0

    const/4 v3, 0x0

    :goto_0
    iget-boolean v4, p0, Lh0/h;->e:Z

    if-nez v4, :cond_4

    const-wide/16 v4, 0x1f4

    :try_start_0
    iget-object v6, p0, Lh0/h;->b:Landroid/content/Context;

    invoke-static {v6}, Lh0/i;->e(Landroid/content/Context;)Z

    move-result v6

    if-nez v6, :cond_0

    const-string v6, "AGUARDANDO"

    iget-object v7, p0, Lh0/h;->b:Landroid/content/Context;

    const v8, 0x7f0b0034

    invoke-virtual {v7, v8}, Landroid/content/Context;->getString(I)Ljava/lang/String;

    move-result-object v7

    invoke-static {v6, v7}, Lg0/d;->n(Ljava/lang/String;Ljava/lang/String;)V

    new-array v6, v1, [Ljava/lang/Object;

    invoke-static {v8, v6}, Lg0/d;->j(I[Ljava/lang/Object;)V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_1

    const-wide/16 v6, 0x1388

    :try_start_1
    invoke-static {v6, v7}, Ljava/lang/Thread;->sleep(J)V
    :try_end_1
    .catch Ljava/lang/InterruptedException; {:try_start_1 .. :try_end_1} :catch_0
    .catch Ljava/lang/Exception; {:try_start_1 .. :try_end_1} :catch_1

    goto :goto_2

    :cond_0
    if-lez v3, :cond_1

    :try_start_2
    new-instance v6, Ljava/lang/StringBuilder;

    invoke-direct {v6}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v6, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object v7, p0, Lh0/h;->b:Landroid/content/Context;

    const v8, 0x7f0b0038

    invoke-virtual {v7, v8}, Landroid/content/Context;->getString(I)Ljava/lang/String;

    move-result-object v7

    invoke-virtual {v6, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v6, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v6}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v6

    invoke-static {v6}, Lg0/d;->k(Ljava/lang/String;)V
    :try_end_2
    .catch Ljava/lang/Exception; {:try_start_2 .. :try_end_2} :catch_1

    :cond_1
    :try_start_3
    invoke-static {v4, v5}, Ljava/lang/Thread;->sleep(J)V
    :try_end_3
    .catch Ljava/lang/InterruptedException; {:try_start_3 .. :try_end_3} :catch_0
    .catch Ljava/lang/Exception; {:try_start_3 .. :try_end_3} :catch_1

    :try_start_4
    invoke-virtual {p0}, Lh0/h;->i()V

    goto :goto_3

    :catch_0
    invoke-virtual {p0}, Lh0/h;->k()V
    :try_end_4
    .catch Ljava/lang/Exception; {:try_start_4 .. :try_end_4} :catch_1

    goto :goto_3

    :catch_1
    nop

    const-string v6, "<strong><font color=\'red\'>"

    .line 3
    invoke-static {v6}, Lcom/trilead/ssh2/crypto/digest/a;->e(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v6

    .line 4
    iget-object v7, p0, Lh0/h;->b:Landroid/content/Context;

    const v8, 0x7f0b0032

    invoke-virtual {v7, v8}, Landroid/content/Context;->getString(I)Ljava/lang/String;

    move-result-object v7

    invoke-virtual {v6, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v7, "</font></strong>"

    invoke-virtual {v6, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v6}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v6

    invoke-static {v6}, Lg0/d;->e(Ljava/lang/String;)V

    invoke-virtual {p0}, Lh0/h;->e()V

    .line 5
    sget-object v6, Lh0/e;->e:Ljava/net/Socket;

    if-eqz v6, :cond_2

    :try_start_5
    invoke-virtual {v6}, Ljava/net/Socket;->close()V
    :try_end_5
    .catch Ljava/io/IOException; {:try_start_5 .. :try_end_5} :catch_2

    goto :goto_1

    :catch_2
    nop

    :cond_2
    :goto_1
    sget-object v6, Lh0/d;->d:Ljava/net/Socket;

    if-eqz v6, :cond_3

    :try_start_6
    invoke-virtual {v6}, Ljava/net/Socket;->close()V
    :try_end_6
    .catch Ljava/io/IOException; {:try_start_6 .. :try_end_6} :catch_3

    .line 6
    :catch_3
    :cond_3
    :try_start_7
    invoke-static {v4, v5}, Ljava/lang/Thread;->sleep(J)V
    :try_end_7
    .catch Ljava/lang/InterruptedException; {:try_start_7 .. :try_end_7} :catch_4

    :goto_2
    add-int/lit8 v3, v3, 0x1

    goto/16 :goto_0

    :catch_4
    invoke-virtual {p0}, Lh0/h;->k()V

    :cond_4
    :goto_3
    iput-boolean v1, p0, Lh0/h;->f:Z

    iget-boolean v0, p0, Lh0/h;->e:Z

    if-nez v0, :cond_5

    :try_start_8
    iget-object v0, p0, Lh0/h;->h:Ljava/util/concurrent/CountDownLatch;

    invoke-virtual {v0}, Ljava/util/concurrent/CountDownLatch;->await()V
    :try_end_8
    .catch Ljava/lang/InterruptedException; {:try_start_8 .. :try_end_8} :catch_5

    goto :goto_4

    :catch_5
    invoke-static {}, Ljava/lang/Thread;->currentThread()Ljava/lang/Thread;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/Thread;->interrupt()V

    :cond_5
    :goto_4
    iget-object v0, p0, Lh0/h;->a:Lh0/h$d;

    if-eqz v0, :cond_6

    check-cast v0, Lc0/b;

    .line 7
    iget-object v0, v0, Lc0/b;->a:Lxyz/chz/injector/HttpService;

    invoke-virtual {v0}, Lxyz/chz/injector/HttpService;->b()V

    :cond_6
    return-void
.end method
