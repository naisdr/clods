.class public final Lo/k;
.super Ljava/lang/Thread;
.source "SourceFile"


# static fields
.field public static final c:La/b;


# instance fields
.field public a:Lo/a;

.field public b:Ljava/net/Socket;


# direct methods
.method public static constructor <clinit>()V
    .locals 2

    const-class v0, Lo/k;

    .line 1
    new-instance v1, La/b;

    invoke-direct {v1, v0}, La/b;-><init>(Ljava/lang/Class;)V

    .line 2
    sput-object v1, Lo/k;->c:La/b;

    return-void
.end method

.method public constructor <init>(Lo/a;)V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Thread;-><init>()V

    iput-object p1, p0, Lo/k;->a:Lo/a;

    return-void
.end method


# virtual methods
.method public final run()V
    .locals 15

    :try_start_0
    iget-object v0, p0, Lo/k;->a:Lo/a;

    iget-object v1, v0, Lo/a;->b:Lo/c;

    invoke-virtual {v1, v0}, Lo/c;->s(Lo/a;)V

    iget-object v0, p0, Lo/k;->a:Lo/a;

    .line 1
    iget-object v6, v0, Lo/a;->c:Lo/d;

    .line 2
    iget-object v0, v0, Lo/a;->d:Lo/a$a;

    iget-object v11, v0, Lo/a$a;->a:Lo/b;

    const/4 v0, 0x6

    new-array v1, v0, [B

    .line 3
    invoke-static {v11}, Ljava/util/Objects;->requireNonNull(Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v2, 0x0

    .line 4
    invoke-virtual {v11, v1, v2, v0}, Lo/b;->read([BII)I

    move-result v3

    if-ne v3, v0, :cond_10

    aget-byte v3, v1, v2

    const/16 v4, 0x42

    if-eq v3, v4, :cond_1

    aget-byte v3, v1, v2

    const/16 v5, 0x6c

    if-ne v3, v5, :cond_0

    goto :goto_0

    .line 5
    :cond_0
    new-instance v0, Ljava/io/IOException;

    const-string v1, "Unknown endian format in X11 message!"

    invoke-direct {v0, v1}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    throw v0

    :cond_1
    :goto_0
    aget-byte v3, v1, v2

    const/4 v14, 0x1

    if-ne v3, v4, :cond_2

    const/4 v3, 0x0

    goto :goto_1

    :cond_2
    const/4 v3, 0x1

    :goto_1
    new-array v4, v0, [B

    .line 6
    invoke-virtual {v11, v4, v2, v0}, Lo/b;->read([BII)I

    move-result v5

    if-ne v5, v0, :cond_f

    .line 7
    aget-byte v5, v4, v3

    and-int/lit16 v5, v5, 0xff

    shl-int/lit8 v5, v5, 0x8

    rsub-int/lit8 v7, v3, 0x1

    aget-byte v7, v4, v7

    and-int/lit16 v7, v7, 0xff

    or-int/2addr v5, v7

    add-int/lit8 v7, v3, 0x2

    aget-byte v7, v4, v7

    and-int/lit16 v7, v7, 0xff

    shl-int/lit8 v7, v7, 0x8

    rsub-int/lit8 v3, v3, 0x3

    aget-byte v3, v4, v3

    and-int/lit16 v3, v3, 0xff

    or-int/2addr v3, v7

    const/16 v4, 0x100

    if-gt v5, v4, :cond_e

    if-gt v3, v4, :cond_e

    rem-int/lit8 v4, v5, 0x4

    const/4 v7, 0x4

    rsub-int/lit8 v4, v4, 0x4

    rem-int/2addr v4, v7

    rem-int/lit8 v8, v3, 0x4

    rsub-int/lit8 v8, v8, 0x4

    rem-int/2addr v8, v7

    new-array v9, v5, [B

    new-array v10, v3, [B

    new-array v7, v7, [B

    .line 8
    invoke-virtual {v11, v9, v2, v5}, Lo/b;->read([BII)I

    move-result v12

    if-ne v12, v5, :cond_d

    .line 9
    invoke-virtual {v11, v7, v2, v4}, Lo/b;->read([BII)I

    move-result v5

    if-ne v5, v4, :cond_c

    .line 10
    invoke-virtual {v11, v10, v2, v3}, Lo/b;->read([BII)I

    move-result v4

    if-ne v4, v3, :cond_b

    .line 11
    invoke-virtual {v11, v7, v2, v8}, Lo/b;->read([BII)I

    move-result v4

    if-ne v4, v8, :cond_a

    const-string v4, "MIT-MAGIC-COOKIE-1"

    new-instance v5, Ljava/lang/String;

    const-string v7, "ISO-8859-1"

    invoke-direct {v5, v9, v7}, Ljava/lang/String;-><init>([BLjava/lang/String;)V

    invoke-virtual {v4, v5}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v4

    if-eqz v4, :cond_9

    const/16 v4, 0x10

    if-ne v3, v4, :cond_8

    new-instance v4, Ljava/lang/StringBuffer;

    const/16 v5, 0x20

    invoke-direct {v4, v5}, Ljava/lang/StringBuffer;-><init>(I)V

    const/4 v5, 0x0

    :goto_2
    if-ge v5, v3, :cond_4

    aget-byte v7, v10, v5

    and-int/lit16 v7, v7, 0xff

    invoke-static {v7}, Ljava/lang/Integer;->toHexString(I)Ljava/lang/String;

    move-result-object v7

    invoke-virtual {v7}, Ljava/lang/String;->length()I

    move-result v8

    const/4 v9, 0x2

    if-ne v8, v9, :cond_3

    goto :goto_3

    :cond_3
    new-instance v8, Ljava/lang/StringBuilder;

    invoke-direct {v8}, Ljava/lang/StringBuilder;-><init>()V

    const-string v9, "0"

    invoke-virtual {v8, v9}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v8, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v8}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v7

    :goto_3
    invoke-virtual {v4, v7}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    add-int/lit8 v5, v5, 0x1

    goto :goto_2

    :cond_4
    invoke-virtual {v4}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object v3

    iget-object v4, p0, Lo/k;->a:Lo/a;

    monitor-enter v4
    :try_end_0
    .catch Ljava/io/IOException; {:try_start_0 .. :try_end_0} :catch_1

    :try_start_1
    iget-object v5, p0, Lo/k;->a:Lo/a;

    invoke-static {v5}, Ljava/util/Objects;->requireNonNull(Ljava/lang/Object;)Ljava/lang/Object;

    monitor-exit v4
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_1

    :try_start_2
    iget-object v4, p0, Lo/k;->a:Lo/a;

    iget-object v4, v4, Lo/a;->b:Lo/c;

    .line 12
    iget-object v5, v4, Lo/c;->a:Ljava/util/HashMap;

    monitor-enter v5
    :try_end_2
    .catch Ljava/io/IOException; {:try_start_2 .. :try_end_2} :catch_1

    const/4 v7, 0x0

    if-eqz v3, :cond_5

    :try_start_3
    iget-object v4, v4, Lo/c;->a:Ljava/util/HashMap;

    invoke-virtual {v4, v3}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Lo/m;

    monitor-exit v5

    goto :goto_4

    :cond_5
    monitor-exit v5
    :try_end_3
    .catchall {:try_start_3 .. :try_end_3} :catchall_0

    move-object v3, v7

    :goto_4
    if-eqz v3, :cond_7

    .line 13
    :try_start_4
    new-instance v3, Ljava/net/Socket;

    invoke-direct {v3, v7, v2}, Ljava/net/Socket;-><init>(Ljava/lang/String;I)V

    iput-object v3, p0, Lo/k;->b:Ljava/net/Socket;

    invoke-virtual {v3}, Ljava/net/Socket;->getOutputStream()Ljava/io/OutputStream;

    move-result-object v12

    iget-object v2, p0, Lo/k;->b:Ljava/net/Socket;

    invoke-virtual {v2}, Ljava/net/Socket;->getInputStream()Ljava/io/InputStream;

    move-result-object v5

    invoke-virtual {v12, v1}, Ljava/io/OutputStream;->write([B)V

    new-array v0, v0, [B

    invoke-virtual {v12, v0}, Ljava/io/OutputStream;->write([B)V

    invoke-virtual {v12}, Ljava/io/OutputStream;->flush()V

    new-instance v0, Lo/l;

    iget-object v8, p0, Lo/k;->a:Lo/a;

    const/4 v9, 0x0

    const/4 v10, 0x0

    const-string v13, "RemoteToX11"

    move-object v7, v0

    invoke-direct/range {v7 .. v13}, Lo/l;-><init>(Lo/a;Lo/l;Ljava/net/Socket;Ljava/io/InputStream;Ljava/io/OutputStream;Ljava/lang/String;)V

    new-instance v8, Lo/l;

    iget-object v2, p0, Lo/k;->a:Lo/a;

    const/4 v3, 0x0

    const/4 v4, 0x0

    const-string v7, "X11ToRemote"

    move-object v1, v8

    invoke-direct/range {v1 .. v7}, Lo/l;-><init>(Lo/a;Lo/l;Ljava/net/Socket;Ljava/io/InputStream;Ljava/io/OutputStream;Ljava/lang/String;)V

    invoke-virtual {v0, v14}, Ljava/lang/Thread;->setDaemon(Z)V

    invoke-virtual {v0}, Ljava/lang/Thread;->start()V

    invoke-virtual {v8}, Lo/l;->run()V

    :goto_5
    invoke-virtual {v0}, Ljava/lang/Thread;->isAlive()Z

    move-result v1
    :try_end_4
    .catch Ljava/io/IOException; {:try_start_4 .. :try_end_4} :catch_1

    if-eqz v1, :cond_6

    :try_start_5
    invoke-virtual {v0}, Ljava/lang/Thread;->join()V
    :try_end_5
    .catch Ljava/lang/InterruptedException; {:try_start_5 .. :try_end_5} :catch_0
    .catch Ljava/io/IOException; {:try_start_5 .. :try_end_5} :catch_1

    goto :goto_5

    :catch_0
    :try_start_6
    new-instance v0, Ljava/io/InterruptedIOException;

    invoke-direct {v0}, Ljava/io/InterruptedIOException;-><init>()V

    throw v0

    :cond_6
    iget-object v0, p0, Lo/k;->a:Lo/a;

    iget-object v1, v0, Lo/a;->b:Lo/c;

    const-string v2, "EOF on both X11 streams reached."

    invoke-virtual {v1, v0, v2}, Lo/c;->e(Lo/a;Ljava/lang/String;)V

    iget-object v0, p0, Lo/k;->b:Ljava/net/Socket;

    invoke-virtual {v0}, Ljava/net/Socket;->close()V

    goto/16 :goto_6

    :cond_7
    new-instance v0, Ljava/io/IOException;

    const-string v1, "Invalid X11 cookie received."

    invoke-direct {v0, v1}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    throw v0
    :try_end_6
    .catch Ljava/io/IOException; {:try_start_6 .. :try_end_6} :catch_1

    :catchall_0
    move-exception v0

    .line 14
    :try_start_7
    monitor-exit v5
    :try_end_7
    .catchall {:try_start_7 .. :try_end_7} :catchall_0

    :try_start_8
    throw v0
    :try_end_8
    .catch Ljava/io/IOException; {:try_start_8 .. :try_end_8} :catch_1

    :catchall_1
    move-exception v0

    .line 15
    :try_start_9
    monitor-exit v4
    :try_end_9
    .catchall {:try_start_9 .. :try_end_9} :catchall_1

    :try_start_a
    throw v0

    :cond_8
    new-instance v0, Ljava/io/IOException;

    const-string v1, "Wrong data length for X11 authorization data!"

    invoke-direct {v0, v1}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    throw v0

    :cond_9
    new-instance v0, Ljava/io/IOException;

    const-string v1, "Unknown X11 authorization protocol!"

    invoke-direct {v0, v1}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    throw v0

    :cond_a
    new-instance v0, Ljava/io/IOException;

    const-string v1, "Unexpected EOF on X11 startup! (authProtocolDataPadding)"

    invoke-direct {v0, v1}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    throw v0

    :cond_b
    new-instance v0, Ljava/io/IOException;

    const-string v1, "Unexpected EOF on X11 startup! (authProtocolData)"

    invoke-direct {v0, v1}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    throw v0

    :cond_c
    new-instance v0, Ljava/io/IOException;

    const-string v1, "Unexpected EOF on X11 startup! (authProtocolNamePadding)"

    invoke-direct {v0, v1}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    throw v0

    :cond_d
    new-instance v0, Ljava/io/IOException;

    const-string v1, "Unexpected EOF on X11 startup! (authProtocolName)"

    invoke-direct {v0, v1}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    throw v0

    :cond_e
    new-instance v0, Ljava/io/IOException;

    const-string v1, "Buggy X11 authorization data"

    invoke-direct {v0, v1}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    throw v0

    :cond_f
    new-instance v0, Ljava/io/IOException;

    const-string v1, "Unexpected EOF on X11 startup!"

    invoke-direct {v0, v1}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    throw v0

    :cond_10
    new-instance v0, Ljava/io/IOException;

    const-string v1, "Unexpected EOF on X11 startup!"

    invoke-direct {v0, v1}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    throw v0
    :try_end_a
    .catch Ljava/io/IOException; {:try_start_a .. :try_end_a} :catch_1

    :catch_1
    move-exception v0

    sget-object v1, Lo/k;->c:La/b;

    invoke-static {v1}, Ljava/util/Objects;->requireNonNull(Ljava/lang/Object;)Ljava/lang/Object;

    .line 16
    invoke-static {v0}, Ljava/util/Objects;->toString(Ljava/lang/Object;)Ljava/lang/String;

    .line 17
    :try_start_b
    iget-object v1, p0, Lo/k;->a:Lo/a;

    iget-object v2, v1, Lo/a;->b:Lo/c;

    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    const-string v4, "IOException in X11 proxy code ("

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v3, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v0, ")"

    invoke-virtual {v3, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v2, v1, v0}, Lo/c;->e(Lo/a;Ljava/lang/String;)V
    :try_end_b
    .catch Ljava/io/IOException; {:try_start_b .. :try_end_b} :catch_2

    :catch_2
    :try_start_c
    iget-object v0, p0, Lo/k;->b:Ljava/net/Socket;

    if-eqz v0, :cond_11

    invoke-virtual {v0}, Ljava/net/Socket;->close()V
    :try_end_c
    .catch Ljava/io/IOException; {:try_start_c .. :try_end_c} :catch_3

    :catch_3
    :cond_11
    :goto_6
    return-void
.end method
