.class public final Lxyz/chz/injector/HttpService$b;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lxyz/chz/injector/HttpService;->onStartCommand(Landroid/content/Intent;II)I
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1
    name = null
.end annotation


# instance fields
.field public final synthetic a:Lxyz/chz/injector/HttpService;


# direct methods
.method public constructor <init>(Lxyz/chz/injector/HttpService;)V
    .locals 0

    iput-object p1, p0, Lxyz/chz/injector/HttpService$b;->a:Lxyz/chz/injector/HttpService;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final run()V
    .locals 4

    iget-object v0, p0, Lxyz/chz/injector/HttpService$b;->a:Lxyz/chz/injector/HttpService;

    .line 1
    monitor-enter v0

    :try_start_0
    const-string v1, "INICIANDO"

    const v2, 0x7f0b0028

    invoke-virtual {v0, v2}, Landroid/content/Context;->getString(I)Ljava/lang/String;

    move-result-object v2

    invoke-static {v1, v2}, Lg0/d;->n(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v1, 0x1

    invoke-virtual {v0}, Lxyz/chz/injector/HttpService;->d()V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    :try_start_1
    iget-object v2, v0, Lxyz/chz/injector/HttpService;->c:Lf0/a;

    .line 2
    iget-object v2, v2, Lf0/a;->c:Lk0/a;

    const-string v3, "tunnelType"

    .line 3
    invoke-virtual {v2, v3, v1}, Lk0/a;->getInt(Ljava/lang/String;I)I

    new-instance v1, Lh0/h;

    iget-object v2, v0, Lxyz/chz/injector/HttpService;->b:Landroid/os/Handler;

    invoke-direct {v1, v2, v0}, Lh0/h;-><init>(Landroid/os/Handler;Landroid/content/Context;)V

    iput-object v1, v0, Lxyz/chz/injector/HttpService;->e:Lh0/h;

    new-instance v2, Lc0/b;

    invoke-direct {v2, v0}, Lc0/b;-><init>(Lxyz/chz/injector/HttpService;)V

    .line 4
    iput-object v2, v1, Lh0/h;->a:Lh0/h$d;

    .line 5
    new-instance v1, Ljava/lang/Thread;

    iget-object v2, v0, Lxyz/chz/injector/HttpService;->e:Lh0/h;

    invoke-direct {v1, v2}, Ljava/lang/Thread;-><init>(Ljava/lang/Runnable;)V

    iput-object v1, v0, Lxyz/chz/injector/HttpService;->d:Ljava/lang/Thread;

    invoke-virtual {v1}, Ljava/lang/Thread;->start()V
    :try_end_1
    .catch Ljava/lang/Exception; {:try_start_1 .. :try_end_1} :catch_0
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    goto :goto_0

    :catch_0
    move-exception v1

    const/4 v2, 0x0

    .line 6
    :try_start_2
    invoke-static {v2, v1}, Lg0/d;->f(Ljava/lang/String;Ljava/lang/Exception;)V

    .line 7
    invoke-virtual {v0}, Lxyz/chz/injector/HttpService;->b()V
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_0

    :goto_0
    monitor-exit v0

    return-void

    :catchall_0
    move-exception v1

    monitor-exit v0

    throw v1
.end method
