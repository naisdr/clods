.class public Lcom/trilead/ssh2/crypto/cipher/CipherInputStream;
.super Ljava/lang/Object;
.source "SourceFile"


# instance fields
.field public a:Lcom/trilead/ssh2/crypto/cipher/BlockCipher;

.field public b:Ljava/io/InputStream;

.field public c:[B

.field public d:[B

.field public e:I

.field public f:I

.field public g:[B

.field public h:I

.field public i:I


# direct methods
.method public constructor <init>(Lcom/trilead/ssh2/crypto/cipher/BlockCipher;Ljava/io/InputStream;)V
    .locals 1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/16 v0, 0x800

    new-array v0, v0, [B

    iput-object v0, p0, Lcom/trilead/ssh2/crypto/cipher/CipherInputStream;->g:[B

    const/4 v0, 0x0

    iput v0, p0, Lcom/trilead/ssh2/crypto/cipher/CipherInputStream;->h:I

    iput v0, p0, Lcom/trilead/ssh2/crypto/cipher/CipherInputStream;->i:I

    iput-object p2, p0, Lcom/trilead/ssh2/crypto/cipher/CipherInputStream;->b:Ljava/io/InputStream;

    .line 1
    iput-object p1, p0, Lcom/trilead/ssh2/crypto/cipher/CipherInputStream;->a:Lcom/trilead/ssh2/crypto/cipher/BlockCipher;

    check-cast p1, Lcom/trilead/ssh2/crypto/cipher/NullCipher;

    .line 2
    iget p1, p1, Lcom/trilead/ssh2/crypto/cipher/NullCipher;->a:I

    .line 3
    iput p1, p0, Lcom/trilead/ssh2/crypto/cipher/CipherInputStream;->e:I

    new-array p2, p1, [B

    iput-object p2, p0, Lcom/trilead/ssh2/crypto/cipher/CipherInputStream;->c:[B

    new-array p2, p1, [B

    iput-object p2, p0, Lcom/trilead/ssh2/crypto/cipher/CipherInputStream;->d:[B

    iput p1, p0, Lcom/trilead/ssh2/crypto/cipher/CipherInputStream;->f:I

    return-void
.end method


# virtual methods
.method public final a([BII)I
    .locals 5

    iget v0, p0, Lcom/trilead/ssh2/crypto/cipher/CipherInputStream;->i:I

    const/4 v1, -0x1

    if-gez v0, :cond_0

    return v1

    :cond_0
    iget v2, p0, Lcom/trilead/ssh2/crypto/cipher/CipherInputStream;->h:I

    if-lt v2, v0, :cond_1

    const/4 v0, 0x0

    .line 1
    iput v0, p0, Lcom/trilead/ssh2/crypto/cipher/CipherInputStream;->h:I

    iget-object v2, p0, Lcom/trilead/ssh2/crypto/cipher/CipherInputStream;->b:Ljava/io/InputStream;

    iget-object v3, p0, Lcom/trilead/ssh2/crypto/cipher/CipherInputStream;->g:[B

    const/16 v4, 0x800

    invoke-virtual {v2, v3, v0, v4}, Ljava/io/InputStream;->read([BII)I

    move-result v0

    iput v0, p0, Lcom/trilead/ssh2/crypto/cipher/CipherInputStream;->i:I

    if-gtz v0, :cond_1

    return v1

    .line 2
    :cond_1
    iget v0, p0, Lcom/trilead/ssh2/crypto/cipher/CipherInputStream;->i:I

    iget v1, p0, Lcom/trilead/ssh2/crypto/cipher/CipherInputStream;->h:I

    sub-int/2addr v0, v1

    if-le p3, v0, :cond_2

    move p3, v0

    :cond_2
    iget-object v0, p0, Lcom/trilead/ssh2/crypto/cipher/CipherInputStream;->g:[B

    invoke-static {v0, v1, p1, p2, p3}, Ljava/lang/System;->arraycopy(Ljava/lang/Object;ILjava/lang/Object;II)V

    iget p1, p0, Lcom/trilead/ssh2/crypto/cipher/CipherInputStream;->h:I

    add-int/2addr p1, p3

    iput p1, p0, Lcom/trilead/ssh2/crypto/cipher/CipherInputStream;->h:I

    return p3
.end method

.method public final b([BI)I
    .locals 6

    const/4 v0, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x0

    :goto_0
    if-lez p2, :cond_3

    iget v3, p0, Lcom/trilead/ssh2/crypto/cipher/CipherInputStream;->f:I

    iget v4, p0, Lcom/trilead/ssh2/crypto/cipher/CipherInputStream;->e:I

    if-lt v3, v4, :cond_2

    const/4 v3, 0x0

    .line 1
    :goto_1
    iget v4, p0, Lcom/trilead/ssh2/crypto/cipher/CipherInputStream;->e:I

    if-ge v3, v4, :cond_1

    iget-object v5, p0, Lcom/trilead/ssh2/crypto/cipher/CipherInputStream;->d:[B

    sub-int/2addr v4, v3

    invoke-virtual {p0, v5, v3, v4}, Lcom/trilead/ssh2/crypto/cipher/CipherInputStream;->a([BII)I

    move-result v4

    if-ltz v4, :cond_0

    add-int/2addr v3, v4

    goto :goto_1

    :cond_0
    new-instance p1, Ljava/io/IOException;

    const-string p2, "Cannot read full block, EOF reached."

    invoke-direct {p1, p2}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    throw p1

    :cond_1
    :try_start_0
    iget-object v3, p0, Lcom/trilead/ssh2/crypto/cipher/CipherInputStream;->a:Lcom/trilead/ssh2/crypto/cipher/BlockCipher;

    iget-object v4, p0, Lcom/trilead/ssh2/crypto/cipher/CipherInputStream;->d:[B

    iget-object v5, p0, Lcom/trilead/ssh2/crypto/cipher/CipherInputStream;->c:[B

    invoke-interface {v3, v4, v0, v5, v0}, Lcom/trilead/ssh2/crypto/cipher/BlockCipher;->c([BI[BI)V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    iput v0, p0, Lcom/trilead/ssh2/crypto/cipher/CipherInputStream;->f:I

    goto :goto_2

    :catch_0
    new-instance p1, Ljava/io/IOException;

    const-string p2, "Error while decrypting block."

    invoke-direct {p1, p2}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    throw p1

    .line 2
    :cond_2
    :goto_2
    iget v3, p0, Lcom/trilead/ssh2/crypto/cipher/CipherInputStream;->e:I

    iget v4, p0, Lcom/trilead/ssh2/crypto/cipher/CipherInputStream;->f:I

    sub-int/2addr v3, v4

    invoke-static {v3, p2}, Ljava/lang/Math;->min(II)I

    move-result v3

    iget-object v4, p0, Lcom/trilead/ssh2/crypto/cipher/CipherInputStream;->c:[B

    iget v5, p0, Lcom/trilead/ssh2/crypto/cipher/CipherInputStream;->f:I

    invoke-static {v4, v5, p1, v2, v3}, Ljava/lang/System;->arraycopy(Ljava/lang/Object;ILjava/lang/Object;II)V

    iget v4, p0, Lcom/trilead/ssh2/crypto/cipher/CipherInputStream;->f:I

    add-int/2addr v4, v3

    iput v4, p0, Lcom/trilead/ssh2/crypto/cipher/CipherInputStream;->f:I

    add-int/2addr v2, v3

    sub-int/2addr p2, v3

    add-int/2addr v1, v3

    goto :goto_0

    :cond_3
    return v1
.end method
