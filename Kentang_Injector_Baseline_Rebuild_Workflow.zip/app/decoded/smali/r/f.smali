.class public abstract Lr/f;
.super Lcom/trilead/ssh2/crypto/CertificateDecoder;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lr/f$b;
    }
.end annotation


# instance fields
.field public final a:Ljava/lang/String;


# direct methods
.method public constructor <init>(Ljava/lang/String;)V
    .locals 0

    invoke-direct {p0}, Lcom/trilead/ssh2/crypto/CertificateDecoder;-><init>()V

    iput-object p1, p0, Lr/f;->a:Ljava/lang/String;

    return-void
.end method


# virtual methods
.method public final a(Lcom/trilead/ssh2/crypto/PEMStructure;)Ljava/security/KeyPair;
    .locals 0

    const/4 p1, 0x0

    return-object p1
.end method

.method public final b(Lcom/trilead/ssh2/crypto/PEMStructure;Ljava/lang/String;)Ljava/security/KeyPair;
    .locals 22

    move-object/from16 v1, p0

    move-object/from16 v0, p2

    new-instance v2, Lq/c;

    move-object/from16 v3, p1

    .line 1
    iget-object v3, v3, Lcom/trilead/ssh2/crypto/PEMStructure;->c:[B

    .line 2
    invoke-direct {v2, v3}, Lq/c;-><init>([B)V

    const/16 v3, 0xf

    invoke-virtual {v2, v3}, Lq/c;->d(I)[B

    move-result-object v3

    new-instance v4, Ljava/lang/String;

    sget-object v5, Ljava/nio/charset/StandardCharsets;->UTF_8:Ljava/nio/charset/Charset;

    invoke-direct {v4, v3, v5}, Ljava/lang/String;-><init>([BLjava/nio/charset/Charset;)V

    invoke-virtual {v4}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object v3

    const-string v4, "openssh-key-v1"

    invoke-virtual {v4, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v3

    if-eqz v3, :cond_11

    invoke-virtual {v2}, Lq/c;->g()Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v2}, Lq/c;->g()Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v2}, Lq/c;->c()[B

    move-result-object v5

    invoke-virtual {v2}, Lq/c;->i()I

    move-result v6

    const/4 v7, 0x1

    if-ne v6, v7, :cond_10

    invoke-virtual {v2}, Lq/c;->c()[B

    invoke-virtual {v2}, Lq/c;->c()[B

    move-result-object v6

    const-string v8, "bcrypt"

    invoke-virtual {v8, v4}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v8

    if-eqz v8, :cond_a

    if-eqz v0, :cond_9

    new-instance v4, Lq/c;

    invoke-direct {v4, v5}, Lq/c;-><init>([B)V

    invoke-virtual {v4}, Lq/c;->c()[B

    move-result-object v5

    invoke-virtual {v4}, Lq/c;->i()I

    move-result v4

    .line 3
    invoke-static {}, Lr/f$b;->values()[Lr/f$b;

    move-result-object v8

    array-length v10, v8

    const/4 v11, 0x0

    :goto_0
    if-ge v11, v10, :cond_8

    aget-object v12, v8, v11

    iget-object v13, v12, Lr/f$b;->a:[Ljava/lang/String;

    array-length v14, v13

    const/4 v15, 0x0

    :goto_1
    if-ge v15, v14, :cond_7

    aget-object v7, v13, v15

    invoke-virtual {v7, v3}, Ljava/lang/String;->equalsIgnoreCase(Ljava/lang/String;)Z

    move-result v7

    if-eqz v7, :cond_6

    .line 4
    sget-object v3, Ljava/nio/charset/StandardCharsets;->UTF_8:Ljava/nio/charset/Charset;

    invoke-virtual {v0, v3}, Ljava/lang/String;->getBytes(Ljava/nio/charset/Charset;)[B

    move-result-object v0

    .line 5
    iget v3, v12, Lr/f$b;->b:I

    .line 6
    iget v7, v12, Lr/f$b;->c:I

    add-int/2addr v3, v7

    .line 7
    new-array v7, v3, [B

    new-instance v8, Lw/a;

    invoke-direct {v8}, Lw/a;-><init>()V

    :try_start_0
    const-string v10, "SHA-512"

    .line 8
    invoke-static {v10}, Ljava/security/MessageDigest;->getInstance(Ljava/lang/String;)Ljava/security/MessageDigest;

    move-result-object v10

    add-int/lit8 v11, v3, 0x1f

    const/16 v13, 0x20

    div-int/2addr v11, v13

    invoke-virtual {v10, v0}, Ljava/security/MessageDigest;->digest([B)[B

    move-result-object v0

    const/16 v14, 0x40

    new-array v15, v14, [B

    const/4 v14, 0x4

    new-array v14, v14, [B

    new-array v9, v13, [B

    move-object/from16 v17, v2

    new-array v2, v13, [B

    const/4 v13, 0x1

    :goto_2
    if-gt v13, v11, :cond_4

    shr-int/lit8 v1, v13, 0x18

    and-int/lit16 v1, v1, 0xff

    int-to-byte v1, v1

    const/16 v16, 0x0

    aput-byte v1, v14, v16

    shr-int/lit8 v1, v13, 0x10

    and-int/lit16 v1, v1, 0xff

    int-to-byte v1, v1

    const/16 v19, 0x1

    aput-byte v1, v14, v19

    shr-int/lit8 v1, v13, 0x8

    and-int/lit16 v1, v1, 0xff

    int-to-byte v1, v1

    const/16 v20, 0x2

    aput-byte v1, v14, v20

    const/4 v1, 0x3

    move-object/from16 p1, v6

    and-int/lit16 v6, v13, 0xff

    int-to-byte v6, v6

    aput-byte v6, v14, v1

    invoke-virtual {v10}, Ljava/security/MessageDigest;->reset()V

    invoke-virtual {v10, v5}, Ljava/security/MessageDigest;->update([B)V

    invoke-virtual {v10, v14}, Ljava/security/MessageDigest;->update([B)V

    const/16 v1, 0x40

    const/4 v6, 0x0

    invoke-virtual {v10, v15, v6, v1}, Ljava/security/MessageDigest;->digest([BII)I

    invoke-virtual {v8, v0, v15, v9}, Lw/a;->b([B[B[B)V

    const/16 v1, 0x20

    invoke-static {v9, v6, v2, v6, v1}, Ljava/lang/System;->arraycopy(Ljava/lang/Object;ILjava/lang/Object;II)V

    const/4 v1, 0x1

    :goto_3
    if-ge v1, v4, :cond_1

    invoke-virtual {v10}, Ljava/security/MessageDigest;->reset()V

    invoke-virtual {v10, v2}, Ljava/security/MessageDigest;->update([B)V

    move/from16 v20, v4

    const/16 v4, 0x40

    invoke-virtual {v10, v15, v6, v4}, Ljava/security/MessageDigest;->digest([BII)I

    invoke-virtual {v8, v0, v15, v2}, Lw/a;->b([B[B[B)V

    const/16 v4, 0x20

    const/4 v6, 0x0

    :goto_4
    if-ge v6, v4, :cond_0

    aget-byte v4, v9, v6

    aget-byte v21, v2, v6

    xor-int v4, v4, v21

    int-to-byte v4, v4

    aput-byte v4, v9, v6

    add-int/lit8 v6, v6, 0x1

    const/16 v4, 0x20

    goto :goto_4

    :cond_0
    add-int/lit8 v1, v1, 0x1

    move/from16 v4, v20

    const/4 v6, 0x0

    goto :goto_3

    :cond_1
    move/from16 v20, v4

    const/4 v1, 0x0

    const/16 v4, 0x20

    :goto_5
    if-ge v1, v4, :cond_3

    mul-int v6, v1, v11

    add-int/lit8 v18, v13, -0x1

    add-int v6, v18, v6

    if-ge v6, v3, :cond_2

    aget-byte v18, v9, v1

    aput-byte v18, v7, v6
    :try_end_0
    .catch Ljava/security/DigestException; {:try_start_0 .. :try_end_0} :catch_1
    .catch Ljava/security/NoSuchAlgorithmException; {:try_start_0 .. :try_end_0} :catch_0

    :cond_2
    add-int/lit8 v1, v1, 0x1

    goto :goto_5

    :cond_3
    add-int/lit8 v13, v13, 0x1

    move-object/from16 v1, p0

    move-object/from16 v6, p1

    move/from16 v4, v20

    goto/16 :goto_2

    :cond_4
    move-object/from16 p1, v6

    .line 9
    iget v0, v12, Lr/f$b;->b:I

    .line 10
    new-array v1, v0, [B

    .line 11
    iget v2, v12, Lr/f$b;->c:I

    .line 12
    new-array v3, v2, [B

    const/4 v6, 0x0

    invoke-static {v7, v6, v1, v6, v0}, Ljava/lang/System;->arraycopy(Ljava/lang/Object;ILjava/lang/Object;II)V

    invoke-static {v7, v0, v3, v6, v2}, Ljava/lang/System;->arraycopy(Ljava/lang/Object;ILjava/lang/Object;II)V

    invoke-virtual {v12, v1, v3}, Lr/f$b;->a([B[B)Lcom/trilead/ssh2/crypto/cipher/BlockCipher;

    move-result-object v0

    move-object/from16 v1, p1

    array-length v2, v1

    new-array v2, v2, [B

    const/4 v3, 0x0

    :goto_6
    array-length v4, v1

    invoke-interface {v0}, Lcom/trilead/ssh2/crypto/cipher/BlockCipher;->a()I

    move-result v5

    div-int/2addr v4, v5

    if-ge v3, v4, :cond_5

    invoke-interface {v0}, Lcom/trilead/ssh2/crypto/cipher/BlockCipher;->a()I

    move-result v4

    mul-int v4, v4, v3

    invoke-interface {v0}, Lcom/trilead/ssh2/crypto/cipher/BlockCipher;->a()I

    move-result v5

    mul-int v5, v5, v3

    invoke-interface {v0, v1, v4, v2, v5}, Lcom/trilead/ssh2/crypto/cipher/BlockCipher;->c([BI[BI)V

    add-int/lit8 v3, v3, 0x1

    goto :goto_6

    :cond_5
    move-object v1, v2

    goto :goto_7

    :catch_0
    move-exception v0

    .line 13
    new-instance v1, Ljava/lang/RuntimeException;

    invoke-direct {v1, v0}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/Throwable;)V

    throw v1

    :catch_1
    move-exception v0

    new-instance v1, Ljava/lang/RuntimeException;

    invoke-direct {v1, v0}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/Throwable;)V

    throw v1

    :cond_6
    move-object/from16 v17, v2

    move/from16 v20, v4

    move-object v1, v6

    const/4 v6, 0x0

    const/16 v19, 0x1

    add-int/lit8 v15, v15, 0x1

    move-object v6, v1

    const/4 v7, 0x1

    move-object/from16 v1, p0

    goto/16 :goto_1

    :cond_7
    move-object/from16 v17, v2

    move/from16 v20, v4

    move-object v1, v6

    const/4 v6, 0x0

    const/16 v19, 0x1

    add-int/lit8 v11, v11, 0x1

    move-object v6, v1

    const/4 v7, 0x1

    move-object/from16 v1, p0

    goto/16 :goto_0

    .line 14
    :cond_8
    new-instance v0, Ljava/lang/IllegalArgumentException;

    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const-string v2, "Unknown Cipher: "

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-direct {v0, v1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw v0

    .line 15
    :cond_9
    new-instance v0, Ljava/io/IOException;

    const-string v1, "PEM is encrypted but password has not been specified"

    invoke-direct {v0, v1}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    throw v0

    :cond_a
    move-object/from16 v17, v2

    move-object v1, v6

    const/4 v6, 0x0

    const-string v0, "none"

    invoke-virtual {v0, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v2

    if-eqz v2, :cond_f

    invoke-virtual {v0, v4}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_f

    :goto_7
    new-instance v0, Lq/c;

    invoke-direct {v0, v1}, Lq/c;-><init>([B)V

    invoke-virtual {v0}, Lq/c;->i()I

    move-result v1

    invoke-virtual {v0}, Lq/c;->i()I

    move-result v2

    if-ne v1, v2, :cond_e

    invoke-virtual {v0}, Lq/c;->g()Ljava/lang/String;

    move-result-object v1

    move-object/from16 v2, p0

    iget-object v3, v2, Lr/f;->a:Ljava/lang/String;

    invoke-virtual {v1, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v3

    if-eqz v3, :cond_d

    :try_start_1
    invoke-virtual {v2, v0}, Lr/f;->e(Lq/c;)Ljava/security/KeyPair;

    move-result-object v1

    invoke-virtual {v0}, Lq/c;->c()[B

    move-object/from16 v0, v17

    const/4 v9, 0x0

    .line 16
    :goto_8
    iget v3, v0, Lq/c;->c:I

    iget v4, v0, Lq/c;->b:I

    sub-int/2addr v3, v4

    if-ge v9, v3, :cond_c

    add-int/lit8 v9, v9, 0x1

    .line 17
    invoke-virtual {v0}, Lq/c;->b()I

    move-result v3

    if-ne v9, v3, :cond_b

    goto :goto_8

    :cond_b
    new-instance v0, Ljava/io/IOException;

    const-string v1, "Incorrect padding on private keys"

    invoke-direct {v0, v1}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    throw v0
    :try_end_1
    .catch Ljava/security/GeneralSecurityException; {:try_start_1 .. :try_end_1} :catch_2

    :cond_c
    return-object v1

    :catch_2
    move-exception v0

    new-instance v1, Ljava/io/IOException;

    const-string v3, "Could not create key pair"

    invoke-direct {v1, v3, v0}, Ljava/io/IOException;-><init>(Ljava/lang/String;Ljava/lang/Throwable;)V

    throw v1

    :cond_d
    new-instance v0, Ljava/io/IOException;

    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    const-string v4, "Invalid key type: "

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v3, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-direct {v0, v1}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    throw v0

    :cond_e
    move-object/from16 v2, p0

    new-instance v0, Ljava/io/IOException;

    const-string v1, "Check integers didn\'t match"

    invoke-direct {v0, v1}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    throw v0

    :cond_f
    move-object/from16 v2, p0

    new-instance v0, Ljava/io/IOException;

    const-string v1, "Unexpected encryption method for key"

    invoke-direct {v0, v1}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    throw v0

    :cond_10
    move-object v2, v1

    new-instance v0, Ljava/io/IOException;

    const-string v1, "Only single OpenSSH keys are supported"

    invoke-direct {v0, v1}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    throw v0

    :cond_11
    move-object v2, v1

    new-instance v0, Ljava/io/IOException;

    const-string v1, "Could not find openssh header in key"

    invoke-direct {v0, v1}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    throw v0
.end method

.method public final c()Ljava/lang/String;
    .locals 1

    const-string v0, "-----END OPENSSH PRIVATE KEY-----"

    return-object v0
.end method

.method public final d()Ljava/lang/String;
    .locals 1

    const-string v0, "-----BEGIN OPENSSH PRIVATE KEY-----"

    return-object v0
.end method

.method public abstract e(Lq/c;)Ljava/security/KeyPair;
.end method
