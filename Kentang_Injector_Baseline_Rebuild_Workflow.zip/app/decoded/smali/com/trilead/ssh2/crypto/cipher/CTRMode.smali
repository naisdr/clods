.class public Lcom/trilead/ssh2/crypto/cipher/CTRMode;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lcom/trilead/ssh2/crypto/cipher/BlockCipher;


# instance fields
.field public a:[B

.field public b:[B

.field public c:Lcom/trilead/ssh2/crypto/cipher/BlockCipher;

.field public d:I


# direct methods
.method public constructor <init>(Lcom/trilead/ssh2/crypto/cipher/BlockCipher;[B)V
    .locals 2

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lcom/trilead/ssh2/crypto/cipher/CTRMode;->c:Lcom/trilead/ssh2/crypto/cipher/BlockCipher;

    invoke-interface {p1}, Lcom/trilead/ssh2/crypto/cipher/BlockCipher;->a()I

    move-result p1

    iput p1, p0, Lcom/trilead/ssh2/crypto/cipher/CTRMode;->d:I

    array-length v0, p2

    if-ne p1, v0, :cond_0

    new-array v0, p1, [B

    iput-object v0, p0, Lcom/trilead/ssh2/crypto/cipher/CTRMode;->a:[B

    new-array v1, p1, [B

    iput-object v1, p0, Lcom/trilead/ssh2/crypto/cipher/CTRMode;->b:[B

    const/4 v1, 0x0

    invoke-static {p2, v1, v0, v1, p1}, Ljava/lang/System;->arraycopy(Ljava/lang/Object;ILjava/lang/Object;II)V

    return-void

    :cond_0
    new-instance p1, Ljava/lang/IllegalArgumentException;

    const-string v0, "IV must be "

    .line 1
    invoke-static {v0}, Lcom/trilead/ssh2/crypto/digest/a;->e(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    .line 2
    iget v1, p0, Lcom/trilead/ssh2/crypto/cipher/CTRMode;->d:I

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string v1, " bytes long! (currently "

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    array-length p2, p2

    invoke-virtual {v0, p2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string p2, ")"

    invoke-virtual {v0, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p2

    invoke-direct {p1, p2}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw p1
.end method


# virtual methods
.method public final a()I
    .locals 1

    iget v0, p0, Lcom/trilead/ssh2/crypto/cipher/CTRMode;->d:I

    return v0
.end method

.method public final b(Z[B)V
    .locals 0

    return-void
.end method

.method public final c([BI[BI)V
    .locals 4

    iget-object v0, p0, Lcom/trilead/ssh2/crypto/cipher/CTRMode;->c:Lcom/trilead/ssh2/crypto/cipher/BlockCipher;

    iget-object v1, p0, Lcom/trilead/ssh2/crypto/cipher/CTRMode;->a:[B

    iget-object v2, p0, Lcom/trilead/ssh2/crypto/cipher/CTRMode;->b:[B

    const/4 v3, 0x0

    invoke-interface {v0, v1, v3, v2, v3}, Lcom/trilead/ssh2/crypto/cipher/BlockCipher;->c([BI[BI)V

    :goto_0
    iget v0, p0, Lcom/trilead/ssh2/crypto/cipher/CTRMode;->d:I

    if-ge v3, v0, :cond_0

    add-int v0, p4, v3

    add-int v1, p2, v3

    aget-byte v1, p1, v1

    iget-object v2, p0, Lcom/trilead/ssh2/crypto/cipher/CTRMode;->b:[B

    aget-byte v2, v2, v3

    xor-int/2addr v1, v2

    int-to-byte v1, v1

    aput-byte v1, p3, v0

    add-int/lit8 v3, v3, 0x1

    goto :goto_0

    :cond_0
    add-int/lit8 v0, v0, -0x1

    :goto_1
    if-ltz v0, :cond_2

    iget-object p1, p0, Lcom/trilead/ssh2/crypto/cipher/CTRMode;->a:[B

    aget-byte p2, p1, v0

    add-int/lit8 p2, p2, 0x1

    int-to-byte p2, p2

    aput-byte p2, p1, v0

    aget-byte p1, p1, v0

    if-eqz p1, :cond_1

    goto :goto_2

    :cond_1
    add-int/lit8 v0, v0, -0x1

    goto :goto_1

    :cond_2
    :goto_2
    return-void
.end method
