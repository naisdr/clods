.class public interface abstract Lf/d;
.super Ljava/lang/Object;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lf/d$d;,
        Lf/d$f;,
        Lf/d$e;,
        Lf/d$h;,
        Lf/d$g;,
        Lf/d$c;,
        Lf/d$b;,
        Lf/d$a;
    }
.end annotation


# virtual methods
.method public abstract a()Z
.end method
