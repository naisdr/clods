.class public final Ll/b;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ljava/lang/Cloneable;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Ll/b$a;
    }
.end annotation


# static fields
.field public static final s:[Ll/b$a;


# instance fields
.field public a:[B

.field public b:[B

.field public c:[S

.field public d:[S

.field public e:I

.field public f:I

.field public g:[S

.field public h:[S

.field public i:[S

.field public j:La/b;

.field public k:La/b;

.field public l:La/b;

.field public m:[S

.field public n:[S

.field public o:[I

.field public p:[B

.field public q:[B

.field public r:Ll/c;


# direct methods
.method public static constructor <clinit>()V
    .locals 9

    const/16 v0, 0xa

    new-array v0, v0, [Ll/b$a;

    sput-object v0, Ll/b;->s:[Ll/b$a;

    new-instance v1, Ll/b$a;

    const/4 v2, 0x0

    invoke-direct {v1, v2, v2, v2, v2}, Ll/b$a;-><init>(IIII)V

    aput-object v1, v0, v2

    new-instance v1, Ll/b$a;

    const/4 v2, 0x4

    const/16 v3, 0x8

    invoke-direct {v1, v2, v2, v3, v2}, Ll/b$a;-><init>(IIII)V

    const/4 v4, 0x1

    aput-object v1, v0, v4

    new-instance v1, Ll/b$a;

    const/4 v4, 0x5

    const/16 v5, 0x10

    invoke-direct {v1, v2, v4, v5, v3}, Ll/b$a;-><init>(IIII)V

    const/4 v6, 0x2

    aput-object v1, v0, v6

    new-instance v1, Ll/b$a;

    const/4 v6, 0x6

    const/16 v7, 0x20

    invoke-direct {v1, v2, v6, v7, v7}, Ll/b$a;-><init>(IIII)V

    const/4 v8, 0x3

    aput-object v1, v0, v8

    new-instance v1, Ll/b$a;

    invoke-direct {v1, v2, v2, v5, v5}, Ll/b$a;-><init>(IIII)V

    aput-object v1, v0, v2

    new-instance v1, Ll/b$a;

    invoke-direct {v1, v3, v5, v7, v7}, Ll/b$a;-><init>(IIII)V

    aput-object v1, v0, v4

    new-instance v1, Ll/b$a;

    const/16 v2, 0x80

    invoke-direct {v1, v3, v5, v2, v2}, Ll/b$a;-><init>(IIII)V

    aput-object v1, v0, v6

    new-instance v1, Ll/b$a;

    const/16 v4, 0x100

    invoke-direct {v1, v3, v7, v2, v4}, Ll/b$a;-><init>(IIII)V

    const/4 v4, 0x7

    aput-object v1, v0, v4

    new-instance v1, Ll/b$a;

    const/16 v4, 0x102

    const/16 v5, 0x400

    invoke-direct {v1, v7, v2, v4, v5}, Ll/b$a;-><init>(IIII)V

    aput-object v1, v0, v3

    new-instance v1, Ll/b$a;

    const/16 v2, 0x1000

    invoke-direct {v1, v7, v4, v4, v2}, Ll/b$a;-><init>(IIII)V

    const/16 v2, 0x9

    aput-object v1, v0, v2

    return-void
.end method

.method public constructor <init>(Ll/f;)V
    .locals 1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    new-instance p1, La/b;

    invoke-direct {p1}, La/b;-><init>()V

    iput-object p1, p0, Ll/b;->j:La/b;

    new-instance p1, La/b;

    invoke-direct {p1}, La/b;-><init>()V

    iput-object p1, p0, Ll/b;->k:La/b;

    new-instance p1, La/b;

    invoke-direct {p1}, La/b;-><init>()V

    iput-object p1, p0, Ll/b;->l:La/b;

    const/16 p1, 0x10

    new-array v0, p1, [S

    iput-object v0, p0, Ll/b;->m:[S

    new-array p1, p1, [S

    iput-object p1, p0, Ll/b;->n:[S

    const/16 p1, 0x23d

    new-array v0, p1, [I

    iput-object v0, p0, Ll/b;->o:[I

    new-array p1, p1, [B

    iput-object p1, p0, Ll/b;->p:[B

    const/4 p1, 0x0

    iput-object p1, p0, Ll/b;->r:Ll/c;

    const/16 p1, 0x47a

    new-array p1, p1, [S

    iput-object p1, p0, Ll/b;->g:[S

    const/16 p1, 0x7a

    new-array p1, p1, [S

    iput-object p1, p0, Ll/b;->h:[S

    const/16 p1, 0x4e

    new-array p1, p1, [S

    iput-object p1, p0, Ll/b;->i:[S

    return-void
.end method


# virtual methods
.method public final a([B)[B
    .locals 3

    array-length v0, p1

    new-array v1, v0, [B

    const/4 v2, 0x0

    invoke-static {p1, v2, v1, v2, v0}, Ljava/lang/System;->arraycopy(Ljava/lang/Object;ILjava/lang/Object;II)V

    return-object v1
.end method

.method public final b([S)[S
    .locals 3

    array-length v0, p1

    new-array v1, v0, [S

    const/4 v2, 0x0

    invoke-static {p1, v2, v1, v2, v0}, Ljava/lang/System;->arraycopy(Ljava/lang/Object;ILjava/lang/Object;II)V

    return-object v1
.end method

.method public final clone()Ljava/lang/Object;
    .locals 5

    invoke-super {p0}, Ljava/lang/Object;->clone()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ll/b;

    iget-object v1, v0, Ll/b;->a:[B

    invoke-virtual {p0, v1}, Ll/b;->a([B)[B

    move-result-object v1

    iput-object v1, v0, Ll/b;->a:[B

    iget-object v1, v0, Ll/b;->q:[B

    invoke-virtual {p0, v1}, Ll/b;->a([B)[B

    move-result-object v1

    iput-object v1, v0, Ll/b;->q:[B

    iget-object v1, v0, Ll/b;->b:[B

    invoke-virtual {p0, v1}, Ll/b;->a([B)[B

    move-result-object v1

    iput-object v1, v0, Ll/b;->b:[B

    iget-object v1, v0, Ll/b;->c:[S

    invoke-virtual {p0, v1}, Ll/b;->b([S)[S

    move-result-object v1

    iput-object v1, v0, Ll/b;->c:[S

    iget-object v1, v0, Ll/b;->d:[S

    invoke-virtual {p0, v1}, Ll/b;->b([S)[S

    move-result-object v1

    iput-object v1, v0, Ll/b;->d:[S

    iget-object v1, v0, Ll/b;->g:[S

    invoke-virtual {p0, v1}, Ll/b;->b([S)[S

    move-result-object v1

    iput-object v1, v0, Ll/b;->g:[S

    iget-object v1, v0, Ll/b;->h:[S

    invoke-virtual {p0, v1}, Ll/b;->b([S)[S

    move-result-object v1

    iput-object v1, v0, Ll/b;->h:[S

    iget-object v1, v0, Ll/b;->i:[S

    invoke-virtual {p0, v1}, Ll/b;->b([S)[S

    move-result-object v1

    iput-object v1, v0, Ll/b;->i:[S

    iget-object v1, v0, Ll/b;->m:[S

    invoke-virtual {p0, v1}, Ll/b;->b([S)[S

    move-result-object v1

    iput-object v1, v0, Ll/b;->m:[S

    iget-object v1, v0, Ll/b;->n:[S

    invoke-virtual {p0, v1}, Ll/b;->b([S)[S

    move-result-object v1

    iput-object v1, v0, Ll/b;->n:[S

    iget-object v1, v0, Ll/b;->o:[I

    .line 1
    array-length v2, v1

    new-array v3, v2, [I

    const/4 v4, 0x0

    invoke-static {v1, v4, v3, v4, v2}, Ljava/lang/System;->arraycopy(Ljava/lang/Object;ILjava/lang/Object;II)V

    .line 2
    iput-object v3, v0, Ll/b;->o:[I

    iget-object v1, v0, Ll/b;->p:[B

    invoke-virtual {p0, v1}, Ll/b;->a([B)[B

    move-result-object v1

    iput-object v1, v0, Ll/b;->p:[B

    iget-object v1, v0, Ll/b;->j:La/b;

    invoke-static {v1}, Ljava/util/Objects;->requireNonNull(Ljava/lang/Object;)Ljava/lang/Object;

    iget-object v1, v0, Ll/b;->k:La/b;

    invoke-static {v1}, Ljava/util/Objects;->requireNonNull(Ljava/lang/Object;)Ljava/lang/Object;

    iget-object v1, v0, Ll/b;->l:La/b;

    invoke-static {v1}, Ljava/util/Objects;->requireNonNull(Ljava/lang/Object;)Ljava/lang/Object;

    iget-object v1, v0, Ll/b;->r:Ll/c;

    if-eqz v1, :cond_0

    invoke-virtual {v1}, Ll/c;->clone()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ll/c;

    iput-object v1, v0, Ll/b;->r:Ll/c;

    :cond_0
    return-object v0
.end method
