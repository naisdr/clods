.class public final Lj0/c;
.super Ljava/lang/Object;
.source "SourceFile"


# static fields
.field public static c:Lm0/b;


# instance fields
.field public final a:Lk0/a;

.field public final b:Landroid/content/Context;


# direct methods
.method public static constructor <clinit>()V
    .locals 2

    const-string v0, " "

    .line 1
    invoke-virtual {v0}, Ljava/lang/String;->toCharArray()[C

    move-result-object v0

    .line 2
    new-instance v1, Lm0/b;

    invoke-direct {v1, v0}, Lm0/b;-><init>([C)V

    .line 3
    sput-object v1, Lj0/c;->c:Lm0/b;

    return-void
.end method

.method public constructor <init>(Landroid/content/Context;)V
    .locals 1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lj0/c;->b:Landroid/content/Context;

    sget-object v0, Lj0/c;->c:Lm0/b;

    invoke-static {p1, v0}, Lk0/a;->d(Landroid/content/Context;Lm0/b;)Lk0/a;

    move-result-object p1

    iput-object p1, p0, Lj0/c;->a:Lk0/a;

    return-void
.end method


# virtual methods
.method public final a()Lj0/b;
    .locals 4

    new-instance v0, Lj0/b;

    iget-object v1, p0, Lj0/c;->a:Lk0/a;

    invoke-virtual {p0}, Lj0/c;->b()Ljava/util/List;

    move-result-object v2

    check-cast v2, Ljava/util/ArrayList;

    const/4 v3, 0x0

    invoke-virtual {v2, v3}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Ljava/lang/String;

    const-string v3, "last_profile"

    invoke-virtual {v1, v3, v2}, Lk0/a;->getString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    invoke-direct {v0, v1, v2}, Lj0/b;-><init>(Landroid/content/SharedPreferences;Ljava/lang/String;)V

    return-object v0
.end method

.method public final b()Ljava/util/List;
    .locals 6
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/List<",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation

    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    iget-object v1, p0, Lj0/c;->b:Landroid/content/Context;

    const v2, 0x7f0b001f

    invoke-virtual {v1, v2}, Landroid/content/Context;->getString(I)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    iget-object v1, p0, Lj0/c;->a:Lk0/a;

    const-string v2, "profile"

    const-string v3, ""

    invoke-virtual {v1, v2, v3}, Lk0/a;->getString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    const-string v2, "\n"

    invoke-virtual {v1, v2}, Ljava/lang/String;->split(Ljava/lang/String;)[Ljava/lang/String;

    move-result-object v1

    array-length v2, v1

    const/4 v3, 0x0

    :goto_0
    if-ge v3, v2, :cond_1

    aget-object v4, v1, v3

    invoke-static {v4}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v5

    if-nez v5, :cond_0

    invoke-virtual {v0, v4}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    :cond_0
    add-int/lit8 v3, v3, 0x1

    goto :goto_0

    :cond_1
    return-object v0
.end method
