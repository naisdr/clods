.class public final Lc0/g;
.super Landroid/preference/PreferenceFragment;
.source "SourceFile"

# interfaces
.implements Landroid/preference/Preference$OnPreferenceClickListener;
.implements Landroid/preference/Preference$OnPreferenceChangeListener;
.implements Landroid/widget/CompoundButton$OnCheckedChangeListener;
.implements Lg0/d$b;


# static fields
.field public static s:Lj0/c;


# instance fields
.field public a:Lk0/a;

.field public b:Ld0/c;

.field public c:Landroidx/recyclerview/widget/RecyclerView;

.field public d:Lf0/a;

.field public e:Landroid/os/Handler;

.field public f:Lj0/b;

.field public g:Landroid/preference/ListPreference;

.field public h:Landroid/preference/ListPreference;

.field public i:Landroid/preference/EditTextPreference;

.field public j:Landroid/preference/EditTextPreference;

.field public k:Landroid/preference/EditTextPreference;

.field public l:Landroid/preference/EditTextPreference;

.field public m:Landroid/preference/EditTextPreference;

.field public n:Landroid/preference/EditTextPreference;

.field public o:Landroid/preference/CheckBoxPreference;

.field public p:Landroid/preference/SwitchPreference;

.field public q:Landroid/content/SharedPreferences;

.field public r:Z


# direct methods
.method public constructor <init>()V
    .locals 1

    invoke-direct {p0}, Landroid/preference/PreferenceFragment;-><init>()V

    const/4 v0, 0x0

    iput-boolean v0, p0, Lc0/g;->r:Z

    return-void
.end method

.method public static b(Lc0/g;Z)V
    .locals 1

    iget-object v0, p0, Lc0/g;->i:Landroid/preference/EditTextPreference;

    invoke-virtual {v0, p1}, Landroid/preference/Preference;->setEnabled(Z)V

    iget-object v0, p0, Lc0/g;->j:Landroid/preference/EditTextPreference;

    invoke-virtual {v0, p1}, Landroid/preference/Preference;->setEnabled(Z)V

    iget-object v0, p0, Lc0/g;->k:Landroid/preference/EditTextPreference;

    invoke-virtual {v0, p1}, Landroid/preference/Preference;->setEnabled(Z)V

    iget-object v0, p0, Lc0/g;->l:Landroid/preference/EditTextPreference;

    invoke-virtual {v0, p1}, Landroid/preference/Preference;->setEnabled(Z)V

    iget-object v0, p0, Lc0/g;->m:Landroid/preference/EditTextPreference;

    invoke-virtual {v0, p1}, Landroid/preference/Preference;->setEnabled(Z)V

    iget-object v0, p0, Lc0/g;->n:Landroid/preference/EditTextPreference;

    invoke-virtual {v0, p1}, Landroid/preference/Preference;->setEnabled(Z)V

    iget-object v0, p0, Lc0/g;->o:Landroid/preference/CheckBoxPreference;

    invoke-virtual {v0, p1}, Landroid/preference/Preference;->setEnabled(Z)V

    iget-object v0, p0, Lc0/g;->h:Landroid/preference/ListPreference;

    invoke-virtual {v0, p1}, Landroid/preference/Preference;->setEnabled(Z)V

    iput-boolean p1, p0, Lc0/g;->r:Z

    return-void
.end method


# virtual methods
.method public final a(Lg0/a;)V
    .locals 2

    iget-object v0, p0, Lc0/g;->e:Landroid/os/Handler;

    new-instance v1, Lc0/f;

    invoke-direct {v1, p0, p1}, Lc0/f;-><init>(Lc0/g;Lg0/a;)V

    invoke-virtual {v0, v1}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    return-void
.end method

.method public final c()V
    .locals 8

    iget-object v0, p0, Lc0/g;->f:Lj0/b;

    if-nez v0, :cond_0

    sget-object v0, Lc0/g;->s:Lj0/c;

    invoke-virtual {v0}, Lj0/c;->a()Lj0/b;

    move-result-object v0

    iput-object v0, p0, Lc0/g;->f:Lj0/b;

    :cond_0
    iget-object v0, p0, Lc0/g;->g:Landroid/preference/ListPreference;

    sget-object v1, Lc0/g;->s:Lj0/c;

    .line 1
    invoke-virtual {v1}, Lj0/c;->b()Ljava/util/List;

    move-result-object v1

    const/4 v2, 0x0

    new-array v3, v2, [Ljava/lang/String;

    check-cast v1, Ljava/util/ArrayList;

    invoke-virtual {v1, v3}, Ljava/util/ArrayList;->toArray([Ljava/lang/Object;)[Ljava/lang/Object;

    move-result-object v1

    check-cast v1, [Ljava/lang/String;

    .line 2
    invoke-virtual {v0, v1}, Landroid/preference/ListPreference;->setEntries([Ljava/lang/CharSequence;)V

    iget-object v0, p0, Lc0/g;->g:Landroid/preference/ListPreference;

    sget-object v1, Lc0/g;->s:Lj0/c;

    .line 3
    invoke-virtual {v1}, Lj0/c;->b()Ljava/util/List;

    move-result-object v1

    new-array v3, v2, [Ljava/lang/String;

    check-cast v1, Ljava/util/ArrayList;

    invoke-virtual {v1, v3}, Ljava/util/ArrayList;->toArray([Ljava/lang/Object;)[Ljava/lang/Object;

    move-result-object v1

    check-cast v1, [Ljava/lang/String;

    .line 4
    invoke-virtual {v0, v1}, Landroid/preference/ListPreference;->setEntryValues([Ljava/lang/CharSequence;)V

    iget-object v0, p0, Lc0/g;->g:Landroid/preference/ListPreference;

    iget-object v1, p0, Lc0/g;->f:Lj0/b;

    .line 5
    iget-object v1, v1, Lj0/b;->b:Ljava/lang/String;

    .line 6
    invoke-virtual {v0, v1}, Landroid/preference/ListPreference;->setValue(Ljava/lang/String;)V

    iget-object v0, p0, Lc0/g;->h:Landroid/preference/ListPreference;

    iget-object v1, p0, Lc0/g;->f:Lj0/b;

    .line 7
    iget-object v3, v1, Lj0/b;->a:Landroid/content/SharedPreferences;

    const-string v4, "forcing"

    invoke-virtual {v1, v4}, Lj0/b;->f(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    const-string v4, "tlsAuto"

    invoke-interface {v3, v1, v4}, Landroid/content/SharedPreferences;->getString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    .line 8
    invoke-virtual {v0, v1}, Landroid/preference/ListPreference;->setValue(Ljava/lang/String;)V

    const/4 v0, 0x2

    new-array v1, v0, [Landroid/preference/ListPreference;

    iget-object v3, p0, Lc0/g;->g:Landroid/preference/ListPreference;

    aput-object v3, v1, v2

    iget-object v3, p0, Lc0/g;->h:Landroid/preference/ListPreference;

    const/4 v4, 0x1

    aput-object v3, v1, v4

    const/4 v3, 0x0

    :goto_0
    if-ge v3, v0, :cond_1

    .line 9
    aget-object v5, v1, v3

    invoke-virtual {v5}, Landroid/preference/ListPreference;->getEntry()Ljava/lang/CharSequence;

    move-result-object v6

    invoke-virtual {v5, v6}, Landroid/preference/ListPreference;->setSummary(Ljava/lang/CharSequence;)V

    add-int/lit8 v3, v3, 0x1

    goto :goto_0

    .line 10
    :cond_1
    iget-object v1, p0, Lc0/g;->i:Landroid/preference/EditTextPreference;

    iget-object v3, p0, Lc0/g;->f:Lj0/b;

    invoke-virtual {v3}, Lj0/b;->e()Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v1, v3}, Landroid/preference/EditTextPreference;->setText(Ljava/lang/String;)V

    iget-object v1, p0, Lc0/g;->j:Landroid/preference/EditTextPreference;

    iget-object v3, p0, Lc0/g;->f:Lj0/b;

    invoke-virtual {v3}, Lj0/b;->b()Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v1, v3}, Landroid/preference/EditTextPreference;->setText(Ljava/lang/String;)V

    iget-object v1, p0, Lc0/g;->k:Landroid/preference/EditTextPreference;

    iget-object v3, p0, Lc0/g;->f:Lj0/b;

    invoke-virtual {v3}, Lj0/b;->c()Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v1, v3}, Landroid/preference/EditTextPreference;->setText(Ljava/lang/String;)V

    iget-object v1, p0, Lc0/g;->l:Landroid/preference/EditTextPreference;

    iget-object v3, p0, Lc0/g;->f:Lj0/b;

    invoke-virtual {v3}, Lj0/b;->d()Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v1, v3}, Landroid/preference/EditTextPreference;->setText(Ljava/lang/String;)V

    iget-object v1, p0, Lc0/g;->m:Landroid/preference/EditTextPreference;

    iget-object v3, p0, Lc0/g;->f:Lj0/b;

    invoke-virtual {v3}, Lj0/b;->a()Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v1, v3}, Landroid/preference/EditTextPreference;->setText(Ljava/lang/String;)V

    iget-object v1, p0, Lc0/g;->n:Landroid/preference/EditTextPreference;

    iget-object v3, p0, Lc0/g;->f:Lj0/b;

    .line 11
    iget-object v5, v3, Lj0/b;->a:Landroid/content/SharedPreferences;

    const-string v6, "udpgws"

    invoke-virtual {v3, v6}, Lj0/b;->f(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    const-string v6, "127.0.0.1:7300"

    invoke-interface {v5, v3, v6}, Landroid/content/SharedPreferences;->getString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    .line 12
    invoke-virtual {v1, v3}, Landroid/preference/EditTextPreference;->setText(Ljava/lang/String;)V

    iget-object v1, p0, Lc0/g;->o:Landroid/preference/CheckBoxPreference;

    iget-object v3, p0, Lc0/g;->f:Lj0/b;

    .line 13
    iget-object v5, v3, Lj0/b;->a:Landroid/content/SharedPreferences;

    const-string v6, "autopings"

    invoke-virtual {v3, v6}, Lj0/b;->f(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    invoke-interface {v5, v3, v2}, Landroid/content/SharedPreferences;->getBoolean(Ljava/lang/String;Z)Z

    move-result v3

    .line 14
    invoke-virtual {v1, v3}, Landroid/preference/TwoStatePreference;->setChecked(Z)V

    const/4 v1, 0x5

    new-array v1, v1, [Landroid/preference/EditTextPreference;

    iget-object v3, p0, Lc0/g;->j:Landroid/preference/EditTextPreference;

    aput-object v3, v1, v2

    iget-object v3, p0, Lc0/g;->k:Landroid/preference/EditTextPreference;

    aput-object v3, v1, v4

    iget-object v3, p0, Lc0/g;->l:Landroid/preference/EditTextPreference;

    aput-object v3, v1, v0

    iget-object v3, p0, Lc0/g;->m:Landroid/preference/EditTextPreference;

    const/4 v5, 0x3

    aput-object v3, v1, v5

    const/4 v3, 0x4

    iget-object v6, p0, Lc0/g;->n:Landroid/preference/EditTextPreference;

    aput-object v6, v1, v3

    invoke-virtual {p0, v1}, Lc0/g;->d([Landroid/preference/EditTextPreference;)V

    iget-object v1, p0, Lc0/g;->f:Lj0/b;

    invoke-virtual {v1}, Lj0/b;->e()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/String;->isEmpty()Z

    move-result v1

    if-eqz v1, :cond_3

    iget-object v1, p0, Lc0/g;->f:Lj0/b;

    invoke-virtual {v1}, Lj0/b;->e()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/String;->length()I

    move-result v1

    if-nez v1, :cond_3

    iget-object v1, p0, Lc0/g;->f:Lj0/b;

    invoke-virtual {v1}, Lj0/b;->e()Ljava/lang/String;

    move-result-object v1

    const-string v3, ""

    invoke-virtual {v1, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_2

    goto :goto_1

    :cond_2
    new-array v0, v4, [Landroid/preference/EditTextPreference;

    iget-object v1, p0, Lc0/g;->i:Landroid/preference/EditTextPreference;

    aput-object v1, v0, v2

    invoke-virtual {p0, v0}, Lc0/g;->d([Landroid/preference/EditTextPreference;)V

    goto :goto_2

    :cond_3
    :goto_1
    iget-object v1, p0, Lc0/g;->f:Lj0/b;

    invoke-virtual {v1}, Lj0/b;->e()Ljava/lang/String;

    move-result-object v1

    const-string v3, "[@:]"

    invoke-virtual {v1, v3}, Ljava/lang/String;->split(Ljava/lang/String;)[Ljava/lang/String;

    move-result-object v1

    iget-object v3, p0, Lc0/g;->i:Landroid/preference/EditTextPreference;

    new-instance v6, Ljava/lang/StringBuilder;

    invoke-direct {v6}, Ljava/lang/StringBuilder;-><init>()V

    aget-object v2, v1, v2

    invoke-virtual {v6, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v2, ":"

    invoke-virtual {v6, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    aget-object v4, v1, v4

    invoke-virtual {v6, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v4, "@"

    invoke-virtual {v6, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    aget-object v0, v1, v0

    const-string v4, "[a-zA-Z0-9]"

    const-string v7, "x"

    invoke-virtual {v0, v4, v7}, Ljava/lang/String;->replaceAll(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v6, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v6, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    aget-object v0, v1, v5

    invoke-virtual {v0, v4, v7}, Ljava/lang/String;->replaceAll(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v6, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v6}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v3, v0}, Landroid/preference/Preference;->setSummary(Ljava/lang/CharSequence;)V

    :goto_2
    return-void
.end method

.method public final varargs d([Landroid/preference/EditTextPreference;)V
    .locals 8

    array-length v0, p1

    const/4 v1, 0x0

    const/4 v2, 0x0

    :goto_0
    if-ge v2, v0, :cond_2

    aget-object v3, p1, v2

    invoke-virtual {v3}, Landroid/preference/EditTextPreference;->getEditText()Landroid/widget/EditText;

    move-result-object v4

    invoke-virtual {v4}, Landroid/widget/TextView;->getInputType()I

    move-result v4

    const/16 v5, 0x80

    and-int/2addr v4, v5

    if-eq v4, v5, :cond_0

    invoke-virtual {v3}, Landroid/preference/EditTextPreference;->getText()Ljava/lang/String;

    move-result-object v4

    goto :goto_1

    :cond_0
    invoke-virtual {v3}, Landroid/preference/EditTextPreference;->getText()Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v4}, Ljava/lang/String;->length()I

    move-result v4

    if-lez v4, :cond_1

    sget-object v4, Ljava/util/Locale;->US:Ljava/util/Locale;

    const/4 v5, 0x1

    new-array v6, v5, [Ljava/lang/Object;

    invoke-virtual {v3}, Landroid/preference/EditTextPreference;->getText()Ljava/lang/String;

    move-result-object v7

    invoke-virtual {v7}, Ljava/lang/String;->length()I

    move-result v7

    invoke-static {v7}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v7

    aput-object v7, v6, v1

    const-string v7, "%%0%dd"

    invoke-static {v4, v7, v6}, Ljava/lang/String;->format(Ljava/util/Locale;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v6

    new-array v5, v5, [Ljava/lang/Object;

    invoke-static {v1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v7

    aput-object v7, v5, v1

    invoke-static {v4, v6, v5}, Ljava/lang/String;->format(Ljava/util/Locale;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v4

    const-string v5, "0"

    const-string v6, "*"

    invoke-virtual {v4, v5, v6}, Ljava/lang/String;->replace(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Ljava/lang/String;

    move-result-object v4

    goto :goto_1

    :cond_1
    const-string v4, ""

    :goto_1
    invoke-virtual {v3, v4}, Landroid/preference/Preference;->setSummary(Ljava/lang/CharSequence;)V

    add-int/lit8 v2, v2, 0x1

    goto :goto_0

    :cond_2
    return-void
.end method

.method public final e(Landroid/preference/EditTextPreference;Ljava/lang/Object;)V
    .locals 4

    invoke-virtual {p1}, Landroid/preference/EditTextPreference;->getEditText()Landroid/widget/EditText;

    move-result-object v0

    invoke-virtual {v0}, Landroid/widget/TextView;->getInputType()I

    move-result v0

    const/16 v1, 0x80

    and-int/2addr v0, v1

    invoke-virtual {p2}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object p2

    if-eq v0, v1, :cond_0

    :goto_0
    invoke-virtual {p1, p2}, Landroid/preference/Preference;->setSummary(Ljava/lang/CharSequence;)V

    goto :goto_1

    :cond_0
    invoke-virtual {p2}, Ljava/lang/String;->length()I

    move-result v0

    if-lez v0, :cond_1

    sget-object v0, Ljava/util/Locale;->US:Ljava/util/Locale;

    const/4 v1, 0x1

    new-array v2, v1, [Ljava/lang/Object;

    invoke-virtual {p2}, Ljava/lang/String;->length()I

    move-result p2

    invoke-static {p2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p2

    const/4 v3, 0x0

    aput-object p2, v2, v3

    const-string p2, "%%0%dd"

    invoke-static {v0, p2, v2}, Ljava/lang/String;->format(Ljava/util/Locale;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object p2

    new-array v1, v1, [Ljava/lang/Object;

    invoke-static {v3}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v2

    aput-object v2, v1, v3

    invoke-static {v0, p2, v1}, Ljava/lang/String;->format(Ljava/util/Locale;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object p2

    const-string v0, "0"

    const-string v1, "*"

    invoke-virtual {p2, v0, v1}, Ljava/lang/String;->replace(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Ljava/lang/String;

    move-result-object p2

    goto :goto_0

    :cond_1
    const-string p2, ""

    goto :goto_0

    :goto_1
    return-void
.end method

.method public final f()V
    .locals 5

    sget-object v0, Lxyz/chz/injector/MainActivity;->b:Lxyz/chz/injector/MainActivity;

    invoke-static {v0}, Landroid/view/LayoutInflater;->from(Landroid/content/Context;)Landroid/view/LayoutInflater;

    move-result-object v0

    const v1, 0x7f080002

    const/4 v2, 0x0

    invoke-virtual {v0, v1, v2}, Landroid/view/LayoutInflater;->inflate(ILandroid/view/ViewGroup;)Landroid/view/View;

    move-result-object v0

    new-instance v1, Landroid/app/AlertDialog$Builder;

    sget-object v2, Lxyz/chz/injector/MainActivity;->b:Lxyz/chz/injector/MainActivity;

    invoke-direct {v1, v2}, Landroid/app/AlertDialog$Builder;-><init>(Landroid/content/Context;)V

    invoke-virtual {v1, v0}, Landroid/app/AlertDialog$Builder;->setView(Landroid/view/View;)Landroid/app/AlertDialog$Builder;

    new-instance v2, Landroidx/recyclerview/widget/LinearLayoutManager;

    sget-object v3, Lxyz/chz/injector/MainActivity;->b:Lxyz/chz/injector/MainActivity;

    invoke-direct {v2}, Landroidx/recyclerview/widget/LinearLayoutManager;-><init>()V

    new-instance v3, Ld0/c;

    sget-object v4, Lxyz/chz/injector/MainActivity;->b:Lxyz/chz/injector/MainActivity;

    invoke-direct {v3, v2, v4}, Ld0/c;-><init>(Landroidx/recyclerview/widget/LinearLayoutManager;Landroid/content/Context;)V

    iput-object v3, p0, Lc0/g;->b:Ld0/c;

    const v3, 0x7f06003b

    invoke-virtual {v0, v3}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroidx/recyclerview/widget/RecyclerView;

    iput-object v0, p0, Lc0/g;->c:Landroidx/recyclerview/widget/RecyclerView;

    iget-object v3, p0, Lc0/g;->b:Ld0/c;

    invoke-virtual {v0, v3}, Landroidx/recyclerview/widget/RecyclerView;->setAdapter(Landroidx/recyclerview/widget/RecyclerView$d;)V

    iget-object v0, p0, Lc0/g;->c:Landroidx/recyclerview/widget/RecyclerView;

    invoke-virtual {v0, v2}, Landroidx/recyclerview/widget/RecyclerView;->setLayoutManager(Landroidx/recyclerview/widget/RecyclerView$l;)V

    iget-object v0, p0, Lc0/g;->b:Ld0/c;

    invoke-virtual {v0}, Ld0/c;->f()V

    const/4 v0, 0x0

    invoke-virtual {v1, v0}, Landroid/app/AlertDialog$Builder;->setCancelable(Z)Landroid/app/AlertDialog$Builder;

    new-instance v0, Lc0/g$a;

    invoke-direct {v0}, Lc0/g$a;-><init>()V

    const-string v2, "close"

    invoke-virtual {v1, v2, v0}, Landroid/app/AlertDialog$Builder;->setPositiveButton(Ljava/lang/CharSequence;Landroid/content/DialogInterface$OnClickListener;)Landroid/app/AlertDialog$Builder;

    new-instance v0, Lc0/g$b;

    invoke-direct {v0, p0}, Lc0/g$b;-><init>(Lc0/g;)V

    const-string v2, "clear"

    invoke-virtual {v1, v2, v0}, Landroid/app/AlertDialog$Builder;->setNegativeButton(Ljava/lang/CharSequence;Landroid/content/DialogInterface$OnClickListener;)Landroid/app/AlertDialog$Builder;

    invoke-virtual {v1}, Landroid/app/AlertDialog$Builder;->create()Landroid/app/AlertDialog;

    move-result-object v0

    invoke-virtual {v0}, Landroid/app/Dialog;->show()V

    invoke-virtual {p0}, Landroid/app/Fragment;->getResources()Landroid/content/res/Resources;

    move-result-object v1

    invoke-virtual {v1}, Landroid/content/res/Resources;->getDisplayMetrics()Landroid/util/DisplayMetrics;

    move-result-object v1

    iget v1, v1, Landroid/util/DisplayMetrics;->widthPixels:I

    int-to-double v1, v1

    const-wide v3, 0x3fe999999999999aL    # 0.8

    mul-double v1, v1, v3

    double-to-int v1, v1

    invoke-virtual {p0}, Landroid/app/Fragment;->getResources()Landroid/content/res/Resources;

    move-result-object v2

    invoke-virtual {v2}, Landroid/content/res/Resources;->getDisplayMetrics()Landroid/util/DisplayMetrics;

    move-result-object v2

    iget v2, v2, Landroid/util/DisplayMetrics;->heightPixels:I

    invoke-virtual {v0}, Landroid/app/Dialog;->getWindow()Landroid/view/Window;

    move-result-object v0

    const/4 v2, -0x2

    invoke-virtual {v0, v1, v2}, Landroid/view/Window;->setLayout(II)V

    return-void
.end method

.method public final onActivityResult(IILandroid/content/Intent;)V
    .locals 5

    sget-object v0, Lg0/a;->d:Lg0/a;

    invoke-super {p0, p1, p2, p3}, Landroid/preference/PreferenceFragment;->onActivityResult(IILandroid/content/Intent;)V

    const/16 p3, 0x46

    if-ne p1, p3, :cond_9

    const/4 p1, -0x1

    const-string p3, ""

    if-ne p2, p1, :cond_8

    sget-object p1, Lxyz/chz/injector/MainActivity;->b:Lxyz/chz/injector/MainActivity;

    invoke-static {p1}, Lh0/i;->e(Landroid/content/Context;)Z

    move-result p1

    const p2, 0x7f0b003e

    const-string v1, "USER_VPN_PASSWORD_CANCELLED"

    const/4 v2, 0x0

    if-nez p1, :cond_0

    invoke-static {v1, p3, p2, v0}, Lg0/d;->o(Ljava/lang/String;Ljava/lang/String;ILg0/a;)V

    sget-object p1, Lxyz/chz/injector/MainActivity;->b:Lxyz/chz/injector/MainActivity;

    const p2, 0x7f0b0012

    goto :goto_0

    :cond_0
    iget-object p1, p0, Lc0/g;->a:Lk0/a;

    const/4 v3, 0x1

    const-string v4, "tunnelType"

    invoke-virtual {p1, v4, v3}, Lk0/a;->getInt(Ljava/lang/String;I)I

    move-result p1

    const/4 v4, 0x2

    if-ne p1, v4, :cond_2

    iget-object p1, p0, Lc0/g;->d:Lf0/a;

    const-string v4, "proxyRemoto"

    invoke-virtual {p1, v4}, Lf0/a;->b(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    invoke-virtual {p1}, Ljava/lang/String;->isEmpty()Z

    move-result p1

    if-nez p1, :cond_1

    iget-object p1, p0, Lc0/g;->d:Lf0/a;

    const-string v4, "proxyRemotoPorta"

    invoke-virtual {p1, v4}, Lf0/a;->b(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    invoke-virtual {p1}, Ljava/lang/String;->isEmpty()Z

    move-result p1

    if-eqz p1, :cond_2

    :cond_1
    invoke-static {v1, p3, p2, v0}, Lg0/d;->o(Ljava/lang/String;Ljava/lang/String;ILg0/a;)V

    sget-object p1, Lxyz/chz/injector/MainActivity;->b:Lxyz/chz/injector/MainActivity;

    const p2, 0x7f0b0013

    goto :goto_0

    :cond_2
    iget-object p1, p0, Lc0/g;->a:Lk0/a;

    const-string v4, "usarDefaultPayload"

    invoke-virtual {p1, v4, v3}, Lk0/a;->getBoolean(Ljava/lang/String;Z)Z

    move-result p1

    if-nez p1, :cond_3

    iget-object p1, p0, Lc0/g;->d:Lf0/a;

    const-string v3, "proxyPayload"

    invoke-virtual {p1, v3}, Lf0/a;->b(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    invoke-virtual {p1}, Ljava/lang/String;->isEmpty()Z

    move-result p1

    if-eqz p1, :cond_3

    invoke-static {v1, p3, p2, v0}, Lg0/d;->o(Ljava/lang/String;Ljava/lang/String;ILg0/a;)V

    sget-object p1, Lxyz/chz/injector/MainActivity;->b:Lxyz/chz/injector/MainActivity;

    const p2, 0x7f0b000e

    :goto_0
    invoke-static {p1, p2, v2}, Landroid/widget/Toast;->makeText(Landroid/content/Context;II)Landroid/widget/Toast;

    move-result-object p1

    goto :goto_4

    :cond_3
    iget-object p1, p0, Lc0/g;->d:Lf0/a;

    const-string v3, "sshServer"

    invoke-virtual {p1, v3}, Lf0/a;->b(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    invoke-virtual {p1}, Ljava/lang/String;->isEmpty()Z

    move-result p1

    if-nez p1, :cond_7

    iget-object p1, p0, Lc0/g;->d:Lf0/a;

    const-string v3, "sshPort"

    invoke-virtual {p1, v3}, Lf0/a;->b(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    invoke-virtual {p1}, Ljava/lang/String;->isEmpty()Z

    move-result p1

    if-eqz p1, :cond_4

    goto :goto_2

    :cond_4
    iget-object p1, p0, Lc0/g;->d:Lf0/a;

    const-string p2, "sshUser"

    invoke-virtual {p1, p2}, Lf0/a;->b(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    invoke-virtual {p1}, Ljava/lang/String;->isEmpty()Z

    move-result p1

    if-nez p1, :cond_6

    iget-object p1, p0, Lc0/g;->d:Lf0/a;

    const-string p2, "sshPass"

    invoke-virtual {p1, p2}, Lf0/a;->b(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    invoke-virtual {p1}, Ljava/lang/String;->isEmpty()Z

    move-result p1

    if-eqz p1, :cond_5

    goto :goto_1

    :cond_5
    sget-object p1, Lxyz/chz/injector/MainActivity;->b:Lxyz/chz/injector/MainActivity;

    invoke-static {p1}, Lh0/g;->a(Landroid/content/Context;)V

    goto :goto_5

    :cond_6
    :goto_1
    const p1, 0x7f0b003d

    const-string p2, "USER_VPN_PASSWORD"

    invoke-static {p2, p3, p1, v0}, Lg0/d;->o(Ljava/lang/String;Ljava/lang/String;ILg0/a;)V

    sget-object p1, Lxyz/chz/injector/MainActivity;->b:Lxyz/chz/injector/MainActivity;

    const-string p2, "user or password is empty!!! motherfather!!"

    goto :goto_3

    :cond_7
    :goto_2
    invoke-static {v1, p3, p2, v0}, Lg0/d;->o(Ljava/lang/String;Ljava/lang/String;ILg0/a;)V

    sget-object p1, Lxyz/chz/injector/MainActivity;->b:Lxyz/chz/injector/MainActivity;

    const-string p2, "server or port is empty"

    :goto_3
    invoke-static {p1, p2, v2}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    move-result-object p1

    :goto_4
    invoke-virtual {p1}, Landroid/widget/Toast;->show()V

    goto :goto_5

    :cond_8
    if-nez p2, :cond_9

    const p1, 0x7f0b0040

    const-string p2, "USER_VPN_PERMISSION_CANCELLED"

    invoke-static {p2, p3, p1, v0}, Lg0/d;->o(Ljava/lang/String;Ljava/lang/String;ILg0/a;)V

    sget p1, Landroid/os/Build$VERSION;->SDK_INT:I

    const/16 p2, 0x18

    if-lt p1, p2, :cond_9

    const-string p1, "error on Nougat"

    invoke-static {p1}, Lg0/d;->e(Ljava/lang/String;)V

    :cond_9
    :goto_5
    return-void
.end method

.method public final onCheckedChanged(Landroid/widget/CompoundButton;Z)V
    .locals 0

    return-void
.end method

.method public final onCreate(Landroid/os/Bundle;)V
    .locals 3

    invoke-super {p0, p1}, Landroid/preference/PreferenceFragment;->onCreate(Landroid/os/Bundle;)V

    const/high16 p1, 0x7f0e0000

    invoke-virtual {p0, p1}, Landroid/preference/PreferenceFragment;->addPreferencesFromResource(I)V

    const/4 p1, 0x1

    invoke-virtual {p0, p1}, Landroid/app/Fragment;->setHasOptionsMenu(Z)V

    new-instance v0, Lf0/a;

    invoke-virtual {p0}, Landroid/app/Fragment;->getActivity()Landroid/app/Activity;

    move-result-object v1

    invoke-virtual {v1}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object v1

    invoke-direct {v0, v1}, Lf0/a;-><init>(Landroid/content/Context;)V

    iput-object v0, p0, Lc0/g;->d:Lf0/a;

    .line 1
    iget-object v0, v0, Lf0/a;->c:Lk0/a;

    .line 2
    iput-object v0, p0, Lc0/g;->a:Lk0/a;

    sget-object v0, Lxyz/chz/injector/MainApp;->b:Landroid/content/SharedPreferences;

    iput-object v0, p0, Lc0/g;->q:Landroid/content/SharedPreferences;

    new-instance v0, Landroid/os/Handler;

    invoke-direct {v0}, Landroid/os/Handler;-><init>()V

    iput-object v0, p0, Lc0/g;->e:Landroid/os/Handler;

    iget-object v0, p0, Lc0/g;->q:Landroid/content/SharedPreferences;

    const-string v1, "connect_first_time"

    invoke-interface {v0, v1, p1}, Landroid/content/SharedPreferences;->getBoolean(Ljava/lang/String;Z)Z

    move-result v0

    if-eqz v0, :cond_0

    iget-object v0, p0, Lc0/g;->q:Landroid/content/SharedPreferences;

    invoke-interface {v0}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object v0

    const/4 v2, 0x0

    invoke-interface {v0, v1, v2}, Landroid/content/SharedPreferences$Editor;->putBoolean(Ljava/lang/String;Z)Landroid/content/SharedPreferences$Editor;

    move-result-object v0

    invoke-interface {v0}, Landroid/content/SharedPreferences$Editor;->apply()V

    invoke-virtual {p0}, Landroid/app/Fragment;->getActivity()Landroid/app/Activity;

    move-result-object v0

    invoke-virtual {v0}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object v0

    .line 3
    invoke-static {v0}, Landroid/preference/PreferenceManager;->getDefaultSharedPreferences(Landroid/content/Context;)Landroid/content/SharedPreferences;

    move-result-object v0

    invoke-interface {v0}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object v0

    const-string v1, "dnsForward"

    invoke-interface {v0, v1, p1}, Landroid/content/SharedPreferences$Editor;->putBoolean(Ljava/lang/String;Z)Landroid/content/SharedPreferences$Editor;

    const-string v1, "udpForward"

    invoke-interface {v0, v1, p1}, Landroid/content/SharedPreferences$Editor;->putBoolean(Ljava/lang/String;Z)Landroid/content/SharedPreferences$Editor;

    const-string v1, "udpResolver"

    const-string v2, "127.0.0.1:7300"

    invoke-interface {v0, v1, v2}, Landroid/content/SharedPreferences$Editor;->putString(Ljava/lang/String;Ljava/lang/String;)Landroid/content/SharedPreferences$Editor;

    const-string v1, "dnsResolver1"

    const-string v2, "1.1.1.1"

    invoke-interface {v0, v1, v2}, Landroid/content/SharedPreferences$Editor;->putString(Ljava/lang/String;Ljava/lang/String;)Landroid/content/SharedPreferences$Editor;

    const-string v1, "dnsResolver2"

    const-string v2, "1.0.0.1"

    invoke-interface {v0, v1, v2}, Landroid/content/SharedPreferences$Editor;->putString(Ljava/lang/String;Ljava/lang/String;)Landroid/content/SharedPreferences$Editor;

    const-string v1, "numberMaxThreadSocks"

    const-string v2, "0th"

    invoke-interface {v0, v1, v2}, Landroid/content/SharedPreferences$Editor;->putString(Ljava/lang/String;Ljava/lang/String;)Landroid/content/SharedPreferences$Editor;

    const-string v1, "data_compression"

    invoke-interface {v0, v1, p1}, Landroid/content/SharedPreferences$Editor;->putBoolean(Ljava/lang/String;Z)Landroid/content/SharedPreferences$Editor;

    const-string p1, "modeDebug"

    invoke-interface {v0, p1}, Landroid/content/SharedPreferences$Editor;->remove(Ljava/lang/String;)Landroid/content/SharedPreferences$Editor;

    const-string p1, "filterApps"

    invoke-interface {v0, p1}, Landroid/content/SharedPreferences$Editor;->remove(Ljava/lang/String;)Landroid/content/SharedPreferences$Editor;

    const-string p1, "filterBypassMode"

    invoke-interface {v0, p1}, Landroid/content/SharedPreferences$Editor;->remove(Ljava/lang/String;)Landroid/content/SharedPreferences$Editor;

    const-string p1, "filterAppsList"

    invoke-interface {v0, p1}, Landroid/content/SharedPreferences$Editor;->remove(Ljava/lang/String;)Landroid/content/SharedPreferences$Editor;

    const-string p1, "tetherSubnet"

    invoke-interface {v0, p1}, Landroid/content/SharedPreferences$Editor;->remove(Ljava/lang/String;)Landroid/content/SharedPreferences$Editor;

    const-string p1, "disableDelaySSH"

    invoke-interface {v0, p1}, Landroid/content/SharedPreferences$Editor;->remove(Ljava/lang/String;)Landroid/content/SharedPreferences$Editor;

    invoke-interface {v0}, Landroid/content/SharedPreferences$Editor;->commit()Z

    .line 4
    :cond_0
    new-instance p1, Lj0/c;

    invoke-virtual {p0}, Landroid/app/Fragment;->getActivity()Landroid/app/Activity;

    move-result-object v0

    invoke-virtual {v0}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object v0

    invoke-direct {p1, v0}, Lj0/c;-><init>(Landroid/content/Context;)V

    sput-object p1, Lc0/g;->s:Lj0/c;

    const-string p1, "profile"

    .line 5
    invoke-virtual {p0, p1}, Landroid/preference/PreferenceFragment;->findPreference(Ljava/lang/CharSequence;)Landroid/preference/Preference;

    move-result-object p1

    check-cast p1, Landroid/preference/ListPreference;

    iput-object p1, p0, Lc0/g;->g:Landroid/preference/ListPreference;

    const-string p1, "host_ssh_ok"

    invoke-virtual {p0, p1}, Landroid/preference/PreferenceFragment;->findPreference(Ljava/lang/CharSequence;)Landroid/preference/Preference;

    move-result-object p1

    check-cast p1, Landroid/preference/EditTextPreference;

    iput-object p1, p0, Lc0/g;->i:Landroid/preference/EditTextPreference;

    const-string p1, "conf_payload"

    invoke-virtual {p0, p1}, Landroid/preference/PreferenceFragment;->findPreference(Ljava/lang/CharSequence;)Landroid/preference/Preference;

    move-result-object p1

    check-cast p1, Landroid/preference/EditTextPreference;

    iput-object p1, p0, Lc0/g;->j:Landroid/preference/EditTextPreference;

    const-string p1, "conf_proxys"

    invoke-virtual {p0, p1}, Landroid/preference/PreferenceFragment;->findPreference(Ljava/lang/CharSequence;)Landroid/preference/Preference;

    move-result-object p1

    check-cast p1, Landroid/preference/EditTextPreference;

    iput-object p1, p0, Lc0/g;->k:Landroid/preference/EditTextPreference;

    const-string p1, "conf_sni"

    invoke-virtual {p0, p1}, Landroid/preference/PreferenceFragment;->findPreference(Ljava/lang/CharSequence;)Landroid/preference/Preference;

    move-result-object p1

    check-cast p1, Landroid/preference/EditTextPreference;

    iput-object p1, p0, Lc0/g;->l:Landroid/preference/EditTextPreference;

    const-string p1, "conf_dns"

    invoke-virtual {p0, p1}, Landroid/preference/PreferenceFragment;->findPreference(Ljava/lang/CharSequence;)Landroid/preference/Preference;

    move-result-object p1

    check-cast p1, Landroid/preference/EditTextPreference;

    iput-object p1, p0, Lc0/g;->m:Landroid/preference/EditTextPreference;

    const-string p1, "conf_udpgw"

    invoke-virtual {p0, p1}, Landroid/preference/PreferenceFragment;->findPreference(Ljava/lang/CharSequence;)Landroid/preference/Preference;

    move-result-object p1

    check-cast p1, Landroid/preference/EditTextPreference;

    iput-object p1, p0, Lc0/g;->n:Landroid/preference/EditTextPreference;

    const-string p1, "auto_ping"

    invoke-virtual {p0, p1}, Landroid/preference/PreferenceFragment;->findPreference(Ljava/lang/CharSequence;)Landroid/preference/Preference;

    move-result-object p1

    check-cast p1, Landroid/preference/CheckBoxPreference;

    iput-object p1, p0, Lc0/g;->o:Landroid/preference/CheckBoxPreference;

    const-string p1, "isRunning"

    invoke-virtual {p0, p1}, Landroid/preference/PreferenceFragment;->findPreference(Ljava/lang/CharSequence;)Landroid/preference/Preference;

    move-result-object p1

    check-cast p1, Landroid/preference/SwitchPreference;

    iput-object p1, p0, Lc0/g;->p:Landroid/preference/SwitchPreference;

    const-string p1, "tlsForcing"

    invoke-virtual {p0, p1}, Landroid/preference/PreferenceFragment;->findPreference(Ljava/lang/CharSequence;)Landroid/preference/Preference;

    move-result-object p1

    check-cast p1, Landroid/preference/ListPreference;

    iput-object p1, p0, Lc0/g;->h:Landroid/preference/ListPreference;

    iget-object p1, p0, Lc0/g;->g:Landroid/preference/ListPreference;

    invoke-virtual {p1, p0}, Landroid/preference/Preference;->setOnPreferenceChangeListener(Landroid/preference/Preference$OnPreferenceChangeListener;)V

    iget-object p1, p0, Lc0/g;->i:Landroid/preference/EditTextPreference;

    invoke-virtual {p1, p0}, Landroid/preference/Preference;->setOnPreferenceChangeListener(Landroid/preference/Preference$OnPreferenceChangeListener;)V

    iget-object p1, p0, Lc0/g;->j:Landroid/preference/EditTextPreference;

    invoke-virtual {p1, p0}, Landroid/preference/Preference;->setOnPreferenceChangeListener(Landroid/preference/Preference$OnPreferenceChangeListener;)V

    iget-object p1, p0, Lc0/g;->k:Landroid/preference/EditTextPreference;

    invoke-virtual {p1, p0}, Landroid/preference/Preference;->setOnPreferenceChangeListener(Landroid/preference/Preference$OnPreferenceChangeListener;)V

    iget-object p1, p0, Lc0/g;->l:Landroid/preference/EditTextPreference;

    invoke-virtual {p1, p0}, Landroid/preference/Preference;->setOnPreferenceChangeListener(Landroid/preference/Preference$OnPreferenceChangeListener;)V

    iget-object p1, p0, Lc0/g;->m:Landroid/preference/EditTextPreference;

    invoke-virtual {p1, p0}, Landroid/preference/Preference;->setOnPreferenceChangeListener(Landroid/preference/Preference$OnPreferenceChangeListener;)V

    iget-object p1, p0, Lc0/g;->n:Landroid/preference/EditTextPreference;

    invoke-virtual {p1, p0}, Landroid/preference/Preference;->setOnPreferenceChangeListener(Landroid/preference/Preference$OnPreferenceChangeListener;)V

    iget-object p1, p0, Lc0/g;->o:Landroid/preference/CheckBoxPreference;

    invoke-virtual {p1, p0}, Landroid/preference/Preference;->setOnPreferenceChangeListener(Landroid/preference/Preference$OnPreferenceChangeListener;)V

    iget-object p1, p0, Lc0/g;->p:Landroid/preference/SwitchPreference;

    invoke-virtual {p1, p0}, Landroid/preference/Preference;->setOnPreferenceChangeListener(Landroid/preference/Preference$OnPreferenceChangeListener;)V

    iget-object p1, p0, Lc0/g;->h:Landroid/preference/ListPreference;

    invoke-virtual {p1, p0}, Landroid/preference/Preference;->setOnPreferenceChangeListener(Landroid/preference/Preference$OnPreferenceChangeListener;)V

    .line 6
    invoke-virtual {p0}, Lc0/g;->c()V

    return-void
.end method

.method public final onCreateOptionsMenu(Landroid/view/Menu;Landroid/view/MenuInflater;)V
    .locals 2

    invoke-super {p0, p1, p2}, Landroid/app/Fragment;->onCreateOptionsMenu(Landroid/view/Menu;Landroid/view/MenuInflater;)V

    const/high16 v0, 0x7f090000

    invoke-virtual {p2, v0, p1}, Landroid/view/MenuInflater;->inflate(ILandroid/view/Menu;)V

    iget-object p2, p0, Lc0/g;->a:Lk0/a;

    const-string v0, "hotspotKeeyy"

    const/4 v1, 0x0

    invoke-virtual {p2, v0, v1}, Lk0/a;->getBoolean(Ljava/lang/String;Z)Z

    move-result p2

    const v0, 0x7f06002c

    invoke-interface {p1, v0}, Landroid/view/Menu;->findItem(I)Landroid/view/MenuItem;

    move-result-object v0

    invoke-interface {v0, p2}, Landroid/view/MenuItem;->setChecked(Z)Landroid/view/MenuItem;

    iget-object p2, p0, Lc0/g;->a:Lk0/a;

    const-string v0, "HotspotRootKey"

    invoke-virtual {p2, v0, v1}, Lk0/a;->getBoolean(Ljava/lang/String;Z)Z

    move-result p2

    const v0, 0x7f06004a

    invoke-interface {p1, v0}, Landroid/view/Menu;->findItem(I)Landroid/view/MenuItem;

    move-result-object p1

    invoke-interface {p1, p2}, Landroid/view/MenuItem;->setChecked(Z)Landroid/view/MenuItem;

    return-void
.end method

.method public final onOptionsItemSelected(Landroid/view/MenuItem;)Z
    .locals 8

    const-string v0, "[:]"

    invoke-interface {p1}, Landroid/view/MenuItem;->getItemId()I

    move-result v1

    const/4 v2, 0x1

    const/4 v3, 0x0

    const v4, 0x7f06003f

    if-ne v1, v4, :cond_0

    .line 1
    sget-object p1, Lxyz/chz/injector/MainActivity;->b:Lxyz/chz/injector/MainActivity;

    invoke-static {p1}, Landroid/view/LayoutInflater;->from(Landroid/content/Context;)Landroid/view/LayoutInflater;

    move-result-object p1

    const/high16 v0, 0x7f080000

    const/4 v1, 0x0

    invoke-virtual {p1, v0, v1}, Landroid/view/LayoutInflater;->inflate(ILandroid/view/ViewGroup;)Landroid/view/View;

    move-result-object p1

    new-instance v0, Landroid/app/AlertDialog$Builder;

    sget-object v1, Lxyz/chz/injector/MainActivity;->b:Lxyz/chz/injector/MainActivity;

    invoke-direct {v0, v1}, Landroid/app/AlertDialog$Builder;-><init>(Landroid/content/Context;)V

    invoke-virtual {v0, p1}, Landroid/app/AlertDialog$Builder;->setView(Landroid/view/View;)Landroid/app/AlertDialog$Builder;

    const v1, 0x7f060026

    invoke-virtual {p1, v1}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object p1

    check-cast p1, Landroid/widget/TextView;

    :try_start_0
    invoke-virtual {p0}, Landroid/app/Fragment;->getActivity()Landroid/app/Activity;

    move-result-object v1

    invoke-virtual {v1}, Landroid/content/Context;->getPackageManager()Landroid/content/pm/PackageManager;

    move-result-object v1

    invoke-virtual {p0}, Landroid/app/Fragment;->getActivity()Landroid/app/Activity;

    move-result-object v4

    invoke-virtual {v4}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v1, v4, v3}, Landroid/content/pm/PackageManager;->getPackageInfo(Ljava/lang/String;I)Landroid/content/pm/PackageInfo;

    move-result-object v1

    const-string v4, "App Ver: v%s (%s)"

    const/4 v5, 0x2

    new-array v5, v5, [Ljava/lang/Object;

    iget-object v6, v1, Landroid/content/pm/PackageInfo;->versionName:Ljava/lang/String;

    aput-object v6, v5, v3

    iget v1, v1, Landroid/content/pm/PackageInfo;->versionCode:I

    invoke-static {v1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v1

    aput-object v1, v5, v2

    invoke-static {v4, v5}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {p1, v1}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V
    :try_end_0
    .catch Landroid/content/pm/PackageManager$NameNotFoundException; {:try_start_0 .. :try_end_0} :catch_0

    :catch_0
    invoke-virtual {v0}, Landroid/app/AlertDialog$Builder;->create()Landroid/app/AlertDialog;

    move-result-object p1

    invoke-virtual {p1}, Landroid/app/Dialog;->show()V

    invoke-virtual {p0}, Landroid/app/Fragment;->getResources()Landroid/content/res/Resources;

    move-result-object v0

    invoke-virtual {v0}, Landroid/content/res/Resources;->getDisplayMetrics()Landroid/util/DisplayMetrics;

    move-result-object v0

    iget v0, v0, Landroid/util/DisplayMetrics;->widthPixels:I

    int-to-double v0, v0

    const-wide v3, 0x3fe999999999999aL    # 0.8

    mul-double v0, v0, v3

    double-to-int v0, v0

    invoke-virtual {p0}, Landroid/app/Fragment;->getResources()Landroid/content/res/Resources;

    move-result-object v1

    invoke-virtual {v1}, Landroid/content/res/Resources;->getDisplayMetrics()Landroid/util/DisplayMetrics;

    move-result-object v1

    iget v1, v1, Landroid/util/DisplayMetrics;->heightPixels:I

    invoke-virtual {p1}, Landroid/app/Dialog;->getWindow()Landroid/view/Window;

    move-result-object p1

    const/4 v1, -0x2

    invoke-virtual {p1, v0, v1}, Landroid/view/Window;->setLayout(II)V

    return v2

    :cond_0
    const v4, 0x7f060040

    if-ne v1, v4, :cond_1

    .line 2
    invoke-virtual {p0}, Lc0/g;->f()V

    return v2

    :cond_1
    const v4, 0x7f060039

    const/high16 v5, 0x1040000

    const v6, 0x104000a

    const-string v7, "Service Running"

    if-ne v1, v4, :cond_3

    iget-boolean p1, p0, Lc0/g;->r:Z

    if-nez p1, :cond_2

    sget-object p1, Lxyz/chz/injector/MainActivity;->b:Lxyz/chz/injector/MainActivity;

    invoke-static {p1, v7, v3}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    move-result-object p1

    invoke-virtual {p1}, Landroid/widget/Toast;->show()V

    goto :goto_0

    .line 3
    :cond_2
    new-instance p1, Landroid/widget/EditText;

    invoke-virtual {p0}, Landroid/app/Fragment;->getActivity()Landroid/app/Activity;

    move-result-object v0

    invoke-direct {p1, v0}, Landroid/widget/EditText;-><init>(Landroid/content/Context;)V

    invoke-virtual {p1, v2}, Landroid/widget/TextView;->setSingleLine(Z)V

    new-instance v0, Landroid/app/AlertDialog$Builder;

    invoke-virtual {p0}, Landroid/app/Fragment;->getActivity()Landroid/app/Activity;

    move-result-object v1

    invoke-direct {v0, v1}, Landroid/app/AlertDialog$Builder;-><init>(Landroid/content/Context;)V

    const v1, 0x7f0b001e

    invoke-virtual {v0, v1}, Landroid/app/AlertDialog$Builder;->setTitle(I)Landroid/app/AlertDialog$Builder;

    move-result-object v0

    invoke-virtual {v0, p1}, Landroid/app/AlertDialog$Builder;->setView(Landroid/view/View;)Landroid/app/AlertDialog$Builder;

    move-result-object v0

    new-instance v1, Lc0/d;

    invoke-direct {v1, p0, p1}, Lc0/d;-><init>(Lc0/g;Landroid/widget/EditText;)V

    invoke-virtual {v0, v6, v1}, Landroid/app/AlertDialog$Builder;->setPositiveButton(ILandroid/content/DialogInterface$OnClickListener;)Landroid/app/AlertDialog$Builder;

    move-result-object p1

    sget-object v0, Lc0/e;->b:Lc0/e;

    invoke-virtual {p1, v5, v0}, Landroid/app/AlertDialog$Builder;->setNegativeButton(ILandroid/content/DialogInterface$OnClickListener;)Landroid/app/AlertDialog$Builder;

    move-result-object p1

    invoke-virtual {p1}, Landroid/app/AlertDialog$Builder;->create()Landroid/app/AlertDialog;

    move-result-object p1

    invoke-virtual {p1}, Landroid/app/Dialog;->show()V

    :goto_0
    return v2

    :cond_3
    const v4, 0x7f06003a

    if-ne v1, v4, :cond_5

    .line 4
    iget-boolean p1, p0, Lc0/g;->r:Z

    if-nez p1, :cond_4

    sget-object p1, Lxyz/chz/injector/MainActivity;->b:Lxyz/chz/injector/MainActivity;

    invoke-static {p1, v7, v3}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    move-result-object p1

    invoke-virtual {p1}, Landroid/widget/Toast;->show()V

    goto :goto_1

    .line 5
    :cond_4
    new-instance p1, Landroid/app/AlertDialog$Builder;

    invoke-virtual {p0}, Landroid/app/Fragment;->getActivity()Landroid/app/Activity;

    move-result-object v0

    invoke-direct {p1, v0}, Landroid/app/AlertDialog$Builder;-><init>(Landroid/content/Context;)V

    const v0, 0x7f0b0020

    invoke-virtual {p1, v0}, Landroid/app/AlertDialog$Builder;->setTitle(I)Landroid/app/AlertDialog$Builder;

    move-result-object p1

    const v0, 0x7f0b0021

    invoke-virtual {p0, v0}, Landroid/app/Fragment;->getString(I)Ljava/lang/String;

    move-result-object v0

    new-array v1, v2, [Ljava/lang/Object;

    iget-object v4, p0, Lc0/g;->f:Lj0/b;

    .line 6
    iget-object v4, v4, Lj0/b;->b:Ljava/lang/String;

    aput-object v4, v1, v3

    .line 7
    invoke-static {v0, v1}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p1, v0}, Landroid/app/AlertDialog$Builder;->setMessage(Ljava/lang/CharSequence;)Landroid/app/AlertDialog$Builder;

    move-result-object p1

    new-instance v0, Lc0/c;

    invoke-direct {v0, p0}, Lc0/c;-><init>(Lc0/g;)V

    invoke-virtual {p1, v6, v0}, Landroid/app/AlertDialog$Builder;->setPositiveButton(ILandroid/content/DialogInterface$OnClickListener;)Landroid/app/AlertDialog$Builder;

    move-result-object p1

    sget-object v0, Lc0/e;->c:Lc0/e;

    invoke-virtual {p1, v5, v0}, Landroid/app/AlertDialog$Builder;->setNegativeButton(ILandroid/content/DialogInterface$OnClickListener;)Landroid/app/AlertDialog$Builder;

    move-result-object p1

    invoke-virtual {p1}, Landroid/app/AlertDialog$Builder;->create()Landroid/app/AlertDialog;

    move-result-object p1

    invoke-virtual {p1}, Landroid/app/Dialog;->show()V

    :goto_1
    return v2

    :cond_5
    const v4, 0x7f06002c

    if-ne v1, v4, :cond_8

    .line 8
    iget-boolean v0, p0, Lc0/g;->r:Z

    if-nez v0, :cond_6

    sget-object p1, Lxyz/chz/injector/MainActivity;->b:Lxyz/chz/injector/MainActivity;

    invoke-static {p1, v7, v3}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    move-result-object p1

    invoke-virtual {p1}, Landroid/widget/Toast;->show()V

    sget-object p1, Lxyz/chz/injector/MainActivity;->b:Lxyz/chz/injector/MainActivity;

    invoke-static {p1, v7, v3}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    move-result-object p1

    invoke-virtual {p1}, Landroid/widget/Toast;->show()V

    goto :goto_2

    :cond_6
    invoke-static {v3}, Lj0/e;->b(Z)Ljava/lang/String;

    move-result-object v0

    const-string v1, "hotspotKeeyy"

    if-nez v0, :cond_7

    sget-object v0, Lxyz/chz/injector/MainActivity;->b:Lxyz/chz/injector/MainActivity;

    const-string v4, "Turn on MOBILE Hotspot first"

    invoke-static {v0, v4, v2}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    move-result-object v0

    invoke-virtual {v0}, Landroid/widget/Toast;->show()V

    invoke-interface {p1, v3}, Landroid/view/MenuItem;->setChecked(Z)Landroid/view/MenuItem;

    iget-object p1, p0, Lc0/g;->a:Lk0/a;

    invoke-static {p1}, Ljava/util/Objects;->requireNonNull(Ljava/lang/Object;)Ljava/lang/Object;

    .line 9
    iget-object v0, p1, Lk0/a;->b:Landroid/content/SharedPreferences;

    .line 10
    invoke-interface {v0}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object v0

    .line 11
    invoke-virtual {p1, v1}, Lk0/a;->c(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    .line 12
    invoke-static {v3}, Ljava/lang/Boolean;->toString(Z)Ljava/lang/String;

    move-result-object v2

    invoke-static {p1, v2}, Lk0/a;->a(Lk0/a;Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    invoke-interface {v0, v1, p1}, Landroid/content/SharedPreferences$Editor;->putString(Ljava/lang/String;Ljava/lang/String;)Landroid/content/SharedPreferences$Editor;

    .line 13
    invoke-interface {v0}, Landroid/content/SharedPreferences$Editor;->apply()V

    return v3

    .line 14
    :cond_7
    invoke-interface {p1}, Landroid/view/MenuItem;->isChecked()Z

    move-result v0

    xor-int/2addr v0, v2

    invoke-interface {p1, v0}, Landroid/view/MenuItem;->setChecked(Z)Landroid/view/MenuItem;

    iget-object v0, p0, Lc0/g;->a:Lk0/a;

    invoke-static {v0}, Ljava/util/Objects;->requireNonNull(Ljava/lang/Object;)Ljava/lang/Object;

    .line 15
    iget-object v3, v0, Lk0/a;->b:Landroid/content/SharedPreferences;

    .line 16
    invoke-interface {v3}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object v3

    .line 17
    invoke-interface {p1}, Landroid/view/MenuItem;->isChecked()Z

    move-result p1

    .line 18
    invoke-virtual {v0, v1}, Lk0/a;->c(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    .line 19
    invoke-static {p1}, Ljava/lang/Boolean;->toString(Z)Ljava/lang/String;

    move-result-object p1

    invoke-static {v0, p1}, Lk0/a;->a(Lk0/a;Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    invoke-interface {v3, v1, p1}, Landroid/content/SharedPreferences$Editor;->putString(Ljava/lang/String;Ljava/lang/String;)Landroid/content/SharedPreferences$Editor;

    .line 20
    invoke-interface {v3}, Landroid/content/SharedPreferences$Editor;->apply()V

    :goto_2
    return v2

    :cond_8
    const v4, 0x7f06004a

    if-ne v1, v4, :cond_c

    .line 21
    iget-boolean v1, p0, Lc0/g;->r:Z

    const-string v4, "HotspotRootKey"

    if-nez v1, :cond_b

    invoke-static {v3}, Lj0/e;->b(Z)Ljava/lang/String;

    move-result-object v1

    if-eqz v1, :cond_a

    invoke-interface {p1}, Landroid/view/MenuItem;->isChecked()Z

    move-result v1

    if-nez v1, :cond_9

    :try_start_1
    iget-object v1, p0, Lc0/g;->f:Lj0/b;

    invoke-virtual {v1}, Lj0/b;->a()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v1, v0}, Ljava/lang/String;->split(Ljava/lang/String;)[Ljava/lang/String;

    move-result-object v1

    aget-object v1, v1, v3

    iget-object v5, p0, Lc0/g;->f:Lj0/b;

    invoke-virtual {v5}, Lj0/b;->a()Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v5, v0}, Ljava/lang/String;->split(Ljava/lang/String;)[Ljava/lang/String;

    move-result-object v0

    aget-object v0, v0, v2

    invoke-static {v1, v0}, Lj0/e;->d(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    invoke-static {v0}, Lj0/e;->a(Ljava/lang/String;)I

    sget-object v0, Lxyz/chz/injector/MainActivity;->b:Lxyz/chz/injector/MainActivity;

    const-string v1, "Hotspot root on"

    goto :goto_3

    :cond_9
    const-string v0, "iptables -t nat -F PREROUTING && while iptables -D FORWARD -j vpnhotspot_fwd; do done && iptables -F vpnhotspot_fwd && iptables -X vpnhotspot_fwd && while iptables -t nat -D POSTROUTING -j vpnhotspot_masquerade; do done && iptables -t nat -F vpnhotspot_masquerade && iptables -t nat -X vpnhotspot_masquerade && while ip rule del priority 17700; do done && while ip rule del priority 17701; do done && while ip rule del priority 17800; do done && while ip rule del priority 17900; do done && while ip rule del priority 17980; do done"

    invoke-static {v0}, Lj0/e;->a(Ljava/lang/String;)I

    sget-object v0, Lxyz/chz/injector/MainActivity;->b:Lxyz/chz/injector/MainActivity;

    const-string v1, "Hotspot root off"

    :goto_3
    invoke-static {v0, v1, v3}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    move-result-object v0

    invoke-virtual {v0}, Landroid/widget/Toast;->show()V
    :try_end_1
    .catch Ljava/lang/InterruptedException; {:try_start_1 .. :try_end_1} :catch_1
    .catch Ljava/io/IOException; {:try_start_1 .. :try_end_1} :catch_1

    :catch_1
    invoke-interface {p1}, Landroid/view/MenuItem;->isChecked()Z

    move-result v0

    xor-int/2addr v0, v2

    invoke-interface {p1, v0}, Landroid/view/MenuItem;->setChecked(Z)Landroid/view/MenuItem;

    iget-object v0, p0, Lc0/g;->a:Lk0/a;

    invoke-static {v0}, Ljava/util/Objects;->requireNonNull(Ljava/lang/Object;)Ljava/lang/Object;

    .line 22
    iget-object v1, v0, Lk0/a;->b:Landroid/content/SharedPreferences;

    .line 23
    invoke-interface {v1}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object v1

    .line 24
    invoke-interface {p1}, Landroid/view/MenuItem;->isChecked()Z

    move-result p1

    .line 25
    invoke-virtual {v0, v4}, Lk0/a;->c(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    .line 26
    invoke-static {p1}, Ljava/lang/Boolean;->toString(Z)Ljava/lang/String;

    move-result-object p1

    invoke-static {v0, p1}, Lk0/a;->a(Lk0/a;Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    invoke-interface {v1, v3, p1}, Landroid/content/SharedPreferences$Editor;->putString(Ljava/lang/String;Ljava/lang/String;)Landroid/content/SharedPreferences$Editor;

    .line 27
    invoke-interface {v1}, Landroid/content/SharedPreferences$Editor;->apply()V

    return v2

    .line 28
    :cond_a
    invoke-interface {p1, v3}, Landroid/view/MenuItem;->setChecked(Z)Landroid/view/MenuItem;

    iget-object p1, p0, Lc0/g;->a:Lk0/a;

    invoke-static {p1}, Ljava/util/Objects;->requireNonNull(Ljava/lang/Object;)Ljava/lang/Object;

    .line 29
    iget-object v0, p1, Lk0/a;->b:Landroid/content/SharedPreferences;

    .line 30
    invoke-interface {v0}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object v0

    .line 31
    invoke-virtual {p1, v4}, Lk0/a;->c(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    .line 32
    invoke-static {v3}, Ljava/lang/Boolean;->toString(Z)Ljava/lang/String;

    move-result-object v2

    invoke-static {p1, v2}, Lk0/a;->a(Lk0/a;Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    invoke-interface {v0, v1, p1}, Landroid/content/SharedPreferences$Editor;->putString(Ljava/lang/String;Ljava/lang/String;)Landroid/content/SharedPreferences$Editor;

    .line 33
    invoke-interface {v0}, Landroid/content/SharedPreferences$Editor;->apply()V

    .line 34
    sget-object p1, Lxyz/chz/injector/MainActivity;->b:Lxyz/chz/injector/MainActivity;

    const-string v0, "Turn on hotspot first"

    goto :goto_4

    :cond_b
    invoke-interface {p1, v3}, Landroid/view/MenuItem;->setChecked(Z)Landroid/view/MenuItem;

    iget-object p1, p0, Lc0/g;->a:Lk0/a;

    invoke-static {p1}, Ljava/util/Objects;->requireNonNull(Ljava/lang/Object;)Ljava/lang/Object;

    .line 35
    iget-object v0, p1, Lk0/a;->b:Landroid/content/SharedPreferences;

    .line 36
    invoke-interface {v0}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object v0

    .line 37
    invoke-virtual {p1, v4}, Lk0/a;->c(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    .line 38
    invoke-static {v3}, Ljava/lang/Boolean;->toString(Z)Ljava/lang/String;

    move-result-object v2

    invoke-static {p1, v2}, Lk0/a;->a(Lk0/a;Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    invoke-interface {v0, v1, p1}, Landroid/content/SharedPreferences$Editor;->putString(Ljava/lang/String;Ljava/lang/String;)Landroid/content/SharedPreferences$Editor;

    .line 39
    invoke-interface {v0}, Landroid/content/SharedPreferences$Editor;->apply()V

    .line 40
    sget-object p1, Lxyz/chz/injector/MainActivity;->b:Lxyz/chz/injector/MainActivity;

    const-string v0, "Start VPN first"

    :goto_4
    invoke-static {p1, v0, v3}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    move-result-object p1

    invoke-virtual {p1}, Landroid/widget/Toast;->show()V

    return v3

    :cond_c
    invoke-super {p0, p1}, Landroid/app/Fragment;->onOptionsItemSelected(Landroid/view/MenuItem;)Z

    move-result p1

    return p1
.end method

.method public final onPause()V
    .locals 0

    invoke-super {p0}, Landroid/app/Fragment;->onPause()V

    invoke-static {p0}, Lg0/d;->m(Lg0/d$b;)V

    return-void
.end method

.method public final onPreferenceChange(Landroid/preference/Preference;Ljava/lang/Object;)Z
    .locals 18

    move-object/from16 v0, p0

    move-object/from16 v1, p1

    iget-object v2, v0, Lc0/g;->p:Landroid/preference/SwitchPreference;

    const/4 v4, 0x4

    const/4 v6, 0x2

    const/4 v7, 0x1

    const/4 v8, 0x0

    const-string v9, ""

    const-string v10, "udpgws"

    const-string v11, "autopings"

    const-string v12, "[@:]"

    const-string v13, ":"

    if-ne v1, v2, :cond_f

    const-string v1, "[:]"

    .line 1
    :try_start_0
    iget-object v2, v0, Lc0/g;->f:Lj0/b;

    invoke-virtual {v2}, Lj0/b;->e()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v2, v12}, Ljava/lang/String;->split(Ljava/lang/String;)[Ljava/lang/String;

    move-result-object v2

    iget-object v12, v0, Lc0/g;->f:Lj0/b;

    invoke-virtual {v12}, Lj0/b;->c()Ljava/lang/String;

    move-result-object v12

    invoke-virtual {v12, v1}, Ljava/lang/String;->split(Ljava/lang/String;)[Ljava/lang/String;

    move-result-object v12

    iget-object v14, v0, Lc0/g;->f:Lj0/b;

    invoke-virtual {v14}, Lj0/b;->a()Ljava/lang/String;

    move-result-object v14

    invoke-virtual {v14, v1}, Ljava/lang/String;->split(Ljava/lang/String;)[Ljava/lang/String;

    move-result-object v1

    iget-object v14, v0, Lc0/g;->f:Lj0/b;

    invoke-virtual {v14}, Lj0/b;->c()Ljava/lang/String;

    move-result-object v14

    invoke-virtual {v14}, Ljava/lang/String;->isEmpty()Z

    move-result v14

    if-nez v14, :cond_0

    iget-object v14, v0, Lc0/g;->f:Lj0/b;

    invoke-virtual {v14}, Lj0/b;->b()Ljava/lang/String;

    move-result-object v14

    const-string v15, "[host]"

    aget-object v3, v2, v8

    invoke-virtual {v14, v15, v3}, Ljava/lang/String;->replace(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Ljava/lang/String;

    move-result-object v3

    const-string v14, "[host_port]"

    new-instance v15, Ljava/lang/StringBuilder;

    invoke-direct {v15}, Ljava/lang/StringBuilder;-><init>()V

    aget-object v5, v2, v8

    invoke-virtual {v15, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v15, v13}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    aget-object v5, v2, v7

    invoke-virtual {v15, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v15}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v3, v14, v5}, Ljava/lang/String;->replace(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Ljava/lang/String;

    move-result-object v3

    goto :goto_0

    :cond_0
    iget-object v3, v0, Lc0/g;->f:Lj0/b;

    invoke-virtual {v3}, Lj0/b;->b()Ljava/lang/String;

    move-result-object v3

    :goto_0
    iget-object v5, v0, Lc0/g;->a:Lk0/a;

    invoke-static {v5}, Ljava/util/Objects;->requireNonNull(Ljava/lang/Object;)Ljava/lang/Object;

    .line 2
    iget-object v13, v5, Lk0/a;->b:Landroid/content/SharedPreferences;

    .line 3
    invoke-interface {v13}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object v13

    const-string v14, "cbPinger"

    .line 4
    iget-object v15, v0, Lc0/g;->f:Lj0/b;

    .line 5
    iget-object v7, v15, Lj0/b;->a:Landroid/content/SharedPreferences;

    invoke-virtual {v15, v11}, Lj0/b;->f(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v11

    invoke-interface {v7, v11, v8}, Landroid/content/SharedPreferences;->getBoolean(Ljava/lang/String;Z)Z

    move-result v7

    .line 6
    invoke-virtual {v5, v14}, Lk0/a;->c(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v11

    .line 7
    invoke-static {v7}, Ljava/lang/Boolean;->toString(Z)Ljava/lang/String;

    move-result-object v7

    invoke-static {v5, v7}, Lk0/a;->a(Lk0/a;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v5

    invoke-interface {v13, v11, v5}, Landroid/content/SharedPreferences$Editor;->putString(Ljava/lang/String;Ljava/lang/String;)Landroid/content/SharedPreferences$Editor;

    .line 8
    invoke-interface {v13}, Landroid/content/SharedPreferences$Editor;->apply()V

    .line 9
    array-length v5, v2

    if-eq v5, v4, :cond_1

    sget-object v1, Lxyz/chz/injector/MainActivity;->b:Lxyz/chz/injector/MainActivity;

    const-string v2, "check ssh"

    :goto_1
    invoke-static {v1, v2, v8}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    move-result-object v1

    goto :goto_2

    :cond_1
    array-length v5, v1

    if-eq v5, v6, :cond_2

    sget-object v1, Lxyz/chz/injector/MainActivity;->b:Lxyz/chz/injector/MainActivity;

    const-string v2, "invalid dns"

    goto :goto_1

    :goto_2
    invoke-virtual {v1}, Landroid/widget/Toast;->show()V

    move-object/from16 v17, v9

    goto/16 :goto_7

    :cond_2
    aget-object v5, v2, v8

    invoke-virtual {v5}, Ljava/lang/String;->isEmpty()Z

    move-result v5

    if-nez v5, :cond_9

    const/4 v5, 0x1

    aget-object v7, v2, v5

    invoke-virtual {v7}, Ljava/lang/String;->isEmpty()Z

    move-result v5

    if-nez v5, :cond_9

    aget-object v5, v2, v6

    invoke-virtual {v5}, Ljava/lang/String;->isEmpty()Z

    move-result v5

    if-nez v5, :cond_9

    const/4 v5, 0x3

    aget-object v7, v2, v5

    invoke-virtual {v7}, Ljava/lang/String;->isEmpty()Z

    move-result v5

    if-eqz v5, :cond_3

    goto/16 :goto_5

    :cond_3
    iget-object v5, v0, Lc0/g;->q:Landroid/content/SharedPreferences;

    invoke-interface {v5}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object v5

    const-string v7, "dnsResolver1"

    aget-object v11, v1, v8

    invoke-virtual {v11}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object v11

    invoke-interface {v5, v7, v11}, Landroid/content/SharedPreferences$Editor;->putString(Ljava/lang/String;Ljava/lang/String;)Landroid/content/SharedPreferences$Editor;

    move-result-object v5

    invoke-interface {v5}, Landroid/content/SharedPreferences$Editor;->apply()V

    iget-object v5, v0, Lc0/g;->q:Landroid/content/SharedPreferences;

    invoke-interface {v5}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object v5

    const-string v7, "dnsResolver2"

    const/4 v11, 0x1

    aget-object v1, v1, v11

    invoke-virtual {v1}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object v1

    invoke-interface {v5, v7, v1}, Landroid/content/SharedPreferences$Editor;->putString(Ljava/lang/String;Ljava/lang/String;)Landroid/content/SharedPreferences$Editor;

    move-result-object v1

    invoke-interface {v1}, Landroid/content/SharedPreferences$Editor;->apply()V

    iget-object v1, v0, Lc0/g;->q:Landroid/content/SharedPreferences;

    invoke-interface {v1}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object v1

    const-string v5, "udpResolver"

    iget-object v7, v0, Lc0/g;->f:Lj0/b;

    .line 10
    iget-object v11, v7, Lj0/b;->a:Landroid/content/SharedPreferences;

    invoke-virtual {v7, v10}, Lj0/b;->f(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v7

    const-string v10, "127.0.0.1:7300"

    invoke-interface {v11, v7, v10}, Landroid/content/SharedPreferences;->getString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v7

    .line 11
    invoke-virtual {v7}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object v7

    invoke-interface {v1, v5, v7}, Landroid/content/SharedPreferences$Editor;->putString(Ljava/lang/String;Ljava/lang/String;)Landroid/content/SharedPreferences$Editor;

    move-result-object v1

    invoke-interface {v1}, Landroid/content/SharedPreferences$Editor;->apply()V

    iget-object v1, v0, Lc0/g;->f:Lj0/b;

    invoke-virtual {v1}, Lj0/b;->e()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/String;->isEmpty()Z

    move-result v1
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    const-string v5, "proxyRemotoPorta"

    const-string v7, "proxyRemoto"

    const-string v10, "wsPayload"

    const-string v11, "proxyPayload"

    const-string v13, "tunnelType"

    const-string v14, "usarDefaultPayload"

    const-string v15, "sshPass"

    const-string v4, "sshUser"

    const-string v6, "sshPort"

    const-string v8, "sshServer"

    if-nez v1, :cond_4

    :try_start_1
    iget-object v1, v0, Lc0/g;->f:Lj0/b;

    invoke-virtual {v1}, Lj0/b;->b()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/String;->isEmpty()Z

    move-result v1

    if-nez v1, :cond_4

    iget-object v1, v0, Lc0/g;->f:Lj0/b;

    invoke-virtual {v1}, Lj0/b;->d()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/String;->isEmpty()Z

    move-result v1

    if-nez v1, :cond_4

    iget-object v1, v0, Lc0/g;->f:Lj0/b;

    invoke-virtual {v1}, Lj0/b;->c()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/String;->isEmpty()Z

    move-result v1

    if-nez v1, :cond_4

    iget-object v1, v0, Lc0/g;->a:Lk0/a;

    invoke-static {v1}, Ljava/util/Objects;->requireNonNull(Ljava/lang/Object;)Ljava/lang/Object;
    :try_end_1
    .catch Ljava/lang/Exception; {:try_start_1 .. :try_end_1} :catch_0

    move-object/from16 v17, v9

    .line 12
    :try_start_2
    iget-object v9, v1, Lk0/a;->b:Landroid/content/SharedPreferences;

    .line 13
    invoke-interface {v9}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object v9

    move-object/from16 p1, v13

    const/16 v16, 0x0

    .line 14
    aget-object v13, v12, v16

    .line 15
    invoke-virtual {v1, v8}, Lk0/a;->c(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v8

    .line 16
    invoke-static {v1, v13}, Lk0/a;->a(Lk0/a;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    invoke-interface {v9, v8, v1}, Landroid/content/SharedPreferences$Editor;->putString(Ljava/lang/String;Ljava/lang/String;)Landroid/content/SharedPreferences$Editor;

    .line 17
    invoke-interface {v9}, Landroid/content/SharedPreferences$Editor;->apply()V

    .line 18
    iget-object v1, v0, Lc0/g;->a:Lk0/a;

    invoke-static {v1}, Ljava/util/Objects;->requireNonNull(Ljava/lang/Object;)Ljava/lang/Object;

    .line 19
    iget-object v8, v1, Lk0/a;->b:Landroid/content/SharedPreferences;

    .line 20
    invoke-interface {v8}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object v8

    const/4 v9, 0x1

    .line 21
    aget-object v13, v2, v9

    .line 22
    invoke-virtual {v1, v6}, Lk0/a;->c(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v6

    .line 23
    invoke-static {v1, v13}, Lk0/a;->a(Lk0/a;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    invoke-interface {v8, v6, v1}, Landroid/content/SharedPreferences$Editor;->putString(Ljava/lang/String;Ljava/lang/String;)Landroid/content/SharedPreferences$Editor;

    .line 24
    invoke-interface {v8}, Landroid/content/SharedPreferences$Editor;->apply()V

    .line 25
    iget-object v1, v0, Lc0/g;->a:Lk0/a;

    invoke-static {v1}, Ljava/util/Objects;->requireNonNull(Ljava/lang/Object;)Ljava/lang/Object;

    .line 26
    iget-object v6, v1, Lk0/a;->b:Landroid/content/SharedPreferences;

    .line 27
    invoke-interface {v6}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object v6

    const/4 v8, 0x2

    .line 28
    aget-object v8, v2, v8

    .line 29
    invoke-virtual {v1, v4}, Lk0/a;->c(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    .line 30
    invoke-static {v1, v8}, Lk0/a;->a(Lk0/a;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    invoke-interface {v6, v4, v1}, Landroid/content/SharedPreferences$Editor;->putString(Ljava/lang/String;Ljava/lang/String;)Landroid/content/SharedPreferences$Editor;

    .line 31
    invoke-interface {v6}, Landroid/content/SharedPreferences$Editor;->apply()V

    .line 32
    iget-object v1, v0, Lc0/g;->a:Lk0/a;

    invoke-static {v1}, Ljava/util/Objects;->requireNonNull(Ljava/lang/Object;)Ljava/lang/Object;

    .line 33
    iget-object v4, v1, Lk0/a;->b:Landroid/content/SharedPreferences;

    .line 34
    invoke-interface {v4}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object v4

    const/4 v6, 0x3

    .line 35
    aget-object v2, v2, v6

    .line 36
    invoke-virtual {v1, v15}, Lk0/a;->c(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v6

    .line 37
    invoke-static {v1, v2}, Lk0/a;->a(Lk0/a;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    invoke-interface {v4, v6, v1}, Landroid/content/SharedPreferences$Editor;->putString(Ljava/lang/String;Ljava/lang/String;)Landroid/content/SharedPreferences$Editor;

    .line 38
    invoke-interface {v4}, Landroid/content/SharedPreferences$Editor;->apply()V

    .line 39
    iget-object v1, v0, Lc0/g;->a:Lk0/a;

    invoke-static {v1}, Ljava/util/Objects;->requireNonNull(Ljava/lang/Object;)Ljava/lang/Object;

    .line 40
    iget-object v2, v1, Lk0/a;->b:Landroid/content/SharedPreferences;

    .line 41
    invoke-interface {v2}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object v2

    const/4 v4, 0x0

    .line 42
    aget-object v6, v12, v4

    .line 43
    invoke-virtual {v1, v7}, Lk0/a;->c(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    .line 44
    invoke-static {v1, v6}, Lk0/a;->a(Lk0/a;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    invoke-interface {v2, v4, v1}, Landroid/content/SharedPreferences$Editor;->putString(Ljava/lang/String;Ljava/lang/String;)Landroid/content/SharedPreferences$Editor;

    .line 45
    invoke-interface {v2}, Landroid/content/SharedPreferences$Editor;->apply()V

    .line 46
    iget-object v1, v0, Lc0/g;->a:Lk0/a;

    invoke-static {v1}, Ljava/util/Objects;->requireNonNull(Ljava/lang/Object;)Ljava/lang/Object;

    .line 47
    iget-object v2, v1, Lk0/a;->b:Landroid/content/SharedPreferences;

    .line 48
    invoke-interface {v2}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object v2

    const/4 v4, 0x1

    .line 49
    aget-object v6, v12, v4

    .line 50
    invoke-virtual {v1, v5}, Lk0/a;->c(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    .line 51
    invoke-static {v1, v6}, Lk0/a;->a(Lk0/a;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    invoke-interface {v2, v4, v1}, Landroid/content/SharedPreferences$Editor;->putString(Ljava/lang/String;Ljava/lang/String;)Landroid/content/SharedPreferences$Editor;

    .line 52
    invoke-interface {v2}, Landroid/content/SharedPreferences$Editor;->apply()V

    .line 53
    iget-object v1, v0, Lc0/g;->a:Lk0/a;

    invoke-static {v1}, Ljava/util/Objects;->requireNonNull(Ljava/lang/Object;)Ljava/lang/Object;

    .line 54
    iget-object v2, v1, Lk0/a;->b:Landroid/content/SharedPreferences;

    .line 55
    invoke-interface {v2}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object v2

    .line 56
    invoke-virtual {v1, v14}, Lk0/a;->c(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    const/4 v5, 0x0

    .line 57
    invoke-static {v5}, Ljava/lang/Boolean;->toString(Z)Ljava/lang/String;

    move-result-object v6

    invoke-static {v1, v6}, Lk0/a;->a(Lk0/a;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    invoke-interface {v2, v4, v1}, Landroid/content/SharedPreferences$Editor;->putString(Ljava/lang/String;Ljava/lang/String;)Landroid/content/SharedPreferences$Editor;

    .line 58
    invoke-interface {v2}, Landroid/content/SharedPreferences$Editor;->apply()V

    .line 59
    iget-object v1, v0, Lc0/g;->a:Lk0/a;

    invoke-static {v1}, Ljava/util/Objects;->requireNonNull(Ljava/lang/Object;)Ljava/lang/Object;

    .line 60
    iget-object v2, v1, Lk0/a;->b:Landroid/content/SharedPreferences;

    .line 61
    invoke-interface {v2}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object v2

    .line 62
    invoke-virtual {v1, v11}, Lk0/a;->c(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    .line 63
    invoke-static {v1, v3}, Lk0/a;->a(Lk0/a;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    invoke-interface {v2, v4, v1}, Landroid/content/SharedPreferences$Editor;->putString(Ljava/lang/String;Ljava/lang/String;)Landroid/content/SharedPreferences$Editor;

    .line 64
    invoke-interface {v2}, Landroid/content/SharedPreferences$Editor;->apply()V

    .line 65
    iget-object v1, v0, Lc0/g;->a:Lk0/a;

    invoke-static {v1}, Ljava/util/Objects;->requireNonNull(Ljava/lang/Object;)Ljava/lang/Object;

    .line 66
    iget-object v2, v1, Lk0/a;->b:Landroid/content/SharedPreferences;

    .line 67
    invoke-interface {v2}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object v2

    .line 68
    iget-object v3, v0, Lc0/g;->f:Lj0/b;

    invoke-virtual {v3}, Lj0/b;->d()Ljava/lang/String;

    move-result-object v3

    .line 69
    invoke-virtual {v1, v10}, Lk0/a;->c(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    .line 70
    invoke-static {v1, v3}, Lk0/a;->a(Lk0/a;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    invoke-interface {v2, v4, v1}, Landroid/content/SharedPreferences$Editor;->putString(Ljava/lang/String;Ljava/lang/String;)Landroid/content/SharedPreferences$Editor;

    .line 71
    invoke-interface {v2}, Landroid/content/SharedPreferences$Editor;->apply()V

    .line 72
    iget-object v1, v0, Lc0/g;->a:Lk0/a;

    invoke-static {v1}, Ljava/util/Objects;->requireNonNull(Ljava/lang/Object;)Ljava/lang/Object;

    .line 73
    iget-object v2, v1, Lk0/a;->b:Landroid/content/SharedPreferences;

    .line 74
    invoke-interface {v2}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object v2

    const/4 v3, 0x5

    move-object/from16 v9, p1

    .line 75
    invoke-virtual {v1, v9}, Lk0/a;->c(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    .line 76
    invoke-static {v3}, Ljava/lang/Integer;->toString(I)Ljava/lang/String;

    move-result-object v3

    invoke-static {v1, v3}, Lk0/a;->a(Lk0/a;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    invoke-interface {v2, v4, v1}, Landroid/content/SharedPreferences$Editor;->putString(Ljava/lang/String;Ljava/lang/String;)Landroid/content/SharedPreferences$Editor;

    .line 77
    invoke-interface {v2}, Landroid/content/SharedPreferences$Editor;->apply()V

    .line 78
    sget-object v1, Lxyz/chz/injector/MainActivity;->b:Lxyz/chz/injector/MainActivity;

    const-string v2, "Type: SSH + SSL + Payload + Proxy"

    const/4 v3, 0x0

    :goto_3
    invoke-static {v1, v2, v3}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    move-result-object v1

    goto/16 :goto_4

    :cond_4
    move-object/from16 v17, v9

    move-object v9, v13

    iget-object v1, v0, Lc0/g;->f:Lj0/b;

    invoke-virtual {v1}, Lj0/b;->e()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/String;->isEmpty()Z

    move-result v1

    if-nez v1, :cond_5

    iget-object v1, v0, Lc0/g;->f:Lj0/b;

    invoke-virtual {v1}, Lj0/b;->b()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/String;->isEmpty()Z

    move-result v1

    if-nez v1, :cond_5

    iget-object v1, v0, Lc0/g;->f:Lj0/b;

    invoke-virtual {v1}, Lj0/b;->d()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/String;->isEmpty()Z

    move-result v1

    if-nez v1, :cond_5

    iget-object v1, v0, Lc0/g;->a:Lk0/a;

    invoke-static {v1}, Ljava/util/Objects;->requireNonNull(Ljava/lang/Object;)Ljava/lang/Object;

    .line 79
    iget-object v3, v1, Lk0/a;->b:Landroid/content/SharedPreferences;

    .line 80
    invoke-interface {v3}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object v3

    const/4 v5, 0x0

    .line 81
    aget-object v7, v2, v5

    .line 82
    invoke-virtual {v1, v8}, Lk0/a;->c(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v5

    .line 83
    invoke-static {v1, v7}, Lk0/a;->a(Lk0/a;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    invoke-interface {v3, v5, v1}, Landroid/content/SharedPreferences$Editor;->putString(Ljava/lang/String;Ljava/lang/String;)Landroid/content/SharedPreferences$Editor;

    .line 84
    invoke-interface {v3}, Landroid/content/SharedPreferences$Editor;->apply()V

    .line 85
    iget-object v1, v0, Lc0/g;->a:Lk0/a;

    invoke-static {v1}, Ljava/util/Objects;->requireNonNull(Ljava/lang/Object;)Ljava/lang/Object;

    .line 86
    iget-object v3, v1, Lk0/a;->b:Landroid/content/SharedPreferences;

    .line 87
    invoke-interface {v3}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object v3

    const/4 v5, 0x1

    .line 88
    aget-object v7, v2, v5

    .line 89
    invoke-virtual {v1, v6}, Lk0/a;->c(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v5

    .line 90
    invoke-static {v1, v7}, Lk0/a;->a(Lk0/a;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    invoke-interface {v3, v5, v1}, Landroid/content/SharedPreferences$Editor;->putString(Ljava/lang/String;Ljava/lang/String;)Landroid/content/SharedPreferences$Editor;

    .line 91
    invoke-interface {v3}, Landroid/content/SharedPreferences$Editor;->apply()V

    .line 92
    iget-object v1, v0, Lc0/g;->a:Lk0/a;

    invoke-static {v1}, Ljava/util/Objects;->requireNonNull(Ljava/lang/Object;)Ljava/lang/Object;

    .line 93
    iget-object v3, v1, Lk0/a;->b:Landroid/content/SharedPreferences;

    .line 94
    invoke-interface {v3}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object v3

    const/4 v5, 0x2

    .line 95
    aget-object v5, v2, v5

    .line 96
    invoke-virtual {v1, v4}, Lk0/a;->c(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    .line 97
    invoke-static {v1, v5}, Lk0/a;->a(Lk0/a;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    invoke-interface {v3, v4, v1}, Landroid/content/SharedPreferences$Editor;->putString(Ljava/lang/String;Ljava/lang/String;)Landroid/content/SharedPreferences$Editor;

    .line 98
    invoke-interface {v3}, Landroid/content/SharedPreferences$Editor;->apply()V

    .line 99
    iget-object v1, v0, Lc0/g;->a:Lk0/a;

    invoke-static {v1}, Ljava/util/Objects;->requireNonNull(Ljava/lang/Object;)Ljava/lang/Object;

    .line 100
    iget-object v3, v1, Lk0/a;->b:Landroid/content/SharedPreferences;

    .line 101
    invoke-interface {v3}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object v3

    const/4 v4, 0x3

    .line 102
    aget-object v2, v2, v4

    .line 103
    invoke-virtual {v1, v15}, Lk0/a;->c(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    .line 104
    invoke-static {v1, v2}, Lk0/a;->a(Lk0/a;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    invoke-interface {v3, v4, v1}, Landroid/content/SharedPreferences$Editor;->putString(Ljava/lang/String;Ljava/lang/String;)Landroid/content/SharedPreferences$Editor;

    .line 105
    invoke-interface {v3}, Landroid/content/SharedPreferences$Editor;->apply()V

    .line 106
    iget-object v1, v0, Lc0/g;->a:Lk0/a;

    invoke-static {v1}, Ljava/util/Objects;->requireNonNull(Ljava/lang/Object;)Ljava/lang/Object;

    .line 107
    iget-object v2, v1, Lk0/a;->b:Landroid/content/SharedPreferences;

    .line 108
    invoke-interface {v2}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object v2

    .line 109
    invoke-virtual {v1, v14}, Lk0/a;->c(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    const/4 v4, 0x0

    .line 110
    invoke-static {v4}, Ljava/lang/Boolean;->toString(Z)Ljava/lang/String;

    move-result-object v5

    invoke-static {v1, v5}, Lk0/a;->a(Lk0/a;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    invoke-interface {v2, v3, v1}, Landroid/content/SharedPreferences$Editor;->putString(Ljava/lang/String;Ljava/lang/String;)Landroid/content/SharedPreferences$Editor;

    .line 111
    invoke-interface {v2}, Landroid/content/SharedPreferences$Editor;->apply()V

    .line 112
    iget-object v1, v0, Lc0/g;->a:Lk0/a;

    invoke-static {v1}, Ljava/util/Objects;->requireNonNull(Ljava/lang/Object;)Ljava/lang/Object;

    .line 113
    iget-object v2, v1, Lk0/a;->b:Landroid/content/SharedPreferences;

    .line 114
    invoke-interface {v2}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object v2

    .line 115
    iget-object v3, v0, Lc0/g;->f:Lj0/b;

    invoke-virtual {v3}, Lj0/b;->b()Ljava/lang/String;

    move-result-object v3

    .line 116
    invoke-virtual {v1, v11}, Lk0/a;->c(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    .line 117
    invoke-static {v1, v3}, Lk0/a;->a(Lk0/a;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    invoke-interface {v2, v4, v1}, Landroid/content/SharedPreferences$Editor;->putString(Ljava/lang/String;Ljava/lang/String;)Landroid/content/SharedPreferences$Editor;

    .line 118
    invoke-interface {v2}, Landroid/content/SharedPreferences$Editor;->apply()V

    .line 119
    iget-object v1, v0, Lc0/g;->a:Lk0/a;

    invoke-static {v1}, Ljava/util/Objects;->requireNonNull(Ljava/lang/Object;)Ljava/lang/Object;

    .line 120
    iget-object v2, v1, Lk0/a;->b:Landroid/content/SharedPreferences;

    .line 121
    invoke-interface {v2}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object v2

    .line 122
    iget-object v3, v0, Lc0/g;->f:Lj0/b;

    invoke-virtual {v3}, Lj0/b;->d()Ljava/lang/String;

    move-result-object v3

    .line 123
    invoke-virtual {v1, v10}, Lk0/a;->c(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    .line 124
    invoke-static {v1, v3}, Lk0/a;->a(Lk0/a;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    invoke-interface {v2, v4, v1}, Landroid/content/SharedPreferences$Editor;->putString(Ljava/lang/String;Ljava/lang/String;)Landroid/content/SharedPreferences$Editor;

    .line 125
    invoke-interface {v2}, Landroid/content/SharedPreferences$Editor;->apply()V

    .line 126
    iget-object v1, v0, Lc0/g;->a:Lk0/a;

    invoke-static {v1}, Ljava/util/Objects;->requireNonNull(Ljava/lang/Object;)Ljava/lang/Object;

    .line 127
    iget-object v2, v1, Lk0/a;->b:Landroid/content/SharedPreferences;

    .line 128
    invoke-interface {v2}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object v2

    .line 129
    invoke-virtual {v1, v9}, Lk0/a;->c(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    const/4 v4, 0x4

    .line 130
    invoke-static {v4}, Ljava/lang/Integer;->toString(I)Ljava/lang/String;

    move-result-object v4

    invoke-static {v1, v4}, Lk0/a;->a(Lk0/a;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    invoke-interface {v2, v3, v1}, Landroid/content/SharedPreferences$Editor;->putString(Ljava/lang/String;Ljava/lang/String;)Landroid/content/SharedPreferences$Editor;

    .line 131
    invoke-interface {v2}, Landroid/content/SharedPreferences$Editor;->apply()V

    .line 132
    sget-object v1, Lxyz/chz/injector/MainActivity;->b:Lxyz/chz/injector/MainActivity;

    const-string v2, "Type: SSH + SSL + Payload"

    const/4 v3, 0x0

    goto/16 :goto_3

    :cond_5
    iget-object v1, v0, Lc0/g;->f:Lj0/b;

    invoke-virtual {v1}, Lj0/b;->e()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/String;->isEmpty()Z

    move-result v1

    if-nez v1, :cond_6

    iget-object v1, v0, Lc0/g;->f:Lj0/b;

    invoke-virtual {v1}, Lj0/b;->b()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/String;->isEmpty()Z

    move-result v1

    if-eqz v1, :cond_6

    iget-object v1, v0, Lc0/g;->f:Lj0/b;

    invoke-virtual {v1}, Lj0/b;->d()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/String;->isEmpty()Z

    move-result v1

    if-nez v1, :cond_6

    iget-object v1, v0, Lc0/g;->a:Lk0/a;

    invoke-static {v1}, Ljava/util/Objects;->requireNonNull(Ljava/lang/Object;)Ljava/lang/Object;

    .line 133
    iget-object v3, v1, Lk0/a;->b:Landroid/content/SharedPreferences;

    .line 134
    invoke-interface {v3}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object v3

    const/4 v5, 0x0

    .line 135
    aget-object v7, v2, v5

    .line 136
    invoke-virtual {v1, v8}, Lk0/a;->c(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v5

    .line 137
    invoke-static {v1, v7}, Lk0/a;->a(Lk0/a;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    invoke-interface {v3, v5, v1}, Landroid/content/SharedPreferences$Editor;->putString(Ljava/lang/String;Ljava/lang/String;)Landroid/content/SharedPreferences$Editor;

    .line 138
    invoke-interface {v3}, Landroid/content/SharedPreferences$Editor;->apply()V

    .line 139
    iget-object v1, v0, Lc0/g;->a:Lk0/a;

    invoke-static {v1}, Ljava/util/Objects;->requireNonNull(Ljava/lang/Object;)Ljava/lang/Object;

    .line 140
    iget-object v3, v1, Lk0/a;->b:Landroid/content/SharedPreferences;

    .line 141
    invoke-interface {v3}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object v3

    const/4 v5, 0x1

    .line 142
    aget-object v7, v2, v5

    .line 143
    invoke-virtual {v1, v6}, Lk0/a;->c(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v5

    .line 144
    invoke-static {v1, v7}, Lk0/a;->a(Lk0/a;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    invoke-interface {v3, v5, v1}, Landroid/content/SharedPreferences$Editor;->putString(Ljava/lang/String;Ljava/lang/String;)Landroid/content/SharedPreferences$Editor;

    .line 145
    invoke-interface {v3}, Landroid/content/SharedPreferences$Editor;->apply()V

    .line 146
    iget-object v1, v0, Lc0/g;->a:Lk0/a;

    invoke-static {v1}, Ljava/util/Objects;->requireNonNull(Ljava/lang/Object;)Ljava/lang/Object;

    .line 147
    iget-object v3, v1, Lk0/a;->b:Landroid/content/SharedPreferences;

    .line 148
    invoke-interface {v3}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object v3

    const/4 v5, 0x2

    .line 149
    aget-object v5, v2, v5

    .line 150
    invoke-virtual {v1, v4}, Lk0/a;->c(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    .line 151
    invoke-static {v1, v5}, Lk0/a;->a(Lk0/a;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    invoke-interface {v3, v4, v1}, Landroid/content/SharedPreferences$Editor;->putString(Ljava/lang/String;Ljava/lang/String;)Landroid/content/SharedPreferences$Editor;

    .line 152
    invoke-interface {v3}, Landroid/content/SharedPreferences$Editor;->apply()V

    .line 153
    iget-object v1, v0, Lc0/g;->a:Lk0/a;

    invoke-static {v1}, Ljava/util/Objects;->requireNonNull(Ljava/lang/Object;)Ljava/lang/Object;

    .line 154
    iget-object v3, v1, Lk0/a;->b:Landroid/content/SharedPreferences;

    .line 155
    invoke-interface {v3}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object v3

    const/4 v4, 0x3

    .line 156
    aget-object v2, v2, v4

    .line 157
    invoke-virtual {v1, v15}, Lk0/a;->c(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    .line 158
    invoke-static {v1, v2}, Lk0/a;->a(Lk0/a;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    invoke-interface {v3, v4, v1}, Landroid/content/SharedPreferences$Editor;->putString(Ljava/lang/String;Ljava/lang/String;)Landroid/content/SharedPreferences$Editor;

    .line 159
    invoke-interface {v3}, Landroid/content/SharedPreferences$Editor;->apply()V

    .line 160
    iget-object v1, v0, Lc0/g;->a:Lk0/a;

    invoke-static {v1}, Ljava/util/Objects;->requireNonNull(Ljava/lang/Object;)Ljava/lang/Object;

    .line 161
    iget-object v2, v1, Lk0/a;->b:Landroid/content/SharedPreferences;

    .line 162
    invoke-interface {v2}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object v2

    .line 163
    invoke-virtual {v1, v14}, Lk0/a;->c(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    const/4 v4, 0x1

    .line 164
    invoke-static {v4}, Ljava/lang/Boolean;->toString(Z)Ljava/lang/String;

    move-result-object v5

    invoke-static {v1, v5}, Lk0/a;->a(Lk0/a;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    invoke-interface {v2, v3, v1}, Landroid/content/SharedPreferences$Editor;->putString(Ljava/lang/String;Ljava/lang/String;)Landroid/content/SharedPreferences$Editor;

    .line 165
    invoke-interface {v2}, Landroid/content/SharedPreferences$Editor;->apply()V

    .line 166
    iget-object v1, v0, Lc0/g;->a:Lk0/a;

    invoke-static {v1}, Ljava/util/Objects;->requireNonNull(Ljava/lang/Object;)Ljava/lang/Object;

    .line 167
    iget-object v2, v1, Lk0/a;->b:Landroid/content/SharedPreferences;

    .line 168
    invoke-interface {v2}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object v2

    .line 169
    iget-object v3, v0, Lc0/g;->f:Lj0/b;

    invoke-virtual {v3}, Lj0/b;->d()Ljava/lang/String;

    move-result-object v3

    .line 170
    invoke-virtual {v1, v10}, Lk0/a;->c(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    .line 171
    invoke-static {v1, v3}, Lk0/a;->a(Lk0/a;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    invoke-interface {v2, v4, v1}, Landroid/content/SharedPreferences$Editor;->putString(Ljava/lang/String;Ljava/lang/String;)Landroid/content/SharedPreferences$Editor;

    .line 172
    invoke-interface {v2}, Landroid/content/SharedPreferences$Editor;->apply()V

    .line 173
    iget-object v1, v0, Lc0/g;->a:Lk0/a;

    invoke-static {v1}, Ljava/util/Objects;->requireNonNull(Ljava/lang/Object;)Ljava/lang/Object;

    .line 174
    iget-object v2, v1, Lk0/a;->b:Landroid/content/SharedPreferences;

    .line 175
    invoke-interface {v2}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object v2

    .line 176
    invoke-virtual {v1, v9}, Lk0/a;->c(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    const/4 v4, 0x3

    .line 177
    invoke-static {v4}, Ljava/lang/Integer;->toString(I)Ljava/lang/String;

    move-result-object v4

    invoke-static {v1, v4}, Lk0/a;->a(Lk0/a;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    invoke-interface {v2, v3, v1}, Landroid/content/SharedPreferences$Editor;->putString(Ljava/lang/String;Ljava/lang/String;)Landroid/content/SharedPreferences$Editor;

    .line 178
    invoke-interface {v2}, Landroid/content/SharedPreferences$Editor;->apply()V

    .line 179
    sget-object v1, Lxyz/chz/injector/MainActivity;->b:Lxyz/chz/injector/MainActivity;

    const-string v2, "Type: SSH + SSL"

    const/4 v3, 0x0

    goto/16 :goto_3

    :cond_6
    iget-object v1, v0, Lc0/g;->f:Lj0/b;

    invoke-virtual {v1}, Lj0/b;->e()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/String;->isEmpty()Z

    move-result v1

    if-nez v1, :cond_7

    iget-object v1, v0, Lc0/g;->f:Lj0/b;

    invoke-virtual {v1}, Lj0/b;->b()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/String;->isEmpty()Z

    move-result v1

    if-nez v1, :cond_7

    iget-object v1, v0, Lc0/g;->f:Lj0/b;

    invoke-virtual {v1}, Lj0/b;->c()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/String;->isEmpty()Z

    move-result v1

    if-nez v1, :cond_7

    iget-object v1, v0, Lc0/g;->f:Lj0/b;

    invoke-virtual {v1}, Lj0/b;->d()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/String;->isEmpty()Z

    move-result v1

    if-eqz v1, :cond_7

    iget-object v1, v0, Lc0/g;->a:Lk0/a;

    invoke-static {v1}, Ljava/util/Objects;->requireNonNull(Ljava/lang/Object;)Ljava/lang/Object;

    .line 180
    iget-object v10, v1, Lk0/a;->b:Landroid/content/SharedPreferences;

    .line 181
    invoke-interface {v10}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object v10

    move-object/from16 p1, v9

    const/4 v13, 0x0

    .line 182
    aget-object v9, v12, v13

    .line 183
    invoke-virtual {v1, v8}, Lk0/a;->c(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v8

    .line 184
    invoke-static {v1, v9}, Lk0/a;->a(Lk0/a;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    invoke-interface {v10, v8, v1}, Landroid/content/SharedPreferences$Editor;->putString(Ljava/lang/String;Ljava/lang/String;)Landroid/content/SharedPreferences$Editor;

    .line 185
    invoke-interface {v10}, Landroid/content/SharedPreferences$Editor;->apply()V

    .line 186
    iget-object v1, v0, Lc0/g;->a:Lk0/a;

    invoke-static {v1}, Ljava/util/Objects;->requireNonNull(Ljava/lang/Object;)Ljava/lang/Object;

    .line 187
    iget-object v8, v1, Lk0/a;->b:Landroid/content/SharedPreferences;

    .line 188
    invoke-interface {v8}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object v8

    const/4 v9, 0x1

    .line 189
    aget-object v10, v2, v9

    .line 190
    invoke-virtual {v1, v6}, Lk0/a;->c(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v6

    .line 191
    invoke-static {v1, v10}, Lk0/a;->a(Lk0/a;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    invoke-interface {v8, v6, v1}, Landroid/content/SharedPreferences$Editor;->putString(Ljava/lang/String;Ljava/lang/String;)Landroid/content/SharedPreferences$Editor;

    .line 192
    invoke-interface {v8}, Landroid/content/SharedPreferences$Editor;->apply()V

    .line 193
    iget-object v1, v0, Lc0/g;->a:Lk0/a;

    invoke-static {v1}, Ljava/util/Objects;->requireNonNull(Ljava/lang/Object;)Ljava/lang/Object;

    .line 194
    iget-object v6, v1, Lk0/a;->b:Landroid/content/SharedPreferences;

    .line 195
    invoke-interface {v6}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object v6

    const/4 v8, 0x2

    .line 196
    aget-object v9, v2, v8

    .line 197
    invoke-virtual {v1, v4}, Lk0/a;->c(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    .line 198
    invoke-static {v1, v9}, Lk0/a;->a(Lk0/a;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    invoke-interface {v6, v4, v1}, Landroid/content/SharedPreferences$Editor;->putString(Ljava/lang/String;Ljava/lang/String;)Landroid/content/SharedPreferences$Editor;

    .line 199
    invoke-interface {v6}, Landroid/content/SharedPreferences$Editor;->apply()V

    .line 200
    iget-object v1, v0, Lc0/g;->a:Lk0/a;

    invoke-static {v1}, Ljava/util/Objects;->requireNonNull(Ljava/lang/Object;)Ljava/lang/Object;

    .line 201
    iget-object v4, v1, Lk0/a;->b:Landroid/content/SharedPreferences;

    .line 202
    invoke-interface {v4}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object v4

    const/4 v6, 0x3

    .line 203
    aget-object v2, v2, v6

    .line 204
    invoke-virtual {v1, v15}, Lk0/a;->c(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v6

    .line 205
    invoke-static {v1, v2}, Lk0/a;->a(Lk0/a;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    invoke-interface {v4, v6, v1}, Landroid/content/SharedPreferences$Editor;->putString(Ljava/lang/String;Ljava/lang/String;)Landroid/content/SharedPreferences$Editor;

    .line 206
    invoke-interface {v4}, Landroid/content/SharedPreferences$Editor;->apply()V

    .line 207
    iget-object v1, v0, Lc0/g;->a:Lk0/a;

    invoke-static {v1}, Ljava/util/Objects;->requireNonNull(Ljava/lang/Object;)Ljava/lang/Object;

    .line 208
    iget-object v2, v1, Lk0/a;->b:Landroid/content/SharedPreferences;

    .line 209
    invoke-interface {v2}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object v2

    const/4 v4, 0x0

    .line 210
    aget-object v6, v12, v4

    .line 211
    invoke-virtual {v1, v7}, Lk0/a;->c(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    .line 212
    invoke-static {v1, v6}, Lk0/a;->a(Lk0/a;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    invoke-interface {v2, v4, v1}, Landroid/content/SharedPreferences$Editor;->putString(Ljava/lang/String;Ljava/lang/String;)Landroid/content/SharedPreferences$Editor;

    .line 213
    invoke-interface {v2}, Landroid/content/SharedPreferences$Editor;->apply()V

    .line 214
    iget-object v1, v0, Lc0/g;->a:Lk0/a;

    invoke-static {v1}, Ljava/util/Objects;->requireNonNull(Ljava/lang/Object;)Ljava/lang/Object;

    .line 215
    iget-object v2, v1, Lk0/a;->b:Landroid/content/SharedPreferences;

    .line 216
    invoke-interface {v2}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object v2

    const/4 v4, 0x1

    .line 217
    aget-object v6, v12, v4

    .line 218
    invoke-virtual {v1, v5}, Lk0/a;->c(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    .line 219
    invoke-static {v1, v6}, Lk0/a;->a(Lk0/a;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    invoke-interface {v2, v4, v1}, Landroid/content/SharedPreferences$Editor;->putString(Ljava/lang/String;Ljava/lang/String;)Landroid/content/SharedPreferences$Editor;

    .line 220
    invoke-interface {v2}, Landroid/content/SharedPreferences$Editor;->apply()V

    .line 221
    iget-object v1, v0, Lc0/g;->a:Lk0/a;

    invoke-static {v1}, Ljava/util/Objects;->requireNonNull(Ljava/lang/Object;)Ljava/lang/Object;

    .line 222
    iget-object v2, v1, Lk0/a;->b:Landroid/content/SharedPreferences;

    .line 223
    invoke-interface {v2}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object v2

    .line 224
    invoke-virtual {v1, v14}, Lk0/a;->c(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    const/4 v5, 0x0

    .line 225
    invoke-static {v5}, Ljava/lang/Boolean;->toString(Z)Ljava/lang/String;

    move-result-object v6

    invoke-static {v1, v6}, Lk0/a;->a(Lk0/a;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    invoke-interface {v2, v4, v1}, Landroid/content/SharedPreferences$Editor;->putString(Ljava/lang/String;Ljava/lang/String;)Landroid/content/SharedPreferences$Editor;

    .line 226
    invoke-interface {v2}, Landroid/content/SharedPreferences$Editor;->apply()V

    .line 227
    iget-object v1, v0, Lc0/g;->a:Lk0/a;

    invoke-static {v1}, Ljava/util/Objects;->requireNonNull(Ljava/lang/Object;)Ljava/lang/Object;

    .line 228
    iget-object v2, v1, Lk0/a;->b:Landroid/content/SharedPreferences;

    .line 229
    invoke-interface {v2}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object v2

    .line 230
    invoke-virtual {v1, v11}, Lk0/a;->c(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    .line 231
    invoke-static {v1, v3}, Lk0/a;->a(Lk0/a;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    invoke-interface {v2, v4, v1}, Landroid/content/SharedPreferences$Editor;->putString(Ljava/lang/String;Ljava/lang/String;)Landroid/content/SharedPreferences$Editor;

    .line 232
    invoke-interface {v2}, Landroid/content/SharedPreferences$Editor;->apply()V

    .line 233
    iget-object v1, v0, Lc0/g;->a:Lk0/a;

    invoke-static {v1}, Ljava/util/Objects;->requireNonNull(Ljava/lang/Object;)Ljava/lang/Object;

    .line 234
    iget-object v2, v1, Lk0/a;->b:Landroid/content/SharedPreferences;

    .line 235
    invoke-interface {v2}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object v2

    move-object/from16 v3, p1

    .line 236
    invoke-virtual {v1, v3}, Lk0/a;->c(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    const/4 v4, 0x2

    .line 237
    invoke-static {v4}, Ljava/lang/Integer;->toString(I)Ljava/lang/String;

    move-result-object v4

    invoke-static {v1, v4}, Lk0/a;->a(Lk0/a;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    invoke-interface {v2, v3, v1}, Landroid/content/SharedPreferences$Editor;->putString(Ljava/lang/String;Ljava/lang/String;)Landroid/content/SharedPreferences$Editor;

    .line 238
    invoke-interface {v2}, Landroid/content/SharedPreferences$Editor;->apply()V

    .line 239
    sget-object v1, Lxyz/chz/injector/MainActivity;->b:Lxyz/chz/injector/MainActivity;

    const-string v2, "Type: SSH + Payload + Proxy"

    const/4 v3, 0x0

    goto/16 :goto_3

    :cond_7
    move-object v3, v9

    iget-object v1, v0, Lc0/g;->f:Lj0/b;

    invoke-virtual {v1}, Lj0/b;->e()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/String;->isEmpty()Z

    move-result v1

    if-nez v1, :cond_8

    iget-object v1, v0, Lc0/g;->f:Lj0/b;

    invoke-virtual {v1}, Lj0/b;->b()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/String;->isEmpty()Z

    move-result v1

    if-nez v1, :cond_8

    iget-object v1, v0, Lc0/g;->f:Lj0/b;

    invoke-virtual {v1}, Lj0/b;->c()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/String;->isEmpty()Z

    move-result v1

    if-eqz v1, :cond_8

    iget-object v1, v0, Lc0/g;->f:Lj0/b;

    invoke-virtual {v1}, Lj0/b;->d()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/String;->isEmpty()Z

    move-result v1

    if-eqz v1, :cond_8

    iget-object v1, v0, Lc0/g;->a:Lk0/a;

    invoke-static {v1}, Ljava/util/Objects;->requireNonNull(Ljava/lang/Object;)Ljava/lang/Object;

    .line 240
    iget-object v5, v1, Lk0/a;->b:Landroid/content/SharedPreferences;

    .line 241
    invoke-interface {v5}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object v5

    const/4 v7, 0x0

    .line 242
    aget-object v9, v2, v7

    .line 243
    invoke-virtual {v1, v8}, Lk0/a;->c(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v7

    .line 244
    invoke-static {v1, v9}, Lk0/a;->a(Lk0/a;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    invoke-interface {v5, v7, v1}, Landroid/content/SharedPreferences$Editor;->putString(Ljava/lang/String;Ljava/lang/String;)Landroid/content/SharedPreferences$Editor;

    .line 245
    invoke-interface {v5}, Landroid/content/SharedPreferences$Editor;->apply()V

    .line 246
    iget-object v1, v0, Lc0/g;->a:Lk0/a;

    invoke-static {v1}, Ljava/util/Objects;->requireNonNull(Ljava/lang/Object;)Ljava/lang/Object;

    .line 247
    iget-object v5, v1, Lk0/a;->b:Landroid/content/SharedPreferences;

    .line 248
    invoke-interface {v5}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object v5

    const/4 v7, 0x1

    .line 249
    aget-object v8, v2, v7

    .line 250
    invoke-virtual {v1, v6}, Lk0/a;->c(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v6

    .line 251
    invoke-static {v1, v8}, Lk0/a;->a(Lk0/a;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    invoke-interface {v5, v6, v1}, Landroid/content/SharedPreferences$Editor;->putString(Ljava/lang/String;Ljava/lang/String;)Landroid/content/SharedPreferences$Editor;

    .line 252
    invoke-interface {v5}, Landroid/content/SharedPreferences$Editor;->apply()V

    .line 253
    iget-object v1, v0, Lc0/g;->a:Lk0/a;

    invoke-static {v1}, Ljava/util/Objects;->requireNonNull(Ljava/lang/Object;)Ljava/lang/Object;

    .line 254
    iget-object v5, v1, Lk0/a;->b:Landroid/content/SharedPreferences;

    .line 255
    invoke-interface {v5}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object v5

    const/4 v6, 0x2

    .line 256
    aget-object v6, v2, v6

    .line 257
    invoke-virtual {v1, v4}, Lk0/a;->c(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    .line 258
    invoke-static {v1, v6}, Lk0/a;->a(Lk0/a;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    invoke-interface {v5, v4, v1}, Landroid/content/SharedPreferences$Editor;->putString(Ljava/lang/String;Ljava/lang/String;)Landroid/content/SharedPreferences$Editor;

    .line 259
    invoke-interface {v5}, Landroid/content/SharedPreferences$Editor;->apply()V

    .line 260
    iget-object v1, v0, Lc0/g;->a:Lk0/a;

    invoke-static {v1}, Ljava/util/Objects;->requireNonNull(Ljava/lang/Object;)Ljava/lang/Object;

    .line 261
    iget-object v4, v1, Lk0/a;->b:Landroid/content/SharedPreferences;

    .line 262
    invoke-interface {v4}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object v4

    const/4 v5, 0x3

    .line 263
    aget-object v2, v2, v5

    .line 264
    invoke-virtual {v1, v15}, Lk0/a;->c(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v5

    .line 265
    invoke-static {v1, v2}, Lk0/a;->a(Lk0/a;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    invoke-interface {v4, v5, v1}, Landroid/content/SharedPreferences$Editor;->putString(Ljava/lang/String;Ljava/lang/String;)Landroid/content/SharedPreferences$Editor;

    .line 266
    invoke-interface {v4}, Landroid/content/SharedPreferences$Editor;->apply()V

    .line 267
    iget-object v1, v0, Lc0/g;->a:Lk0/a;

    invoke-static {v1}, Ljava/util/Objects;->requireNonNull(Ljava/lang/Object;)Ljava/lang/Object;

    .line 268
    iget-object v2, v1, Lk0/a;->b:Landroid/content/SharedPreferences;

    .line 269
    invoke-interface {v2}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object v2

    .line 270
    invoke-virtual {v1, v14}, Lk0/a;->c(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    const/4 v5, 0x0

    .line 271
    invoke-static {v5}, Ljava/lang/Boolean;->toString(Z)Ljava/lang/String;

    move-result-object v6

    invoke-static {v1, v6}, Lk0/a;->a(Lk0/a;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    invoke-interface {v2, v4, v1}, Landroid/content/SharedPreferences$Editor;->putString(Ljava/lang/String;Ljava/lang/String;)Landroid/content/SharedPreferences$Editor;

    .line 272
    invoke-interface {v2}, Landroid/content/SharedPreferences$Editor;->apply()V

    .line 273
    iget-object v1, v0, Lc0/g;->a:Lk0/a;

    invoke-static {v1}, Ljava/util/Objects;->requireNonNull(Ljava/lang/Object;)Ljava/lang/Object;

    .line 274
    iget-object v2, v1, Lk0/a;->b:Landroid/content/SharedPreferences;

    .line 275
    invoke-interface {v2}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object v2

    .line 276
    iget-object v4, v0, Lc0/g;->f:Lj0/b;

    invoke-virtual {v4}, Lj0/b;->b()Ljava/lang/String;

    move-result-object v4

    .line 277
    invoke-virtual {v1, v11}, Lk0/a;->c(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v5

    .line 278
    invoke-static {v1, v4}, Lk0/a;->a(Lk0/a;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    invoke-interface {v2, v5, v1}, Landroid/content/SharedPreferences$Editor;->putString(Ljava/lang/String;Ljava/lang/String;)Landroid/content/SharedPreferences$Editor;

    .line 279
    invoke-interface {v2}, Landroid/content/SharedPreferences$Editor;->apply()V

    .line 280
    iget-object v1, v0, Lc0/g;->a:Lk0/a;

    invoke-static {v1}, Ljava/util/Objects;->requireNonNull(Ljava/lang/Object;)Ljava/lang/Object;

    .line 281
    iget-object v2, v1, Lk0/a;->b:Landroid/content/SharedPreferences;

    .line 282
    invoke-interface {v2}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object v2

    .line 283
    invoke-virtual {v1, v3}, Lk0/a;->c(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    const/4 v4, 0x1

    .line 284
    invoke-static {v4}, Ljava/lang/Integer;->toString(I)Ljava/lang/String;

    move-result-object v5

    invoke-static {v1, v5}, Lk0/a;->a(Lk0/a;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    invoke-interface {v2, v3, v1}, Landroid/content/SharedPreferences$Editor;->putString(Ljava/lang/String;Ljava/lang/String;)Landroid/content/SharedPreferences$Editor;

    .line 285
    invoke-interface {v2}, Landroid/content/SharedPreferences$Editor;->apply()V

    .line 286
    sget-object v1, Lxyz/chz/injector/MainActivity;->b:Lxyz/chz/injector/MainActivity;

    const-string v2, "Type: SSH + Payload"

    const/4 v3, 0x0

    goto/16 :goto_3

    :cond_8
    iget-object v1, v0, Lc0/g;->f:Lj0/b;

    invoke-virtual {v1}, Lj0/b;->e()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/String;->isEmpty()Z

    move-result v1

    if-nez v1, :cond_a

    iget-object v1, v0, Lc0/g;->f:Lj0/b;

    invoke-virtual {v1}, Lj0/b;->b()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/String;->isEmpty()Z

    move-result v1

    if-eqz v1, :cond_a

    iget-object v1, v0, Lc0/g;->f:Lj0/b;

    invoke-virtual {v1}, Lj0/b;->c()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/String;->isEmpty()Z

    move-result v1

    if-eqz v1, :cond_a

    iget-object v1, v0, Lc0/g;->f:Lj0/b;

    invoke-virtual {v1}, Lj0/b;->d()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/String;->isEmpty()Z

    move-result v1

    if-eqz v1, :cond_a

    iget-object v1, v0, Lc0/g;->a:Lk0/a;

    invoke-static {v1}, Ljava/util/Objects;->requireNonNull(Ljava/lang/Object;)Ljava/lang/Object;

    .line 287
    iget-object v5, v1, Lk0/a;->b:Landroid/content/SharedPreferences;

    .line 288
    invoke-interface {v5}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object v5

    const/4 v7, 0x0

    .line 289
    aget-object v9, v2, v7

    .line 290
    invoke-virtual {v1, v8}, Lk0/a;->c(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v7

    .line 291
    invoke-static {v1, v9}, Lk0/a;->a(Lk0/a;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    invoke-interface {v5, v7, v1}, Landroid/content/SharedPreferences$Editor;->putString(Ljava/lang/String;Ljava/lang/String;)Landroid/content/SharedPreferences$Editor;

    .line 292
    invoke-interface {v5}, Landroid/content/SharedPreferences$Editor;->apply()V

    .line 293
    iget-object v1, v0, Lc0/g;->a:Lk0/a;

    invoke-static {v1}, Ljava/util/Objects;->requireNonNull(Ljava/lang/Object;)Ljava/lang/Object;

    .line 294
    iget-object v5, v1, Lk0/a;->b:Landroid/content/SharedPreferences;

    .line 295
    invoke-interface {v5}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object v5

    const/4 v7, 0x1

    .line 296
    aget-object v8, v2, v7

    .line 297
    invoke-virtual {v1, v6}, Lk0/a;->c(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v6

    .line 298
    invoke-static {v1, v8}, Lk0/a;->a(Lk0/a;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    invoke-interface {v5, v6, v1}, Landroid/content/SharedPreferences$Editor;->putString(Ljava/lang/String;Ljava/lang/String;)Landroid/content/SharedPreferences$Editor;

    .line 299
    invoke-interface {v5}, Landroid/content/SharedPreferences$Editor;->apply()V

    .line 300
    iget-object v1, v0, Lc0/g;->a:Lk0/a;

    invoke-static {v1}, Ljava/util/Objects;->requireNonNull(Ljava/lang/Object;)Ljava/lang/Object;

    .line 301
    iget-object v5, v1, Lk0/a;->b:Landroid/content/SharedPreferences;

    .line 302
    invoke-interface {v5}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object v5

    const/4 v6, 0x2

    .line 303
    aget-object v6, v2, v6

    .line 304
    invoke-virtual {v1, v4}, Lk0/a;->c(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    .line 305
    invoke-static {v1, v6}, Lk0/a;->a(Lk0/a;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    invoke-interface {v5, v4, v1}, Landroid/content/SharedPreferences$Editor;->putString(Ljava/lang/String;Ljava/lang/String;)Landroid/content/SharedPreferences$Editor;

    .line 306
    invoke-interface {v5}, Landroid/content/SharedPreferences$Editor;->apply()V

    .line 307
    iget-object v1, v0, Lc0/g;->a:Lk0/a;

    invoke-static {v1}, Ljava/util/Objects;->requireNonNull(Ljava/lang/Object;)Ljava/lang/Object;

    .line 308
    iget-object v4, v1, Lk0/a;->b:Landroid/content/SharedPreferences;

    .line 309
    invoke-interface {v4}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object v4

    const/4 v5, 0x3

    .line 310
    aget-object v2, v2, v5

    .line 311
    invoke-virtual {v1, v15}, Lk0/a;->c(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v5

    .line 312
    invoke-static {v1, v2}, Lk0/a;->a(Lk0/a;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    invoke-interface {v4, v5, v1}, Landroid/content/SharedPreferences$Editor;->putString(Ljava/lang/String;Ljava/lang/String;)Landroid/content/SharedPreferences$Editor;

    .line 313
    invoke-interface {v4}, Landroid/content/SharedPreferences$Editor;->apply()V

    .line 314
    iget-object v1, v0, Lc0/g;->a:Lk0/a;

    invoke-static {v1}, Ljava/util/Objects;->requireNonNull(Ljava/lang/Object;)Ljava/lang/Object;

    .line 315
    iget-object v2, v1, Lk0/a;->b:Landroid/content/SharedPreferences;

    .line 316
    invoke-interface {v2}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object v2

    .line 317
    invoke-virtual {v1, v14}, Lk0/a;->c(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    const/4 v5, 0x1

    .line 318
    invoke-static {v5}, Ljava/lang/Boolean;->toString(Z)Ljava/lang/String;

    move-result-object v6

    invoke-static {v1, v6}, Lk0/a;->a(Lk0/a;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    invoke-interface {v2, v4, v1}, Landroid/content/SharedPreferences$Editor;->putString(Ljava/lang/String;Ljava/lang/String;)Landroid/content/SharedPreferences$Editor;

    .line 319
    invoke-interface {v2}, Landroid/content/SharedPreferences$Editor;->apply()V

    .line 320
    iget-object v1, v0, Lc0/g;->a:Lk0/a;

    invoke-static {v1}, Ljava/util/Objects;->requireNonNull(Ljava/lang/Object;)Ljava/lang/Object;

    .line 321
    iget-object v2, v1, Lk0/a;->b:Landroid/content/SharedPreferences;

    .line 322
    invoke-interface {v2}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object v2

    .line 323
    invoke-virtual {v1, v3}, Lk0/a;->c(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    const/4 v4, 0x1

    .line 324
    invoke-static {v4}, Ljava/lang/Integer;->toString(I)Ljava/lang/String;

    move-result-object v5

    invoke-static {v1, v5}, Lk0/a;->a(Lk0/a;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    invoke-interface {v2, v3, v1}, Landroid/content/SharedPreferences$Editor;->putString(Ljava/lang/String;Ljava/lang/String;)Landroid/content/SharedPreferences$Editor;

    .line 325
    invoke-interface {v2}, Landroid/content/SharedPreferences$Editor;->apply()V

    .line 326
    sget-object v1, Lxyz/chz/injector/MainActivity;->b:Lxyz/chz/injector/MainActivity;

    const-string v2, "Type: SSH Direct"

    const/4 v3, 0x0

    goto/16 :goto_3

    :goto_4
    invoke-virtual {v1}, Landroid/widget/Toast;->show()V

    const/4 v8, 0x1

    goto :goto_7

    :cond_9
    :goto_5
    move-object/from16 v17, v9

    sget-object v1, Lxyz/chz/injector/MainActivity;->b:Lxyz/chz/injector/MainActivity;

    const-string v2, "wrong format ssh"

    const/4 v3, 0x1

    invoke-static {v1, v2, v3}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    move-result-object v1

    invoke-virtual {v1}, Landroid/widget/Toast;->show()V
    :try_end_2
    .catch Ljava/lang/Exception; {:try_start_2 .. :try_end_2} :catch_1

    goto :goto_6

    :catch_0
    move-object/from16 v17, v9

    :catch_1
    :cond_a
    :goto_6
    const/4 v8, 0x0

    :goto_7
    if-eqz v8, :cond_e

    .line 327
    sget-object v1, Lg0/d;->d:Lg0/a;

    sget-object v2, Lg0/a;->f:Lg0/a;

    if-eq v1, v2, :cond_b

    sget-object v2, Lg0/a;->d:Lg0/a;

    if-eq v1, v2, :cond_b

    const/4 v8, 0x1

    goto :goto_8

    :cond_b
    const/4 v8, 0x0

    .line 328
    :goto_8
    sget-object v1, Lxyz/chz/injector/MainActivity;->b:Lxyz/chz/injector/MainActivity;

    if-eqz v8, :cond_c

    .line 329
    new-instance v2, Landroid/content/Intent;

    sget-object v3, Lxyz/chz/injector/HttpService;->o:Ljava/lang/String;

    invoke-direct {v2, v3}, Landroid/content/Intent;-><init>(Ljava/lang/String;)V

    invoke-static {v1}, Lh/a;->a(Landroid/content/Context;)Lh/a;

    move-result-object v1

    invoke-virtual {v1, v2}, Lh/a;->c(Landroid/content/Intent;)Z

    goto :goto_a

    .line 330
    :cond_c
    invoke-static {v1}, Landroid/net/VpnService;->prepare(Landroid/content/Context;)Landroid/content/Intent;

    move-result-object v1

    const/16 v2, 0x46

    if-eqz v1, :cond_d

    const v3, 0x7f0b003f

    sget-object v4, Lg0/a;->g:Lg0/a;

    const-string v5, "USER_VPN_PERMISSION"

    move-object/from16 v6, v17

    invoke-static {v5, v6, v3, v4}, Lg0/d;->o(Ljava/lang/String;Ljava/lang/String;ILg0/a;)V

    :try_start_3
    invoke-virtual {v0, v1, v2}, Landroid/app/Fragment;->startActivityForResult(Landroid/content/Intent;I)V
    :try_end_3
    .catch Landroid/content/ActivityNotFoundException; {:try_start_3 .. :try_end_3} :catch_2

    goto :goto_9

    :catch_2
    const v1, 0x7f0b001c

    .line 331
    new-instance v2, Lg0/b;

    invoke-direct {v2, v1}, Lg0/b;-><init>(I)V

    invoke-static {v2}, Lg0/d;->l(Lg0/b;)V

    goto :goto_9

    :cond_d
    const/4 v1, -0x1

    const/4 v3, 0x0

    .line 332
    invoke-virtual {v0, v2, v1, v3}, Lc0/g;->onActivityResult(IILandroid/content/Intent;)V

    :goto_9
    invoke-virtual/range {p0 .. p0}, Lc0/g;->f()V

    :goto_a
    const/4 v1, 0x1

    return v1

    :cond_e
    iget-object v1, v0, Lc0/g;->p:Landroid/preference/SwitchPreference;

    const/4 v2, 0x0

    invoke-virtual {v1, v2}, Landroid/preference/TwoStatePreference;->setChecked(Z)V

    return v2

    :cond_f
    move-object v6, v9

    const/4 v2, 0x0

    const/4 v3, 0x0

    iget-object v4, v0, Lc0/g;->g:Landroid/preference/ListPreference;

    if-ne v1, v4, :cond_12

    iget-boolean v1, v0, Lc0/g;->r:Z

    if-nez v1, :cond_10

    sget-object v1, Lxyz/chz/injector/MainActivity;->b:Lxyz/chz/injector/MainActivity;

    const-string v3, "Service Running"

    invoke-static {v1, v3, v2}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    move-result-object v1

    invoke-virtual {v1}, Landroid/widget/Toast;->show()V

    return v2

    :cond_10
    invoke-virtual/range {p2 .. p2}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v1

    sget-object v2, Lc0/g;->s:Lj0/c;

    .line 333
    invoke-virtual {v2}, Lj0/c;->b()Ljava/util/List;

    move-result-object v4

    check-cast v4, Ljava/util/ArrayList;

    invoke-virtual {v4, v1}, Ljava/util/ArrayList;->contains(Ljava/lang/Object;)Z

    move-result v4

    if-nez v4, :cond_11

    goto :goto_b

    :cond_11
    new-instance v3, Lj0/b;

    iget-object v2, v2, Lj0/c;->a:Lk0/a;

    invoke-direct {v3, v2, v1}, Lj0/b;-><init>(Landroid/content/SharedPreferences;Ljava/lang/String;)V

    .line 334
    :goto_b
    iput-object v3, v0, Lc0/g;->f:Lj0/b;

    sget-object v2, Lc0/g;->s:Lj0/c;

    .line 335
    invoke-virtual {v2}, Lj0/c;->b()Ljava/util/List;

    move-result-object v3

    check-cast v3, Ljava/util/ArrayList;

    invoke-virtual {v3, v1}, Ljava/util/ArrayList;->contains(Ljava/lang/Object;)Z

    move-result v3

    if-eqz v3, :cond_1d

    iget-object v2, v2, Lj0/c;->a:Lk0/a;

    invoke-static {v2}, Ljava/util/Objects;->requireNonNull(Ljava/lang/Object;)Ljava/lang/Object;

    .line 336
    iget-object v3, v2, Lk0/a;->b:Landroid/content/SharedPreferences;

    .line 337
    invoke-interface {v3}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object v3

    const-string v4, "last_profile"

    .line 338
    invoke-virtual {v2, v4}, Lk0/a;->c(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    .line 339
    invoke-static {v2, v1}, Lk0/a;->a(Lk0/a;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    invoke-interface {v3, v4, v1}, Landroid/content/SharedPreferences$Editor;->putString(Ljava/lang/String;Ljava/lang/String;)Landroid/content/SharedPreferences$Editor;

    .line 340
    invoke-interface {v3}, Landroid/content/SharedPreferences$Editor;->apply()V

    goto/16 :goto_12

    .line 341
    :cond_12
    iget-object v2, v0, Lc0/g;->i:Landroid/preference/EditTextPreference;

    if-ne v1, v2, :cond_16

    invoke-virtual/range {p2 .. p2}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v1, v12}, Ljava/lang/String;->split(Ljava/lang/String;)[Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v1}, Ljava/lang/String;->isEmpty()Z

    move-result v1

    if-eqz v1, :cond_13

    iget-object v1, v0, Lc0/g;->i:Landroid/preference/EditTextPreference;

    invoke-virtual {v1, v6}, Landroid/preference/Preference;->setSummary(Ljava/lang/CharSequence;)V

    goto/16 :goto_e

    :cond_13
    array-length v1, v2

    const/4 v3, 0x4

    if-ne v1, v3, :cond_15

    const/4 v1, 0x0

    aget-object v3, v2, v1

    invoke-virtual {v3}, Ljava/lang/String;->length()I

    move-result v1

    if-eqz v1, :cond_15

    const/4 v1, 0x1

    aget-object v3, v2, v1

    invoke-virtual {v3}, Ljava/lang/String;->length()I

    move-result v1

    if-eqz v1, :cond_15

    const/4 v1, 0x2

    aget-object v3, v2, v1

    invoke-virtual {v3}, Ljava/lang/String;->length()I

    move-result v1

    if-eqz v1, :cond_15

    const/4 v1, 0x3

    aget-object v3, v2, v1

    invoke-virtual {v3}, Ljava/lang/String;->length()I

    move-result v1

    if-nez v1, :cond_14

    goto :goto_c

    :cond_14
    iget-object v1, v0, Lc0/g;->f:Lj0/b;

    invoke-virtual/range {p2 .. p2}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v3

    .line 342
    iget-object v4, v1, Lj0/b;->a:Landroid/content/SharedPreferences;

    invoke-interface {v4}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object v4

    const-string v5, "sshok"

    invoke-virtual {v1, v5}, Lj0/b;->f(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    invoke-interface {v4, v1, v3}, Landroid/content/SharedPreferences$Editor;->putString(Ljava/lang/String;Ljava/lang/String;)Landroid/content/SharedPreferences$Editor;

    move-result-object v1

    invoke-interface {v1}, Landroid/content/SharedPreferences$Editor;->apply()V

    .line 343
    iget-object v1, v0, Lc0/g;->i:Landroid/preference/EditTextPreference;

    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v4, 0x0

    aget-object v4, v2, v4

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v3, v13}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x1

    aget-object v5, v2, v4

    invoke-virtual {v3, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v4, "@"

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x2

    aget-object v4, v2, v4

    const-string v5, "[a-zA-Z0-9]"

    const-string v6, "x"

    invoke-virtual {v4, v5, v6}, Ljava/lang/String;->replaceAll(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v3, v13}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x3

    aget-object v2, v2, v4

    invoke-virtual {v2, v5, v6}, Ljava/lang/String;->replaceAll(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v3, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    goto :goto_d

    :cond_15
    :goto_c
    iget-object v1, v0, Lc0/g;->i:Landroid/preference/EditTextPreference;

    const-string v2, "Wrong SSH Format! Check again"

    :goto_d
    invoke-virtual {v1, v2}, Landroid/preference/Preference;->setSummary(Ljava/lang/CharSequence;)V

    :goto_e
    const/4 v1, 0x1

    return v1

    :cond_16
    iget-object v2, v0, Lc0/g;->j:Landroid/preference/EditTextPreference;

    if-ne v1, v2, :cond_17

    iget-object v1, v0, Lc0/g;->f:Lj0/b;

    invoke-virtual/range {p2 .. p2}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v2

    .line 344
    iget-object v3, v1, Lj0/b;->a:Landroid/content/SharedPreferences;

    invoke-interface {v3}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object v3

    const-string v4, "payloads"

    invoke-virtual {v1, v4}, Lj0/b;->f(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    invoke-interface {v3, v1, v2}, Landroid/content/SharedPreferences$Editor;->putString(Ljava/lang/String;Ljava/lang/String;)Landroid/content/SharedPreferences$Editor;

    move-result-object v1

    invoke-interface {v1}, Landroid/content/SharedPreferences$Editor;->apply()V

    .line 345
    iget-object v1, v0, Lc0/g;->j:Landroid/preference/EditTextPreference;

    :goto_f
    move-object/from16 v2, p2

    goto/16 :goto_10

    :cond_17
    iget-object v2, v0, Lc0/g;->k:Landroid/preference/EditTextPreference;

    if-ne v1, v2, :cond_18

    iget-object v1, v0, Lc0/g;->f:Lj0/b;

    invoke-virtual/range {p2 .. p2}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v2

    .line 346
    iget-object v3, v1, Lj0/b;->a:Landroid/content/SharedPreferences;

    invoke-interface {v3}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object v3

    const-string v4, "proxys"

    invoke-virtual {v1, v4}, Lj0/b;->f(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    invoke-interface {v3, v1, v2}, Landroid/content/SharedPreferences$Editor;->putString(Ljava/lang/String;Ljava/lang/String;)Landroid/content/SharedPreferences$Editor;

    move-result-object v1

    invoke-interface {v1}, Landroid/content/SharedPreferences$Editor;->apply()V

    .line 347
    iget-object v1, v0, Lc0/g;->k:Landroid/preference/EditTextPreference;

    goto :goto_f

    :cond_18
    iget-object v2, v0, Lc0/g;->l:Landroid/preference/EditTextPreference;

    if-ne v1, v2, :cond_19

    iget-object v1, v0, Lc0/g;->f:Lj0/b;

    invoke-virtual/range {p2 .. p2}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v2

    .line 348
    iget-object v3, v1, Lj0/b;->a:Landroid/content/SharedPreferences;

    invoke-interface {v3}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object v3

    const-string v4, "snis"

    invoke-virtual {v1, v4}, Lj0/b;->f(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    invoke-interface {v3, v1, v2}, Landroid/content/SharedPreferences$Editor;->putString(Ljava/lang/String;Ljava/lang/String;)Landroid/content/SharedPreferences$Editor;

    move-result-object v1

    invoke-interface {v1}, Landroid/content/SharedPreferences$Editor;->apply()V

    .line 349
    iget-object v1, v0, Lc0/g;->l:Landroid/preference/EditTextPreference;

    goto :goto_f

    :cond_19
    iget-object v2, v0, Lc0/g;->m:Landroid/preference/EditTextPreference;

    if-ne v1, v2, :cond_1a

    iget-object v1, v0, Lc0/g;->f:Lj0/b;

    invoke-virtual/range {p2 .. p2}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v2

    .line 350
    iget-object v3, v1, Lj0/b;->a:Landroid/content/SharedPreferences;

    invoke-interface {v3}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object v3

    const-string v4, "dnsd"

    invoke-virtual {v1, v4}, Lj0/b;->f(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    invoke-interface {v3, v1, v2}, Landroid/content/SharedPreferences$Editor;->putString(Ljava/lang/String;Ljava/lang/String;)Landroid/content/SharedPreferences$Editor;

    move-result-object v1

    invoke-interface {v1}, Landroid/content/SharedPreferences$Editor;->apply()V

    .line 351
    iget-object v1, v0, Lc0/g;->m:Landroid/preference/EditTextPreference;

    goto :goto_f

    :cond_1a
    iget-object v2, v0, Lc0/g;->n:Landroid/preference/EditTextPreference;

    if-ne v1, v2, :cond_1b

    iget-object v1, v0, Lc0/g;->f:Lj0/b;

    invoke-virtual/range {p2 .. p2}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v2

    .line 352
    iget-object v3, v1, Lj0/b;->a:Landroid/content/SharedPreferences;

    invoke-interface {v3}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object v3

    invoke-virtual {v1, v10}, Lj0/b;->f(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    invoke-interface {v3, v1, v2}, Landroid/content/SharedPreferences$Editor;->putString(Ljava/lang/String;Ljava/lang/String;)Landroid/content/SharedPreferences$Editor;

    move-result-object v1

    invoke-interface {v1}, Landroid/content/SharedPreferences$Editor;->apply()V

    .line 353
    iget-object v1, v0, Lc0/g;->n:Landroid/preference/EditTextPreference;

    goto/16 :goto_f

    :goto_10
    invoke-virtual {v0, v1, v2}, Lc0/g;->e(Landroid/preference/EditTextPreference;Ljava/lang/Object;)V

    :goto_11
    const/4 v1, 0x1

    goto :goto_13

    :cond_1b
    move-object/from16 v2, p2

    iget-object v3, v0, Lc0/g;->o:Landroid/preference/CheckBoxPreference;

    if-ne v1, v3, :cond_1c

    iget-object v1, v0, Lc0/g;->f:Lj0/b;

    invoke-virtual/range {p2 .. p2}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-static {v2}, Ljava/lang/Boolean;->parseBoolean(Ljava/lang/String;)Z

    move-result v2

    .line 354
    iget-object v3, v1, Lj0/b;->a:Landroid/content/SharedPreferences;

    invoke-interface {v3}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object v3

    invoke-virtual {v1, v11}, Lj0/b;->f(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    invoke-interface {v3, v1, v2}, Landroid/content/SharedPreferences$Editor;->putBoolean(Ljava/lang/String;Z)Landroid/content/SharedPreferences$Editor;

    move-result-object v1

    invoke-interface {v1}, Landroid/content/SharedPreferences$Editor;->apply()V

    const/4 v1, 0x1

    return v1

    .line 355
    :cond_1c
    iget-object v3, v0, Lc0/g;->h:Landroid/preference/ListPreference;

    if-ne v1, v3, :cond_1e

    iget-object v1, v0, Lc0/g;->f:Lj0/b;

    invoke-virtual/range {p2 .. p2}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v3

    .line 356
    iget-object v4, v1, Lj0/b;->a:Landroid/content/SharedPreferences;

    invoke-interface {v4}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object v4

    const-string v5, "forcing"

    invoke-virtual {v1, v5}, Lj0/b;->f(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    invoke-interface {v4, v1, v3}, Landroid/content/SharedPreferences$Editor;->putString(Ljava/lang/String;Ljava/lang/String;)Landroid/content/SharedPreferences$Editor;

    move-result-object v1

    invoke-interface {v1}, Landroid/content/SharedPreferences$Editor;->apply()V

    .line 357
    iget-object v1, v0, Lc0/g;->h:Landroid/preference/ListPreference;

    .line 358
    invoke-virtual/range {p2 .. p2}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v1, v2}, Landroid/preference/ListPreference;->setSummary(Ljava/lang/CharSequence;)V

    .line 359
    :cond_1d
    :goto_12
    invoke-virtual/range {p0 .. p0}, Lc0/g;->c()V

    goto :goto_11

    :goto_13
    return v1

    :cond_1e
    const/4 v1, 0x0

    return v1
.end method

.method public final onPreferenceClick(Landroid/preference/Preference;)Z
    .locals 0

    const/4 p1, 0x0

    return p1
.end method

.method public final onResume()V
    .locals 0

    invoke-super {p0}, Landroid/app/Fragment;->onResume()V

    invoke-static {p0}, Lg0/d;->a(Lg0/d$b;)V

    return-void
.end method
