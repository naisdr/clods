.class public Lnet/i2p/crypto/eddsa/math/bigint/BigIntegerScalarOps;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lnet/i2p/crypto/eddsa/math/ScalarOps;


# virtual methods
.method public final a([B)[B
    .locals 0

    const/4 p1, 0x0

    throw p1
.end method

.method public final b([B[B[B)[B
    .locals 0

    const/4 p1, 0x0

    throw p1
.end method
