.class public abstract Lu/a;
.super Ljava/lang/Object;
.source "SourceFile"


# instance fields
.field public a:Ljava/net/InetAddress;

.field public b:I

.field public c:I

.field public d:I

.field public e:Ljava/lang/String;


# direct methods
.method public constructor <init>()V
    .locals 1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v0, 0x0

    iput-object v0, p0, Lu/a;->a:Ljava/net/InetAddress;

    iput-object v0, p0, Lu/a;->e:Ljava/lang/String;

    return-void
.end method

.method public constructor <init>(ILjava/net/InetAddress;I)V
    .locals 1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v0, 0x0

    iput-object v0, p0, Lu/a;->e:Ljava/lang/String;

    iput p1, p0, Lu/a;->d:I

    iput-object p2, p0, Lu/a;->a:Ljava/net/InetAddress;

    iput p3, p0, Lu/a;->c:I

    return-void
.end method
