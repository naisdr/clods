.class public final Ls/g;
.super Ljava/lang/Object;
.source "SourceFile"


# static fields
.field public static final r:La/b;


# instance fields
.field public a:I

.field public b:I

.field public c:Lcom/trilead/ssh2/crypto/cipher/CipherInputStream;

.field public d:Lcom/trilead/ssh2/crypto/cipher/CipherOutputStream;

.field public e:Z

.field public f:Lcom/trilead/ssh2/crypto/digest/MAC;

.field public g:[B

.field public h:I

.field public i:Lcom/trilead/ssh2/crypto/digest/MAC;

.field public j:[B

.field public k:[B

.field public final l:[B

.field public final m:[B

.field public final n:[B

.field public final o:[B

.field public final p:Ljava/security/SecureRandom;

.field public q:Lc0/h$a;


# direct methods
.method public static constructor <clinit>()V
    .locals 2

    const-class v0, Ls/g;

    .line 1
    new-instance v1, La/b;

    invoke-direct {v1, v0}, La/b;-><init>(Ljava/lang/Class;)V

    .line 2
    sput-object v1, Ls/g;->r:La/b;

    return-void
.end method

.method public constructor <init>(Ljava/io/InputStream;Ljava/io/OutputStream;Ljava/security/SecureRandom;)V
    .locals 3

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v0, 0x0

    iput v0, p0, Ls/g;->a:I

    iput v0, p0, Ls/g;->b:I

    iput-boolean v0, p0, Ls/g;->e:Z

    const/16 v0, 0x8

    iput v0, p0, Ls/g;->h:I

    const/16 v0, 0x100

    new-array v1, v0, [B

    iput-object v1, p0, Ls/g;->l:[B

    const/4 v1, 0x5

    new-array v2, v1, [B

    iput-object v2, p0, Ls/g;->m:[B

    new-array v0, v0, [B

    iput-object v0, p0, Ls/g;->n:[B

    new-array v0, v1, [B

    iput-object v0, p0, Ls/g;->o:[B

    new-instance v0, Lcom/trilead/ssh2/crypto/cipher/CipherInputStream;

    new-instance v1, Lcom/trilead/ssh2/crypto/cipher/NullCipher;

    invoke-direct {v1}, Lcom/trilead/ssh2/crypto/cipher/NullCipher;-><init>()V

    invoke-direct {v0, v1, p1}, Lcom/trilead/ssh2/crypto/cipher/CipherInputStream;-><init>(Lcom/trilead/ssh2/crypto/cipher/BlockCipher;Ljava/io/InputStream;)V

    iput-object v0, p0, Ls/g;->c:Lcom/trilead/ssh2/crypto/cipher/CipherInputStream;

    new-instance p1, Lcom/trilead/ssh2/crypto/cipher/CipherOutputStream;

    new-instance v0, Lcom/trilead/ssh2/crypto/cipher/NullCipher;

    invoke-direct {v0}, Lcom/trilead/ssh2/crypto/cipher/NullCipher;-><init>()V

    invoke-direct {p1, v0, p2}, Lcom/trilead/ssh2/crypto/cipher/CipherOutputStream;-><init>(Lcom/trilead/ssh2/crypto/cipher/BlockCipher;Ljava/io/OutputStream;)V

    iput-object p1, p0, Ls/g;->d:Lcom/trilead/ssh2/crypto/cipher/CipherOutputStream;

    .line 1
    const-class p1, Lc0/h;

    monitor-enter p1

    :try_start_0
    sget-object p2, Lc0/h;->b:Lc0/h;

    if-nez p2, :cond_0

    new-instance p2, Lc0/h;

    invoke-direct {p2}, Lc0/h;-><init>()V

    sput-object p2, Lc0/h;->b:Lc0/h;

    :cond_0
    sget-object p2, Lc0/h;->b:Lc0/h;
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_1

    monitor-exit p1

    .line 2
    monitor-enter p2

    :try_start_1
    iget-object p1, p2, Lc0/h;->a:Lc0/h$a;
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    monitor-exit p2

    .line 3
    iput-object p1, p0, Ls/g;->q:Lc0/h$a;

    iput-object p3, p0, Ls/g;->p:Ljava/security/SecureRandom;

    return-void

    :catchall_0
    move-exception p1

    .line 4
    monitor-exit p2

    throw p1

    :catchall_1
    move-exception p2

    .line 5
    monitor-exit p1

    throw p2
.end method


# virtual methods
.method public final a([B)V
    .locals 9

    array-length v0, p1

    add-int/lit8 v1, v0, 0x5

    add-int/lit8 v2, v1, 0x4

    .line 1
    iget v3, p0, Ls/g;->h:I

    rem-int v4, v2, v3

    if-eqz v4, :cond_0

    sub-int/2addr v3, v4

    add-int/2addr v2, v3

    :cond_0
    const/16 v3, 0x10

    if-ge v2, v3, :cond_1

    const/16 v2, 0x10

    :cond_1
    sub-int v1, v2, v1

    iget-boolean v3, p0, Ls/g;->e:Z

    const/4 v4, 0x0

    if-eqz v3, :cond_2

    const/4 v3, 0x0

    :goto_0
    if-ge v3, v1, :cond_3

    iget-object v5, p0, Ls/g;->p:Ljava/security/SecureRandom;

    invoke-virtual {v5}, Ljava/util/Random;->nextInt()I

    move-result v5

    iget-object v6, p0, Ls/g;->l:[B

    int-to-byte v7, v5

    aput-byte v7, v6, v3

    add-int/lit8 v7, v3, 0x1

    shr-int/lit8 v8, v5, 0x8

    int-to-byte v8, v8

    aput-byte v8, v6, v7

    add-int/lit8 v7, v3, 0x2

    shr-int/lit8 v8, v5, 0x10

    int-to-byte v8, v8

    aput-byte v8, v6, v7

    add-int/lit8 v7, v3, 0x3

    shr-int/lit8 v5, v5, 0x18

    int-to-byte v5, v5

    aput-byte v5, v6, v7

    add-int/lit8 v3, v3, 0x4

    goto :goto_0

    :cond_2
    const/4 v3, 0x0

    :goto_1
    if-ge v3, v1, :cond_3

    iget-object v5, p0, Ls/g;->l:[B

    aput-byte v4, v5, v3

    add-int/lit8 v3, v3, 0x1

    goto :goto_1

    :cond_3
    iget-object v3, p0, Ls/g;->m:[B

    const/4 v5, 0x4

    sub-int/2addr v2, v5

    shr-int/lit8 v6, v2, 0x18

    int-to-byte v6, v6

    aput-byte v6, v3, v4

    shr-int/lit8 v6, v2, 0x10

    int-to-byte v6, v6

    const/4 v7, 0x1

    aput-byte v6, v3, v7

    shr-int/lit8 v6, v2, 0x8

    int-to-byte v6, v6

    const/4 v8, 0x2

    aput-byte v6, v3, v8

    int-to-byte v2, v2

    const/4 v6, 0x3

    aput-byte v2, v3, v6

    int-to-byte v2, v1

    aput-byte v2, v3, v5

    iget-object v2, p0, Ls/g;->d:Lcom/trilead/ssh2/crypto/cipher/CipherOutputStream;

    const/4 v5, 0x5

    invoke-virtual {v2, v3, v5}, Lcom/trilead/ssh2/crypto/cipher/CipherOutputStream;->b([BI)V

    iget-object v2, p0, Ls/g;->d:Lcom/trilead/ssh2/crypto/cipher/CipherOutputStream;

    invoke-virtual {v2, p1, v0}, Lcom/trilead/ssh2/crypto/cipher/CipherOutputStream;->b([BI)V

    iget-object v2, p0, Ls/g;->d:Lcom/trilead/ssh2/crypto/cipher/CipherOutputStream;

    iget-object v3, p0, Ls/g;->l:[B

    invoke-virtual {v2, v3, v1}, Lcom/trilead/ssh2/crypto/cipher/CipherOutputStream;->b([BI)V

    iget-object v2, p0, Ls/g;->f:Lcom/trilead/ssh2/crypto/digest/MAC;

    if-eqz v2, :cond_5

    iget v3, p0, Ls/g;->a:I

    invoke-virtual {v2, v3}, Lcom/trilead/ssh2/crypto/digest/MAC;->b(I)V

    iget-object v2, p0, Ls/g;->f:Lcom/trilead/ssh2/crypto/digest/MAC;

    iget-object v3, p0, Ls/g;->m:[B

    invoke-virtual {v2, v3, v5}, Lcom/trilead/ssh2/crypto/digest/MAC;->d([BI)V

    iget-object v2, p0, Ls/g;->f:Lcom/trilead/ssh2/crypto/digest/MAC;

    invoke-virtual {v2, p1, v0}, Lcom/trilead/ssh2/crypto/digest/MAC;->d([BI)V

    iget-object p1, p0, Ls/g;->f:Lcom/trilead/ssh2/crypto/digest/MAC;

    iget-object v0, p0, Ls/g;->l:[B

    invoke-virtual {p1, v0, v1}, Lcom/trilead/ssh2/crypto/digest/MAC;->d([BI)V

    iget-object p1, p0, Ls/g;->f:Lcom/trilead/ssh2/crypto/digest/MAC;

    iget-object v0, p0, Ls/g;->g:[B

    invoke-virtual {p1, v0}, Lcom/trilead/ssh2/crypto/digest/MAC;->a([B)V

    iget-object p1, p0, Ls/g;->d:Lcom/trilead/ssh2/crypto/cipher/CipherOutputStream;

    iget-object v0, p0, Ls/g;->g:[B

    array-length v1, v0

    .line 2
    iget v2, p1, Lcom/trilead/ssh2/crypto/cipher/CipherOutputStream;->f:I

    if-nez v2, :cond_4

    invoke-virtual {p1, v0, v1}, Lcom/trilead/ssh2/crypto/cipher/CipherOutputStream;->a([BI)V

    goto :goto_2

    :cond_4
    new-instance p1, Ljava/io/IOException;

    const-string v0, "Cannot write plain since crypto buffer is not aligned."

    invoke-direct {p1, v0}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    throw p1

    .line 3
    :cond_5
    :goto_2
    iget-object p1, p0, Ls/g;->d:Lcom/trilead/ssh2/crypto/cipher/CipherOutputStream;

    .line 4
    iget v0, p1, Lcom/trilead/ssh2/crypto/cipher/CipherOutputStream;->f:I

    if-nez v0, :cond_7

    iget v0, p1, Lcom/trilead/ssh2/crypto/cipher/CipherOutputStream;->h:I

    if-lez v0, :cond_6

    iget-object v1, p1, Lcom/trilead/ssh2/crypto/cipher/CipherOutputStream;->b:Ljava/io/OutputStream;

    iget-object v2, p1, Lcom/trilead/ssh2/crypto/cipher/CipherOutputStream;->g:[B

    invoke-virtual {v1, v2, v4, v0}, Ljava/io/OutputStream;->write([BII)V

    iput v4, p1, Lcom/trilead/ssh2/crypto/cipher/CipherOutputStream;->h:I

    :cond_6
    iget-object p1, p1, Lcom/trilead/ssh2/crypto/cipher/CipherOutputStream;->b:Ljava/io/OutputStream;

    invoke-virtual {p1}, Ljava/io/OutputStream;->flush()V

    .line 5
    iget-object p1, p0, Ls/g;->q:Lc0/h$a;

    .line 6
    monitor-enter p1

    :try_start_0
    invoke-virtual {p1}, Lc0/h$a;->a()V

    .line 7
    iget-object v0, p1, Lc0/h$a;->a:Ljava/util/ArrayList;

    invoke-virtual {v0}, Ljava/util/ArrayList;->size()I

    move-result v1

    add-int/lit8 v1, v1, -0x1

    invoke-virtual {v0, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lc0/h$a$a;

    invoke-static {v0}, Ljava/util/Objects;->requireNonNull(Ljava/lang/Object;)Ljava/lang/Object;

    iget-object v0, p1, Lc0/h$a;->c:Ljava/util/ArrayList;

    invoke-virtual {v0}, Ljava/util/ArrayList;->size()I

    move-result v1

    add-int/lit8 v1, v1, -0x1

    invoke-virtual {v0, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lc0/h$a$a;

    invoke-static {v0}, Ljava/util/Objects;->requireNonNull(Ljava/lang/Object;)Ljava/lang/Object;
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 8
    monitor-exit p1

    .line 9
    sget-object p1, Ls/g;->r:La/b;

    invoke-static {p1}, Ljava/util/Objects;->requireNonNull(Ljava/lang/Object;)Ljava/lang/Object;

    iget p1, p0, Ls/g;->a:I

    add-int/2addr p1, v7

    iput p1, p0, Ls/g;->a:I

    return-void

    :catchall_0
    move-exception v0

    .line 10
    monitor-exit p1

    throw v0

    .line 11
    :cond_7
    new-instance p1, Ljava/io/IOException;

    const-string v0, "FATAL: cannot flush since crypto buffer is not aligned."

    invoke-direct {p1, v0}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    throw p1
.end method
