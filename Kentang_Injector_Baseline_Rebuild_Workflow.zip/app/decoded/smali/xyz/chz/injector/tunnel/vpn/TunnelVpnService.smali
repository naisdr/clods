.class public Lxyz/chz/injector/tunnel/vpn/TunnelVpnService;
.super Landroid/net/VpnService;
.source "SourceFile"


# annotations
.annotation build Landroid/annotation/TargetApi;
    value = 0xe
.end annotation

.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lxyz/chz/injector/tunnel/vpn/TunnelVpnService$a;
    }
.end annotation


# instance fields
.field public a:Li0/g;

.field public final b:Lxyz/chz/injector/tunnel/vpn/TunnelVpnService$a;


# direct methods
.method public constructor <init>()V
    .locals 1

    invoke-direct {p0}, Landroid/net/VpnService;-><init>()V

    new-instance v0, Li0/g;

    invoke-direct {v0, p0}, Li0/g;-><init>(Lxyz/chz/injector/tunnel/vpn/TunnelVpnService;)V

    iput-object v0, p0, Lxyz/chz/injector/tunnel/vpn/TunnelVpnService;->a:Li0/g;

    new-instance v0, Lxyz/chz/injector/tunnel/vpn/TunnelVpnService$a;

    invoke-direct {v0}, Lxyz/chz/injector/tunnel/vpn/TunnelVpnService$a;-><init>()V

    iput-object v0, p0, Lxyz/chz/injector/tunnel/vpn/TunnelVpnService;->b:Lxyz/chz/injector/tunnel/vpn/TunnelVpnService$a;

    return-void
.end method


# virtual methods
.method public final a(Z)V
    .locals 2

    new-instance v0, Landroid/content/Intent;

    const-string v1, "tunnelVpnStartBroadcast"

    invoke-direct {v0, v1}, Landroid/content/Intent;-><init>(Ljava/lang/String;)V

    const-string v1, "tunnelVpnStartSuccessExtra"

    invoke-virtual {v0, v1, p1}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Z)Landroid/content/Intent;

    invoke-static {p0}, Lh/a;->a(Landroid/content/Context;)Lh/a;

    move-result-object p1

    invoke-virtual {p1, v0}, Lh/a;->c(Landroid/content/Intent;)Z

    return-void
.end method

.method public final onBind(Landroid/content/Intent;)Landroid/os/IBinder;
    .locals 2

    invoke-virtual {p1}, Landroid/content/Intent;->getAction()Ljava/lang/String;

    move-result-object v0

    if-eqz v0, :cond_0

    const-string v1, "android.net.VpnService"

    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_0

    invoke-super {p0, p1}, Landroid/net/VpnService;->onBind(Landroid/content/Intent;)Landroid/os/IBinder;

    move-result-object p1

    return-object p1

    :cond_0
    iget-object p1, p0, Lxyz/chz/injector/tunnel/vpn/TunnelVpnService;->b:Lxyz/chz/injector/tunnel/vpn/TunnelVpnService$a;

    return-object p1
.end method

.method public final onCreate()V
    .locals 2

    const-string v0, "TunnelVpnService"

    const-string v1, "on create"

    invoke-static {v0, v1}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    invoke-static {}, Li0/e;->b()Li0/e;

    move-result-object v0

    iget-object v1, p0, Lxyz/chz/injector/tunnel/vpn/TunnelVpnService;->a:Li0/g;

    monitor-enter v0

    :try_start_0
    iput-object v1, v0, Li0/e;->a:Li0/g;

    const/4 v1, 0x0

    iput-boolean v1, v0, Li0/e;->b:Z
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    monitor-exit v0

    return-void

    :catchall_0
    move-exception v1

    monitor-exit v0

    throw v1
.end method

.method public final onDestroy()V
    .locals 3

    const-string v0, "TunnelVpnService"

    const-string v1, "on destroy"

    invoke-static {v0, v1}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    invoke-static {}, Li0/e;->b()Li0/e;

    move-result-object v0

    .line 1
    monitor-enter v0

    const/4 v1, 0x0

    :try_start_0
    iput-object v1, v0, Li0/e;->a:Li0/g;

    const/4 v2, 0x0

    iput-boolean v2, v0, Li0/e;->b:Z
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    monitor-exit v0

    .line 2
    iget-object v0, p0, Lxyz/chz/injector/tunnel/vpn/TunnelVpnService;->a:Li0/g;

    .line 3
    iget-object v2, v0, Li0/g;->c:Ljava/lang/Thread;

    if-nez v2, :cond_0

    goto :goto_1

    :cond_0
    invoke-virtual {v0}, Li0/g;->d()V

    :try_start_1
    iget-object v2, v0, Li0/g;->c:Ljava/lang/Thread;

    invoke-virtual {v2}, Ljava/lang/Thread;->join()V
    :try_end_1
    .catch Ljava/lang/InterruptedException; {:try_start_1 .. :try_end_1} :catch_0

    goto :goto_0

    :catch_0
    invoke-static {}, Ljava/lang/Thread;->currentThread()Ljava/lang/Thread;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/Thread;->interrupt()V

    :goto_0
    iput-object v1, v0, Li0/g;->b:Ljava/util/concurrent/CountDownLatch;

    iput-object v1, v0, Li0/g;->c:Ljava/lang/Thread;

    :goto_1
    return-void

    :catchall_0
    move-exception v1

    .line 4
    monitor-exit v0

    throw v1
.end method

.method public final onRevoke()V
    .locals 2

    const-string v0, "<strong>VPN service revoked</strong>"

    invoke-static {v0}, Lg0/d;->h(Ljava/lang/String;)V

    .line 1
    new-instance v0, Landroid/content/Intent;

    const-string v1, "tunnelVpnDisconnectBroadcast"

    invoke-direct {v0, v1}, Landroid/content/Intent;-><init>(Ljava/lang/String;)V

    .line 2
    invoke-static {p0}, Lh/a;->a(Landroid/content/Context;)Lh/a;

    move-result-object v1

    invoke-virtual {v1, v0}, Lh/a;->c(Landroid/content/Intent;)Z

    .line 3
    invoke-virtual {p0}, Landroid/app/Service;->stopSelf()V

    return-void
.end method

.method public final onStartCommand(Landroid/content/Intent;II)I
    .locals 9

    const-string p2, "TunnelVpnService"

    const-string p3, "on start"

    invoke-static {p2, p3}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    iget-object p2, p0, Lxyz/chz/injector/tunnel/vpn/TunnelVpnService;->a:Li0/g;

    invoke-static {p2}, Ljava/util/Objects;->requireNonNull(Ljava/lang/Object;)Ljava/lang/Object;

    const-string p3, "TunnelManager"

    const-string v0, "onStartCommand"

    .line 1
    invoke-static {p3, v0}, Landroid/util/Log;->i(Ljava/lang/String;Ljava/lang/String;)I

    const/4 p3, 0x0

    if-nez p1, :cond_0

    const-string p1, "TunnelManager"

    const-string v0, "Failed to receive intent"

    goto :goto_0

    :cond_0
    const-string v0, "vpnSettings"

    invoke-virtual {p1, v0}, Landroid/content/Intent;->getParcelableExtra(Ljava/lang/String;)Landroid/os/Parcelable;

    move-result-object p1

    check-cast p1, Li0/h;

    iput-object p1, p2, Li0/g;->g:Li0/h;

    if-nez p1, :cond_1

    const-string p1, "TunnelManager"

    const-string v0, "Failed to receive the Vpn Settings."

    goto :goto_0

    :cond_1
    iget-object v0, p1, Li0/h;->a:Ljava/lang/String;

    if-nez v0, :cond_2

    const-string p1, "TunnelManager"

    const-string v0, "Failed to receive the socks server address."

    goto :goto_0

    :cond_2
    iget-object v0, p1, Li0/h;->c:[Ljava/lang/String;

    if-nez v0, :cond_3

    const-string p1, "TunnelManager"

    const-string v0, "Failed to receive the dns resolvers."

    :goto_0
    invoke-static {p1, v0}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    iget-object p1, p2, Li0/g;->a:Lxyz/chz/injector/tunnel/vpn/TunnelVpnService;

    invoke-virtual {p1, p3}, Lxyz/chz/injector/tunnel/vpn/TunnelVpnService;->a(Z)V

    goto :goto_2

    :cond_3
    :try_start_0
    iget-object v8, p2, Li0/g;->e:Li0/d;

    .line 2
    monitor-enter v8
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    :try_start_1
    iget-boolean v1, p1, Li0/h;->b:Z

    iget-object v2, p1, Li0/h;->c:[Ljava/lang/String;

    iget-object v3, p1, Li0/h;->e:[Ljava/lang/String;

    iget-boolean v4, p1, Li0/h;->g:Z

    iget-boolean v5, p1, Li0/h;->h:Z

    iget-object v6, p1, Li0/h;->i:[Ljava/lang/String;

    iget-boolean v7, p1, Li0/h;->j:Z

    move-object v0, v8

    invoke-virtual/range {v0 .. v7}, Li0/d;->b(Z[Ljava/lang/String;[Ljava/lang/String;ZZ[Ljava/lang/String;Z)Z

    move-result p1
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    :try_start_2
    monitor-exit v8

    if-nez p1, :cond_4

    const-string p1, "TunnelManager"

    const-string v0, "Failed to establish VPN"

    .line 3
    invoke-static {p1, v0}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    iget-object p1, p2, Li0/g;->a:Lxyz/chz/injector/tunnel/vpn/TunnelVpnService;

    invoke-virtual {p1, p3}, Lxyz/chz/injector/tunnel/vpn/TunnelVpnService;->a(Z)V

    goto :goto_1

    :catchall_0
    move-exception p1

    .line 4
    monitor-exit v8

    throw p1
    :try_end_2
    .catch Ljava/lang/Exception; {:try_start_2 .. :try_end_2} :catch_0

    :catch_0
    move-exception p1

    const-string v0, "TunnelManager"

    const-string v1, "Failed to establish VPN: %s"

    const/4 v2, 0x1

    new-array v2, v2, [Ljava/lang/Object;

    .line 5
    invoke-virtual {p1}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    move-result-object p1

    aput-object p1, v2, p3

    invoke-static {v1, v2}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object p1

    invoke-static {v0, p1}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    iget-object p1, p2, Li0/g;->a:Lxyz/chz/injector/tunnel/vpn/TunnelVpnService;

    invoke-virtual {p1, p3}, Lxyz/chz/injector/tunnel/vpn/TunnelVpnService;->a(Z)V

    :cond_4
    :goto_1
    const/4 p3, 0x2

    :goto_2
    return p3
.end method
