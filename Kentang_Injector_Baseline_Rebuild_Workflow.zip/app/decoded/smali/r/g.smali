.class public final Lr/g;
.super Lr/d;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lr/g$b;
    }
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Lr/d<",
        "Ljava/security/interfaces/RSAPublicKey;",
        "Ljava/security/interfaces/RSAPrivateKey;",
        ">;"
    }
.end annotation


# direct methods
.method public constructor <init>()V
    .locals 3

    const-class v0, Ljava/security/interfaces/RSAPrivateKey;

    const-string v1, "SHA1WithRSA"

    const-string v2, "ssh-rsa"

    invoke-direct {p0, v1, v2, v0}, Lr/d;-><init>(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Class;)V

    return-void
.end method


# virtual methods
.method public final a([B)Ljava/security/PublicKey;
    .locals 3

    .line 1
    new-instance v0, Lq/c;

    invoke-direct {v0, p1}, Lq/c;-><init>([B)V

    invoke-virtual {v0}, Lq/c;->g()Ljava/lang/String;

    move-result-object p1

    .line 2
    iget-object v1, p0, Lr/d;->b:Ljava/lang/String;

    .line 3
    invoke-virtual {p1, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_1

    invoke-virtual {v0}, Lq/c;->e()Ljava/math/BigInteger;

    move-result-object p1

    invoke-virtual {v0}, Lq/c;->e()Ljava/math/BigInteger;

    move-result-object v1

    .line 4
    iget v2, v0, Lq/c;->c:I

    iget v0, v0, Lq/c;->b:I

    sub-int/2addr v2, v0

    if-nez v2, :cond_0

    :try_start_0
    const-string v0, "RSA"

    .line 5
    invoke-static {v0}, Ljava/security/KeyFactory;->getInstance(Ljava/lang/String;)Ljava/security/KeyFactory;

    move-result-object v0

    new-instance v2, Ljava/security/spec/RSAPublicKeySpec;

    invoke-direct {v2, v1, p1}, Ljava/security/spec/RSAPublicKeySpec;-><init>(Ljava/math/BigInteger;Ljava/math/BigInteger;)V

    invoke-virtual {v0, v2}, Ljava/security/KeyFactory;->generatePublic(Ljava/security/spec/KeySpec;)Ljava/security/PublicKey;

    move-result-object p1

    check-cast p1, Ljava/security/interfaces/RSAPublicKey;
    :try_end_0
    .catch Ljava/security/GeneralSecurityException; {:try_start_0 .. :try_end_0} :catch_0

    return-object p1

    :catch_0
    move-exception p1

    new-instance v0, Ljava/io/IOException;

    const-string v1, "Could not generate RSA key"

    invoke-direct {v0, v1, p1}, Ljava/io/IOException;-><init>(Ljava/lang/String;Ljava/lang/Throwable;)V

    throw v0

    :cond_0
    new-instance p1, Ljava/io/IOException;

    const-string v0, "Padding in RSA public key!"

    invoke-direct {p1, v0}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    throw p1

    :cond_1
    new-instance v0, Lm/g;

    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const-string v2, "Unsupported key format found \'"

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string p1, "\' while expecting "

    invoke-virtual {v1, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 6
    iget-object p1, p0, Lr/d;->b:Ljava/lang/String;

    .line 7
    invoke-virtual {v1, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    invoke-direct {v0, p1}, Lm/g;-><init>(Ljava/lang/String;)V

    throw v0
.end method

.method public final b([B)[B
    .locals 2

    new-instance v0, Lq/c;

    invoke-direct {v0, p1}, Lq/c;-><init>([B)V

    invoke-virtual {v0}, Lq/c;->g()Ljava/lang/String;

    move-result-object p1

    .line 1
    iget-object v1, p0, Lr/d;->b:Ljava/lang/String;

    .line 2
    invoke-virtual {p1, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p1

    if-eqz p1, :cond_2

    invoke-virtual {v0}, Lq/c;->c()[B

    move-result-object p1

    array-length v1, p1

    if-eqz v1, :cond_1

    .line 3
    iget v1, v0, Lq/c;->c:I

    iget v0, v0, Lq/c;->b:I

    sub-int/2addr v1, v0

    if-nez v1, :cond_0

    return-object p1

    .line 4
    :cond_0
    new-instance p1, Ljava/io/IOException;

    const-string v0, "Padding in RSA signature!"

    invoke-direct {p1, v0}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    throw p1

    :cond_1
    new-instance p1, Ljava/io/IOException;

    const-string v0, "Error in RSA signature, S is empty."

    invoke-direct {p1, v0}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    throw p1

    :cond_2
    new-instance p1, Ljava/io/IOException;

    const-string v0, "Peer sent wrong signature format"

    invoke-direct {p1, v0}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    throw p1
.end method

.method public final c(Ljava/security/PublicKey;)[B
    .locals 2

    check-cast p1, Ljava/security/interfaces/RSAPublicKey;

    .line 1
    new-instance v0, Lq/b;

    invoke-direct {v0}, Lq/b;-><init>()V

    .line 2
    iget-object v1, p0, Lr/d;->b:Ljava/lang/String;

    .line 3
    invoke-virtual {v0, v1}, Lq/b;->h(Ljava/lang/String;)V

    invoke-interface {p1}, Ljava/security/interfaces/RSAPublicKey;->getPublicExponent()Ljava/math/BigInteger;

    move-result-object v1

    invoke-virtual {v0, v1}, Lq/b;->f(Ljava/math/BigInteger;)V

    invoke-interface {p1}, Ljava/security/interfaces/RSAKey;->getModulus()Ljava/math/BigInteger;

    move-result-object p1

    invoke-virtual {v0, p1}, Lq/b;->f(Ljava/math/BigInteger;)V

    invoke-virtual {v0}, Lq/b;->a()[B

    move-result-object p1

    return-object p1
.end method

.method public final d([B)[B
    .locals 4

    new-instance v0, Lq/b;

    invoke-direct {v0}, Lq/b;-><init>()V

    .line 1
    iget-object v1, p0, Lr/d;->b:Ljava/lang/String;

    .line 2
    invoke-virtual {v0, v1}, Lq/b;->h(Ljava/lang/String;)V

    array-length v1, p1

    const/4 v2, 0x0

    const/4 v3, 0x1

    if-le v1, v3, :cond_0

    aget-byte v1, p1, v2

    if-nez v1, :cond_0

    array-length v1, p1

    sub-int/2addr v1, v3

    invoke-virtual {v0, p1, v3, v1}, Lq/b;->i([BII)V

    goto :goto_0

    :cond_0
    array-length v1, p1

    invoke-virtual {v0, p1, v2, v1}, Lq/b;->i([BII)V

    :goto_0
    invoke-virtual {v0}, Lq/b;->a()[B

    move-result-object p1

    return-object p1
.end method

.method public final e()Ljava/util/List;
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/List<",
            "Lcom/trilead/ssh2/crypto/CertificateDecoder;",
            ">;"
        }
    .end annotation

    const/4 v0, 0x2

    new-array v0, v0, [Lcom/trilead/ssh2/crypto/CertificateDecoder;

    new-instance v1, Lr/g$b;

    .line 1
    invoke-direct {v1}, Lr/g$b;-><init>()V

    const/4 v2, 0x0

    aput-object v1, v0, v2

    .line 2
    new-instance v1, Lr/g$a;

    invoke-direct {v1}, Lr/g$a;-><init>()V

    const/4 v2, 0x1

    aput-object v1, v0, v2

    invoke-static {v0}, Ljava/util/Arrays;->asList([Ljava/lang/Object;)Ljava/util/List;

    move-result-object v0

    return-object v0
.end method
