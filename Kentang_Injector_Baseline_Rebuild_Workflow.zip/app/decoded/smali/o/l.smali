.class public final Lo/l;
.super Ljava/lang/Thread;
.source "SourceFile"


# instance fields
.field public a:Ljava/io/OutputStream;

.field public b:Ljava/io/InputStream;

.field public c:[B

.field public d:Lo/a;

.field public e:Lo/l;

.field public f:Ljava/net/Socket;

.field public g:Ljava/lang/String;


# direct methods
.method public constructor <init>(Lo/a;Lo/l;Ljava/net/Socket;Ljava/io/InputStream;Ljava/io/OutputStream;Ljava/lang/String;)V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Thread;-><init>()V

    iput-object p4, p0, Lo/l;->b:Ljava/io/InputStream;

    iput-object p5, p0, Lo/l;->a:Ljava/io/OutputStream;

    iput-object p6, p0, Lo/l;->g:Ljava/lang/String;

    iput-object p1, p0, Lo/l;->d:Lo/a;

    iput-object p2, p0, Lo/l;->e:Lo/l;

    iput-object p3, p0, Lo/l;->f:Ljava/net/Socket;

    const/16 p1, 0x2000

    new-array p1, p1, [B

    iput-object p1, p0, Lo/l;->c:[B

    return-void
.end method


# virtual methods
.method public final run()V
    .locals 7

    const-string v0, ") is cleaning up the connection"

    const-string v1, "StreamForwarder ("

    :goto_0
    :try_start_0
    iget-object v2, p0, Lo/l;->b:Ljava/io/InputStream;

    iget-object v3, p0, Lo/l;->c:[B

    invoke-virtual {v2, v3}, Ljava/io/InputStream;->read([B)I

    move-result v2
    :try_end_0
    .catch Ljava/io/IOException; {:try_start_0 .. :try_end_0} :catch_4
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    if-gtz v2, :cond_1

    :try_start_1
    iget-object v2, p0, Lo/l;->a:Ljava/io/OutputStream;

    invoke-virtual {v2}, Ljava/io/OutputStream;->close()V
    :try_end_1
    .catch Ljava/io/IOException; {:try_start_1 .. :try_end_1} :catch_0

    :catch_0
    :try_start_2
    iget-object v2, p0, Lo/l;->b:Ljava/io/InputStream;

    invoke-virtual {v2}, Ljava/io/InputStream;->close()V
    :try_end_2
    .catch Ljava/io/IOException; {:try_start_2 .. :try_end_2} :catch_1

    goto :goto_1

    :catch_1
    nop

    :goto_1
    iget-object v2, p0, Lo/l;->e:Lo/l;

    if-eqz v2, :cond_5

    :goto_2
    iget-object v2, p0, Lo/l;->e:Lo/l;

    invoke-virtual {v2}, Ljava/lang/Thread;->isAlive()Z

    move-result v2

    if-eqz v2, :cond_0

    :try_start_3
    iget-object v2, p0, Lo/l;->e:Lo/l;

    invoke-virtual {v2}, Ljava/lang/Thread;->join()V
    :try_end_3
    .catch Ljava/lang/InterruptedException; {:try_start_3 .. :try_end_3} :catch_2

    goto :goto_2

    :catch_2
    nop

    goto :goto_2

    :cond_0
    :try_start_4
    iget-object v2, p0, Lo/l;->d:Lo/a;

    iget-object v3, v2, Lo/a;->b:Lo/c;

    new-instance v4, Ljava/lang/StringBuilder;

    invoke-direct {v4}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v4, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object v1, p0, Lo/l;->g:Ljava/lang/String;

    invoke-virtual {v4, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v4, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v3, v2, v0}, Lo/c;->e(Lo/a;Ljava/lang/String;)V
    :try_end_4
    .catch Ljava/io/IOException; {:try_start_4 .. :try_end_4} :catch_3

    :catch_3
    :try_start_5
    iget-object v0, p0, Lo/l;->f:Ljava/net/Socket;
    :try_end_5
    .catch Ljava/io/IOException; {:try_start_5 .. :try_end_5} :catch_f

    if-eqz v0, :cond_5

    goto/16 :goto_9

    :cond_1
    :try_start_6
    iget-object v3, p0, Lo/l;->a:Ljava/io/OutputStream;

    iget-object v4, p0, Lo/l;->c:[B

    const/4 v5, 0x0

    invoke-virtual {v3, v4, v5, v2}, Ljava/io/OutputStream;->write([BII)V

    iget-object v2, p0, Lo/l;->a:Ljava/io/OutputStream;

    invoke-virtual {v2}, Ljava/io/OutputStream;->flush()V
    :try_end_6
    .catch Ljava/io/IOException; {:try_start_6 .. :try_end_6} :catch_4
    .catchall {:try_start_6 .. :try_end_6} :catchall_0

    goto :goto_0

    :catchall_0
    move-exception v2

    goto :goto_3

    :catch_4
    move-exception v2

    :try_start_7
    iget-object v3, p0, Lo/l;->d:Lo/a;

    iget-object v4, v3, Lo/a;->b:Lo/c;

    new-instance v5, Ljava/lang/StringBuilder;

    invoke-direct {v5}, Ljava/lang/StringBuilder;-><init>()V

    const-string v6, "Closed due to exception in StreamForwarder ("

    invoke-virtual {v5, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object v6, p0, Lo/l;->g:Ljava/lang/String;

    invoke-virtual {v5, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v6, "): "

    invoke-virtual {v5, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v5, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v5}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v4, v3, v2}, Lo/c;->e(Lo/a;Ljava/lang/String;)V
    :try_end_7
    .catch Ljava/io/IOException; {:try_start_7 .. :try_end_7} :catch_a
    .catchall {:try_start_7 .. :try_end_7} :catchall_0

    goto :goto_6

    :goto_3
    :try_start_8
    iget-object v3, p0, Lo/l;->a:Ljava/io/OutputStream;

    invoke-virtual {v3}, Ljava/io/OutputStream;->close()V
    :try_end_8
    .catch Ljava/io/IOException; {:try_start_8 .. :try_end_8} :catch_5

    :catch_5
    :try_start_9
    iget-object v3, p0, Lo/l;->b:Ljava/io/InputStream;

    invoke-virtual {v3}, Ljava/io/InputStream;->close()V
    :try_end_9
    .catch Ljava/io/IOException; {:try_start_9 .. :try_end_9} :catch_6

    goto :goto_4

    :catch_6
    nop

    :goto_4
    iget-object v3, p0, Lo/l;->e:Lo/l;

    if-eqz v3, :cond_3

    :goto_5
    iget-object v3, p0, Lo/l;->e:Lo/l;

    invoke-virtual {v3}, Ljava/lang/Thread;->isAlive()Z

    move-result v3

    if-eqz v3, :cond_2

    :try_start_a
    iget-object v3, p0, Lo/l;->e:Lo/l;

    invoke-virtual {v3}, Ljava/lang/Thread;->join()V
    :try_end_a
    .catch Ljava/lang/InterruptedException; {:try_start_a .. :try_end_a} :catch_7

    goto :goto_5

    :catch_7
    nop

    goto :goto_5

    :cond_2
    :try_start_b
    iget-object v3, p0, Lo/l;->d:Lo/a;

    iget-object v4, v3, Lo/a;->b:Lo/c;

    new-instance v5, Ljava/lang/StringBuilder;

    invoke-direct {v5}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v5, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object v1, p0, Lo/l;->g:Ljava/lang/String;

    invoke-virtual {v5, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v5, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v5}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v4, v3, v0}, Lo/c;->e(Lo/a;Ljava/lang/String;)V
    :try_end_b
    .catch Ljava/io/IOException; {:try_start_b .. :try_end_b} :catch_8

    :catch_8
    :try_start_c
    iget-object v0, p0, Lo/l;->f:Ljava/net/Socket;

    if-eqz v0, :cond_3

    invoke-virtual {v0}, Ljava/net/Socket;->close()V
    :try_end_c
    .catch Ljava/io/IOException; {:try_start_c .. :try_end_c} :catch_9

    :catch_9
    :cond_3
    throw v2

    :catch_a
    :goto_6
    :try_start_d
    iget-object v2, p0, Lo/l;->a:Ljava/io/OutputStream;

    invoke-virtual {v2}, Ljava/io/OutputStream;->close()V
    :try_end_d
    .catch Ljava/io/IOException; {:try_start_d .. :try_end_d} :catch_b

    :catch_b
    :try_start_e
    iget-object v2, p0, Lo/l;->b:Ljava/io/InputStream;

    invoke-virtual {v2}, Ljava/io/InputStream;->close()V
    :try_end_e
    .catch Ljava/io/IOException; {:try_start_e .. :try_end_e} :catch_c

    goto :goto_7

    :catch_c
    nop

    :goto_7
    iget-object v2, p0, Lo/l;->e:Lo/l;

    if-eqz v2, :cond_5

    :goto_8
    iget-object v2, p0, Lo/l;->e:Lo/l;

    invoke-virtual {v2}, Ljava/lang/Thread;->isAlive()Z

    move-result v2

    if-eqz v2, :cond_4

    :try_start_f
    iget-object v2, p0, Lo/l;->e:Lo/l;

    invoke-virtual {v2}, Ljava/lang/Thread;->join()V
    :try_end_f
    .catch Ljava/lang/InterruptedException; {:try_start_f .. :try_end_f} :catch_d

    goto :goto_8

    :catch_d
    nop

    goto :goto_8

    :cond_4
    :try_start_10
    iget-object v2, p0, Lo/l;->d:Lo/a;

    iget-object v3, v2, Lo/a;->b:Lo/c;

    new-instance v4, Ljava/lang/StringBuilder;

    invoke-direct {v4}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v4, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object v1, p0, Lo/l;->g:Ljava/lang/String;

    invoke-virtual {v4, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v4, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v3, v2, v0}, Lo/c;->e(Lo/a;Ljava/lang/String;)V
    :try_end_10
    .catch Ljava/io/IOException; {:try_start_10 .. :try_end_10} :catch_e

    :catch_e
    :try_start_11
    iget-object v0, p0, Lo/l;->f:Ljava/net/Socket;

    if-eqz v0, :cond_5

    :goto_9
    invoke-virtual {v0}, Ljava/net/Socket;->close()V
    :try_end_11
    .catch Ljava/io/IOException; {:try_start_11 .. :try_end_11} :catch_f

    :catch_f
    :cond_5
    return-void
.end method
