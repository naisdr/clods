.class public interface abstract Lm/j;
.super Ljava/lang/Object;
.source "SourceFile"


# virtual methods
.method public abstract a(Ljava/lang/String;I)Ljava/net/Socket;
.end method

.method public abstract close()V
.end method
