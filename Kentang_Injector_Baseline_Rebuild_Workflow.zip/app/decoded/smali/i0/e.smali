.class public final Li0/e;
.super Ljava/lang/Object;
.source "SourceFile"


# static fields
.field public static c:Li0/e;


# instance fields
.field public a:Li0/g;

.field public b:Z


# direct methods
.method public constructor <init>()V
    .locals 1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v0, 0x0

    iput-object v0, p0, Li0/e;->a:Li0/g;

    const/4 v0, 0x0

    iput-boolean v0, p0, Li0/e;->b:Z

    return-void
.end method

.method public static declared-synchronized b()Li0/e;
    .locals 2

    const-class v0, Li0/e;

    monitor-enter v0

    :try_start_0
    sget-object v1, Li0/e;->c:Li0/e;

    if-nez v1, :cond_0

    new-instance v1, Li0/e;

    invoke-direct {v1}, Li0/e;-><init>()V

    sput-object v1, Li0/e;->c:Li0/e;

    :cond_0
    sget-object v1, Li0/e;->c:Li0/e;
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    monitor-exit v0

    return-object v1

    :catchall_0
    move-exception v1

    monitor-exit v0

    throw v1
.end method


# virtual methods
.method public final declared-synchronized a()Li0/g;
    .locals 1

    monitor-enter p0

    :try_start_0
    iget-object v0, p0, Li0/e;->a:Li0/g;
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    monitor-exit p0

    return-object v0

    :catchall_0
    move-exception v0

    monitor-exit p0

    throw v0
.end method

.method public final clone()Ljava/lang/Object;
    .locals 1

    new-instance v0, Ljava/lang/CloneNotSupportedException;

    invoke-direct {v0}, Ljava/lang/CloneNotSupportedException;-><init>()V

    throw v0
.end method
