.class public Lcom/trilead/ssh2/crypto/SimpleDERReader;
.super Ljava/lang/Object;
.source "SourceFile"


# instance fields
.field public a:[B

.field public b:I

.field public c:I


# direct methods
.method public constructor <init>([B)V
    .locals 1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 1
    array-length v0, p1

    .line 2
    iput-object p1, p0, Lcom/trilead/ssh2/crypto/SimpleDERReader;->a:[B

    const/4 p1, 0x0

    iput p1, p0, Lcom/trilead/ssh2/crypto/SimpleDERReader;->b:I

    iput v0, p0, Lcom/trilead/ssh2/crypto/SimpleDERReader;->c:I

    return-void
.end method

.method public constructor <init>([BII)V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 3
    iput-object p1, p0, Lcom/trilead/ssh2/crypto/SimpleDERReader;->a:[B

    iput p2, p0, Lcom/trilead/ssh2/crypto/SimpleDERReader;->b:I

    iput p3, p0, Lcom/trilead/ssh2/crypto/SimpleDERReader;->c:I

    return-void
.end method


# virtual methods
.method public final a()B
    .locals 3

    iget v0, p0, Lcom/trilead/ssh2/crypto/SimpleDERReader;->c:I

    if-lez v0, :cond_0

    add-int/lit8 v0, v0, -0x1

    iput v0, p0, Lcom/trilead/ssh2/crypto/SimpleDERReader;->c:I

    iget-object v0, p0, Lcom/trilead/ssh2/crypto/SimpleDERReader;->a:[B

    iget v1, p0, Lcom/trilead/ssh2/crypto/SimpleDERReader;->b:I

    add-int/lit8 v2, v1, 0x1

    iput v2, p0, Lcom/trilead/ssh2/crypto/SimpleDERReader;->b:I

    aget-byte v0, v0, v1

    return v0

    :cond_0
    new-instance v0, Ljava/io/IOException;

    const-string v1, "DER byte array: out of data"

    invoke-direct {v0, v1}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    throw v0
.end method

.method public final b(I)[B
    .locals 4

    iget v0, p0, Lcom/trilead/ssh2/crypto/SimpleDERReader;->c:I

    if-gt p1, v0, :cond_0

    new-array v0, p1, [B

    iget-object v1, p0, Lcom/trilead/ssh2/crypto/SimpleDERReader;->a:[B

    iget v2, p0, Lcom/trilead/ssh2/crypto/SimpleDERReader;->b:I

    const/4 v3, 0x0

    invoke-static {v1, v2, v0, v3, p1}, Ljava/lang/System;->arraycopy(Ljava/lang/Object;ILjava/lang/Object;II)V

    iget v1, p0, Lcom/trilead/ssh2/crypto/SimpleDERReader;->b:I

    add-int/2addr v1, p1

    iput v1, p0, Lcom/trilead/ssh2/crypto/SimpleDERReader;->b:I

    iget v1, p0, Lcom/trilead/ssh2/crypto/SimpleDERReader;->c:I

    sub-int/2addr v1, p1

    iput v1, p0, Lcom/trilead/ssh2/crypto/SimpleDERReader;->c:I

    return-object v0

    :cond_0
    new-instance p1, Ljava/io/IOException;

    const-string v0, "DER byte array: out of data"

    invoke-direct {p1, v0}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    throw p1
.end method

.method public final c()Ljava/math/BigInteger;
    .locals 4

    invoke-virtual {p0}, Lcom/trilead/ssh2/crypto/SimpleDERReader;->a()B

    move-result v0

    and-int/lit16 v0, v0, 0xff

    const/4 v1, 0x2

    if-ne v0, v1, :cond_1

    invoke-virtual {p0}, Lcom/trilead/ssh2/crypto/SimpleDERReader;->d()I

    move-result v0

    if-ltz v0, :cond_0

    .line 1
    iget v1, p0, Lcom/trilead/ssh2/crypto/SimpleDERReader;->c:I

    if-gt v0, v1, :cond_0

    .line 2
    invoke-virtual {p0, v0}, Lcom/trilead/ssh2/crypto/SimpleDERReader;->b(I)[B

    move-result-object v0

    new-instance v1, Ljava/math/BigInteger;

    const/4 v2, 0x1

    invoke-direct {v1, v2, v0}, Ljava/math/BigInteger;-><init>(I[B)V

    return-object v1

    :cond_0
    new-instance v1, Ljava/io/IOException;

    const-string v2, "Illegal len in DER object ("

    const-string v3, ")"

    .line 3
    invoke-static {v2, v0, v3}, Lcom/trilead/ssh2/crypto/digest/a;->d(Ljava/lang/String;ILjava/lang/String;)Ljava/lang/String;

    move-result-object v0

    .line 4
    invoke-direct {v1, v0}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    throw v1

    :cond_1
    new-instance v1, Ljava/io/IOException;

    const-string v2, "Expected DER Integer, but found type "

    .line 5
    invoke-static {v2, v0}, Lcom/trilead/ssh2/crypto/digest/a;->c(Ljava/lang/String;I)Ljava/lang/String;

    move-result-object v0

    .line 6
    invoke-direct {v1, v0}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    throw v1
.end method

.method public final d()I
    .locals 4

    invoke-virtual {p0}, Lcom/trilead/ssh2/crypto/SimpleDERReader;->a()B

    move-result v0

    and-int/lit16 v0, v0, 0xff

    and-int/lit16 v1, v0, 0x80

    if-nez v1, :cond_0

    return v0

    :cond_0
    and-int/lit8 v0, v0, 0x7f

    const/4 v1, -0x1

    if-eqz v0, :cond_4

    const/4 v2, 0x4

    if-le v0, v2, :cond_1

    goto :goto_1

    :cond_1
    const/4 v2, 0x0

    :goto_0
    if-lez v0, :cond_2

    shl-int/lit8 v2, v2, 0x8

    invoke-virtual {p0}, Lcom/trilead/ssh2/crypto/SimpleDERReader;->a()B

    move-result v3

    and-int/lit16 v3, v3, 0xff

    or-int/2addr v2, v3

    add-int/lit8 v0, v0, -0x1

    goto :goto_0

    :cond_2
    if-gez v2, :cond_3

    return v1

    :cond_3
    return v2

    :cond_4
    :goto_1
    return v1
.end method

.method public final e()[B
    .locals 4

    invoke-virtual {p0}, Lcom/trilead/ssh2/crypto/SimpleDERReader;->a()B

    move-result v0

    and-int/lit16 v0, v0, 0xff

    const/4 v1, 0x4

    if-eq v0, v1, :cond_1

    const/4 v1, 0x3

    if-ne v0, v1, :cond_0

    goto :goto_0

    :cond_0
    new-instance v1, Ljava/io/IOException;

    const-string v2, "Expected DER Octetstring, but found type "

    .line 1
    invoke-static {v2, v0}, Lcom/trilead/ssh2/crypto/digest/a;->c(Ljava/lang/String;I)Ljava/lang/String;

    move-result-object v0

    .line 2
    invoke-direct {v1, v0}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    throw v1

    :cond_1
    :goto_0
    invoke-virtual {p0}, Lcom/trilead/ssh2/crypto/SimpleDERReader;->d()I

    move-result v0

    if-ltz v0, :cond_2

    .line 3
    iget v1, p0, Lcom/trilead/ssh2/crypto/SimpleDERReader;->c:I

    if-gt v0, v1, :cond_2

    .line 4
    invoke-virtual {p0, v0}, Lcom/trilead/ssh2/crypto/SimpleDERReader;->b(I)[B

    move-result-object v0

    return-object v0

    :cond_2
    new-instance v1, Ljava/io/IOException;

    const-string v2, "Illegal len in DER object ("

    const-string v3, ")"

    .line 5
    invoke-static {v2, v0, v3}, Lcom/trilead/ssh2/crypto/digest/a;->d(Ljava/lang/String;ILjava/lang/String;)Ljava/lang/String;

    move-result-object v0

    .line 6
    invoke-direct {v1, v0}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    throw v1
.end method

.method public final f()[B
    .locals 4

    invoke-virtual {p0}, Lcom/trilead/ssh2/crypto/SimpleDERReader;->a()B

    move-result v0

    and-int/lit16 v0, v0, 0xff

    const/16 v1, 0x30

    if-ne v0, v1, :cond_1

    invoke-virtual {p0}, Lcom/trilead/ssh2/crypto/SimpleDERReader;->d()I

    move-result v0

    if-ltz v0, :cond_0

    .line 1
    iget v1, p0, Lcom/trilead/ssh2/crypto/SimpleDERReader;->c:I

    if-gt v0, v1, :cond_0

    .line 2
    invoke-virtual {p0, v0}, Lcom/trilead/ssh2/crypto/SimpleDERReader;->b(I)[B

    move-result-object v0

    return-object v0

    :cond_0
    new-instance v1, Ljava/io/IOException;

    const-string v2, "Illegal len in DER object ("

    const-string v3, ")"

    .line 3
    invoke-static {v2, v0, v3}, Lcom/trilead/ssh2/crypto/digest/a;->d(Ljava/lang/String;ILjava/lang/String;)Ljava/lang/String;

    move-result-object v0

    .line 4
    invoke-direct {v1, v0}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    throw v1

    :cond_1
    new-instance v1, Ljava/io/IOException;

    const-string v2, "Expected DER Sequence, but found type "

    .line 5
    invoke-static {v2, v0}, Lcom/trilead/ssh2/crypto/digest/a;->c(Ljava/lang/String;I)Ljava/lang/String;

    move-result-object v0

    .line 6
    invoke-direct {v1, v0}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    throw v1
.end method
