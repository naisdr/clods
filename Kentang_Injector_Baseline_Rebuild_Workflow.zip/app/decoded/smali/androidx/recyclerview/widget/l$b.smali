.class public final Landroidx/recyclerview/widget/l$b;
.super Landroidx/recyclerview/widget/RecyclerView$p;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroidx/recyclerview/widget/l;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1
    name = null
.end annotation


# instance fields
.field public final synthetic a:Landroidx/recyclerview/widget/l;


# direct methods
.method public constructor <init>(Landroidx/recyclerview/widget/l;)V
    .locals 0

    iput-object p1, p0, Landroidx/recyclerview/widget/l$b;->a:Landroidx/recyclerview/widget/l;

    invoke-direct {p0}, Landroidx/recyclerview/widget/RecyclerView$p;-><init>()V

    return-void
.end method


# virtual methods
.method public final a(Landroidx/recyclerview/widget/RecyclerView;)V
    .locals 10

    iget-object v0, p0, Landroidx/recyclerview/widget/l$b;->a:Landroidx/recyclerview/widget/l;

    invoke-virtual {p1}, Landroidx/recyclerview/widget/RecyclerView;->computeHorizontalScrollOffset()I

    move-result v1

    invoke-virtual {p1}, Landroidx/recyclerview/widget/RecyclerView;->computeVerticalScrollOffset()I

    move-result p1

    iget-object v2, v0, Landroidx/recyclerview/widget/l;->s:Landroidx/recyclerview/widget/RecyclerView;

    invoke-virtual {v2}, Landroidx/recyclerview/widget/RecyclerView;->computeVerticalScrollRange()I

    move-result v2

    iget v3, v0, Landroidx/recyclerview/widget/l;->r:I

    sub-int v4, v2, v3

    const/4 v5, 0x0

    const/4 v6, 0x1

    if-lez v4, :cond_0

    iget v4, v0, Landroidx/recyclerview/widget/l;->a:I

    if-lt v3, v4, :cond_0

    const/4 v4, 0x1

    goto :goto_0

    :cond_0
    const/4 v4, 0x0

    :goto_0
    iput-boolean v4, v0, Landroidx/recyclerview/widget/l;->t:Z

    iget-object v4, v0, Landroidx/recyclerview/widget/l;->s:Landroidx/recyclerview/widget/RecyclerView;

    invoke-virtual {v4}, Landroidx/recyclerview/widget/RecyclerView;->computeHorizontalScrollRange()I

    move-result v4

    iget v7, v0, Landroidx/recyclerview/widget/l;->q:I

    sub-int v8, v4, v7

    if-lez v8, :cond_1

    iget v8, v0, Landroidx/recyclerview/widget/l;->a:I

    if-lt v7, v8, :cond_1

    const/4 v8, 0x1

    goto :goto_1

    :cond_1
    const/4 v8, 0x0

    :goto_1
    iput-boolean v8, v0, Landroidx/recyclerview/widget/l;->u:Z

    iget-boolean v9, v0, Landroidx/recyclerview/widget/l;->t:Z

    if-nez v9, :cond_2

    if-nez v8, :cond_2

    iget p1, v0, Landroidx/recyclerview/widget/l;->v:I

    if-eqz p1, :cond_6

    invoke-virtual {v0, v5}, Landroidx/recyclerview/widget/l;->j(I)V

    goto :goto_2

    :cond_2
    const/high16 v5, 0x40000000    # 2.0f

    if-eqz v9, :cond_3

    int-to-float p1, p1

    int-to-float v8, v3

    div-float v9, v8, v5

    add-float/2addr v9, p1

    mul-float v9, v9, v8

    int-to-float p1, v2

    div-float/2addr v9, p1

    float-to-int p1, v9

    iput p1, v0, Landroidx/recyclerview/widget/l;->l:I

    mul-int p1, v3, v3

    div-int/2addr p1, v2

    invoke-static {v3, p1}, Ljava/lang/Math;->min(II)I

    move-result p1

    iput p1, v0, Landroidx/recyclerview/widget/l;->k:I

    :cond_3
    iget-boolean p1, v0, Landroidx/recyclerview/widget/l;->u:Z

    if-eqz p1, :cond_4

    int-to-float p1, v1

    int-to-float v1, v7

    div-float v2, v1, v5

    add-float/2addr v2, p1

    mul-float v2, v2, v1

    int-to-float p1, v4

    div-float/2addr v2, p1

    float-to-int p1, v2

    iput p1, v0, Landroidx/recyclerview/widget/l;->o:I

    mul-int p1, v7, v7

    div-int/2addr p1, v4

    invoke-static {v7, p1}, Ljava/lang/Math;->min(II)I

    move-result p1

    iput p1, v0, Landroidx/recyclerview/widget/l;->n:I

    :cond_4
    iget p1, v0, Landroidx/recyclerview/widget/l;->v:I

    if-eqz p1, :cond_5

    if-ne p1, v6, :cond_6

    :cond_5
    invoke-virtual {v0, v6}, Landroidx/recyclerview/widget/l;->j(I)V

    :cond_6
    :goto_2
    return-void
.end method
