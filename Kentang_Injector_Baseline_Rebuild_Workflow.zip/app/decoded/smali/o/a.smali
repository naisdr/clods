.class public final Lo/a;
.super Ljava/lang/Object;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lo/a$a;
    }
.end annotation


# static fields
.field public static final s:I

.field public static final t:La/b;


# instance fields
.field public a:I

.field public final b:Lo/c;

.field public final c:Lo/d;

.field public final d:Lo/a$a;

.field public final e:Lo/a$a;

.field public f:I

.field public g:I

.field public final h:Ljava/lang/Object;

.field public i:Z

.field public final j:[B

.field public k:I

.field public l:I

.field public m:J

.field public n:I

.field public o:I

.field public p:Z

.field public final q:Ljava/lang/Object;

.field public r:Ljava/lang/Throwable;


# direct methods
.method public static constructor <clinit>()V
    .locals 3

    const-class v0, Lo/a;

    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v0}, Ljava/lang/Class;->getName()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v2, ".bufferSize"

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    const v2, 0x104000

    invoke-static {v1, v2}, Ljava/lang/Integer;->getInteger(Ljava/lang/String;I)Ljava/lang/Integer;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/Integer;->intValue()I

    move-result v1

    sput v1, Lo/a;->s:I

    .line 1
    new-instance v1, La/b;

    invoke-direct {v1, v0}, La/b;-><init>(Ljava/lang/Class;)V

    .line 2
    sput-object v1, Lo/a;->t:La/b;

    return-void
.end method

.method public constructor <init>(Lo/c;)V
    .locals 7

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    sget v0, Lo/a;->s:I

    iput v0, p0, Lo/a;->a:I

    new-instance v0, Lo/a$a;

    invoke-direct {v0, p0}, Lo/a$a;-><init>(Lo/a;)V

    iput-object v0, p0, Lo/a;->d:Lo/a$a;

    new-instance v1, Lo/a$a;

    invoke-direct {v1, p0}, Lo/a$a;-><init>(Lo/a;)V

    iput-object v1, p0, Lo/a;->e:Lo/a$a;

    const/4 v2, -0x1

    iput v2, p0, Lo/a;->f:I

    iput v2, p0, Lo/a;->g:I

    new-instance v3, Ljava/lang/Object;

    invoke-direct {v3}, Ljava/lang/Object;-><init>()V

    iput-object v3, p0, Lo/a;->h:Ljava/lang/Object;

    const/4 v3, 0x0

    iput-boolean v3, p0, Lo/a;->i:Z

    const/16 v4, 0x9

    new-array v4, v4, [B

    iput-object v4, p0, Lo/a;->j:[B

    const/4 v4, 0x1

    iput v4, p0, Lo/a;->k:I

    const-wide/16 v5, 0x0

    iput-wide v5, p0, Lo/a;->m:J

    iput v2, p0, Lo/a;->n:I

    iput v2, p0, Lo/a;->o:I

    iput-boolean v3, p0, Lo/a;->p:Z

    new-instance v2, Ljava/lang/Object;

    invoke-direct {v2}, Ljava/lang/Object;-><init>()V

    iput-object v2, p0, Lo/a;->q:Ljava/lang/Object;

    const/4 v2, 0x0

    iput-object v2, p0, Lo/a;->r:Ljava/lang/Throwable;

    iput-object p1, p0, Lo/a;->b:Lo/c;

    iget p1, p0, Lo/a;->a:I

    iput p1, p0, Lo/a;->l:I

    sget p1, Ls/i;->r:I

    add-int/lit16 p1, p1, -0x400

    iput p1, p0, Lo/a;->n:I

    new-instance p1, Lo/d;

    invoke-direct {p1, p0}, Lo/d;-><init>(Lo/a;)V

    iput-object p1, p0, Lo/a;->c:Lo/d;

    new-instance p1, Lo/b;

    invoke-direct {p1, p0, v3}, Lo/b;-><init>(Lo/a;Z)V

    iput-object p1, v0, Lo/a$a;->a:Lo/b;

    new-instance p1, Lo/b;

    invoke-direct {p1, p0, v4}, Lo/b;-><init>(Lo/a;Z)V

    iput-object p1, v1, Lo/a$a;->a:Lo/b;

    return-void
.end method


# virtual methods
.method public final declared-synchronized a()V
    .locals 1

    monitor-enter p0

    :try_start_0
    iget-object v0, p0, Lo/a;->d:Lo/a$a;

    invoke-virtual {v0}, Lo/a$a;->a()V

    iget-object v0, p0, Lo/a;->e:Lo/a$a;

    invoke-virtual {v0}, Lo/a$a;->a()V

    const/4 v0, 0x1

    iput-boolean v0, p0, Lo/a;->p:Z
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    monitor-exit p0

    return-void

    :catchall_0
    move-exception v0

    monitor-exit p0

    throw v0
.end method

.method public final b(I)V
    .locals 6

    if-gtz p1, :cond_0

    return-void

    :cond_0
    monitor-enter p0

    :try_start_0
    iget p1, p0, Lo/a;->l:I

    iget v0, p0, Lo/a;->a:I

    mul-int/lit8 v1, v0, 0x3

    const/4 v2, 0x4

    div-int/2addr v1, v2

    const/4 v3, 0x0

    if-gt p1, v1, :cond_3

    iget-object p1, p0, Lo/a;->d:Lo/a$a;

    .line 1
    iget-object p1, p1, Lo/a$a;->b:Lo/f;

    if-eqz p1, :cond_1

    invoke-virtual {p1}, Lo/f;->a()I

    move-result p1

    goto :goto_0

    :cond_1
    const/4 p1, 0x0

    :goto_0
    sub-int/2addr v0, p1

    .line 2
    iget-object p1, p0, Lo/a;->e:Lo/a$a;

    .line 3
    iget-object p1, p1, Lo/a$a;->b:Lo/f;

    if-eqz p1, :cond_2

    invoke-virtual {p1}, Lo/f;->a()I

    move-result p1

    goto :goto_1

    :cond_2
    const/4 p1, 0x0

    :goto_1
    sub-int/2addr v0, p1

    .line 4
    iget p1, p0, Lo/a;->l:I

    sub-int/2addr v0, p1

    if-lez v0, :cond_4

    add-int/2addr p1, v0

    iput p1, p0, Lo/a;->l:I

    goto :goto_2

    :cond_3
    const/4 v0, 0x0

    :cond_4
    :goto_2
    iget p1, p0, Lo/a;->g:I

    monitor-exit p0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_1

    if-lez v0, :cond_6

    sget-object v1, Lo/a;->t:La/b;

    invoke-static {v1}, Ljava/util/Objects;->requireNonNull(Ljava/lang/Object;)Ljava/lang/Object;

    iget-object v1, p0, Lo/a;->h:Ljava/lang/Object;

    monitor-enter v1

    :try_start_1
    iget-object v4, p0, Lo/a;->j:[B

    const/16 v5, 0x5d

    aput-byte v5, v4, v3

    const/4 v3, 0x1

    shr-int/lit8 v5, p1, 0x18

    int-to-byte v5, v5

    aput-byte v5, v4, v3

    const/4 v3, 0x2

    shr-int/lit8 v5, p1, 0x10

    int-to-byte v5, v5

    aput-byte v5, v4, v3

    shr-int/lit8 v3, p1, 0x8

    int-to-byte v3, v3

    const/4 v5, 0x3

    aput-byte v3, v4, v5

    int-to-byte p1, p1

    aput-byte p1, v4, v2

    const/4 p1, 0x5

    shr-int/lit8 v2, v0, 0x18

    int-to-byte v2, v2

    aput-byte v2, v4, p1

    const/4 p1, 0x6

    shr-int/lit8 v2, v0, 0x10

    int-to-byte v2, v2

    aput-byte v2, v4, p1

    const/4 p1, 0x7

    shr-int/lit8 v2, v0, 0x8

    int-to-byte v2, v2

    aput-byte v2, v4, p1

    int-to-byte p1, v0

    const/16 v0, 0x8

    aput-byte p1, v4, v0

    iget-boolean p1, p0, Lo/a;->i:Z

    if-nez p1, :cond_5

    iget-object p1, p0, Lo/a;->b:Lo/c;

    iget-object p1, p1, Lo/c;->b:Ls/i;

    invoke-virtual {p1, v4}, Ls/i;->m([B)V

    :cond_5
    monitor-exit v1

    goto :goto_3

    :catchall_0
    move-exception p1

    monitor-exit v1
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    throw p1

    :cond_6
    :goto_3
    return-void

    :catchall_1
    move-exception p1

    :try_start_2
    monitor-exit p0
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_1

    throw p1
.end method

.method public final c(Ljava/lang/String;)V
    .locals 2

    new-instance v0, Ljava/io/IOException;

    invoke-direct {v0, p1}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    iget-object p1, p0, Lo/a;->q:Ljava/lang/Object;

    monitor-enter p1

    :try_start_0
    iget-object v1, p0, Lo/a;->r:Ljava/lang/Throwable;

    if-nez v1, :cond_0

    iput-object v0, p0, Lo/a;->r:Ljava/lang/Throwable;

    :cond_0
    monitor-exit p1

    return-void

    :catchall_0
    move-exception v0

    monitor-exit p1
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    throw v0
.end method
