.class public final Lc0/h$a;
.super Ljava/lang/Object;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lc0/h;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1
    name = "a"
.end annotation

.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lc0/h$a$a;
    }
.end annotation


# instance fields
.field public a:Ljava/util/ArrayList;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/ArrayList<",
            "Lc0/h$a$a;",
            ">;"
        }
    .end annotation
.end field

.field public b:J

.field public c:Ljava/util/ArrayList;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/ArrayList<",
            "Lc0/h$a$a;",
            ">;"
        }
    .end annotation
.end field

.field public d:J


# direct methods
.method public constructor <init>()V
    .locals 6

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 1
    monitor-enter p0

    .line 2
    :try_start_0
    invoke-static {}, Landroid/os/SystemClock;->elapsedRealtime()J

    move-result-wide v0

    const-wide/32 v2, 0x493e0

    .line 3
    div-long v4, v0, v2

    mul-long v4, v4, v2

    .line 4
    iput-wide v4, p0, Lc0/h$a;->b:J

    invoke-virtual {p0}, Lc0/h$a;->b()Ljava/util/ArrayList;

    move-result-object v2

    iput-object v2, p0, Lc0/h$a;->a:Ljava/util/ArrayList;

    const-wide/16 v2, 0x3e8

    .line 5
    div-long/2addr v0, v2

    mul-long v0, v0, v2

    .line 6
    iput-wide v0, p0, Lc0/h$a;->d:J

    invoke-virtual {p0}, Lc0/h$a;->b()Ljava/util/ArrayList;

    move-result-object v0

    iput-object v0, p0, Lc0/h$a;->c:Ljava/util/ArrayList;
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 7
    monitor-exit p0

    return-void

    :catchall_0
    move-exception v0

    monitor-exit p0

    throw v0
.end method


# virtual methods
.method public final a()V
    .locals 10

    invoke-static {}, Landroid/os/SystemClock;->elapsedRealtime()J

    move-result-wide v0

    iget-wide v2, p0, Lc0/h$a;->b:J

    sub-long v5, v0, v2

    const-wide/32 v2, 0x493e0

    cmp-long v4, v5, v2

    if-ltz v4, :cond_0

    const-wide/32 v7, 0x493e0

    iget-object v9, p0, Lc0/h$a;->a:Ljava/util/ArrayList;

    move-object v4, p0

    invoke-virtual/range {v4 .. v9}, Lc0/h$a;->c(JJLjava/util/ArrayList;)V

    .line 1
    div-long v4, v0, v2

    mul-long v4, v4, v2

    .line 2
    iput-wide v4, p0, Lc0/h$a;->b:J

    :cond_0
    iget-wide v2, p0, Lc0/h$a;->d:J

    sub-long v5, v0, v2

    const-wide/16 v2, 0x3e8

    cmp-long v4, v5, v2

    if-ltz v4, :cond_1

    const-wide/16 v7, 0x3e8

    iget-object v9, p0, Lc0/h$a;->c:Ljava/util/ArrayList;

    move-object v4, p0

    invoke-virtual/range {v4 .. v9}, Lc0/h$a;->c(JJLjava/util/ArrayList;)V

    .line 3
    div-long/2addr v0, v2

    mul-long v0, v0, v2

    .line 4
    iput-wide v0, p0, Lc0/h$a;->d:J

    :cond_1
    return-void
.end method

.method public final b()Ljava/util/ArrayList;
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/ArrayList<",
            "Lc0/h$a$a;",
            ">;"
        }
    .end annotation

    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    const/4 v1, 0x0

    :goto_0
    const/16 v2, 0x120

    if-ge v1, v2, :cond_0

    new-instance v2, Lc0/h$a$a;

    invoke-direct {v2}, Lc0/h$a$a;-><init>()V

    invoke-virtual {v0, v2}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    add-int/lit8 v1, v1, 0x1

    goto :goto_0

    :cond_0
    return-object v0
.end method

.method public final c(JJLjava/util/ArrayList;)V
    .locals 8
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(JJ",
            "Ljava/util/ArrayList<",
            "Lc0/h$a$a;",
            ">;)V"
        }
    .end annotation

    const/4 v0, 0x0

    const/4 v1, 0x0

    :goto_0
    int-to-long v2, v1

    div-long v4, p1, p3

    const-wide/16 v6, 0x1

    add-long/2addr v4, v6

    cmp-long v6, v2, v4

    if-gez v6, :cond_1

    invoke-virtual {p5}, Ljava/util/ArrayList;->size()I

    move-result v2

    new-instance v3, Lc0/h$a$a;

    invoke-direct {v3}, Lc0/h$a$a;-><init>()V

    invoke-virtual {p5, v2, v3}, Ljava/util/ArrayList;->add(ILjava/lang/Object;)V

    invoke-virtual {p5}, Ljava/util/ArrayList;->size()I

    move-result v2

    const/16 v3, 0x120

    if-lt v2, v3, :cond_0

    invoke-virtual {p5, v0}, Ljava/util/ArrayList;->remove(I)Ljava/lang/Object;

    :cond_0
    add-int/lit8 v1, v1, 0x1

    goto :goto_0

    :cond_1
    return-void
.end method
