.class public final Lxyz/chz/injector/HttpService$e$a;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lxyz/chz/injector/HttpService$e;->onReceive(Landroid/content/Context;Landroid/content/Intent;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1
    name = null
.end annotation


# instance fields
.field public final synthetic a:Lxyz/chz/injector/HttpService$e;


# direct methods
.method public constructor <init>(Lxyz/chz/injector/HttpService$e;)V
    .locals 0

    iput-object p1, p0, Lxyz/chz/injector/HttpService$e$a;->a:Lxyz/chz/injector/HttpService$e;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final run()V
    .locals 1

    iget-object v0, p0, Lxyz/chz/injector/HttpService$e$a;->a:Lxyz/chz/injector/HttpService$e;

    iget-object v0, v0, Lxyz/chz/injector/HttpService$e;->a:Lxyz/chz/injector/HttpService;

    .line 1
    iget-object v0, v0, Lxyz/chz/injector/HttpService;->e:Lh0/h;

    if-eqz v0, :cond_0

    .line 2
    invoke-virtual {v0}, Lh0/h;->h()V

    :cond_0
    return-void
.end method
