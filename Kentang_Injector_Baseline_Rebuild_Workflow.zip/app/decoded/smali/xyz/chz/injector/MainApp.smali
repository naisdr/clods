.class public Lxyz/chz/injector/MainApp;
.super Landroid/app/Application;
.source "SourceFile"


# static fields
.field public static a:Lk0/a;

.field public static b:Landroid/content/SharedPreferences;


# direct methods
.method public constructor <init>()V
    .locals 0

    invoke-direct {p0}, Landroid/app/Application;-><init>()V

    return-void
.end method


# virtual methods
.method public final attachBaseContext(Landroid/content/Context;)V
    .locals 0

    invoke-super {p0, p1}, Landroid/content/ContextWrapper;->attachBaseContext(Landroid/content/Context;)V

    return-void
.end method

.method public final onConfigurationChanged(Landroid/content/res/Configuration;)V
    .locals 0

    invoke-super {p0, p1}, Landroid/app/Application;->onConfigurationChanged(Landroid/content/res/Configuration;)V

    return-void
.end method

.method public final onCreate()V
    .locals 1

    invoke-super {p0}, Landroid/app/Application;->onCreate()V

    .line 1
    sget-object v0, Lc0/a;->b:Lc0/a;

    if-nez v0, :cond_0

    new-instance v0, Lc0/a;

    invoke-direct {v0, p0}, Lc0/a;-><init>(Landroid/content/Context;)V

    sput-object v0, Lc0/a;->b:Lc0/a;

    .line 2
    :cond_0
    new-instance v0, Lf0/a;

    invoke-direct {v0, p0}, Lf0/a;-><init>(Landroid/content/Context;)V

    .line 3
    iget-object v0, v0, Lf0/a;->c:Lk0/a;

    .line 4
    sput-object v0, Lxyz/chz/injector/MainApp;->a:Lk0/a;

    invoke-static {p0}, Landroid/preference/PreferenceManager;->getDefaultSharedPreferences(Landroid/content/Context;)Landroid/content/SharedPreferences;

    move-result-object v0

    sput-object v0, Lxyz/chz/injector/MainApp;->b:Landroid/content/SharedPreferences;

    return-void
.end method
