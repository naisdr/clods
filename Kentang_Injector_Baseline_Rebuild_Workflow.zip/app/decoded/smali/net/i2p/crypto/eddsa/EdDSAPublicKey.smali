.class public Lnet/i2p/crypto/eddsa/EdDSAPublicKey;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lnet/i2p/crypto/eddsa/EdDSAKey;
.implements Ljava/security/PublicKey;


# instance fields
.field public final a:Lnet/i2p/crypto/eddsa/math/GroupElement;

.field public b:Lnet/i2p/crypto/eddsa/math/GroupElement;

.field public final c:[B

.field public final d:Lnet/i2p/crypto/eddsa/spec/EdDSAParameterSpec;


# direct methods
.method public constructor <init>(Ljava/security/spec/X509EncodedKeySpec;)V
    .locals 14

    new-instance v0, Lnet/i2p/crypto/eddsa/spec/EdDSAPublicKeySpec;

    invoke-virtual {p1}, Ljava/security/spec/X509EncodedKeySpec;->getEncoded()[B

    move-result-object p1

    const/16 v1, 0x2c

    const/16 v2, 0x8

    .line 1
    :try_start_0
    aget-byte v3, p1, v2
    :try_end_0
    .catch Ljava/lang/IndexOutOfBoundsException; {:try_start_0 .. :try_end_0} :catch_0

    const/16 v4, 0x64

    const/4 v5, 0x3

    const-string v6, "unsupported key spec"

    const/4 v7, 0x7

    const/4 v8, 0x5

    if-ne v3, v4, :cond_0

    const/16 v1, 0x2f

    goto :goto_0

    :cond_0
    const/16 v2, 0x70

    if-ne v3, v2, :cond_9

    :try_start_1
    aget-byte v2, p1, v5

    if-ne v2, v7, :cond_1

    const/16 v1, 0x2e

    const/4 v2, 0x7

    goto :goto_0

    :cond_1
    const/4 v2, 0x5

    :goto_0
    array-length v9, p1

    if-ne v9, v1, :cond_8

    const/4 v9, 0x0

    aget-byte v10, p1, v9

    const/16 v11, 0x30

    if-ne v10, v11, :cond_7

    const/4 v10, 0x1

    aget-byte v12, p1, v10

    const/4 v13, 0x2

    sub-int/2addr v1, v13

    if-ne v12, v1, :cond_7

    aget-byte v1, p1, v13

    if-ne v1, v11, :cond_7

    const/4 v1, 0x4

    aget-byte v11, p1, v5

    if-ne v11, v2, :cond_7

    aget-byte v1, p1, v1

    const/4 v11, 0x6

    if-ne v1, v11, :cond_7

    aget-byte v1, p1, v8

    if-ne v1, v5, :cond_7

    aget-byte v1, p1, v11

    const/16 v11, 0x2b

    if-ne v1, v11, :cond_7

    aget-byte v1, p1, v7

    const/16 v11, 0x65

    if-ne v1, v11, :cond_7

    const/16 v1, 0x9

    const/16 v11, 0xa

    const/16 v12, 0xb

    if-ne v3, v4, :cond_3

    aget-byte v1, p1, v1

    if-ne v1, v11, :cond_2

    aget-byte v1, p1, v11

    if-ne v1, v10, :cond_2

    const/16 v1, 0xc

    aget-byte v2, p1, v12

    if-ne v2, v10, :cond_2

    goto :goto_1

    :cond_2
    new-instance p1, Ljava/security/spec/InvalidKeySpecException;

    invoke-direct {p1, v6}, Ljava/security/spec/InvalidKeySpecException;-><init>(Ljava/lang/String;)V

    throw p1

    :cond_3
    if-ne v2, v7, :cond_5

    aget-byte v1, p1, v1

    if-ne v1, v8, :cond_4

    aget-byte v1, p1, v11

    if-nez v1, :cond_4

    const/16 v1, 0xb

    goto :goto_1

    :cond_4
    new-instance p1, Ljava/security/spec/InvalidKeySpecException;

    invoke-direct {p1, v6}, Ljava/security/spec/InvalidKeySpecException;-><init>(Ljava/lang/String;)V

    throw p1

    :cond_5
    :goto_1
    add-int/lit8 v2, v1, 0x1

    aget-byte v1, p1, v1

    if-ne v1, v5, :cond_6

    add-int/lit8 v1, v2, 0x1

    aget-byte v2, p1, v2

    const/16 v3, 0x21

    if-ne v2, v3, :cond_6

    add-int/lit8 v2, v1, 0x1

    aget-byte v1, p1, v1

    if-nez v1, :cond_6

    const/16 v1, 0x20

    new-array v3, v1, [B

    invoke-static {p1, v2, v3, v9, v1}, Ljava/lang/System;->arraycopy(Ljava/lang/Object;ILjava/lang/Object;II)V
    :try_end_1
    .catch Ljava/lang/IndexOutOfBoundsException; {:try_start_1 .. :try_end_1} :catch_0

    .line 2
    sget-object p1, Lnet/i2p/crypto/eddsa/spec/EdDSANamedCurveTable;->a:Lnet/i2p/crypto/eddsa/spec/EdDSANamedCurveSpec;

    invoke-direct {v0, v3, p1}, Lnet/i2p/crypto/eddsa/spec/EdDSAPublicKeySpec;-><init>([BLnet/i2p/crypto/eddsa/spec/EdDSAParameterSpec;)V

    invoke-direct {p0, v0}, Lnet/i2p/crypto/eddsa/EdDSAPublicKey;-><init>(Lnet/i2p/crypto/eddsa/spec/EdDSAPublicKeySpec;)V

    return-void

    .line 3
    :cond_6
    :try_start_2
    new-instance p1, Ljava/security/spec/InvalidKeySpecException;

    invoke-direct {p1, v6}, Ljava/security/spec/InvalidKeySpecException;-><init>(Ljava/lang/String;)V

    throw p1

    :cond_7
    new-instance p1, Ljava/security/spec/InvalidKeySpecException;

    invoke-direct {p1, v6}, Ljava/security/spec/InvalidKeySpecException;-><init>(Ljava/lang/String;)V

    throw p1

    :cond_8
    new-instance p1, Ljava/security/spec/InvalidKeySpecException;

    const-string v0, "invalid key spec length"

    invoke-direct {p1, v0}, Ljava/security/spec/InvalidKeySpecException;-><init>(Ljava/lang/String;)V

    throw p1

    :cond_9
    new-instance p1, Ljava/security/spec/InvalidKeySpecException;

    invoke-direct {p1, v6}, Ljava/security/spec/InvalidKeySpecException;-><init>(Ljava/lang/String;)V

    throw p1
    :try_end_2
    .catch Ljava/lang/IndexOutOfBoundsException; {:try_start_2 .. :try_end_2} :catch_0

    :catch_0
    move-exception p1

    new-instance v0, Ljava/security/spec/InvalidKeySpecException;

    invoke-direct {v0, p1}, Ljava/security/spec/InvalidKeySpecException;-><init>(Ljava/lang/Throwable;)V

    throw v0
.end method

.method public constructor <init>(Lnet/i2p/crypto/eddsa/spec/EdDSAPublicKeySpec;)V
    .locals 1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v0, 0x0

    iput-object v0, p0, Lnet/i2p/crypto/eddsa/EdDSAPublicKey;->b:Lnet/i2p/crypto/eddsa/math/GroupElement;

    .line 4
    iget-object v0, p1, Lnet/i2p/crypto/eddsa/spec/EdDSAPublicKeySpec;->a:Lnet/i2p/crypto/eddsa/math/GroupElement;

    .line 5
    iput-object v0, p0, Lnet/i2p/crypto/eddsa/EdDSAPublicKey;->a:Lnet/i2p/crypto/eddsa/math/GroupElement;

    invoke-virtual {v0}, Lnet/i2p/crypto/eddsa/math/GroupElement;->n()[B

    move-result-object v0

    iput-object v0, p0, Lnet/i2p/crypto/eddsa/EdDSAPublicKey;->c:[B

    .line 6
    iget-object p1, p1, Lnet/i2p/crypto/eddsa/spec/EdDSAPublicKeySpec;->b:Lnet/i2p/crypto/eddsa/spec/EdDSAParameterSpec;

    .line 7
    iput-object p1, p0, Lnet/i2p/crypto/eddsa/EdDSAPublicKey;->d:Lnet/i2p/crypto/eddsa/spec/EdDSAParameterSpec;

    return-void
.end method


# virtual methods
.method public final a()Lnet/i2p/crypto/eddsa/spec/EdDSAParameterSpec;
    .locals 1

    iget-object v0, p0, Lnet/i2p/crypto/eddsa/EdDSAPublicKey;->d:Lnet/i2p/crypto/eddsa/spec/EdDSAParameterSpec;

    return-object v0
.end method

.method public final equals(Ljava/lang/Object;)Z
    .locals 4

    const/4 v0, 0x1

    if-ne p1, p0, :cond_0

    return v0

    :cond_0
    instance-of v1, p1, Lnet/i2p/crypto/eddsa/EdDSAPublicKey;

    const/4 v2, 0x0

    if-nez v1, :cond_1

    return v2

    :cond_1
    check-cast p1, Lnet/i2p/crypto/eddsa/EdDSAPublicKey;

    iget-object v1, p0, Lnet/i2p/crypto/eddsa/EdDSAPublicKey;->c:[B

    .line 1
    iget-object v3, p1, Lnet/i2p/crypto/eddsa/EdDSAPublicKey;->c:[B

    .line 2
    invoke-static {v1, v3}, Ljava/util/Arrays;->equals([B[B)Z

    move-result v1

    if-eqz v1, :cond_2

    iget-object v1, p0, Lnet/i2p/crypto/eddsa/EdDSAPublicKey;->d:Lnet/i2p/crypto/eddsa/spec/EdDSAParameterSpec;

    .line 3
    iget-object p1, p1, Lnet/i2p/crypto/eddsa/EdDSAPublicKey;->d:Lnet/i2p/crypto/eddsa/spec/EdDSAParameterSpec;

    .line 4
    invoke-virtual {v1, p1}, Lnet/i2p/crypto/eddsa/spec/EdDSAParameterSpec;->equals(Ljava/lang/Object;)Z

    move-result p1

    if-eqz p1, :cond_2

    goto :goto_0

    :cond_2
    const/4 v0, 0x0

    :goto_0
    return v0
.end method

.method public final getAlgorithm()Ljava/lang/String;
    .locals 1

    const-string v0, "EdDSA"

    return-object v0
.end method

.method public final getEncoded()[B
    .locals 9

    iget-object v0, p0, Lnet/i2p/crypto/eddsa/EdDSAPublicKey;->d:Lnet/i2p/crypto/eddsa/spec/EdDSAParameterSpec;

    sget-object v1, Lnet/i2p/crypto/eddsa/spec/EdDSANamedCurveTable;->a:Lnet/i2p/crypto/eddsa/spec/EdDSANamedCurveSpec;

    invoke-virtual {v0, v1}, Lnet/i2p/crypto/eddsa/spec/EdDSAParameterSpec;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_0

    const/4 v0, 0x0

    return-object v0

    :cond_0
    iget-object v0, p0, Lnet/i2p/crypto/eddsa/EdDSAPublicKey;->c:[B

    array-length v1, v0

    const/16 v2, 0xc

    add-int/2addr v1, v2

    new-array v3, v1, [B

    const/4 v4, 0x0

    const/16 v5, 0x30

    aput-byte v5, v3, v4

    const/4 v6, 0x2

    sub-int/2addr v1, v6

    int-to-byte v1, v1

    const/4 v7, 0x1

    aput-byte v1, v3, v7

    aput-byte v5, v3, v6

    const/4 v1, 0x4

    const/4 v5, 0x3

    const/4 v6, 0x5

    aput-byte v6, v3, v5

    const/4 v8, 0x6

    aput-byte v8, v3, v1

    aput-byte v5, v3, v6

    const/4 v1, 0x7

    const/16 v6, 0x2b

    aput-byte v6, v3, v8

    const/16 v6, 0x8

    const/16 v8, 0x65

    aput-byte v8, v3, v1

    const/16 v1, 0x9

    const/16 v8, 0x70

    aput-byte v8, v3, v6

    const/16 v6, 0xa

    aput-byte v5, v3, v1

    const/16 v1, 0xb

    array-length v5, v0

    add-int/2addr v5, v7

    int-to-byte v5, v5

    aput-byte v5, v3, v6

    aput-byte v4, v3, v1

    array-length v1, v0

    invoke-static {v0, v4, v3, v2, v1}, Ljava/lang/System;->arraycopy(Ljava/lang/Object;ILjava/lang/Object;II)V

    return-object v3
.end method

.method public final getFormat()Ljava/lang/String;
    .locals 1

    const-string v0, "X.509"

    return-object v0
.end method

.method public final hashCode()I
    .locals 1

    iget-object v0, p0, Lnet/i2p/crypto/eddsa/EdDSAPublicKey;->c:[B

    invoke-static {v0}, Ljava/util/Arrays;->hashCode([B)I

    move-result v0

    return v0
.end method
