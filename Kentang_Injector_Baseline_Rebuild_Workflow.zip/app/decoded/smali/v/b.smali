.class public final Lv/b;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lv/a;


# instance fields
.field public a:Ljava/io/InputStream;

.field public b:Ljava/io/OutputStream;


# direct methods
.method public constructor <init>()V
    .locals 1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v0, 0x0

    iput-object v0, p0, Lv/b;->a:Ljava/io/InputStream;

    iput-object v0, p0, Lv/b;->b:Ljava/io/OutputStream;

    return-void
.end method

.method public constructor <init>(Ljava/io/InputStream;Ljava/io/OutputStream;)V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lv/b;->a:Ljava/io/InputStream;

    iput-object p2, p0, Lv/b;->b:Ljava/io/OutputStream;

    return-void
.end method


# virtual methods
.method public final a(Ljava/net/Socket;)Lv/a;
    .locals 9

    new-instance v0, Ljava/io/PushbackInputStream;

    invoke-virtual {p1}, Ljava/net/Socket;->getInputStream()Ljava/io/InputStream;

    move-result-object v1

    invoke-direct {v0, v1}, Ljava/io/PushbackInputStream;-><init>(Ljava/io/InputStream;)V

    invoke-virtual {p1}, Ljava/net/Socket;->getOutputStream()Ljava/io/OutputStream;

    move-result-object p1

    invoke-virtual {v0}, Ljava/io/PushbackInputStream;->read()I

    move-result v1

    const/4 v2, 0x0

    const/4 v3, 0x5

    if-ne v1, v3, :cond_5

    .line 1
    invoke-virtual {v0}, Ljava/io/InputStream;->read()I

    move-result v1

    const/4 v3, 0x0

    if-gtz v1, :cond_0

    goto :goto_3

    :cond_0
    new-array v4, v1, [B

    const/4 v5, 0x2

    new-array v5, v5, [B

    fill-array-data v5, :array_0

    const/4 v6, 0x0

    :goto_0
    if-ge v6, v1, :cond_1

    sub-int v7, v1, v6

    invoke-virtual {v0, v4, v6, v7}, Ljava/io/InputStream;->read([BII)I

    move-result v7

    add-int/2addr v6, v7

    goto :goto_0

    :cond_1
    const/4 v6, 0x0

    :goto_1
    const/4 v7, 0x1

    if-ge v6, v1, :cond_3

    aget-byte v8, v4, v6

    if-nez v8, :cond_2

    int-to-byte v1, v3

    aput-byte v1, v5, v7

    const/4 v3, 0x1

    goto :goto_2

    :cond_2
    add-int/lit8 v6, v6, 0x1

    goto :goto_1

    :cond_3
    :goto_2
    invoke-virtual {p1, v5}, Ljava/io/OutputStream;->write([B)V

    :goto_3
    if-nez v3, :cond_4

    return-object v2

    .line 2
    :cond_4
    new-instance v1, Lv/b;

    invoke-direct {v1, v0, p1}, Lv/b;-><init>(Ljava/io/InputStream;Ljava/io/OutputStream;)V

    return-object v1

    :cond_5
    return-object v2

    nop

    :array_0
    .array-data 1
        0x5t
        -0x1t
    .end array-data
.end method
