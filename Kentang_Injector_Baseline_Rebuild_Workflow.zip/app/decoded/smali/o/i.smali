.class public final Lo/i;
.super Ljava/lang/Thread;
.source "SourceFile"


# static fields
.field public static final e:La/b;


# instance fields
.field public a:Lo/a;

.field public b:Ljava/lang/String;

.field public c:I

.field public d:Ljava/net/Socket;


# direct methods
.method public static constructor <clinit>()V
    .locals 2

    const-class v0, Lo/i;

    .line 1
    new-instance v1, La/b;

    invoke-direct {v1, v0}, La/b;-><init>(Ljava/lang/Class;)V

    .line 2
    sput-object v1, Lo/i;->e:La/b;

    return-void
.end method

.method public constructor <init>(Lo/a;)V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Thread;-><init>()V

    iput-object p1, p0, Lo/i;->a:Lo/a;

    const/4 p1, 0x0

    iput-object p1, p0, Lo/i;->b:Ljava/lang/String;

    const/4 p1, 0x0

    iput p1, p0, Lo/i;->c:I

    sget-object p1, Lo/i;->e:La/b;

    invoke-static {p1}, Ljava/util/Objects;->requireNonNull(Ljava/lang/Object;)Ljava/lang/Object;

    return-void
.end method


# virtual methods
.method public final run()V
    .locals 18

    move-object/from16 v1, p0

    :try_start_0
    iget-object v0, v1, Lo/i;->a:Lo/a;

    iget-object v2, v0, Lo/a;->b:Lo/c;

    invoke-virtual {v2, v0}, Lo/c;->s(Lo/a;)V

    new-instance v0, Ljava/net/Socket;

    iget-object v2, v1, Lo/i;->b:Ljava/lang/String;

    iget v3, v1, Lo/i;->c:I

    invoke-direct {v0, v2, v3}, Ljava/net/Socket;-><init>(Ljava/lang/String;I)V

    iput-object v0, v1, Lo/i;->d:Ljava/net/Socket;

    new-instance v2, Lo/l;

    iget-object v5, v1, Lo/i;->a:Lo/a;

    const/4 v6, 0x0

    const/4 v7, 0x0

    .line 1
    iget-object v3, v5, Lo/a;->d:Lo/a$a;

    iget-object v8, v3, Lo/a$a;->a:Lo/b;

    .line 2
    invoke-virtual {v0}, Ljava/net/Socket;->getOutputStream()Ljava/io/OutputStream;

    move-result-object v9

    const-string v10, "RemoteToLocal"

    move-object v4, v2

    invoke-direct/range {v4 .. v10}, Lo/l;-><init>(Lo/a;Lo/l;Ljava/net/Socket;Ljava/io/InputStream;Ljava/io/OutputStream;Ljava/lang/String;)V

    new-instance v0, Lo/l;

    iget-object v12, v1, Lo/i;->a:Lo/a;

    const/4 v13, 0x0

    const/4 v14, 0x0

    iget-object v3, v1, Lo/i;->d:Ljava/net/Socket;

    invoke-virtual {v3}, Ljava/net/Socket;->getInputStream()Ljava/io/InputStream;

    move-result-object v15

    iget-object v3, v1, Lo/i;->a:Lo/a;

    .line 3
    iget-object v3, v3, Lo/a;->c:Lo/d;

    const-string v17, "LocalToRemote"

    move-object v11, v0

    move-object/from16 v16, v3

    .line 4
    invoke-direct/range {v11 .. v17}, Lo/l;-><init>(Lo/a;Lo/l;Ljava/net/Socket;Ljava/io/InputStream;Ljava/io/OutputStream;Ljava/lang/String;)V

    const/4 v3, 0x1

    invoke-virtual {v2, v3}, Ljava/lang/Thread;->setDaemon(Z)V

    invoke-virtual {v2}, Ljava/lang/Thread;->start()V

    invoke-virtual {v0}, Lo/l;->run()V

    :goto_0
    invoke-virtual {v2}, Ljava/lang/Thread;->isAlive()Z

    move-result v0
    :try_end_0
    .catch Ljava/io/IOException; {:try_start_0 .. :try_end_0} :catch_1

    if-eqz v0, :cond_0

    :try_start_1
    invoke-virtual {v2}, Ljava/lang/Thread;->join()V
    :try_end_1
    .catch Ljava/lang/InterruptedException; {:try_start_1 .. :try_end_1} :catch_0
    .catch Ljava/io/IOException; {:try_start_1 .. :try_end_1} :catch_1

    goto :goto_0

    :catch_0
    :try_start_2
    new-instance v0, Ljava/io/InterruptedIOException;

    invoke-direct {v0}, Ljava/io/InterruptedIOException;-><init>()V

    throw v0

    :cond_0
    iget-object v0, v1, Lo/i;->a:Lo/a;

    iget-object v2, v0, Lo/a;->b:Lo/c;

    const-string v3, "EOF on both streams reached."

    invoke-virtual {v2, v0, v3}, Lo/c;->e(Lo/a;Ljava/lang/String;)V

    iget-object v0, v1, Lo/i;->d:Ljava/net/Socket;

    invoke-virtual {v0}, Ljava/net/Socket;->close()V
    :try_end_2
    .catch Ljava/io/IOException; {:try_start_2 .. :try_end_2} :catch_1

    goto :goto_1

    :catch_1
    move-exception v0

    sget-object v2, Lo/i;->e:La/b;

    invoke-static {v2}, Ljava/util/Objects;->requireNonNull(Ljava/lang/Object;)Ljava/lang/Object;

    .line 5
    invoke-static {v0}, Ljava/util/Objects;->toString(Ljava/lang/Object;)Ljava/lang/String;

    .line 6
    :try_start_3
    iget-object v2, v1, Lo/i;->a:Lo/a;

    iget-object v3, v2, Lo/a;->b:Lo/c;

    new-instance v4, Ljava/lang/StringBuilder;

    invoke-direct {v4}, Ljava/lang/StringBuilder;-><init>()V

    const-string v5, "IOException in proxy code ("

    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v4, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v0, ")"

    invoke-virtual {v4, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v3, v2, v0}, Lo/c;->e(Lo/a;Ljava/lang/String;)V
    :try_end_3
    .catch Ljava/io/IOException; {:try_start_3 .. :try_end_3} :catch_2

    :catch_2
    :try_start_4
    iget-object v0, v1, Lo/i;->d:Ljava/net/Socket;

    if-eqz v0, :cond_1

    invoke-virtual {v0}, Ljava/net/Socket;->close()V
    :try_end_4
    .catch Ljava/io/IOException; {:try_start_4 .. :try_end_4} :catch_3

    :catch_3
    :cond_1
    :goto_1
    return-void
.end method
