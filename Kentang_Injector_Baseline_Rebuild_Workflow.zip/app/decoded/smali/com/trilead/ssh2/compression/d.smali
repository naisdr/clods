.class public Lcom/trilead/ssh2/compression/d;
.super Lcom/trilead/ssh2/compression/c;
.source "SourceFile"


# direct methods
.method public constructor <init>()V
    .locals 0

    invoke-direct {p0}, Lcom/trilead/ssh2/compression/c;-><init>()V

    return-void
.end method
