.class public final Lxyz/chz/injector/HttpService$e;
.super Landroid/content/BroadcastReceiver;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lxyz/chz/injector/HttpService;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1
    name = null
.end annotation


# instance fields
.field public final synthetic a:Lxyz/chz/injector/HttpService;


# direct methods
.method public constructor <init>(Lxyz/chz/injector/HttpService;)V
    .locals 0

    iput-object p1, p0, Lxyz/chz/injector/HttpService$e;->a:Lxyz/chz/injector/HttpService;

    invoke-direct {p0}, Landroid/content/BroadcastReceiver;-><init>()V

    return-void
.end method


# virtual methods
.method public final onReceive(Landroid/content/Context;Landroid/content/Intent;)V
    .locals 0

    invoke-virtual {p2}, Landroid/content/Intent;->getAction()Ljava/lang/String;

    move-result-object p1

    if-nez p1, :cond_0

    return-void

    :cond_0
    sget-object p2, Lxyz/chz/injector/HttpService;->n:Ljava/lang/String;

    invoke-virtual {p1, p2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p2

    if-eqz p2, :cond_1

    new-instance p1, Ljava/lang/Thread;

    new-instance p2, Lxyz/chz/injector/HttpService$e$a;

    invoke-direct {p2, p0}, Lxyz/chz/injector/HttpService$e$a;-><init>(Lxyz/chz/injector/HttpService$e;)V

    invoke-direct {p1, p2}, Ljava/lang/Thread;-><init>(Ljava/lang/Runnable;)V

    invoke-virtual {p1}, Ljava/lang/Thread;->start()V

    goto :goto_0

    :cond_1
    sget-object p2, Lxyz/chz/injector/HttpService;->o:Ljava/lang/String;

    invoke-virtual {p1, p2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p1

    if-eqz p1, :cond_2

    iget-object p1, p0, Lxyz/chz/injector/HttpService$e;->a:Lxyz/chz/injector/HttpService;

    invoke-virtual {p1}, Lxyz/chz/injector/HttpService;->b()V

    :cond_2
    :goto_0
    return-void
.end method
