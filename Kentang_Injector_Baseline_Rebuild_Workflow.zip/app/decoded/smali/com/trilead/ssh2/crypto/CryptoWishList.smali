.class public Lcom/trilead/ssh2/crypto/CryptoWishList;
.super Ljava/lang/Object;
.source "SourceFile"


# instance fields
.field public a:[Ljava/lang/String;

.field public b:[Ljava/lang/String;

.field public c:[Ljava/lang/String;

.field public d:[Ljava/lang/String;

.field public e:[Ljava/lang/String;

.field public f:[Ljava/lang/String;


# direct methods
.method public constructor <init>()V
    .locals 4

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    sget-object v0, Ls/a;->q:La/b;

    const-string v0, "diffie-hellman-group-exchange-sha256"

    const-string v1, "diffie-hellman-group-exchange-sha1"

    const-string v2, "diffie-hellman-group14-sha1"

    const-string v3, "diffie-hellman-group1-sha1"

    .line 1
    filled-new-array {v0, v1, v2, v3}, [Ljava/lang/String;

    move-result-object v0

    .line 2
    iput-object v0, p0, Lcom/trilead/ssh2/crypto/CryptoWishList;->a:[Ljava/lang/String;

    .line 3
    sget-object v0, Ls/a;->r:Ljava/util/ArrayList;

    invoke-virtual {v0}, Ljava/util/ArrayList;->size()I

    move-result v1

    new-array v1, v1, [Ljava/lang/String;

    invoke-virtual {v0, v1}, Ljava/util/ArrayList;->toArray([Ljava/lang/Object;)[Ljava/lang/Object;

    move-result-object v0

    check-cast v0, [Ljava/lang/String;

    .line 4
    iput-object v0, p0, Lcom/trilead/ssh2/crypto/CryptoWishList;->b:[Ljava/lang/String;

    invoke-static {}, Lcom/trilead/ssh2/crypto/cipher/BlockCipherFactory;->c()[Ljava/lang/String;

    move-result-object v0

    iput-object v0, p0, Lcom/trilead/ssh2/crypto/CryptoWishList;->c:[Ljava/lang/String;

    invoke-static {}, Lcom/trilead/ssh2/crypto/cipher/BlockCipherFactory;->c()[Ljava/lang/String;

    move-result-object v0

    iput-object v0, p0, Lcom/trilead/ssh2/crypto/CryptoWishList;->d:[Ljava/lang/String;

    invoke-static {}, Lcom/trilead/ssh2/crypto/digest/MessageMac;->f()[Ljava/lang/String;

    move-result-object v0

    iput-object v0, p0, Lcom/trilead/ssh2/crypto/CryptoWishList;->e:[Ljava/lang/String;

    invoke-static {}, Lcom/trilead/ssh2/crypto/digest/MessageMac;->f()[Ljava/lang/String;

    move-result-object v0

    iput-object v0, p0, Lcom/trilead/ssh2/crypto/CryptoWishList;->f:[Ljava/lang/String;

    invoke-static {}, Lcom/trilead/ssh2/compression/a;->a()[Ljava/lang/String;

    invoke-static {}, Lcom/trilead/ssh2/compression/a;->a()[Ljava/lang/String;

    return-void
.end method
