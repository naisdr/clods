.class public final Lo/e$a;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lo/e;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1
    name = "a"
.end annotation


# instance fields
.field public a:Lv/a;

.field public b:Ljava/net/Socket;

.field public c:Ljava/io/InputStream;

.field public d:Ljava/io/OutputStream;

.field public e:Lu/b;

.field public final synthetic f:Lo/e;


# direct methods
.method public constructor <init>(Lo/e;Lv/a;Ljava/net/Socket;)V
    .locals 0

    iput-object p1, p0, Lo/e$a;->f:Lo/e;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p2, p0, Lo/e$a;->a:Lv/a;

    iput-object p3, p0, Lo/e$a;->b:Ljava/net/Socket;

    const-string p2, "DynamicAcceptRunnable"

    invoke-virtual {p1, p2}, Ljava/lang/Thread;->setName(Ljava/lang/String;)V

    return-void
.end method


# virtual methods
.method public final a()V
    .locals 13

    iget-object v0, p0, Lo/e$a;->b:Ljava/net/Socket;

    const v1, 0x57e40

    invoke-virtual {v0, v1}, Ljava/net/Socket;->setSoTimeout(I)V

    const/4 v0, 0x0

    :try_start_0
    iget-object v1, p0, Lo/e$a;->a:Lv/a;

    iget-object v2, p0, Lo/e$a;->b:Ljava/net/Socket;

    check-cast v1, Lv/b;

    invoke-virtual {v1, v2}, Lv/b;->a(Ljava/net/Socket;)Lv/a;

    move-result-object v1

    iput-object v1, p0, Lo/e$a;->a:Lv/a;
    :try_end_0
    .catch Ljava/io/IOException; {:try_start_0 .. :try_end_0} :catch_3

    if-nez v1, :cond_0

    .line 1
    sget-object v0, Lo/e;->d:La/b;

    .line 2
    invoke-static {v0}, Ljava/util/Objects;->requireNonNull(Ljava/lang/Object;)Ljava/lang/Object;

    return-void

    :cond_0
    check-cast v1, Lv/b;

    .line 3
    iget-object v2, v1, Lv/b;->a:Ljava/io/InputStream;

    .line 4
    iput-object v2, p0, Lo/e$a;->c:Ljava/io/InputStream;

    .line 5
    iget-object v1, v1, Lv/b;->b:Ljava/io/OutputStream;

    .line 6
    iput-object v1, p0, Lo/e$a;->d:Ljava/io/OutputStream;

    .line 7
    instance-of v1, v2, Ljava/io/PushbackInputStream;

    if-eqz v1, :cond_1

    check-cast v2, Ljava/io/PushbackInputStream;

    goto :goto_0

    :cond_1
    new-instance v1, Ljava/io/PushbackInputStream;

    invoke-direct {v1, v2}, Ljava/io/PushbackInputStream;-><init>(Ljava/io/InputStream;)V

    move-object v2, v1

    :goto_0
    invoke-virtual {v2}, Ljava/io/PushbackInputStream;->read()I

    move-result v1

    invoke-virtual {v2, v1}, Ljava/io/PushbackInputStream;->unread(I)V

    const/4 v3, 0x5

    const/4 v4, 0x1

    if-ne v1, v3, :cond_4

    new-instance v1, Lu/b;

    const/4 v3, 0x0

    invoke-direct {v1, v2}, Lu/b;-><init>(Ljava/io/InputStream;)V

    .line 8
    iput-object v1, p0, Lo/e$a;->e:Lu/b;

    .line 9
    iget-object v2, p0, Lo/e$a;->a:Lv/a;

    invoke-static {v2}, Ljava/util/Objects;->requireNonNull(Ljava/lang/Object;)Ljava/lang/Object;

    iget v2, v1, Lu/a;->d:I

    if-ne v2, v4, :cond_3

    .line 10
    new-instance v2, Lu/b;

    invoke-direct {v2, v3, v0, v3}, Lu/b;-><init>(ILjava/net/InetAddress;I)V

    iget-object v0, p0, Lo/e$a;->d:Ljava/io/OutputStream;

    invoke-virtual {v2, v0}, Lu/b;->a(Ljava/io/OutputStream;)V

    iget-object v0, v1, Lu/a;->e:Ljava/lang/String;

    iget-object v2, v1, Lu/a;->a:Ljava/net/InetAddress;

    if-eqz v2, :cond_2

    invoke-virtual {v2}, Ljava/net/InetAddress;->getHostAddress()Ljava/lang/String;

    move-result-object v0

    :cond_2
    :try_start_1
    iget-object v2, p0, Lo/e$a;->f:Lo/e;

    .line 11
    iget-object v2, v2, Lo/e;->a:Lo/c;

    .line 12
    iget v1, v1, Lu/a;->c:I

    const-string v5, "127.0.0.1"

    invoke-virtual {v2, v0, v1, v5, v3}, Lo/c;->p(Ljava/lang/String;ILjava/lang/String;I)Lo/a;

    move-result-object v0
    :try_end_1
    .catch Ljava/io/IOException; {:try_start_1 .. :try_end_1} :catch_1

    :try_start_2
    new-instance v1, Lo/l;

    const/4 v8, 0x0

    const/4 v9, 0x0

    .line 13
    iget-object v2, v0, Lo/a;->d:Lo/a$a;

    iget-object v10, v2, Lo/a$a;->a:Lo/b;

    .line 14
    iget-object v11, p0, Lo/e$a;->d:Ljava/io/OutputStream;

    const-string v12, "RemoteToLocal"

    move-object v6, v1

    move-object v7, v0

    invoke-direct/range {v6 .. v12}, Lo/l;-><init>(Lo/a;Lo/l;Ljava/net/Socket;Ljava/io/InputStream;Ljava/io/OutputStream;Ljava/lang/String;)V

    new-instance v2, Lo/l;

    iget-object v9, p0, Lo/e$a;->b:Ljava/net/Socket;

    iget-object v10, p0, Lo/e$a;->c:Ljava/io/InputStream;

    iget-object v11, v0, Lo/a;->c:Lo/d;

    const-string v12, "LocalToRemote"

    move-object v6, v2

    move-object v7, v0

    move-object v8, v1

    invoke-direct/range {v6 .. v12}, Lo/l;-><init>(Lo/a;Lo/l;Ljava/net/Socket;Ljava/io/InputStream;Ljava/io/OutputStream;Ljava/lang/String;)V
    :try_end_2
    .catch Ljava/io/IOException; {:try_start_2 .. :try_end_2} :catch_0

    invoke-virtual {v1, v4}, Ljava/lang/Thread;->setDaemon(Z)V

    invoke-virtual {v2, v4}, Ljava/lang/Thread;->setDaemon(Z)V

    invoke-virtual {v1}, Ljava/lang/Thread;->start()V

    invoke-virtual {v2}, Ljava/lang/Thread;->start()V

    goto :goto_1

    :catch_0
    move-exception v1

    :try_start_3
    iget-object v2, v0, Lo/a;->b:Lo/c;

    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    const-string v4, "Weird error during creation of StreamForwarder ("

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v3, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v1, ")"

    invoke-virtual {v3, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v2, v0, v1}, Lo/c;->e(Lo/a;Ljava/lang/String;)V

    goto :goto_1

    :catch_1
    iget-object v0, p0, Lo/e$a;->b:Ljava/net/Socket;

    invoke-virtual {v0}, Ljava/net/Socket;->close()V
    :try_end_3
    .catch Ljava/io/IOException; {:try_start_3 .. :try_end_3} :catch_2

    :catch_2
    :goto_1
    return-void

    .line 15
    :cond_3
    new-instance v0, Lu/c;

    const/4 v1, 0x7

    invoke-direct {v0, v1}, Lu/c;-><init>(I)V

    throw v0

    .line 16
    :cond_4
    new-instance v0, Lu/c;

    invoke-direct {v0, v4}, Lu/c;-><init>(I)V

    throw v0

    :catch_3
    move-exception v1

    .line 17
    sget-object v2, Lo/e;->d:La/b;

    .line 18
    invoke-static {v2}, Ljava/util/Objects;->requireNonNull(Ljava/lang/Object;)Ljava/lang/Object;

    invoke-virtual {v1}, Ljava/lang/Throwable;->printStackTrace()V

    iput-object v0, p0, Lo/e$a;->a:Lv/a;

    return-void
.end method

.method public final run()V
    .locals 3

    :try_start_0
    invoke-virtual {p0}, Lo/e$a;->a()V
    :try_end_0
    .catch Ljava/io/IOException; {:try_start_0 .. :try_end_0} :catch_1
    .catch Ljava/lang/Error; {:try_start_0 .. :try_end_0} :catch_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    iget-object v0, p0, Lo/e$a;->a:Lv/a;

    if-eqz v0, :cond_0

    invoke-static {v0}, Ljava/util/Objects;->requireNonNull(Ljava/lang/Object;)Ljava/lang/Object;

    :cond_0
    iget-object v0, p0, Lo/e$a;->f:Lo/e;

    .line 1
    :goto_0
    iget-object v0, v0, Lo/e;->b:Ljava/util/concurrent/Semaphore;

    .line 2
    invoke-virtual {v0}, Ljava/util/concurrent/Semaphore;->release()V

    goto :goto_3

    :catchall_0
    move-exception v0

    goto :goto_4

    :catch_0
    :try_start_1
    invoke-static {}, Ljava/lang/System;->gc()V
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    iget-object v0, p0, Lo/e$a;->a:Lv/a;

    if-eqz v0, :cond_1

    iget-object v0, p0, Lo/e$a;->a:Lv/a;

    invoke-static {v0}, Ljava/util/Objects;->requireNonNull(Ljava/lang/Object;)Ljava/lang/Object;

    :cond_1
    iget-object v0, p0, Lo/e$a;->f:Lo/e;

    goto :goto_0

    :catch_1
    move-exception v0

    :try_start_2
    instance-of v1, v0, Lu/c;

    const/4 v2, 0x1

    if-eqz v1, :cond_2

    check-cast v0, Lu/c;

    iget v0, v0, Lu/c;->b:I

    goto :goto_1

    :cond_2
    instance-of v1, v0, Ljava/net/NoRouteToHostException;

    if-eqz v1, :cond_3

    const/4 v0, 0x4

    goto :goto_1

    :cond_3
    instance-of v1, v0, Ljava/net/ConnectException;

    if-eqz v1, :cond_4

    const/4 v0, 0x5

    goto :goto_1

    :cond_4
    instance-of v0, v0, Ljava/io/InterruptedIOException;

    if-eqz v0, :cond_5

    const/4 v0, 0x6

    goto :goto_1

    :cond_5
    const/4 v0, 0x1

    :goto_1
    const/16 v1, 0x8

    if-gt v0, v1, :cond_7

    if-gez v0, :cond_6

    goto :goto_2

    :cond_6
    move v2, v0

    .line 3
    :cond_7
    :goto_2
    new-instance v0, Lu/b;

    invoke-direct {v0, v2}, Lu/b;-><init>(I)V
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_0

    :try_start_3
    iget-object v1, p0, Lo/e$a;->d:Ljava/io/OutputStream;

    invoke-virtual {v0, v1}, Lu/b;->a(Ljava/io/OutputStream;)V
    :try_end_3
    .catch Ljava/io/IOException; {:try_start_3 .. :try_end_3} :catch_2
    .catchall {:try_start_3 .. :try_end_3} :catchall_0

    .line 4
    :catch_2
    iget-object v0, p0, Lo/e$a;->a:Lv/a;

    if-eqz v0, :cond_8

    invoke-static {v0}, Ljava/util/Objects;->requireNonNull(Ljava/lang/Object;)Ljava/lang/Object;

    :cond_8
    iget-object v0, p0, Lo/e$a;->f:Lo/e;

    goto :goto_0

    :goto_3
    return-void

    :goto_4
    iget-object v1, p0, Lo/e$a;->a:Lv/a;

    if-eqz v1, :cond_9

    invoke-static {v1}, Ljava/util/Objects;->requireNonNull(Ljava/lang/Object;)Ljava/lang/Object;

    :cond_9
    iget-object v1, p0, Lo/e$a;->f:Lo/e;

    .line 5
    iget-object v1, v1, Lo/e;->b:Ljava/util/concurrent/Semaphore;

    .line 6
    invoke-virtual {v1}, Ljava/util/concurrent/Semaphore;->release()V

    throw v0
.end method
