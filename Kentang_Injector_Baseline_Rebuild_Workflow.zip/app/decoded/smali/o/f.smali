.class public final Lo/f;
.super Ljava/lang/Object;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lo/f$a;,
        Lo/f$b;
    }
.end annotation


# instance fields
.field public final a:Ljava/lang/Object;

.field public b:I

.field public c:I

.field public final d:I

.field public e:Lo/f$b;

.field public f:Lo/f$b;

.field public g:Z


# direct methods
.method public constructor <init>(Ljava/lang/Object;I)V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    if-nez p1, :cond_0

    move-object p1, p0

    :cond_0
    iput-object p1, p0, Lo/f;->a:Ljava/lang/Object;

    iput p2, p0, Lo/f;->c:I

    const/16 p1, 0x800

    iput p1, p0, Lo/f;->d:I

    .line 1
    new-instance p2, Lo/f$a;

    invoke-direct {p2, p1}, Lo/f$a;-><init>(I)V

    .line 2
    new-instance p1, Lo/f$b;

    invoke-direct {p1, p0, p2}, Lo/f$b;-><init>(Lo/f;Lo/f$a;)V

    iput-object p1, p0, Lo/f;->e:Lo/f$b;

    new-instance p1, Lo/f$b;

    invoke-direct {p1, p0, p2}, Lo/f$b;-><init>(Lo/f;Lo/f$a;)V

    iput-object p1, p0, Lo/f;->f:Lo/f$b;

    return-void
.end method


# virtual methods
.method public final a()I
    .locals 2

    iget-object v0, p0, Lo/f;->a:Ljava/lang/Object;

    monitor-enter v0

    :try_start_0
    iget v1, p0, Lo/f;->b:I

    monitor-exit v0

    return v1

    :catchall_0
    move-exception v1

    monitor-exit v0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    throw v1
.end method

.method public final b([BII)V
    .locals 8

    :goto_0
    if-lez p3, :cond_2

    iget-object v0, p0, Lo/f;->a:Ljava/lang/Object;

    monitor-enter v0

    .line 1
    :goto_1
    :try_start_0
    iget v1, p0, Lo/f;->c:I

    invoke-virtual {p0}, Lo/f;->a()I

    move-result v2

    sub-int/2addr v1, v2

    const/4 v2, 0x0

    invoke-static {v2, v1}, Ljava/lang/Math;->max(II)I

    move-result v1

    .line 2
    invoke-static {p3, v1}, Ljava/lang/Math;->min(II)I

    move-result v1

    if-nez v1, :cond_0

    iget-object v1, p0, Lo/f;->a:Ljava/lang/Object;

    invoke-virtual {v1}, Ljava/lang/Object;->wait()V

    goto :goto_1

    :cond_0
    iget-object v2, p0, Lo/f;->f:Lo/f$b;

    invoke-static {v2}, Ljava/util/Objects;->requireNonNull(Ljava/lang/Object;)Ljava/lang/Object;

    move v4, p2

    move v3, v1

    :goto_2
    if-lez v3, :cond_1

    .line 3
    invoke-virtual {v2}, Lo/f$b;->a()I

    move-result v5

    invoke-static {v3, v5}, Ljava/lang/Math;->min(II)I

    move-result v5

    iget-object v6, v2, Lo/f$b;->a:Lo/f$a;

    iget-object v6, v6, Lo/f$a;->a:[B

    iget v7, v2, Lo/f$b;->b:I

    invoke-static {p1, v4, v6, v7, v5}, Ljava/lang/System;->arraycopy(Ljava/lang/Object;ILjava/lang/Object;II)V

    iget v6, v2, Lo/f$b;->b:I

    add-int/2addr v6, v5

    iput v6, v2, Lo/f$b;->b:I

    sub-int/2addr v3, v5

    add-int/2addr v4, v5

    goto :goto_2

    :cond_1
    add-int/2addr p2, v1

    sub-int/2addr p3, v1

    .line 4
    iget v2, p0, Lo/f;->b:I

    add-int/2addr v2, v1

    iput v2, p0, Lo/f;->b:I

    iget-object v1, p0, Lo/f;->a:Ljava/lang/Object;

    invoke-virtual {v1}, Ljava/lang/Object;->notifyAll()V

    monitor-exit v0

    goto :goto_0

    :catchall_0
    move-exception p1

    monitor-exit v0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    throw p1

    :cond_2
    return-void
.end method
