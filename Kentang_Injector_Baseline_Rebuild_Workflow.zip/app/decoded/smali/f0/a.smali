.class public final Lf0/a;
.super Ljava/lang/Object;
.source "SourceFile"


# static fields
.field public static d:Lm0/b;


# instance fields
.field public a:Landroid/content/Context;

.field public b:Landroid/content/SharedPreferences;

.field public c:Lk0/a;


# direct methods
.method public static constructor <clinit>()V
    .locals 2

    const-string v0, " "

    .line 1
    invoke-virtual {v0}, Ljava/lang/String;->toCharArray()[C

    move-result-object v0

    .line 2
    new-instance v1, Lm0/b;

    invoke-direct {v1, v0}, Lm0/b;-><init>([C)V

    .line 3
    sput-object v1, Lf0/a;->d:Lm0/b;

    return-void
.end method

.method public constructor <init>(Landroid/content/Context;)V
    .locals 1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lf0/a;->a:Landroid/content/Context;

    invoke-static {p1}, Landroid/preference/PreferenceManager;->getDefaultSharedPreferences(Landroid/content/Context;)Landroid/content/SharedPreferences;

    move-result-object p1

    iput-object p1, p0, Lf0/a;->b:Landroid/content/SharedPreferences;

    iget-object p1, p0, Lf0/a;->a:Landroid/content/Context;

    sget-object v0, Lf0/a;->d:Lm0/b;

    invoke-static {p1, v0}, Lk0/a;->d(Landroid/content/Context;Lm0/b;)Lk0/a;

    move-result-object p1

    iput-object p1, p0, Lf0/a;->c:Lk0/a;

    return-void
.end method


# virtual methods
.method public final a()I
    .locals 3

    iget-object v0, p0, Lf0/a;->b:Landroid/content/SharedPreferences;

    const-string v1, "numberMaxThreadSocks"

    const-string v2, "0th"

    invoke-interface {v0, v1, v2}, Landroid/content/SharedPreferences;->getString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    if-eqz v0, :cond_1

    invoke-virtual {v0}, Ljava/lang/String;->isEmpty()Z

    move-result v1

    if-eqz v1, :cond_0

    goto :goto_0

    :cond_0
    move-object v2, v0

    :cond_1
    :goto_0
    const-string v0, "th"

    const-string v1, ""

    invoke-virtual {v2, v0, v1}, Ljava/lang/String;->replace(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Ljava/lang/String;

    move-result-object v0

    invoke-static {v0}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I

    move-result v0

    return v0
.end method

.method public final b(Ljava/lang/String;)Ljava/lang/String;
    .locals 2

    const-string v0, "sshPortaLocal"

    invoke-virtual {p1, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_0

    const-string v0, ""

    goto :goto_0

    :cond_0
    const-string v0, "1080"

    :goto_0
    iget-object v1, p0, Lf0/a;->c:Lk0/a;

    invoke-virtual {v1, p1, v0}, Lk0/a;->getString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    return-object p1
.end method
