.class public final enum Lr/f$b$e;
.super Lr/f$b;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lr/f$b;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x4011
    name = null
.end annotation


# direct methods
.method public varargs constructor <init>([Ljava/lang/String;)V
    .locals 8

    const-string v1, "AES256_CBC"

    const/4 v2, 0x4

    const/16 v3, 0x20

    const/16 v4, 0x10

    const-string v5, "aes-256-cbc"

    const/4 v7, 0x0

    move-object v0, p0

    move-object v6, p1

    invoke-direct/range {v0 .. v7}, Lr/f$b;-><init>(Ljava/lang/String;IIILjava/lang/String;[Ljava/lang/String;Lr/f$a;)V

    return-void
.end method


# virtual methods
.method public final a([B[B)Lcom/trilead/ssh2/crypto/cipher/BlockCipher;
    .locals 2

    const-string v0, "aes256-cbc"

    const/4 v1, 0x0

    invoke-static {v0, v1, p1, p2}, Lcom/trilead/ssh2/crypto/cipher/BlockCipherFactory;->a(Ljava/lang/String;Z[B[B)Lcom/trilead/ssh2/crypto/cipher/BlockCipher;

    move-result-object p1

    return-object p1
.end method
