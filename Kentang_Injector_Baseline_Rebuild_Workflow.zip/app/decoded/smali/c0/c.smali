.class public final synthetic Lc0/c;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Landroid/content/DialogInterface$OnClickListener;


# instance fields
.field public final synthetic a:Lc0/g;


# direct methods
.method public synthetic constructor <init>(Lc0/g;)V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lc0/c;->a:Lc0/g;

    return-void
.end method


# virtual methods
.method public final onClick(Landroid/content/DialogInterface;I)V
    .locals 8

    iget-object p1, p0, Lc0/c;->a:Lc0/g;

    .line 1
    sget-object p2, Lc0/g;->s:Lj0/c;

    iget-object v0, p1, Lc0/g;->f:Lj0/b;

    .line 2
    iget-object v0, v0, Lj0/b;->b:Ljava/lang/String;

    .line 3
    invoke-virtual {p2}, Lj0/c;->b()Ljava/util/List;

    move-result-object v1

    move-object v2, v1

    check-cast v2, Ljava/util/ArrayList;

    const/4 v3, 0x0

    invoke-virtual {v2, v3}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v4

    invoke-virtual {v0, v4}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v4

    const/4 v5, 0x1

    if-nez v4, :cond_1

    invoke-virtual {v2, v0}, Ljava/util/ArrayList;->contains(Ljava/lang/Object;)Z

    move-result v4

    if-nez v4, :cond_0

    goto/16 :goto_0

    :cond_0
    new-instance v4, Lj0/b;

    iget-object v6, p2, Lj0/c;->a:Lk0/a;

    invoke-direct {v4, v6, v0}, Lj0/b;-><init>(Landroid/content/SharedPreferences;Ljava/lang/String;)V

    .line 4
    invoke-static {v6}, Ljava/util/Objects;->requireNonNull(Ljava/lang/Object;)Ljava/lang/Object;

    .line 5
    new-instance v7, Lk0/a$a;

    invoke-direct {v7, v6}, Lk0/a$a;-><init>(Lk0/a;)V

    const-string v6, "sshok"

    .line 6
    invoke-virtual {v4, v6}, Lj0/b;->f(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v6

    invoke-virtual {v7, v6}, Lk0/a$a;->remove(Ljava/lang/String;)Landroid/content/SharedPreferences$Editor;

    const-string v6, "payloads"

    invoke-virtual {v4, v6}, Lj0/b;->f(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v6

    invoke-virtual {v7, v6}, Lk0/a$a;->remove(Ljava/lang/String;)Landroid/content/SharedPreferences$Editor;

    const-string v6, "proxys"

    invoke-virtual {v4, v6}, Lj0/b;->f(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v6

    invoke-virtual {v7, v6}, Lk0/a$a;->remove(Ljava/lang/String;)Landroid/content/SharedPreferences$Editor;

    const-string v6, "snis"

    invoke-virtual {v4, v6}, Lj0/b;->f(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v6

    invoke-virtual {v7, v6}, Lk0/a$a;->remove(Ljava/lang/String;)Landroid/content/SharedPreferences$Editor;

    const-string v6, "dnsd"

    invoke-virtual {v4, v6}, Lj0/b;->f(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v6

    invoke-virtual {v7, v6}, Lk0/a$a;->remove(Ljava/lang/String;)Landroid/content/SharedPreferences$Editor;

    const-string v6, "udpgws"

    invoke-virtual {v4, v6}, Lj0/b;->f(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v6

    invoke-virtual {v7, v6}, Lk0/a$a;->remove(Ljava/lang/String;)Landroid/content/SharedPreferences$Editor;

    const-string v6, "autopings"

    invoke-virtual {v4, v6}, Lj0/b;->f(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v6

    invoke-virtual {v7, v6}, Lk0/a$a;->remove(Ljava/lang/String;)Landroid/content/SharedPreferences$Editor;

    const-string v6, "isFook"

    invoke-virtual {v4, v6}, Lj0/b;->f(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v6

    invoke-virtual {v7, v6}, Lk0/a$a;->remove(Ljava/lang/String;)Landroid/content/SharedPreferences$Editor;

    const-string v6, "forcing"

    invoke-virtual {v4, v6}, Lj0/b;->f(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v7, v4}, Lk0/a$a;->remove(Ljava/lang/String;)Landroid/content/SharedPreferences$Editor;

    invoke-virtual {v7}, Lk0/a$a;->apply()V

    .line 7
    invoke-virtual {v2, v3}, Ljava/util/ArrayList;->remove(I)Ljava/lang/Object;

    invoke-virtual {v2, v0}, Ljava/util/ArrayList;->remove(Ljava/lang/Object;)Z

    iget-object p2, p2, Lj0/c;->a:Lk0/a;

    invoke-static {p2}, Ljava/util/Objects;->requireNonNull(Ljava/lang/Object;)Ljava/lang/Object;

    .line 8
    iget-object v0, p2, Lk0/a;->b:Landroid/content/SharedPreferences;

    .line 9
    invoke-interface {v0}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object v0

    .line 10
    invoke-static {v1}, Lj0/e;->c(Ljava/util/List;)Ljava/lang/String;

    move-result-object v1

    const-string v2, "profile"

    .line 11
    invoke-virtual {p2, v2}, Lk0/a;->c(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    .line 12
    invoke-static {p2, v1}, Lk0/a;->a(Lk0/a;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    invoke-interface {v0, v2, v1}, Landroid/content/SharedPreferences$Editor;->putString(Ljava/lang/String;Ljava/lang/String;)Landroid/content/SharedPreferences$Editor;

    const-string v1, "last_profile"

    .line 13
    invoke-virtual {p2, v1}, Lk0/a;->c(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p2

    .line 14
    invoke-interface {v0, p2}, Landroid/content/SharedPreferences$Editor;->remove(Ljava/lang/String;)Landroid/content/SharedPreferences$Editor;

    .line 15
    invoke-interface {v0}, Landroid/content/SharedPreferences$Editor;->apply()V

    const/4 p2, 0x1

    goto :goto_1

    :cond_1
    :goto_0
    const/4 p2, 0x0

    :goto_1
    if-nez p2, :cond_2

    .line 16
    invoke-virtual {p1}, Landroid/app/Fragment;->getActivity()Landroid/app/Activity;

    move-result-object p2

    const v0, 0x7f0b000d

    new-array v1, v5, [Ljava/lang/Object;

    iget-object v2, p1, Lc0/g;->f:Lj0/b;

    .line 17
    iget-object v2, v2, Lj0/b;->b:Ljava/lang/String;

    aput-object v2, v1, v3

    .line 18
    invoke-virtual {p1, v0, v1}, Landroid/app/Fragment;->getString(I[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object p1

    invoke-static {p2, p1, v3}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    move-result-object p1

    invoke-virtual {p1}, Landroid/widget/Toast;->show()V

    goto :goto_2

    :cond_2
    sget-object p2, Lc0/g;->s:Lj0/c;

    invoke-virtual {p2}, Lj0/c;->a()Lj0/b;

    move-result-object p2

    iput-object p2, p1, Lc0/g;->f:Lj0/b;

    invoke-virtual {p1}, Lc0/g;->c()V

    :goto_2
    return-void
.end method
