.class public final La0/a;
.super Ljava/lang/Object;
.source "SourceFile"


# static fields
.field public static h:Ljava/util/Hashtable;


# instance fields
.field public a:Lx/a;

.field public b:I

.field public c:I

.field public d:Lb0/a;

.field public e:Lb0/a;

.field public f:[B

.field public g:[B


# direct methods
.method public static constructor <clinit>()V
    .locals 5

    new-instance v0, Ljava/util/Hashtable;

    invoke-direct {v0}, Ljava/util/Hashtable;-><init>()V

    sput-object v0, La0/a;->h:Ljava/util/Hashtable;

    const/16 v1, 0x20

    .line 1
    invoke-static {v1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v1

    const-string v2, "GOST3411"

    .line 2
    invoke-virtual {v0, v2, v1}, Ljava/util/Hashtable;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    sget-object v0, La0/a;->h:Ljava/util/Hashtable;

    const/16 v1, 0x10

    .line 3
    invoke-static {v1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v1

    const-string v2, "MD2"

    .line 4
    invoke-virtual {v0, v2, v1}, Ljava/util/Hashtable;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    sget-object v0, La0/a;->h:Ljava/util/Hashtable;

    const/16 v1, 0x40

    .line 5
    invoke-static {v1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v2

    const-string v3, "MD4"

    .line 6
    invoke-virtual {v0, v3, v2}, Ljava/util/Hashtable;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    sget-object v0, La0/a;->h:Ljava/util/Hashtable;

    .line 7
    invoke-static {v1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v2

    const-string v3, "MD5"

    .line 8
    invoke-virtual {v0, v3, v2}, Ljava/util/Hashtable;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    sget-object v0, La0/a;->h:Ljava/util/Hashtable;

    .line 9
    invoke-static {v1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v2

    const-string v3, "RIPEMD128"

    .line 10
    invoke-virtual {v0, v3, v2}, Ljava/util/Hashtable;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    sget-object v0, La0/a;->h:Ljava/util/Hashtable;

    .line 11
    invoke-static {v1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v2

    const-string v3, "RIPEMD160"

    .line 12
    invoke-virtual {v0, v3, v2}, Ljava/util/Hashtable;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    sget-object v0, La0/a;->h:Ljava/util/Hashtable;

    .line 13
    invoke-static {v1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v2

    const-string v3, "SHA-1"

    .line 14
    invoke-virtual {v0, v3, v2}, Ljava/util/Hashtable;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    sget-object v0, La0/a;->h:Ljava/util/Hashtable;

    .line 15
    invoke-static {v1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v2

    const-string v3, "SHA-224"

    .line 16
    invoke-virtual {v0, v3, v2}, Ljava/util/Hashtable;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    sget-object v0, La0/a;->h:Ljava/util/Hashtable;

    .line 17
    invoke-static {v1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v2

    const-string v3, "SHA-256"

    .line 18
    invoke-virtual {v0, v3, v2}, Ljava/util/Hashtable;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    sget-object v0, La0/a;->h:Ljava/util/Hashtable;

    const/16 v2, 0x80

    .line 19
    invoke-static {v2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v3

    const-string v4, "SHA-384"

    .line 20
    invoke-virtual {v0, v4, v3}, Ljava/util/Hashtable;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    sget-object v0, La0/a;->h:Ljava/util/Hashtable;

    .line 21
    invoke-static {v2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v2

    const-string v3, "SHA-512"

    .line 22
    invoke-virtual {v0, v3, v2}, Ljava/util/Hashtable;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    sget-object v0, La0/a;->h:Ljava/util/Hashtable;

    .line 23
    invoke-static {v1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v2

    const-string v3, "Tiger"

    .line 24
    invoke-virtual {v0, v3, v2}, Ljava/util/Hashtable;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    sget-object v0, La0/a;->h:Ljava/util/Hashtable;

    .line 25
    invoke-static {v1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v1

    const-string v2, "Whirlpool"

    .line 26
    invoke-virtual {v0, v2, v1}, Ljava/util/Hashtable;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    return-void
.end method

.method public constructor <init>(Lx/a;)V
    .locals 2

    .line 1
    instance-of v0, p1, Lx/b;

    if-eqz v0, :cond_0

    move-object v0, p1

    check-cast v0, Lx/b;

    invoke-interface {v0}, Lx/b;->h()I

    move-result v0

    goto :goto_0

    :cond_0
    sget-object v0, La0/a;->h:Ljava/util/Hashtable;

    invoke-interface {p1}, Lx/a;->g()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/util/Hashtable;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/lang/Integer;

    if-eqz v0, :cond_1

    invoke-virtual {v0}, Ljava/lang/Integer;->intValue()I

    move-result v0

    .line 2
    :goto_0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, La0/a;->a:Lx/a;

    invoke-interface {p1}, Lx/a;->c()I

    move-result p1

    iput p1, p0, La0/a;->b:I

    iput v0, p0, La0/a;->c:I

    new-array v1, v0, [B

    iput-object v1, p0, La0/a;->f:[B

    add-int/2addr v0, p1

    new-array p1, v0, [B

    iput-object p1, p0, La0/a;->g:[B

    return-void

    .line 3
    :cond_1
    new-instance v0, Ljava/lang/IllegalArgumentException;

    const-string v1, "unknown digest passed: "

    .line 4
    invoke-static {v1}, Lcom/trilead/ssh2/crypto/digest/a;->e(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    .line 5
    invoke-interface {p1}, Lx/a;->g()Ljava/lang/String;

    move-result-object p1

    invoke-virtual {v1, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    invoke-direct {v0, p1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw v0
.end method


# virtual methods
.method public final a([B)I
    .locals 5

    iget-object v0, p0, La0/a;->a:Lx/a;

    iget-object v1, p0, La0/a;->g:[B

    iget v2, p0, La0/a;->c:I

    invoke-interface {v0, v1, v2}, Lx/a;->f([BI)I

    iget-object v0, p0, La0/a;->e:Lb0/a;

    const/4 v1, 0x0

    if-eqz v0, :cond_0

    iget-object v2, p0, La0/a;->a:Lx/a;

    check-cast v2, Lb0/a;

    invoke-interface {v2, v0}, Lb0/a;->b(Lb0/a;)V

    iget-object v0, p0, La0/a;->a:Lx/a;

    iget-object v2, p0, La0/a;->g:[B

    iget v3, p0, La0/a;->c:I

    invoke-interface {v0}, Lx/a;->c()I

    move-result v4

    invoke-interface {v0, v2, v3, v4}, Lx/a;->d([BII)V

    goto :goto_0

    :cond_0
    iget-object v0, p0, La0/a;->a:Lx/a;

    iget-object v2, p0, La0/a;->g:[B

    array-length v3, v2

    invoke-interface {v0, v2, v1, v3}, Lx/a;->d([BII)V

    :goto_0
    iget-object v0, p0, La0/a;->a:Lx/a;

    invoke-interface {v0, p1, v1}, Lx/a;->f([BI)I

    move-result p1

    iget v0, p0, La0/a;->c:I

    :goto_1
    iget-object v2, p0, La0/a;->g:[B

    array-length v3, v2

    if-ge v0, v3, :cond_1

    aput-byte v1, v2, v0

    add-int/lit8 v0, v0, 0x1

    goto :goto_1

    :cond_1
    iget-object v0, p0, La0/a;->d:Lb0/a;

    if-eqz v0, :cond_2

    iget-object v1, p0, La0/a;->a:Lx/a;

    check-cast v1, Lb0/a;

    invoke-interface {v1, v0}, Lb0/a;->b(Lb0/a;)V

    goto :goto_2

    :cond_2
    iget-object v0, p0, La0/a;->a:Lx/a;

    iget-object v2, p0, La0/a;->f:[B

    array-length v3, v2

    invoke-interface {v0, v2, v1, v3}, Lx/a;->d([BII)V

    :goto_2
    return p1
.end method

.method public final b([BI)V
    .locals 2

    iget-object v0, p0, La0/a;->a:Lx/a;

    const/4 v1, 0x0

    invoke-interface {v0, p1, v1, p2}, Lx/a;->d([BII)V

    return-void
.end method
