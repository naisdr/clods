# Kentang Injector 3.0 — feature patch (implementation components)

This ZIP contains actual Java implementation components for persistent usage accumulation,
a per-session SQLite history table, and a simple dashboard layout.

## Included
- `UsageStore.java`: persistent counters and session history.
- `activity_dashboard.xml`: minimal dashboard layout with START/STOP and usage fields.

## Integration status
This is a feature patch, NOT a complete installable APK and NOT yet wired into the reconstructed
obfuscated APK. The existing app is built from APKTool Smali output and has no original Gradle
project. Java sources cannot simply be copied into that decoded tree; they must be compiled to DEX
and integrated, and the existing PreferenceFragment/`isRunning` event flow must be connected to
the new controls. Do not replace your working APK with an APK built from this patch alone.

## Required integration points
1. Add `UsageStore` to the app source set and compile it into DEX.
2. In the actual VPN-start success path, call `startSession(context)`.
3. While the VPN is active, call `sample(context)` on a periodic worker/timer and update UI.
4. On VPN stop/disconnect, call `sample(context)` then `stopSession(context)`.
5. Bind dashboard START/STOP to the app's existing `isRunning` preference/service flow.
6. Render `history(limit)` in a History screen.

## Accuracy note
The implementation uses Android `TrafficStats` per-UID counters. Depending on Android version and
VPN transport implementation, UID counters may count the app's tunnel transport sockets and may
not exactly equal inner VPN payload bytes. Validate against the TUN interface or tunnel counters
before presenting as exact VPN-only traffic. Counter resets/reboots are guarded against negative
deltas; stored totals and session rows remain in app-private SQLite/preferences.
