.class public final Ln/a;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ls/d;


# static fields
.field public static final h:Ljava/lang/String;

.field public static final i:J


# instance fields
.field public a:Ls/i;

.field public b:Ljava/util/Vector;

.field public c:Ljava/util/Vector;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/Vector<",
            "Lm/d;",
            ">;"
        }
    .end annotation
.end field

.field public d:Z

.field public e:[Ljava/lang/String;

.field public f:Z

.field public g:Z


# direct methods
.method public static constructor <clinit>()V
    .locals 2

    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const-class v1, Ln/a;

    invoke-virtual {v1}, Ljava/lang/Class;->getName()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v1, ".timeout"

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    sput-object v0, Ln/a;->h:Ljava/lang/String;

    const-string v1, "120000"

    invoke-static {v0, v1}, Ljava/lang/System;->getProperty(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    invoke-static {v0}, Ljava/lang/Long;->valueOf(Ljava/lang/String;)Ljava/lang/Long;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/Long;->longValue()J

    move-result-wide v0

    sput-wide v0, Ln/a;->i:J

    return-void
.end method

.method public constructor <init>(Ls/i;)V
    .locals 2

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    new-instance v0, Ljava/util/Vector;

    invoke-direct {v0}, Ljava/util/Vector;-><init>()V

    iput-object v0, p0, Ln/a;->b:Ljava/util/Vector;

    new-instance v0, Ljava/util/Vector;

    invoke-direct {v0}, Ljava/util/Vector;-><init>()V

    iput-object v0, p0, Ln/a;->c:Ljava/util/Vector;

    const/4 v0, 0x0

    iput-boolean v0, p0, Ln/a;->d:Z

    new-array v1, v0, [Ljava/lang/String;

    iput-object v1, p0, Ln/a;->e:[Ljava/lang/String;

    iput-boolean v0, p0, Ln/a;->f:Z

    iput-boolean v0, p0, Ln/a;->g:Z

    iput-object p1, p0, Ln/a;->a:Ls/i;

    return-void
.end method


# virtual methods
.method public final a(Ljava/lang/Throwable;)V
    .locals 1

    iget-object p1, p0, Ln/a;->b:Ljava/util/Vector;

    monitor-enter p1

    const/4 v0, 0x1

    :try_start_0
    iput-boolean v0, p0, Ln/a;->d:Z

    iget-object v0, p0, Ln/a;->b:Ljava/util/Vector;

    invoke-virtual {v0}, Ljava/lang/Object;->notifyAll()V

    monitor-exit p1

    return-void

    :catchall_0
    move-exception v0

    monitor-exit p1
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    throw v0
.end method

.method public final b([BI)V
    .locals 3

    iget-object v0, p0, Ln/a;->b:Ljava/util/Vector;

    monitor-enter v0

    :try_start_0
    new-array v1, p2, [B

    const/4 v2, 0x0

    invoke-static {p1, v2, v1, v2, p2}, Ljava/lang/System;->arraycopy(Ljava/lang/Object;ILjava/lang/Object;II)V

    iget-object p1, p0, Ln/a;->b:Ljava/util/Vector;

    invoke-virtual {p1, v1}, Ljava/util/Vector;->addElement(Ljava/lang/Object;)V

    iget-object p1, p0, Ln/a;->b:Ljava/util/Vector;

    invoke-virtual {p1}, Ljava/lang/Object;->notifyAll()V

    iget-object p1, p0, Ln/a;->b:Ljava/util/Vector;

    invoke-virtual {p1}, Ljava/util/Vector;->size()I

    move-result p1

    const/4 p2, 0x5

    if-gt p1, p2, :cond_0

    monitor-exit v0

    return-void

    :cond_0
    const/4 p1, 0x1

    iput-boolean p1, p0, Ln/a;->d:Z

    new-instance p1, Ljava/io/IOException;

    const-string p2, "Error, peer is flooding us with authentication packets."

    invoke-direct {p1, p2}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    throw p1

    :catchall_0
    move-exception p1

    monitor-exit v0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    throw p1
.end method

.method public final c(Ljava/lang/String;Ljava/lang/String;)Z
    .locals 6

    const-string v0, "password"

    const/4 v1, 0x0

    :try_start_0
    invoke-virtual {p0, p1}, Ln/a;->f(Ljava/lang/String;)Z

    invoke-virtual {p0, v0}, Ln/a;->g(Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_4

    const-string v2, "ssh-connection"

    iget-object v3, p0, Ln/a;->a:Ls/i;

    .line 1
    new-instance v4, Lq/b;

    invoke-direct {v4}, Lq/b;-><init>()V

    const/16 v5, 0x32

    invoke-virtual {v4, v5}, Lq/b;->d(I)V

    invoke-virtual {v4, p1}, Lq/b;->h(Ljava/lang/String;)V

    invoke-virtual {v4, v2}, Lq/b;->h(Ljava/lang/String;)V

    invoke-virtual {v4, v0}, Lq/b;->h(Ljava/lang/String;)V

    invoke-virtual {v4, v1}, Lq/b;->c(Z)V

    invoke-virtual {v4, p2}, Lq/b;->h(Ljava/lang/String;)V

    invoke-virtual {v4}, Lq/b;->a()[B

    move-result-object p1

    .line 2
    invoke-virtual {v3, p1}, Ls/i;->m([B)V

    invoke-virtual {p0}, Ln/a;->e()[B

    move-result-object p1

    aget-byte p2, p1, v1

    const/16 v0, 0x34

    if-ne p2, v0, :cond_0

    const/4 p1, 0x1

    iput-boolean p1, p0, Ln/a;->f:Z

    iget-object p2, p0, Ln/a;->a:Ls/i;

    invoke-virtual {p2, p0}, Ls/i;->j(Ls/d;)V

    return p1

    :cond_0
    aget-byte p2, p1, v1
    :try_end_0
    .catch Ljava/io/IOException; {:try_start_0 .. :try_end_0} :catch_0

    const-string v0, ")"

    const/16 v2, 0x33

    if-ne p2, v2, :cond_3

    :try_start_1
    array-length p2, p1

    .line 3
    new-array v3, p2, [B

    invoke-static {p1, v1, v3, v1, p2}, Ljava/lang/System;->arraycopy(Ljava/lang/Object;ILjava/lang/Object;II)V

    new-instance v3, Lq/c;

    invoke-direct {v3, p1, p2}, Lq/c;-><init>([BI)V

    invoke-virtual {v3}, Lq/c;->b()I

    move-result p1

    if-ne p1, v2, :cond_2

    invoke-virtual {v3}, Lq/c;->f()[Ljava/lang/String;

    move-result-object p1

    invoke-virtual {v3}, Lq/c;->a()Z

    .line 4
    iget p2, v3, Lq/c;->c:I

    iget v0, v3, Lq/c;->b:I

    sub-int/2addr p2, v0

    if-nez p2, :cond_1

    .line 5
    iput-object p1, p0, Ln/a;->e:[Ljava/lang/String;

    return v1

    .line 6
    :cond_1
    new-instance p1, Ljava/io/IOException;

    const-string p2, "Padding in SSH_MSG_USERAUTH_FAILURE packet!"

    invoke-direct {p1, p2}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    throw p1

    :cond_2
    new-instance p2, Ljava/io/IOException;

    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const-string v3, "This is not a SSH_MSG_USERAUTH_FAILURE! ("

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2, p1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    invoke-direct {p2, p1}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    throw p2

    .line 7
    :cond_3
    new-instance p2, Ljava/io/IOException;

    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const-string v3, "Unexpected SSH message (type "

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    aget-byte p1, p1, v1

    invoke-virtual {v2, p1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    invoke-direct {p2, p1}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    throw p2

    :cond_4
    new-instance p1, Ljava/io/IOException;

    const-string p2, "Authentication method password not supported by the server at this stage."

    invoke-direct {p1, p2}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    throw p1
    :try_end_1
    .catch Ljava/io/IOException; {:try_start_1 .. :try_end_1} :catch_0

    :catch_0
    move-exception p1

    iget-object p2, p0, Ln/a;->a:Ls/i;

    invoke-virtual {p2, p1, v1}, Ls/i;->b(Ljava/lang/Throwable;Z)V

    new-instance p2, Ljava/io/IOException;

    const-string v0, "Password authentication failed."

    invoke-direct {p2, v0, p1}, Ljava/io/IOException;-><init>(Ljava/lang/String;Ljava/lang/Throwable;)V

    throw p2
.end method

.method public final d(Ljava/lang/String;[CLjava/lang/String;Ljava/security/SecureRandom;)Z
    .locals 9

    const-string v0, "ssh-connection"

    const-string v1, "publickey"

    const/4 v2, 0x0

    :try_start_0
    invoke-virtual {p0, p1}, Ln/a;->f(Ljava/lang/String;)Z

    invoke-virtual {p0, v1}, Ln/a;->g(Ljava/lang/String;)Z

    move-result v3

    if-eqz v3, :cond_8

    invoke-static {p2, p3}, Lcom/trilead/ssh2/crypto/PEMDecoder;->a([CLjava/lang/String;)Ljava/security/KeyPair;

    move-result-object p2

    invoke-virtual {p2}, Ljava/security/KeyPair;->getPrivate()Ljava/security/PrivateKey;

    move-result-object p3

    .line 1
    sget-object v3, Lr/e;->a:Ljava/util/Collection;

    .line 2
    invoke-interface {v3}, Ljava/util/Collection;->iterator()Ljava/util/Iterator;

    move-result-object v3

    :cond_0
    invoke-interface {v3}, Ljava/util/Iterator;->hasNext()Z

    move-result v4

    const/4 v5, 0x1

    if-eqz v4, :cond_2

    invoke-interface {v3}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v4

    check-cast v4, Lr/d;

    invoke-virtual {v4, p3}, Lr/d;->f(Ljava/security/PrivateKey;)Z

    move-result v6

    if-eqz v6, :cond_0

    invoke-virtual {p2}, Ljava/security/KeyPair;->getPublic()Ljava/security/PublicKey;

    move-result-object p3

    invoke-virtual {v4, p3}, Lr/d;->c(Ljava/security/PublicKey;)[B

    move-result-object p3

    new-instance v3, Lq/b;

    invoke-direct {v3}, Lq/b;-><init>()V

    iget-object v6, p0, Ln/a;->a:Ls/i;

    .line 3
    iget-object v6, v6, Ls/i;->l:Ls/a;

    iget-object v6, v6, Ls/a;->d:[B

    .line 4
    array-length v7, v6

    invoke-virtual {v3, v6, v2, v7}, Lq/b;->i([BII)V

    const/16 v6, 0x32

    invoke-virtual {v3, v6}, Lq/b;->d(I)V

    invoke-virtual {v3, p1}, Lq/b;->h(Ljava/lang/String;)V

    invoke-virtual {v3, v0}, Lq/b;->h(Ljava/lang/String;)V

    invoke-virtual {v3, v1}, Lq/b;->h(Ljava/lang/String;)V

    invoke-virtual {v3, v5}, Lq/b;->c(Z)V

    .line 5
    iget-object v7, v4, Lr/d;->b:Ljava/lang/String;

    .line 6
    invoke-virtual {v3, v7}, Lq/b;->h(Ljava/lang/String;)V

    array-length v7, p3

    invoke-virtual {v3, p3, v2, v7}, Lq/b;->i([BII)V

    invoke-virtual {v3}, Lq/b;->a()[B

    move-result-object v3

    invoke-virtual {p2}, Ljava/security/KeyPair;->getPrivate()Ljava/security/PrivateKey;

    move-result-object p2
    :try_end_0
    .catch Ljava/io/IOException; {:try_start_0 .. :try_end_0} :catch_1

    .line 7
    :try_start_1
    iget-object v7, v4, Lr/d;->d:Ljava/security/Provider;

    if-nez v7, :cond_1

    iget-object v7, v4, Lr/d;->a:Ljava/lang/String;

    invoke-static {v7}, Ljava/security/Signature;->getInstance(Ljava/lang/String;)Ljava/security/Signature;

    move-result-object v7

    goto :goto_0

    :cond_1
    iget-object v8, v4, Lr/d;->a:Ljava/lang/String;

    invoke-static {v8, v7}, Ljava/security/Signature;->getInstance(Ljava/lang/String;Ljava/security/Provider;)Ljava/security/Signature;

    move-result-object v7

    :goto_0
    invoke-virtual {v7, p2, p4}, Ljava/security/Signature;->initSign(Ljava/security/PrivateKey;Ljava/security/SecureRandom;)V

    invoke-virtual {v7, v3}, Ljava/security/Signature;->update([B)V

    invoke-virtual {v7}, Ljava/security/Signature;->sign()[B

    move-result-object p2
    :try_end_1
    .catch Ljava/security/GeneralSecurityException; {:try_start_1 .. :try_end_1} :catch_0
    .catch Ljava/io/IOException; {:try_start_1 .. :try_end_1} :catch_1

    .line 8
    :try_start_2
    invoke-virtual {v4, p2}, Lr/d;->d([B)[B

    move-result-object p2

    .line 9
    iget-object p4, v4, Lr/d;->b:Ljava/lang/String;

    .line 10
    iget-object v3, p0, Ln/a;->a:Ls/i;

    .line 11
    new-instance v4, Lq/b;

    invoke-direct {v4}, Lq/b;-><init>()V

    invoke-virtual {v4, v6}, Lq/b;->d(I)V

    invoke-virtual {v4, p1}, Lq/b;->h(Ljava/lang/String;)V

    invoke-virtual {v4, v0}, Lq/b;->h(Ljava/lang/String;)V

    invoke-virtual {v4, v1}, Lq/b;->h(Ljava/lang/String;)V

    invoke-virtual {v4, v5}, Lq/b;->c(Z)V

    invoke-virtual {v4, p4}, Lq/b;->h(Ljava/lang/String;)V

    array-length p1, p3

    invoke-virtual {v4, p3, v2, p1}, Lq/b;->i([BII)V

    array-length p1, p2

    invoke-virtual {v4, p2, v2, p1}, Lq/b;->i([BII)V

    invoke-virtual {v4}, Lq/b;->a()[B

    move-result-object p1

    .line 12
    invoke-virtual {v3, p1}, Ls/i;->m([B)V

    const/4 p1, 0x1

    goto :goto_1

    :catch_0
    move-exception p1

    .line 13
    new-instance p2, Ljava/io/IOException;

    const-string p3, "Could not generate signature"

    invoke-direct {p2, p3, p1}, Ljava/io/IOException;-><init>(Ljava/lang/String;Ljava/lang/Throwable;)V

    throw p2

    :cond_2
    const/4 p1, 0x0

    :goto_1
    if-eqz p1, :cond_7

    .line 14
    invoke-virtual {p0}, Ln/a;->e()[B

    move-result-object p1

    aget-byte p2, p1, v2

    const/16 p3, 0x34

    if-ne p2, p3, :cond_3

    iput-boolean v5, p0, Ln/a;->f:Z

    iget-object p1, p0, Ln/a;->a:Ls/i;

    invoke-virtual {p1, p0}, Ls/i;->j(Ls/d;)V

    return v5

    :cond_3
    aget-byte p2, p1, v2
    :try_end_2
    .catch Ljava/io/IOException; {:try_start_2 .. :try_end_2} :catch_1

    const-string p3, ")"

    const/16 p4, 0x33

    if-ne p2, p4, :cond_6

    :try_start_3
    array-length p2, p1

    .line 15
    new-array v0, p2, [B

    invoke-static {p1, v2, v0, v2, p2}, Ljava/lang/System;->arraycopy(Ljava/lang/Object;ILjava/lang/Object;II)V

    new-instance v0, Lq/c;

    invoke-direct {v0, p1, p2}, Lq/c;-><init>([BI)V

    invoke-virtual {v0}, Lq/c;->b()I

    move-result p1

    if-ne p1, p4, :cond_5

    invoke-virtual {v0}, Lq/c;->f()[Ljava/lang/String;

    move-result-object p1

    invoke-virtual {v0}, Lq/c;->a()Z

    .line 16
    iget p2, v0, Lq/c;->c:I

    iget p3, v0, Lq/c;->b:I

    sub-int/2addr p2, p3

    if-nez p2, :cond_4

    .line 17
    iput-object p1, p0, Ln/a;->e:[Ljava/lang/String;

    return v2

    .line 18
    :cond_4
    new-instance p1, Ljava/io/IOException;

    const-string p2, "Padding in SSH_MSG_USERAUTH_FAILURE packet!"

    invoke-direct {p1, p2}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    throw p1

    :cond_5
    new-instance p2, Ljava/io/IOException;

    new-instance p4, Ljava/lang/StringBuilder;

    invoke-direct {p4}, Ljava/lang/StringBuilder;-><init>()V

    const-string v0, "This is not a SSH_MSG_USERAUTH_FAILURE! ("

    invoke-virtual {p4, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p4, p1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    invoke-virtual {p4, p3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    invoke-direct {p2, p1}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    throw p2

    .line 19
    :cond_6
    new-instance p2, Ljava/io/IOException;

    new-instance p4, Ljava/lang/StringBuilder;

    invoke-direct {p4}, Ljava/lang/StringBuilder;-><init>()V

    const-string v0, "Unexpected SSH message (type "

    invoke-virtual {p4, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    aget-byte p1, p1, v2

    invoke-virtual {p4, p1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    invoke-virtual {p4, p3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    invoke-direct {p2, p1}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    throw p2

    :cond_7
    new-instance p1, Ljava/io/IOException;

    const-string p2, "Unknown private key type returned by the PEM decoder."

    invoke-direct {p1, p2}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    throw p1

    :cond_8
    new-instance p1, Ljava/io/IOException;

    const-string p2, "Authentication method publickey not supported by the server at this stage."

    invoke-direct {p1, p2}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    throw p1
    :try_end_3
    .catch Ljava/io/IOException; {:try_start_3 .. :try_end_3} :catch_1

    :catch_1
    move-exception p1

    iget-object p2, p0, Ln/a;->a:Ls/i;

    invoke-virtual {p2, p1, v2}, Ls/i;->b(Ljava/lang/Throwable;Z)V

    new-instance p2, Ljava/io/IOException;

    const-string p3, "Publickey authentication failed."

    invoke-direct {p2, p3, p1}, Ljava/io/IOException;-><init>(Ljava/lang/String;Ljava/lang/Throwable;)V

    throw p2
.end method

.method public final e()[B
    .locals 6

    .line 1
    :cond_0
    iget-object v0, p0, Ln/a;->b:Ljava/util/Vector;

    monitor-enter v0

    :try_start_0
    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v1

    sget-wide v3, Ln/a;->i:J

    add-long/2addr v1, v3

    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v3

    :goto_0
    iget-object v5, p0, Ln/a;->b:Ljava/util/Vector;

    invoke-virtual {v5}, Ljava/util/Vector;->size()I

    move-result v5

    if-nez v5, :cond_2

    cmp-long v5, v3, v1

    if-gez v5, :cond_2

    iget-boolean v3, p0, Ln/a;->d:Z
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    if-nez v3, :cond_1

    :try_start_1
    iget-object v3, p0, Ln/a;->b:Ljava/util/Vector;

    sget-wide v4, Ln/a;->i:J

    invoke-virtual {v3, v4, v5}, Ljava/lang/Object;->wait(J)V
    :try_end_1
    .catch Ljava/lang/InterruptedException; {:try_start_1 .. :try_end_1} :catch_0
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    :try_start_2
    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v3

    goto :goto_0

    :catch_0
    move-exception v1

    new-instance v2, Ljava/io/InterruptedIOException;

    invoke-virtual {v1}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    move-result-object v1

    invoke-direct {v2, v1}, Ljava/io/InterruptedIOException;-><init>(Ljava/lang/String;)V

    throw v2

    :cond_1
    new-instance v1, Ljava/io/IOException;

    const-string v2, "The connection is closed."

    iget-object v3, p0, Ln/a;->a:Ls/i;

    invoke-virtual {v3}, Ls/i;->f()Ljava/lang/Throwable;

    move-result-object v3

    invoke-direct {v1, v2, v3}, Ljava/io/IOException;-><init>(Ljava/lang/String;Ljava/lang/Throwable;)V

    throw v1

    :cond_2
    iget-object v1, p0, Ln/a;->b:Ljava/util/Vector;

    invoke-virtual {v1}, Ljava/util/Vector;->size()I

    move-result v1

    if-eqz v1, :cond_6

    iget-object v1, p0, Ln/a;->b:Ljava/util/Vector;

    invoke-virtual {v1}, Ljava/util/Vector;->firstElement()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, [B

    iget-object v2, p0, Ln/a;->b:Ljava/util/Vector;

    const/4 v3, 0x0

    invoke-virtual {v2, v3}, Ljava/util/Vector;->removeElementAt(I)V

    monitor-exit v0
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_0

    .line 2
    aget-byte v0, v1, v3

    const/16 v2, 0x35

    if-eq v0, v2, :cond_3

    return-object v1

    :cond_3
    array-length v0, v1

    new-array v4, v0, [B

    invoke-static {v1, v3, v4, v3, v0}, Ljava/lang/System;->arraycopy(Ljava/lang/Object;ILjava/lang/Object;II)V

    new-instance v3, Lq/c;

    invoke-direct {v3, v1, v0}, Lq/c;-><init>([BI)V

    invoke-virtual {v3}, Lq/c;->b()I

    move-result v0

    if-ne v0, v2, :cond_5

    const-string v0, "UTF-8"

    invoke-virtual {v3, v0}, Lq/c;->h(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v3}, Lq/c;->g()Ljava/lang/String;

    .line 3
    iget v1, v3, Lq/c;->c:I

    iget v2, v3, Lq/c;->b:I

    sub-int/2addr v1, v2

    if-nez v1, :cond_4

    .line 4
    iget-object v1, p0, Ln/a;->c:Ljava/util/Vector;

    invoke-virtual {v1}, Ljava/util/Vector;->iterator()Ljava/util/Iterator;

    move-result-object v1

    :goto_1
    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    move-result v2

    if-eqz v2, :cond_0

    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Lm/d;

    invoke-interface {v2, v0}, Lm/d;->b(Ljava/lang/String;)V

    goto :goto_1

    .line 5
    :cond_4
    new-instance v0, Ljava/io/IOException;

    const-string v1, "Padding in SSH_MSG_USERAUTH_REQUEST packet!"

    invoke-direct {v0, v1}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    throw v0

    :cond_5
    new-instance v1, Ljava/io/IOException;

    const-string v2, "This is not a SSH_MSG_USERAUTH_BANNER! ("

    const-string v3, ")"

    .line 6
    invoke-static {v2, v0, v3}, Lcom/trilead/ssh2/crypto/digest/a;->d(Ljava/lang/String;ILjava/lang/String;)Ljava/lang/String;

    move-result-object v0

    .line 7
    invoke-direct {v1, v0}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    throw v1

    .line 8
    :cond_6
    :try_start_3
    new-instance v1, Ljava/io/IOException;

    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const-string v3, "No valid packets after "

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    sget-wide v3, Ln/a;->i:J

    invoke-virtual {v2, v3, v4}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    const-string v3, " milliseconds, you can increase the timeout by setting the property -D"

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    sget-object v3, Ln/a;->h:Ljava/lang/String;

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v3, "=<MILLISECONDS>"

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-direct {v1, v2}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    throw v1

    :catchall_0
    move-exception v1

    monitor-exit v0
    :try_end_3
    .catchall {:try_start_3 .. :try_end_3} :catchall_0

    throw v1
.end method

.method public final f(Ljava/lang/String;)Z
    .locals 5

    iget-boolean v0, p0, Ln/a;->g:Z

    if-nez v0, :cond_7

    iget-object v0, p0, Ln/a;->a:Ls/i;

    const/4 v1, 0x0

    const/16 v2, 0xff

    invoke-virtual {v0, p0, v1, v2}, Ls/i;->i(Ls/d;II)V

    iget-object v0, p0, Ln/a;->a:Ls/i;

    .line 1
    new-instance v2, Lq/b;

    invoke-direct {v2}, Lq/b;-><init>()V

    const/4 v3, 0x5

    invoke-virtual {v2, v3}, Lq/b;->d(I)V

    const-string v3, "ssh-userauth"

    invoke-virtual {v2, v3}, Lq/b;->h(Ljava/lang/String;)V

    invoke-virtual {v2}, Lq/b;->a()[B

    move-result-object v2

    .line 2
    invoke-virtual {v0, v2}, Ls/i;->m([B)V

    iget-object v0, p0, Ln/a;->a:Ls/i;

    .line 3
    new-instance v2, Lq/b;

    invoke-direct {v2}, Lq/b;-><init>()V

    const/16 v3, 0x32

    invoke-virtual {v2, v3}, Lq/b;->d(I)V

    invoke-virtual {v2, p1}, Lq/b;->h(Ljava/lang/String;)V

    const-string p1, "ssh-connection"

    invoke-virtual {v2, p1}, Lq/b;->h(Ljava/lang/String;)V

    const-string p1, "none"

    invoke-virtual {v2, p1}, Lq/b;->h(Ljava/lang/String;)V

    invoke-virtual {v2}, Lq/b;->a()[B

    move-result-object p1

    .line 4
    invoke-virtual {v0, p1}, Ls/i;->m([B)V

    invoke-virtual {p0}, Ln/a;->e()[B

    move-result-object p1

    array-length v0, p1

    new-array v2, v0, [B

    invoke-static {p1, v1, v2, v1, v0}, Ljava/lang/System;->arraycopy(Ljava/lang/Object;ILjava/lang/Object;II)V

    new-instance v2, Lq/c;

    invoke-direct {v2, p1, v0}, Lq/c;-><init>([BI)V

    invoke-virtual {v2}, Lq/c;->b()I

    move-result p1

    const/4 v0, 0x6

    const-string v3, ")"

    if-ne p1, v0, :cond_6

    .line 5
    iget p1, v2, Lq/c;->c:I

    iget v0, v2, Lq/c;->b:I

    sub-int/2addr p1, v0

    if-lez p1, :cond_0

    .line 6
    invoke-virtual {v2}, Lq/c;->g()Ljava/lang/String;

    .line 7
    :cond_0
    iget p1, v2, Lq/c;->c:I

    iget v0, v2, Lq/c;->b:I

    sub-int/2addr p1, v0

    if-nez p1, :cond_5

    .line 8
    invoke-virtual {p0}, Ln/a;->e()[B

    move-result-object p1

    const/4 v0, 0x1

    iput-boolean v0, p0, Ln/a;->g:Z

    aget-byte v2, p1, v1

    const/16 v4, 0x34

    if-ne v2, v4, :cond_1

    iput-boolean v0, p0, Ln/a;->f:Z

    iget-object p1, p0, Ln/a;->a:Ls/i;

    invoke-virtual {p1, p0}, Ls/i;->j(Ls/d;)V

    return v0

    :cond_1
    aget-byte v0, p1, v1

    const/16 v2, 0x33

    if-ne v0, v2, :cond_4

    array-length v0, p1

    .line 9
    new-array v4, v0, [B

    invoke-static {p1, v1, v4, v1, v0}, Ljava/lang/System;->arraycopy(Ljava/lang/Object;ILjava/lang/Object;II)V

    new-instance v4, Lq/c;

    invoke-direct {v4, p1, v0}, Lq/c;-><init>([BI)V

    invoke-virtual {v4}, Lq/c;->b()I

    move-result p1

    if-ne p1, v2, :cond_3

    invoke-virtual {v4}, Lq/c;->f()[Ljava/lang/String;

    move-result-object p1

    invoke-virtual {v4}, Lq/c;->a()Z

    .line 10
    iget v0, v4, Lq/c;->c:I

    iget v2, v4, Lq/c;->b:I

    sub-int/2addr v0, v2

    if-nez v0, :cond_2

    .line 11
    iput-object p1, p0, Ln/a;->e:[Ljava/lang/String;

    return v1

    .line 12
    :cond_2
    new-instance p1, Ljava/io/IOException;

    const-string v0, "Padding in SSH_MSG_USERAUTH_FAILURE packet!"

    invoke-direct {p1, v0}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    throw p1

    :cond_3
    new-instance v0, Ljava/io/IOException;

    const-string v1, "This is not a SSH_MSG_USERAUTH_FAILURE! ("

    .line 13
    invoke-static {v1, p1, v3}, Lcom/trilead/ssh2/crypto/digest/a;->d(Ljava/lang/String;ILjava/lang/String;)Ljava/lang/String;

    move-result-object p1

    .line 14
    invoke-direct {v0, p1}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    throw v0

    .line 15
    :cond_4
    new-instance v0, Ljava/io/IOException;

    const-string v2, "Unexpected SSH message (type "

    .line 16
    invoke-static {v2}, Lcom/trilead/ssh2/crypto/digest/a;->e(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    .line 17
    aget-byte p1, p1, v1

    invoke-virtual {v2, p1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    invoke-direct {v0, p1}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    throw v0

    .line 18
    :cond_5
    new-instance p1, Ljava/io/IOException;

    const-string v0, "Padding in SSH_MSG_SERVICE_ACCEPT packet!"

    invoke-direct {p1, v0}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    throw p1

    :cond_6
    new-instance v0, Ljava/io/IOException;

    const-string v1, "This is not a SSH_MSG_SERVICE_ACCEPT! ("

    .line 19
    invoke-static {v1, p1, v3}, Lcom/trilead/ssh2/crypto/digest/a;->d(Ljava/lang/String;ILjava/lang/String;)Ljava/lang/String;

    move-result-object p1

    .line 20
    invoke-direct {v0, p1}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    throw v0

    .line 21
    :cond_7
    iget-boolean p1, p0, Ln/a;->f:Z

    return p1
.end method

.method public final g(Ljava/lang/String;)Z
    .locals 5

    iget-object v0, p0, Ln/a;->e:[Ljava/lang/String;

    const/4 v1, 0x0

    if-nez v0, :cond_0

    return v1

    :cond_0
    array-length v2, v0

    const/4 v3, 0x0

    :goto_0
    if-ge v3, v2, :cond_2

    aget-object v4, v0, v3

    invoke-virtual {v4, p1}, Ljava/lang/String;->compareTo(Ljava/lang/String;)I

    move-result v4

    if-nez v4, :cond_1

    const/4 p1, 0x1

    return p1

    :cond_1
    add-int/lit8 v3, v3, 0x1

    goto :goto_0

    :cond_2
    return v1
.end method

.method public final h(Ljava/util/Vector;)V
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/Vector<",
            "Lm/d;",
            ">;)V"
        }
    .end annotation

    invoke-virtual {p1}, Ljava/util/Vector;->clone()Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Ljava/util/Vector;

    iput-object p1, p0, Ln/a;->c:Ljava/util/Vector;

    return-void
.end method
