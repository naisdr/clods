.class public final Lo/a$a;
.super Ljava/lang/Object;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lo/a;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1
    name = "a"
.end annotation


# instance fields
.field public a:Lo/b;

.field public b:Lo/f;

.field public final synthetic c:Lo/a;


# direct methods
.method public constructor <init>(Lo/a;)V
    .locals 2

    iput-object p1, p0, Lo/a$a;->c:Lo/a;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    new-instance v0, Lo/f;

    iget v1, p1, Lo/a;->a:I

    invoke-direct {v0, p1, v1}, Lo/f;-><init>(Ljava/lang/Object;I)V

    iput-object v0, p0, Lo/a$a;->b:Lo/f;

    return-void
.end method


# virtual methods
.method public final a()V
    .locals 4

    iget-object v0, p0, Lo/a$a;->b:Lo/f;

    const/4 v1, 0x0

    if-eqz v0, :cond_2

    .line 1
    iget-object v2, v0, Lo/f;->a:Ljava/lang/Object;

    monitor-enter v2

    :try_start_0
    iget-boolean v3, v0, Lo/f;->g:Z

    if-nez v3, :cond_1

    const/4 v3, 0x1

    iput-boolean v3, v0, Lo/f;->g:Z

    .line 2
    invoke-virtual {v0}, Lo/f;->a()I

    move-result v3

    if-nez v3, :cond_0

    iput-object v1, v0, Lo/f;->f:Lo/f$b;

    iput-object v1, v0, Lo/f;->e:Lo/f$b;

    .line 3
    :cond_0
    iget-object v0, v0, Lo/f;->a:Ljava/lang/Object;

    invoke-virtual {v0}, Ljava/lang/Object;->notifyAll()V

    :cond_1
    monitor-exit v2

    return-void

    :catchall_0
    move-exception v0

    monitor-exit v2
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    throw v0

    .line 4
    :cond_2
    throw v1
.end method

.method public final b([BII)I
    .locals 10

    iget-object v0, p0, Lo/a$a;->b:Lo/f;

    invoke-static {v0}, Ljava/util/Objects;->requireNonNull(Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v1, 0x0

    if-nez p3, :cond_0

    goto :goto_3

    .line 1
    :cond_0
    :goto_0
    iget-object v2, v0, Lo/f;->a:Ljava/lang/Object;

    monitor-enter v2

    :goto_1
    :try_start_0
    invoke-virtual {v0}, Lo/f;->a()I

    move-result v3

    invoke-static {p3, v3}, Ljava/lang/Math;->min(II)I

    move-result v3

    if-lez v3, :cond_2

    iget-object v4, v0, Lo/f;->e:Lo/f$b;

    invoke-static {v4}, Ljava/util/Objects;->requireNonNull(Ljava/lang/Object;)Ljava/lang/Object;

    move v6, p2

    move v5, v3

    :goto_2
    if-lez v5, :cond_1

    .line 2
    invoke-virtual {v4}, Lo/f$b;->a()I

    move-result v7

    invoke-static {v5, v7}, Ljava/lang/Math;->min(II)I

    move-result v7

    iget-object v8, v4, Lo/f$b;->a:Lo/f$a;

    iget-object v8, v8, Lo/f$a;->a:[B

    iget v9, v4, Lo/f$b;->b:I

    invoke-static {v8, v9, p1, v6, v7}, Ljava/lang/System;->arraycopy(Ljava/lang/Object;ILjava/lang/Object;II)V

    iget v8, v4, Lo/f$b;->b:I

    add-int/2addr v8, v7

    iput v8, v4, Lo/f$b;->b:I

    sub-int/2addr v5, v7

    add-int/2addr v6, v7

    goto :goto_2

    :cond_1
    add-int/2addr p2, v3

    sub-int/2addr p3, v3

    add-int/2addr v1, v3

    .line 3
    iget v4, v0, Lo/f;->b:I

    sub-int/2addr v4, v3

    iput v4, v0, Lo/f;->b:I

    iget-object v3, v0, Lo/f;->a:Ljava/lang/Object;

    invoke-virtual {v3}, Ljava/lang/Object;->notifyAll()V

    monitor-exit v2

    goto :goto_0

    :cond_2
    if-lez v1, :cond_3

    monitor-exit v2

    goto :goto_3

    :cond_3
    iget-boolean v3, v0, Lo/f;->g:Z

    if-eqz v3, :cond_5

    if-eqz v3, :cond_4

    .line 4
    invoke-virtual {v0}, Lo/f;->a()I

    move-result p1

    if-nez p1, :cond_4

    const/4 p1, 0x0

    iput-object p1, v0, Lo/f;->f:Lo/f$b;

    iput-object p1, v0, Lo/f;->e:Lo/f$b;

    :cond_4
    const/4 v1, -0x1

    .line 5
    monitor-exit v2

    :goto_3
    return v1

    :cond_5
    iget-object v3, v0, Lo/f;->a:Ljava/lang/Object;

    invoke-virtual {v3}, Ljava/lang/Object;->wait()V

    goto :goto_1

    :catchall_0
    move-exception p1

    monitor-exit v2
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    throw p1
.end method
