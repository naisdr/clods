.class public final Lm0/b;
.super Ljava/lang/Object;
.source "SourceFile"


# instance fields
.field public final a:[C

.field public final b:I

.field public final c:I

.field public final d:I

.field public final e:Lm0/a;

.field public final f:I


# direct methods
.method public constructor <init>([C)V
    .locals 5

    sget-object v0, Lm0/a;->b:Lm0/a;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    array-length v1, p1

    invoke-static {p1, v1}, Ljava/util/Arrays;->copyOf([CI)[C

    move-result-object p1

    iput-object p1, p0, Lm0/b;->a:[C

    const/16 p1, 0x3e8

    iput p1, p0, Lm0/b;->b:I

    const/4 p1, 0x2

    iput p1, p0, Lm0/b;->d:I

    const/16 p1, 0x20

    iput p1, p0, Lm0/b;->c:I

    iput-object v0, p0, Lm0/b;->e:Lm0/a;

    .line 1
    iget-object p1, v0, Lm0/a;->a:[I

    .line 2
    array-length v0, p1

    const/4 v1, 0x0

    const/4 v2, 0x0

    :goto_0
    const/16 v3, 0x80

    if-ge v2, v0, :cond_1

    aget v4, p1, v2

    if-ne v3, v4, :cond_0

    const/4 v1, 0x1

    goto :goto_1

    :cond_0
    add-int/lit8 v2, v2, 0x1

    goto :goto_0

    :cond_1
    :goto_1
    if-eqz v1, :cond_2

    iput v3, p0, Lm0/b;->f:I

    return-void

    :cond_2
    new-instance p1, Ljava/lang/IllegalArgumentException;

    const-string v0, "Key size is invalid for the selected algorithm"

    invoke-direct {p1, v0}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw p1
.end method
