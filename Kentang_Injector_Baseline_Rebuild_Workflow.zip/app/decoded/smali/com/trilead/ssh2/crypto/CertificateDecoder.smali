.class public abstract Lcom/trilead/ssh2/crypto/CertificateDecoder;
.super Ljava/lang/Object;
.source "SourceFile"


# direct methods
.method public constructor <init>()V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public abstract a(Lcom/trilead/ssh2/crypto/PEMStructure;)Ljava/security/KeyPair;
.end method

.method public b(Lcom/trilead/ssh2/crypto/PEMStructure;Ljava/lang/String;)Ljava/security/KeyPair;
    .locals 0

    invoke-virtual {p0, p1}, Lcom/trilead/ssh2/crypto/CertificateDecoder;->a(Lcom/trilead/ssh2/crypto/PEMStructure;)Ljava/security/KeyPair;

    move-result-object p1

    return-object p1
.end method

.method public abstract c()Ljava/lang/String;
.end method

.method public abstract d()Ljava/lang/String;
.end method
