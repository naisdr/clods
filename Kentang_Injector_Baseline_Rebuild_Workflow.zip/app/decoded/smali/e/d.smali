.class public interface abstract Le/d;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Le/c;


# virtual methods
.method public abstract a()V
.end method
