.class public final Lm/e;
.super Ljava/lang/Object;
.source "SourceFile"


# instance fields
.field public a:Ljava/lang/Object;

.field public b:Ljava/lang/Object;


# direct methods
.method public synthetic constructor <init>(Lcom/trilead/ssh2/crypto/CryptoWishList;Ljava/security/SecureRandom;)V
    .locals 2

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    new-instance v0, Ls/b;

    invoke-direct {v0}, Ls/b;-><init>()V

    iput-object v0, p0, Lm/e;->b:Ljava/lang/Object;

    const/16 v1, 0x10

    new-array v1, v1, [B

    iput-object v1, v0, Ls/b;->a:[B

    iget-object v0, v0, Ls/b;->a:[B

    invoke-virtual {p2, v0}, Ljava/security/SecureRandom;->nextBytes([B)V

    iget-object p2, p0, Lm/e;->b:Ljava/lang/Object;

    move-object v0, p2

    check-cast v0, Ls/b;

    iget-object v1, p1, Lcom/trilead/ssh2/crypto/CryptoWishList;->a:[Ljava/lang/String;

    iput-object v1, v0, Ls/b;->b:[Ljava/lang/String;

    move-object v0, p2

    check-cast v0, Ls/b;

    iget-object v1, p1, Lcom/trilead/ssh2/crypto/CryptoWishList;->b:[Ljava/lang/String;

    iput-object v1, v0, Ls/b;->c:[Ljava/lang/String;

    move-object v0, p2

    check-cast v0, Ls/b;

    iget-object v1, p1, Lcom/trilead/ssh2/crypto/CryptoWishList;->c:[Ljava/lang/String;

    iput-object v1, v0, Ls/b;->d:[Ljava/lang/String;

    move-object v0, p2

    check-cast v0, Ls/b;

    iget-object v1, p1, Lcom/trilead/ssh2/crypto/CryptoWishList;->d:[Ljava/lang/String;

    iput-object v1, v0, Ls/b;->e:[Ljava/lang/String;

    move-object v0, p2

    check-cast v0, Ls/b;

    iget-object v1, p1, Lcom/trilead/ssh2/crypto/CryptoWishList;->e:[Ljava/lang/String;

    iput-object v1, v0, Ls/b;->f:[Ljava/lang/String;

    move-object v0, p2

    check-cast v0, Ls/b;

    iget-object p1, p1, Lcom/trilead/ssh2/crypto/CryptoWishList;->f:[Ljava/lang/String;

    iput-object p1, v0, Ls/b;->g:[Ljava/lang/String;

    move-object p1, p2

    check-cast p1, Ls/b;

    const-string v0, "none"

    filled-new-array {v0}, [Ljava/lang/String;

    move-result-object v1

    iput-object v1, p1, Ls/b;->h:[Ljava/lang/String;

    move-object p1, p2

    check-cast p1, Ls/b;

    filled-new-array {v0}, [Ljava/lang/String;

    move-result-object v0

    iput-object v0, p1, Ls/b;->i:[Ljava/lang/String;

    move-object p1, p2

    check-cast p1, Ls/b;

    const/4 v0, 0x0

    new-array v1, v0, [Ljava/lang/String;

    iput-object v1, p1, Ls/b;->j:[Ljava/lang/String;

    move-object p1, p2

    check-cast p1, Ls/b;

    new-array v1, v0, [Ljava/lang/String;

    iput-object v1, p1, Ls/b;->k:[Ljava/lang/String;

    move-object p1, p2

    check-cast p1, Ls/b;

    iput-boolean v0, p1, Ls/b;->l:Z

    check-cast p2, Ls/b;

    iput v0, p2, Ls/b;->m:I

    return-void
.end method

.method public synthetic constructor <init>(Lo/c;II)V
    .locals 1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lm/e;->a:Ljava/lang/Object;

    new-instance v0, Lo/e;

    invoke-direct {v0, p1, p2, p3}, Lo/e;-><init>(Lo/c;II)V

    iput-object v0, p0, Lm/e;->b:Ljava/lang/Object;

    const/4 p1, 0x1

    invoke-virtual {v0, p1}, Ljava/lang/Thread;->setDaemon(Z)V

    iget-object p1, p0, Lm/e;->b:Ljava/lang/Object;

    check-cast p1, Lo/e;

    invoke-virtual {p1}, Ljava/lang/Thread;->start()V

    return-void
.end method

.method public constructor <init>([BI)V
    .locals 2

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    new-instance v0, Ls/b;

    invoke-direct {v0}, Ls/b;-><init>()V

    iput-object v0, p0, Lm/e;->b:Ljava/lang/Object;

    new-array v0, p2, [B

    iput-object v0, p0, Lm/e;->a:Ljava/lang/Object;

    const/4 v1, 0x0

    invoke-static {p1, v1, v0, v1, p2}, Ljava/lang/System;->arraycopy(Ljava/lang/Object;ILjava/lang/Object;II)V

    new-instance v0, Lq/c;

    invoke-direct {v0, p1, p2}, Lq/c;-><init>([BI)V

    invoke-virtual {v0}, Lq/c;->b()I

    move-result p1

    const/16 p2, 0x14

    if-ne p1, p2, :cond_1

    iget-object p1, p0, Lm/e;->b:Ljava/lang/Object;

    check-cast p1, Ls/b;

    const/16 p2, 0x10

    invoke-virtual {v0, p2}, Lq/c;->d(I)[B

    move-result-object p2

    iput-object p2, p1, Ls/b;->a:[B

    iget-object p1, p0, Lm/e;->b:Ljava/lang/Object;

    check-cast p1, Ls/b;

    invoke-virtual {v0}, Lq/c;->f()[Ljava/lang/String;

    move-result-object p2

    iput-object p2, p1, Ls/b;->b:[Ljava/lang/String;

    iget-object p1, p0, Lm/e;->b:Ljava/lang/Object;

    check-cast p1, Ls/b;

    invoke-virtual {v0}, Lq/c;->f()[Ljava/lang/String;

    move-result-object p2

    iput-object p2, p1, Ls/b;->c:[Ljava/lang/String;

    iget-object p1, p0, Lm/e;->b:Ljava/lang/Object;

    check-cast p1, Ls/b;

    invoke-virtual {v0}, Lq/c;->f()[Ljava/lang/String;

    move-result-object p2

    iput-object p2, p1, Ls/b;->d:[Ljava/lang/String;

    iget-object p1, p0, Lm/e;->b:Ljava/lang/Object;

    check-cast p1, Ls/b;

    invoke-virtual {v0}, Lq/c;->f()[Ljava/lang/String;

    move-result-object p2

    iput-object p2, p1, Ls/b;->e:[Ljava/lang/String;

    iget-object p1, p0, Lm/e;->b:Ljava/lang/Object;

    check-cast p1, Ls/b;

    invoke-virtual {v0}, Lq/c;->f()[Ljava/lang/String;

    move-result-object p2

    iput-object p2, p1, Ls/b;->f:[Ljava/lang/String;

    iget-object p1, p0, Lm/e;->b:Ljava/lang/Object;

    check-cast p1, Ls/b;

    invoke-virtual {v0}, Lq/c;->f()[Ljava/lang/String;

    move-result-object p2

    iput-object p2, p1, Ls/b;->g:[Ljava/lang/String;

    iget-object p1, p0, Lm/e;->b:Ljava/lang/Object;

    check-cast p1, Ls/b;

    invoke-virtual {v0}, Lq/c;->f()[Ljava/lang/String;

    move-result-object p2

    iput-object p2, p1, Ls/b;->h:[Ljava/lang/String;

    iget-object p1, p0, Lm/e;->b:Ljava/lang/Object;

    check-cast p1, Ls/b;

    invoke-virtual {v0}, Lq/c;->f()[Ljava/lang/String;

    move-result-object p2

    iput-object p2, p1, Ls/b;->i:[Ljava/lang/String;

    iget-object p1, p0, Lm/e;->b:Ljava/lang/Object;

    check-cast p1, Ls/b;

    invoke-virtual {v0}, Lq/c;->f()[Ljava/lang/String;

    move-result-object p2

    iput-object p2, p1, Ls/b;->j:[Ljava/lang/String;

    iget-object p1, p0, Lm/e;->b:Ljava/lang/Object;

    check-cast p1, Ls/b;

    invoke-virtual {v0}, Lq/c;->f()[Ljava/lang/String;

    move-result-object p2

    iput-object p2, p1, Ls/b;->k:[Ljava/lang/String;

    iget-object p1, p0, Lm/e;->b:Ljava/lang/Object;

    check-cast p1, Ls/b;

    invoke-virtual {v0}, Lq/c;->a()Z

    move-result p2

    iput-boolean p2, p1, Ls/b;->l:Z

    iget-object p1, p0, Lm/e;->b:Ljava/lang/Object;

    check-cast p1, Ls/b;

    invoke-virtual {v0}, Lq/c;->i()I

    move-result p2

    iput p2, p1, Ls/b;->m:I

    .line 1
    iget p1, v0, Lq/c;->c:I

    iget p2, v0, Lq/c;->b:I

    sub-int/2addr p1, p2

    if-nez p1, :cond_0

    return-void

    .line 2
    :cond_0
    new-instance p1, Ljava/io/IOException;

    const-string p2, "Padding in KexInitPacket!"

    invoke-direct {p1, p2}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    throw p1

    :cond_1
    new-instance p2, Ljava/io/IOException;

    const-string v0, "This is not a KexInitPacket! ("

    const-string v1, ")"

    .line 3
    invoke-static {v0, p1, v1}, Lcom/trilead/ssh2/crypto/digest/a;->d(Ljava/lang/String;ILjava/lang/String;)Ljava/lang/String;

    move-result-object p1

    .line 4
    invoke-direct {p2, p1}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    throw p2
.end method


# virtual methods
.method public final a()Ls/b;
    .locals 1

    iget-object v0, p0, Lm/e;->b:Ljava/lang/Object;

    check-cast v0, Ls/b;

    return-object v0
.end method

.method public final b()[B
    .locals 4

    iget-object v0, p0, Lm/e;->a:Ljava/lang/Object;

    check-cast v0, [B

    if-nez v0, :cond_0

    new-instance v0, Lq/b;

    invoke-direct {v0}, Lq/b;-><init>()V

    const/16 v1, 0x14

    invoke-virtual {v0, v1}, Lq/b;->d(I)V

    iget-object v1, p0, Lm/e;->b:Ljava/lang/Object;

    check-cast v1, Ls/b;

    iget-object v1, v1, Ls/b;->a:[B

    const/4 v2, 0x0

    const/16 v3, 0x10

    invoke-virtual {v0, v1, v2, v3}, Lq/b;->e([BII)V

    iget-object v1, p0, Lm/e;->b:Ljava/lang/Object;

    check-cast v1, Ls/b;

    iget-object v1, v1, Ls/b;->b:[Ljava/lang/String;

    invoke-virtual {v0, v1}, Lq/b;->g([Ljava/lang/String;)V

    iget-object v1, p0, Lm/e;->b:Ljava/lang/Object;

    check-cast v1, Ls/b;

    iget-object v1, v1, Ls/b;->c:[Ljava/lang/String;

    invoke-virtual {v0, v1}, Lq/b;->g([Ljava/lang/String;)V

    iget-object v1, p0, Lm/e;->b:Ljava/lang/Object;

    check-cast v1, Ls/b;

    iget-object v1, v1, Ls/b;->d:[Ljava/lang/String;

    invoke-virtual {v0, v1}, Lq/b;->g([Ljava/lang/String;)V

    iget-object v1, p0, Lm/e;->b:Ljava/lang/Object;

    check-cast v1, Ls/b;

    iget-object v1, v1, Ls/b;->e:[Ljava/lang/String;

    invoke-virtual {v0, v1}, Lq/b;->g([Ljava/lang/String;)V

    iget-object v1, p0, Lm/e;->b:Ljava/lang/Object;

    check-cast v1, Ls/b;

    iget-object v1, v1, Ls/b;->f:[Ljava/lang/String;

    invoke-virtual {v0, v1}, Lq/b;->g([Ljava/lang/String;)V

    iget-object v1, p0, Lm/e;->b:Ljava/lang/Object;

    check-cast v1, Ls/b;

    iget-object v1, v1, Ls/b;->g:[Ljava/lang/String;

    invoke-virtual {v0, v1}, Lq/b;->g([Ljava/lang/String;)V

    iget-object v1, p0, Lm/e;->b:Ljava/lang/Object;

    check-cast v1, Ls/b;

    iget-object v1, v1, Ls/b;->h:[Ljava/lang/String;

    invoke-virtual {v0, v1}, Lq/b;->g([Ljava/lang/String;)V

    iget-object v1, p0, Lm/e;->b:Ljava/lang/Object;

    check-cast v1, Ls/b;

    iget-object v1, v1, Ls/b;->i:[Ljava/lang/String;

    invoke-virtual {v0, v1}, Lq/b;->g([Ljava/lang/String;)V

    iget-object v1, p0, Lm/e;->b:Ljava/lang/Object;

    check-cast v1, Ls/b;

    iget-object v1, v1, Ls/b;->j:[Ljava/lang/String;

    invoke-virtual {v0, v1}, Lq/b;->g([Ljava/lang/String;)V

    iget-object v1, p0, Lm/e;->b:Ljava/lang/Object;

    check-cast v1, Ls/b;

    iget-object v1, v1, Ls/b;->k:[Ljava/lang/String;

    invoke-virtual {v0, v1}, Lq/b;->g([Ljava/lang/String;)V

    iget-object v1, p0, Lm/e;->b:Ljava/lang/Object;

    check-cast v1, Ls/b;

    iget-boolean v1, v1, Ls/b;->l:Z

    invoke-virtual {v0, v1}, Lq/b;->c(Z)V

    iget-object v1, p0, Lm/e;->b:Ljava/lang/Object;

    check-cast v1, Ls/b;

    iget v1, v1, Ls/b;->m:I

    invoke-virtual {v0, v1}, Lq/b;->j(I)V

    invoke-virtual {v0}, Lq/b;->a()[B

    move-result-object v0

    iput-object v0, p0, Lm/e;->a:Ljava/lang/Object;

    :cond_0
    iget-object v0, p0, Lm/e;->a:Ljava/lang/Object;

    check-cast v0, [B

    return-object v0
.end method

.method public final c()Z
    .locals 1

    iget-object v0, p0, Lm/e;->b:Ljava/lang/Object;

    check-cast v0, Ls/b;

    iget-boolean v0, v0, Ls/b;->l:Z

    return v0
.end method
