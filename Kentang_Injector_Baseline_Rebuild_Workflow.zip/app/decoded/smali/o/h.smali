.class public final Lo/h;
.super Ljava/lang/Thread;
.source "SourceFile"

# interfaces
.implements Lo/g;


# instance fields
.field public a:Lo/c;

.field public b:Ljava/lang/String;

.field public c:I

.field public final d:Ljava/net/ServerSocket;


# direct methods
.method public constructor <init>(Lo/c;Ljava/lang/String;)V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Thread;-><init>()V

    iput-object p1, p0, Lo/h;->a:Lo/c;

    iput-object p2, p0, Lo/h;->b:Ljava/lang/String;

    const/16 p1, 0x50

    iput p1, p0, Lo/h;->c:I

    new-instance p1, Ljava/net/ServerSocket;

    const/16 p2, 0x24b3

    invoke-direct {p1, p2}, Ljava/net/ServerSocket;-><init>(I)V

    iput-object p1, p0, Lo/h;->d:Ljava/net/ServerSocket;

    return-void
.end method


# virtual methods
.method public final a()V
    .locals 1

    :try_start_0
    iget-object v0, p0, Lo/h;->d:Ljava/net/ServerSocket;

    invoke-virtual {v0}, Ljava/net/ServerSocket;->close()V
    :try_end_0
    .catch Ljava/io/IOException; {:try_start_0 .. :try_end_0} :catch_0

    :catch_0
    return-void
.end method

.method public final run()V
    .locals 15

    :try_start_0
    iget-object v0, p0, Lo/h;->a:Lo/c;

    invoke-virtual {v0, p0}, Lo/c;->q(Lo/g;)V
    :try_end_0
    .catch Ljava/io/IOException; {:try_start_0 .. :try_end_0} :catch_4

    :catch_0
    :goto_0
    :try_start_1
    iget-object v0, p0, Lo/h;->d:Ljava/net/ServerSocket;

    invoke-virtual {v0}, Ljava/net/ServerSocket;->accept()Ljava/net/Socket;

    move-result-object v4
    :try_end_1
    .catch Ljava/io/IOException; {:try_start_1 .. :try_end_1} :catch_3

    :try_start_2
    iget-object v0, p0, Lo/h;->a:Lo/c;

    iget-object v1, p0, Lo/h;->b:Ljava/lang/String;

    iget v2, p0, Lo/h;->c:I

    invoke-virtual {v4}, Ljava/net/Socket;->getInetAddress()Ljava/net/InetAddress;

    move-result-object v3

    invoke-virtual {v3}, Ljava/net/InetAddress;->getHostAddress()Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v4}, Ljava/net/Socket;->getPort()I

    move-result v5

    invoke-virtual {v0, v1, v2, v3, v5}, Lo/c;->p(Ljava/lang/String;ILjava/lang/String;I)Lo/a;

    move-result-object v0
    :try_end_2
    .catch Ljava/io/IOException; {:try_start_2 .. :try_end_2} :catch_2

    const/4 v13, 0x1

    :try_start_3
    new-instance v14, Lo/l;

    const/4 v8, 0x0

    const/4 v9, 0x0

    .line 1
    iget-object v1, v0, Lo/a;->d:Lo/a$a;

    iget-object v10, v1, Lo/a$a;->a:Lo/b;

    .line 2
    invoke-virtual {v4}, Ljava/net/Socket;->getOutputStream()Ljava/io/OutputStream;

    move-result-object v11

    const-string v12, "RemoteToLocal"

    move-object v6, v14

    move-object v7, v0

    invoke-direct/range {v6 .. v12}, Lo/l;-><init>(Lo/a;Lo/l;Ljava/net/Socket;Ljava/io/InputStream;Ljava/io/OutputStream;Ljava/lang/String;)V

    new-instance v8, Lo/l;

    invoke-virtual {v4}, Ljava/net/Socket;->getInputStream()Ljava/io/InputStream;

    move-result-object v5

    iget-object v6, v0, Lo/a;->c:Lo/d;

    const-string v7, "LocalToRemote"

    move-object v1, v8

    move-object v2, v0

    move-object v3, v14

    invoke-direct/range {v1 .. v7}, Lo/l;-><init>(Lo/a;Lo/l;Ljava/net/Socket;Ljava/io/InputStream;Ljava/io/OutputStream;Ljava/lang/String;)V
    :try_end_3
    .catch Ljava/io/IOException; {:try_start_3 .. :try_end_3} :catch_1

    invoke-virtual {v14, v13}, Ljava/lang/Thread;->setDaemon(Z)V

    invoke-virtual {v8, v13}, Ljava/lang/Thread;->setDaemon(Z)V

    invoke-virtual {v14}, Ljava/lang/Thread;->start()V

    invoke-virtual {v8}, Ljava/lang/Thread;->start()V

    goto :goto_0

    :catch_1
    move-exception v1

    :try_start_4
    iget-object v2, v0, Lo/a;->b:Lo/c;

    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    const-string v4, "Weird error during creation of StreamForwarder ("

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v3, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v1, ")"

    invoke-virtual {v3, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v2, v0, v1}, Lo/c;->e(Lo/a;Ljava/lang/String;)V

    goto :goto_0

    :catch_2
    invoke-virtual {v4}, Ljava/net/Socket;->close()V
    :try_end_4
    .catch Ljava/io/IOException; {:try_start_4 .. :try_end_4} :catch_0

    goto :goto_0

    :catch_3
    invoke-virtual {p0}, Lo/h;->a()V

    return-void

    :catch_4
    invoke-virtual {p0}, Lo/h;->a()V

    return-void
.end method
