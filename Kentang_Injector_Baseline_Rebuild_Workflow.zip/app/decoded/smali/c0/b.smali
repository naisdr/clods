.class public final Lc0/b;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lh0/h$d;


# instance fields
.field public final synthetic a:Lxyz/chz/injector/HttpService;


# direct methods
.method public constructor <init>(Lxyz/chz/injector/HttpService;)V
    .locals 0

    iput-object p1, p0, Lc0/b;->a:Lxyz/chz/injector/HttpService;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method
