.class public Lxyz/chz/injector/HttpService;
.super Landroid/app/Service;
.source "SourceFile"

# interfaces
.implements Lg0/d$b;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lxyz/chz/injector/HttpService$f;
    }
.end annotation


# static fields
.field public static m:Lk0/a;

.field public static final n:Ljava/lang/String;

.field public static final o:Ljava/lang/String;

.field public static p:Ljava/lang/String;


# instance fields
.field public a:Landroid/app/NotificationManager;

.field public b:Landroid/os/Handler;

.field public c:Lf0/a;

.field public d:Ljava/lang/Thread;

.field public e:Lh0/h;

.field public f:Landroid/net/ConnectivityManager;

.field public final g:Lxyz/chz/injector/HttpService$a;

.field public h:Lf0/a;

.field public i:Landroid/app/Notification$Builder;

.field public j:Ljava/lang/String;

.field public k:Lxyz/chz/injector/HttpService$d;

.field public l:Lxyz/chz/injector/HttpService$e;


# direct methods
.method public static constructor <clinit>()V
    .locals 2

    const-class v0, Lxyz/chz/injector/HttpService;

    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const-class v1, Lxyz/chz/injector/HttpService;

    invoke-virtual {v1}, Ljava/lang/Class;->getName()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v1, "::restartservicebroadcast"

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    sput-object v0, Lxyz/chz/injector/HttpService;->n:Ljava/lang/String;

    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const-class v1, Lxyz/chz/injector/HttpService;

    invoke-virtual {v1}, Ljava/lang/Class;->getName()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v1, "::stopservicebroadcast"

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    sput-object v0, Lxyz/chz/injector/HttpService;->o:Ljava/lang/String;

    return-void
.end method

.method public constructor <init>()V
    .locals 1

    invoke-direct {p0}, Landroid/app/Service;-><init>()V

    new-instance v0, Lxyz/chz/injector/HttpService$a;

    invoke-direct {v0, p0}, Lxyz/chz/injector/HttpService$a;-><init>(Lxyz/chz/injector/HttpService;)V

    iput-object v0, p0, Lxyz/chz/injector/HttpService;->g:Lxyz/chz/injector/HttpService$a;

    const/4 v0, 0x0

    iput-object v0, p0, Lxyz/chz/injector/HttpService;->i:Landroid/app/Notification$Builder;

    new-instance v0, Lxyz/chz/injector/HttpService$d;

    invoke-direct {v0}, Lxyz/chz/injector/HttpService$d;-><init>()V

    iput-object v0, p0, Lxyz/chz/injector/HttpService;->k:Lxyz/chz/injector/HttpService$d;

    new-instance v0, Lxyz/chz/injector/HttpService$e;

    invoke-direct {v0, p0}, Lxyz/chz/injector/HttpService$e;-><init>(Lxyz/chz/injector/HttpService;)V

    iput-object v0, p0, Lxyz/chz/injector/HttpService;->l:Lxyz/chz/injector/HttpService$e;

    return-void
.end method

.method public static c(Landroid/content/Context;)Landroid/app/PendingIntent;
    .locals 4

    new-instance v0, Landroid/content/Intent;

    const-string v1, "android.intent.action.VIEW"

    invoke-direct {v0, v1}, Landroid/content/Intent;-><init>(Ljava/lang/String;)V

    new-instance v1, Landroid/content/ComponentName;

    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {p0}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v3, ".MainActivity"

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-direct {v1, p0, v2}, Landroid/content/ComponentName;-><init>(Landroid/content/Context;Ljava/lang/String;)V

    invoke-virtual {v0, v1}, Landroid/content/Intent;->setComponent(Landroid/content/ComponentName;)Landroid/content/Intent;

    const/high16 v1, 0x24000000

    invoke-virtual {v0, v1}, Landroid/content/Intent;->setFlags(I)Landroid/content/Intent;

    const/4 v1, 0x0

    const/high16 v2, 0x4000000

    invoke-static {p0, v1, v0, v2}, Landroid/app/PendingIntent;->getActivity(Landroid/content/Context;ILandroid/content/Intent;I)Landroid/app/PendingIntent;

    move-result-object p0

    return-object p0
.end method


# virtual methods
.method public final a(Lg0/a;)V
    .locals 4

    iget-object v0, p0, Lxyz/chz/injector/HttpService;->d:Ljava/lang/Thread;

    if-nez v0, :cond_0

    return-void

    :cond_0
    sget-object v0, Lg0/a;->a:Lg0/a;

    invoke-virtual {p1, v0}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    move-result v0

    const-string v1, "onn"

    const/4 v2, 0x0

    if-eqz v0, :cond_2

    sget-object v0, Lxyz/chz/injector/HttpService;->m:Lk0/a;

    const-string v3, "hotspotKeeyy"

    invoke-virtual {v0, v3, v2}, Lk0/a;->getBoolean(Ljava/lang/String;Z)Z

    move-result v0

    if-eqz v0, :cond_2

    invoke-static {v2}, Lj0/e;->b(Z)Ljava/lang/String;

    move-result-object v0

    if-eqz v0, :cond_1

    new-instance v0, Lxyz/chz/injector/HttpService$f;

    invoke-direct {v0}, Lxyz/chz/injector/HttpService$f;-><init>()V

    const/4 v3, 0x1

    invoke-virtual {v0, v3}, Ljava/lang/Thread;->setDaemon(Z)V

    invoke-virtual {v0}, Ljava/lang/Thread;->start()V

    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const-string v3, "<font color=\'#00FF7F\'>Tether Proxy: "

    invoke-virtual {v0, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-static {v2}, Lj0/e;->b(Z)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v0, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v3, ":9001</font>"

    invoke-virtual {v0, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-static {v0}, Lg0/d;->k(Ljava/lang/String;)V

    move-object v0, v1

    goto :goto_0

    :cond_1
    const-string v0, "<font color=\'#FF5733\'>Please turn on MOBILE Hotspot before use Tether Proxy</font>"

    invoke-static {v0}, Lg0/d;->k(Ljava/lang/String;)V

    const-string v0, "off"

    goto :goto_0

    :cond_2
    const-string v0, ""

    :goto_0
    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_3

    const-string v0, "Proxy: "

    .line 1
    invoke-static {v0}, Lcom/trilead/ssh2/crypto/digest/a;->e(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    .line 2
    invoke-static {v2}, Lj0/e;->b(Z)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v1, ":9001"

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    goto :goto_1

    .line 3
    :cond_3
    sget-object v0, Lg0/d;->f:Ljava/lang/String;

    .line 4
    invoke-static {v0}, Lg0/d;->c(Ljava/lang/String;)I

    move-result v0

    invoke-virtual {p0, v0}, Landroid/content/Context;->getString(I)Ljava/lang/String;

    move-result-object v0

    :goto_1
    const-string v1, "openvpn_bg"

    invoke-virtual {p0, v0, v1, p1}, Lxyz/chz/injector/HttpService;->e(Ljava/lang/String;Ljava/lang/String;Lg0/a;)V

    return-void
.end method

.method public final b()V
    .locals 2

    iget-object v0, p0, Lxyz/chz/injector/HttpService;->b:Landroid/os/Handler;

    new-instance v1, Lxyz/chz/injector/HttpService$c;

    invoke-direct {v1, p0}, Lxyz/chz/injector/HttpService$c;-><init>(Lxyz/chz/injector/HttpService;)V

    invoke-virtual {v0, v1}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    return-void
.end method

.method public final d()V
    .locals 7

    :try_start_0
    iget-object v0, p0, Lxyz/chz/injector/HttpService;->f:Landroid/net/ConnectivityManager;

    invoke-virtual {v0}, Landroid/net/ConnectivityManager;->getActiveNetworkInfo()Landroid/net/NetworkInfo;

    move-result-object v0

    if-nez v0, :cond_0

    const-string v0, "not connected"

    goto :goto_1

    :cond_0
    invoke-virtual {v0}, Landroid/net/NetworkInfo;->getSubtypeName()Ljava/lang/String;

    move-result-object v1
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    const-string v2, ""

    if-nez v1, :cond_1

    move-object v1, v2

    :cond_1
    :try_start_1
    invoke-virtual {v0}, Landroid/net/NetworkInfo;->getExtraInfo()Ljava/lang/String;

    move-result-object v3

    if-nez v3, :cond_2

    goto :goto_0

    :cond_2
    move-object v2, v3

    :goto_0
    const-string v3, "%2$s %4$s to %1$s %3$s"

    const/4 v4, 0x4

    new-array v4, v4, [Ljava/lang/Object;

    const/4 v5, 0x0

    invoke-virtual {v0}, Landroid/net/NetworkInfo;->getTypeName()Ljava/lang/String;

    move-result-object v6

    aput-object v6, v4, v5

    const/4 v5, 0x1

    invoke-virtual {v0}, Landroid/net/NetworkInfo;->getDetailedState()Landroid/net/NetworkInfo$DetailedState;

    move-result-object v0

    aput-object v0, v4, v5

    const/4 v0, 0x2

    aput-object v2, v4, v0

    const/4 v0, 0x3

    aput-object v1, v4, v0

    invoke-static {v3, v4}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v0
    :try_end_1
    .catch Ljava/lang/Exception; {:try_start_1 .. :try_end_1} :catch_0

    goto :goto_1

    :catch_0
    move-exception v0

    invoke-virtual {v0}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    move-result-object v0

    :goto_1
    invoke-static {v0}, Lg0/d;->h(Ljava/lang/String;)V

    sput-object v0, Lxyz/chz/injector/HttpService;->p:Ljava/lang/String;

    return-void
.end method

.method public final e(Ljava/lang/String;Ljava/lang/String;Lg0/a;)V
    .locals 8

    iget-object v0, p0, Lxyz/chz/injector/HttpService;->h:Lf0/a;

    invoke-static {v0}, Ljava/util/Objects;->requireNonNull(Ljava/lang/Object;)Ljava/lang/Object;

    .line 1
    invoke-virtual {p3}, Ljava/lang/Enum;->ordinal()I

    move-result v0

    const v1, 0x7f050002

    if-eqz v0, :cond_0

    const v0, 0x7f050001

    goto :goto_0

    :cond_0
    const v0, 0x7f050002

    .line 2
    :goto_0
    iget-object v2, p0, Lxyz/chz/injector/HttpService;->i:Landroid/app/Notification$Builder;

    const/4 v3, 0x1

    const/4 v4, 0x0

    if-nez v2, :cond_1

    new-instance v2, Landroid/app/Notification$Builder;

    invoke-direct {v2, p0}, Landroid/app/Notification$Builder;-><init>(Landroid/content/Context;)V

    const v5, 0x7f0b0002

    invoke-virtual {p0, v5}, Landroid/content/Context;->getString(I)Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v2, v5}, Landroid/app/Notification$Builder;->setContentTitle(Ljava/lang/CharSequence;)Landroid/app/Notification$Builder;

    move-result-object v2

    invoke-virtual {v2, v3}, Landroid/app/Notification$Builder;->setOnlyAlertOnce(Z)Landroid/app/Notification$Builder;

    move-result-object v2

    invoke-virtual {v2, v3}, Landroid/app/Notification$Builder;->setOngoing(Z)Landroid/app/Notification$Builder;

    move-result-object v2

    iput-object v2, p0, Lxyz/chz/injector/HttpService;->i:Landroid/app/Notification$Builder;

    .line 3
    new-instance v5, Landroid/content/Intent;

    const-class v6, Lxyz/chz/injector/MainReceiver;

    invoke-direct {v5, p0, v6}, Landroid/content/Intent;-><init>(Landroid/content/Context;Ljava/lang/Class;)V

    const-string v6, "sshTunnelServiceRestsrt"

    invoke-virtual {v5, v6}, Landroid/content/Intent;->setAction(Ljava/lang/String;)Landroid/content/Intent;

    const/high16 v6, 0x14000000

    invoke-static {p0, v4, v5, v6}, Landroid/app/PendingIntent;->getBroadcast(Landroid/content/Context;ILandroid/content/Intent;I)Landroid/app/PendingIntent;

    move-result-object v5

    const v7, 0x7f0b0024

    invoke-virtual {p0, v7}, Landroid/content/Context;->getString(I)Ljava/lang/String;

    move-result-object v7

    invoke-virtual {v2, v1, v7, v5}, Landroid/app/Notification$Builder;->addAction(ILjava/lang/CharSequence;Landroid/app/PendingIntent;)Landroid/app/Notification$Builder;

    new-instance v5, Landroid/content/Intent;

    const-class v7, Lxyz/chz/injector/MainReceiver;

    invoke-direct {v5, p0, v7}, Landroid/content/Intent;-><init>(Landroid/content/Context;Ljava/lang/Class;)V

    const-string v7, "sshtunnelservicestop"

    invoke-virtual {v5, v7}, Landroid/content/Intent;->setAction(Ljava/lang/String;)Landroid/content/Intent;

    invoke-static {p0, v4, v5, v6}, Landroid/app/PendingIntent;->getBroadcast(Landroid/content/Context;ILandroid/content/Intent;I)Landroid/app/PendingIntent;

    move-result-object v5

    const v6, 0x7f0b0044

    invoke-virtual {p0, v6}, Landroid/content/Context;->getString(I)Ljava/lang/String;

    move-result-object v6

    invoke-virtual {v2, v1, v6, v5}, Landroid/app/Notification$Builder;->addAction(ILjava/lang/CharSequence;Landroid/app/PendingIntent;)Landroid/app/Notification$Builder;

    .line 4
    iget-object v1, p0, Lxyz/chz/injector/HttpService;->i:Landroid/app/Notification$Builder;

    const-string v2, "service"

    .line 5
    invoke-virtual {v1, v2}, Landroid/app/Notification$Builder;->setCategory(Ljava/lang/String;)Landroid/app/Notification$Builder;

    invoke-virtual {v1, v3}, Landroid/app/Notification$Builder;->setLocalOnly(Z)Landroid/app/Notification$Builder;

    :cond_1
    const-string v1, "openvpn_bg"

    .line 6
    invoke-virtual {p2, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_2

    const/4 v1, -0x2

    goto :goto_1

    :cond_2
    const/4 v1, 0x0

    :goto_1
    iget-object v2, p0, Lxyz/chz/injector/HttpService;->i:Landroid/app/Notification$Builder;

    invoke-virtual {v2, v0}, Landroid/app/Notification$Builder;->setSmallIcon(I)Landroid/app/Notification$Builder;

    iget-object v0, p0, Lxyz/chz/injector/HttpService;->i:Landroid/app/Notification$Builder;

    invoke-virtual {v0, p1}, Landroid/app/Notification$Builder;->setContentText(Ljava/lang/CharSequence;)Landroid/app/Notification$Builder;

    sget-object v0, Lg0/a;->g:Lg0/a;

    const/4 v2, 0x0

    if-ne p3, v0, :cond_3

    const/high16 p3, 0x4000000

    invoke-static {p0, v4, v2, p3}, Landroid/app/PendingIntent;->getActivity(Landroid/content/Context;ILandroid/content/Intent;I)Landroid/app/PendingIntent;

    move-result-object p3

    iget-object v0, p0, Lxyz/chz/injector/HttpService;->i:Landroid/app/Notification$Builder;

    invoke-virtual {v0, p3}, Landroid/app/Notification$Builder;->setContentIntent(Landroid/app/PendingIntent;)Landroid/app/Notification$Builder;

    goto :goto_2

    :cond_3
    iget-object p3, p0, Lxyz/chz/injector/HttpService;->i:Landroid/app/Notification$Builder;

    invoke-static {p0}, Lxyz/chz/injector/HttpService;->c(Landroid/content/Context;)Landroid/app/PendingIntent;

    move-result-object v0

    invoke-virtual {p3, v0}, Landroid/app/Notification$Builder;->setContentIntent(Landroid/app/PendingIntent;)Landroid/app/Notification$Builder;

    :goto_2
    iget-object p3, p0, Lxyz/chz/injector/HttpService;->i:Landroid/app/Notification$Builder;

    if-eqz v1, :cond_4

    .line 7
    :try_start_0
    invoke-virtual {p3}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-result-object v0

    const-string v5, "setPriority"

    new-array v6, v3, [Ljava/lang/Class;

    sget-object v7, Ljava/lang/Integer;->TYPE:Ljava/lang/Class;

    aput-object v7, v6, v4

    invoke-virtual {v0, v5, v6}, Ljava/lang/Class;->getMethod(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;

    move-result-object v0

    new-array v5, v3, [Ljava/lang/Object;

    invoke-static {v1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v1

    aput-object v1, v5, v4

    invoke-virtual {v0, p3, v5}, Ljava/lang/reflect/Method;->invoke(Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;

    invoke-virtual {p3}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-result-object v0

    const-string v1, "setUsesChronometer"

    new-array v5, v3, [Ljava/lang/Class;

    sget-object v6, Ljava/lang/Boolean;->TYPE:Ljava/lang/Class;

    aput-object v6, v5, v4

    invoke-virtual {v0, v1, v5}, Ljava/lang/Class;->getMethod(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;

    move-result-object v0

    new-array v1, v3, [Ljava/lang/Object;

    sget-object v3, Ljava/lang/Boolean;->TRUE:Ljava/lang/Boolean;

    aput-object v3, v1, v4

    invoke-virtual {v0, p3, v1}, Ljava/lang/reflect/Method;->invoke(Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;
    :try_end_0
    .catch Ljava/lang/NoSuchMethodException; {:try_start_0 .. :try_end_0} :catch_3
    .catch Ljava/lang/IllegalArgumentException; {:try_start_0 .. :try_end_0} :catch_2
    .catch Ljava/lang/reflect/InvocationTargetException; {:try_start_0 .. :try_end_0} :catch_1
    .catch Ljava/lang/IllegalAccessException; {:try_start_0 .. :try_end_0} :catch_0

    goto :goto_4

    :catch_0
    move-exception p3

    goto :goto_3

    :catch_1
    move-exception p3

    goto :goto_3

    :catch_2
    move-exception p3

    goto :goto_3

    :catch_3
    move-exception p3

    .line 8
    :goto_3
    invoke-static {v2, p3}, Lg0/d;->f(Ljava/lang/String;Ljava/lang/Exception;)V

    .line 9
    :cond_4
    :goto_4
    sget p3, Landroid/os/Build$VERSION;->SDK_INT:I

    const/16 v0, 0x1a

    if-lt p3, v0, :cond_5

    iget-object p3, p0, Lxyz/chz/injector/HttpService;->i:Landroid/app/Notification$Builder;

    invoke-virtual {p3, p2}, Landroid/app/Notification$Builder;->setChannelId(Ljava/lang/String;)Landroid/app/Notification$Builder;

    :cond_5
    if-eqz p1, :cond_6

    const-string p3, ""

    invoke-virtual {p1, p3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p3

    if-nez p3, :cond_6

    iget-object p3, p0, Lxyz/chz/injector/HttpService;->i:Landroid/app/Notification$Builder;

    invoke-virtual {p3, p1}, Landroid/app/Notification$Builder;->setTicker(Ljava/lang/CharSequence;)Landroid/app/Notification$Builder;

    :cond_6
    iget-object p1, p0, Lxyz/chz/injector/HttpService;->i:Landroid/app/Notification$Builder;

    invoke-virtual {p1}, Landroid/app/Notification$Builder;->build()Landroid/app/Notification;

    move-result-object p1

    invoke-virtual {p2}, Ljava/lang/String;->hashCode()I

    move-result p3

    invoke-virtual {p0, p3, p1}, Landroid/app/Service;->startForeground(ILandroid/app/Notification;)V

    iget-object v0, p0, Lxyz/chz/injector/HttpService;->a:Landroid/app/NotificationManager;

    invoke-virtual {v0, p3, p1}, Landroid/app/NotificationManager;->notify(ILandroid/app/Notification;)V

    iget-object p1, p0, Lxyz/chz/injector/HttpService;->j:Ljava/lang/String;

    if-eqz p1, :cond_7

    invoke-virtual {p2, p1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p1

    if-nez p1, :cond_7

    iget-object p1, p0, Lxyz/chz/injector/HttpService;->a:Landroid/app/NotificationManager;

    iget-object p3, p0, Lxyz/chz/injector/HttpService;->j:Ljava/lang/String;

    invoke-virtual {p3}, Ljava/lang/String;->hashCode()I

    move-result p3

    invoke-virtual {p1, p3}, Landroid/app/NotificationManager;->cancel(I)V

    :cond_7
    iput-object p2, p0, Lxyz/chz/injector/HttpService;->j:Ljava/lang/String;

    return-void
.end method

.method public final declared-synchronized f()V
    .locals 3

    monitor-enter p0

    :try_start_0
    iget-object v0, p0, Lxyz/chz/injector/HttpService;->c:Lf0/a;

    .line 1
    iget-object v0, v0, Lf0/a;->c:Lk0/a;

    const-string v1, "tunnelType"

    const/4 v2, 0x1

    .line 2
    invoke-virtual {v0, v1, v2}, Lk0/a;->getInt(Ljava/lang/String;I)I

    iget-object v0, p0, Lxyz/chz/injector/HttpService;->e:Lh0/h;

    if-eqz v0, :cond_1

    invoke-virtual {v0}, Lh0/h;->k()V

    invoke-virtual {p0}, Lxyz/chz/injector/HttpService;->d()V

    iget-object v0, p0, Lxyz/chz/injector/HttpService;->d:Ljava/lang/Thread;

    if-eqz v0, :cond_0

    invoke-virtual {v0}, Ljava/lang/Thread;->interrupt()V

    :cond_0
    const/4 v0, 0x0

    iput-object v0, p0, Lxyz/chz/injector/HttpService;->e:Lh0/h;
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    :cond_1
    monitor-exit p0

    return-void

    :catchall_0
    move-exception v0

    monitor-exit p0

    throw v0
.end method

.method public final onBind(Landroid/content/Intent;)Landroid/os/IBinder;
    .locals 0

    iget-object p1, p0, Lxyz/chz/injector/HttpService;->g:Lxyz/chz/injector/HttpService$a;

    return-object p1
.end method

.method public final onCreate()V
    .locals 2

    const-string v0, "HttpService"

    const-string v1, "onCreate"

    invoke-static {v0, v1}, Landroid/util/Log;->i(Ljava/lang/String;Ljava/lang/String;)I

    invoke-super {p0}, Landroid/app/Service;->onCreate()V

    new-instance v0, Lf0/a;

    invoke-direct {v0, p0}, Lf0/a;-><init>(Landroid/content/Context;)V

    .line 1
    iget-object v0, v0, Lf0/a;->c:Lk0/a;

    .line 2
    sput-object v0, Lxyz/chz/injector/HttpService;->m:Lk0/a;

    new-instance v0, Lf0/a;

    invoke-direct {v0, p0}, Lf0/a;-><init>(Landroid/content/Context;)V

    iput-object v0, p0, Lxyz/chz/injector/HttpService;->c:Lf0/a;

    new-instance v0, Landroid/os/Handler;

    invoke-direct {v0}, Landroid/os/Handler;-><init>()V

    iput-object v0, p0, Lxyz/chz/injector/HttpService;->b:Landroid/os/Handler;

    new-instance v0, Lf0/a;

    invoke-direct {v0, p0}, Lf0/a;-><init>(Landroid/content/Context;)V

    iput-object v0, p0, Lxyz/chz/injector/HttpService;->h:Lf0/a;

    const-string v0, "connectivity"

    invoke-virtual {p0, v0}, Landroid/content/Context;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Landroid/net/ConnectivityManager;

    iput-object v0, p0, Lxyz/chz/injector/HttpService;->f:Landroid/net/ConnectivityManager;

    const-string v0, "notification"

    invoke-virtual {p0, v0}, Landroid/content/Context;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Landroid/app/NotificationManager;

    iput-object v0, p0, Lxyz/chz/injector/HttpService;->a:Landroid/app/NotificationManager;

    return-void
.end method

.method public final onDestroy()V
    .locals 2

    const-string v0, "HttpService"

    const-string v1, "onDestroy"

    invoke-static {v0, v1}, Landroid/util/Log;->i(Ljava/lang/String;Ljava/lang/String;)I

    invoke-super {p0}, Landroid/app/Service;->onDestroy()V

    invoke-virtual {p0}, Lxyz/chz/injector/HttpService;->f()V

    .line 1
    invoke-static {p0}, Lh/a;->a(Landroid/content/Context;)Lh/a;

    move-result-object v0

    iget-object v1, p0, Lxyz/chz/injector/HttpService;->l:Lxyz/chz/injector/HttpService$e;

    invoke-virtual {v0, v1}, Lh/a;->d(Landroid/content/BroadcastReceiver;)V

    sget v0, Landroid/os/Build$VERSION;->SDK_INT:I

    const/16 v1, 0x18

    if-lt v0, v1, :cond_0

    iget-object v0, p0, Lxyz/chz/injector/HttpService;->f:Landroid/net/ConnectivityManager;

    iget-object v1, p0, Lxyz/chz/injector/HttpService;->k:Lxyz/chz/injector/HttpService$d;

    invoke-virtual {v0, v1}, Landroid/net/ConnectivityManager;->unregisterNetworkCallback(Landroid/net/ConnectivityManager$NetworkCallback;)V

    .line 2
    :cond_0
    invoke-static {p0}, Lg0/d;->m(Lg0/d$b;)V

    return-void
.end method

.method public final onLowMemory()V
    .locals 1

    invoke-super {p0}, Landroid/app/Service;->onLowMemory()V

    const-string v0, "Low Memory Warning!"

    invoke-static {v0}, Lg0/d;->k(Ljava/lang/String;)V

    return-void
.end method

.method public final onStartCommand(Landroid/content/Intent;II)I
    .locals 1

    const-string p2, "HttpService"

    const-string p3, "onStartCommand"

    invoke-static {p2, p3}, Landroid/util/Log;->i(Ljava/lang/String;Ljava/lang/String;)I

    .line 1
    sget p2, Landroid/os/Build$VERSION;->SDK_INT:I

    const/16 p3, 0x18

    if-lt p2, p3, :cond_0

    iget-object p2, p0, Lxyz/chz/injector/HttpService;->f:Landroid/net/ConnectivityManager;

    iget-object p3, p0, Lxyz/chz/injector/HttpService;->k:Lxyz/chz/injector/HttpService$d;

    invoke-virtual {p2, p3}, Landroid/net/ConnectivityManager;->registerDefaultNetworkCallback(Landroid/net/ConnectivityManager$NetworkCallback;)V

    :cond_0
    new-instance p2, Landroid/content/IntentFilter;

    invoke-direct {p2}, Landroid/content/IntentFilter;-><init>()V

    sget-object p3, Lxyz/chz/injector/HttpService;->o:Ljava/lang/String;

    invoke-virtual {p2, p3}, Landroid/content/IntentFilter;->addAction(Ljava/lang/String;)V

    sget-object p3, Lxyz/chz/injector/HttpService;->n:Ljava/lang/String;

    invoke-virtual {p2, p3}, Landroid/content/IntentFilter;->addAction(Ljava/lang/String;)V

    invoke-static {p0}, Lh/a;->a(Landroid/content/Context;)Lh/a;

    move-result-object p3

    iget-object v0, p0, Lxyz/chz/injector/HttpService;->l:Lxyz/chz/injector/HttpService$e;

    invoke-virtual {p3, v0, p2}, Lh/a;->b(Landroid/content/BroadcastReceiver;Landroid/content/IntentFilter;)V

    .line 2
    invoke-static {p0}, Lg0/d;->a(Lg0/d$b;)V

    const/4 p2, 0x2

    if-eqz p1, :cond_1

    invoke-virtual {p1}, Landroid/content/Intent;->getAction()Ljava/lang/String;

    move-result-object p1

    const-string p3, "xyz.chz.injector:startTunnel"

    invoke-virtual {p3, p1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p1

    if-eqz p1, :cond_1

    return p2

    .line 3
    :cond_1
    sget-object p1, Lg0/d;->f:Ljava/lang/String;

    .line 4
    invoke-static {p1}, Lg0/d;->c(Ljava/lang/String;)I

    move-result p1

    invoke-virtual {p0, p1}, Landroid/content/Context;->getString(I)Ljava/lang/String;

    move-result-object p1

    sget-object p3, Lg0/a;->e:Lg0/a;

    const-string v0, "openvpn_newstat"

    invoke-virtual {p0, p1, v0, p3}, Lxyz/chz/injector/HttpService;->e(Ljava/lang/String;Ljava/lang/String;Lg0/a;)V

    new-instance p1, Ljava/lang/Thread;

    new-instance p3, Lxyz/chz/injector/HttpService$b;

    invoke-direct {p3, p0}, Lxyz/chz/injector/HttpService$b;-><init>(Lxyz/chz/injector/HttpService;)V

    invoke-direct {p1, p3}, Ljava/lang/Thread;-><init>(Ljava/lang/Runnable;)V

    invoke-virtual {p1}, Ljava/lang/Thread;->start()V

    return p2
.end method

.method public final onTaskRemoved(Landroid/content/Intent;)V
    .locals 1

    const-string p1, "HttpService"

    const-string v0, "task removed"

    invoke-static {p1, v0}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    new-instance p1, Landroid/content/Intent;

    const-class v0, Lxyz/chz/injector/DummyActivity;

    invoke-direct {p1, p0, v0}, Landroid/content/Intent;-><init>(Landroid/content/Context;Ljava/lang/Class;)V

    const/high16 v0, 0x14000000

    invoke-virtual {p1, v0}, Landroid/content/Intent;->addFlags(I)Landroid/content/Intent;

    invoke-virtual {p0, p1}, Landroid/content/Context;->startActivity(Landroid/content/Intent;)V

    return-void
.end method
