.class public final Lh0/h$a;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lh0/h;->k()V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1
    name = null
.end annotation


# instance fields
.field public final synthetic a:Lh0/h;


# direct methods
.method public constructor <init>(Lh0/h;)V
    .locals 0

    iput-object p1, p0, Lh0/h$a;->a:Lh0/h;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final run()V
    .locals 2

    iget-object v0, p0, Lh0/h$a;->a:Lh0/h;

    const/4 v1, 0x1

    .line 1
    iput-boolean v1, v0, Lh0/h;->e:Z

    .line 2
    iget-object v0, v0, Lh0/h;->h:Ljava/util/concurrent/CountDownLatch;

    if-eqz v0, :cond_0

    .line 3
    invoke-virtual {v0}, Ljava/util/concurrent/CountDownLatch;->countDown()V

    :cond_0
    iget-object v0, p0, Lh0/h$a;->a:Lh0/h;

    invoke-virtual {v0}, Lh0/h;->e()V

    const-wide/16 v0, 0x3e8

    :try_start_0
    invoke-static {v0, v1}, Ljava/lang/Thread;->sleep(J)V
    :try_end_0
    .catch Ljava/lang/InterruptedException; {:try_start_0 .. :try_end_0} :catch_0

    :catch_0
    iget-object v0, p0, Lh0/h$a;->a:Lh0/h;

    .line 4
    iget-object v0, v0, Lh0/h;->b:Landroid/content/Context;

    const v1, 0x7f0b0032

    .line 5
    invoke-virtual {v0, v1}, Landroid/content/Context;->getString(I)Ljava/lang/String;

    move-result-object v0

    const-string v1, "DESCONECTADO"

    invoke-static {v1, v0}, Lg0/d;->n(Ljava/lang/String;Ljava/lang/String;)V

    iget-object v0, p0, Lh0/h$a;->a:Lh0/h;

    .line 6
    invoke-static {v0}, Ljava/util/Objects;->requireNonNull(Ljava/lang/Object;)Ljava/lang/Object;

    .line 7
    iget-object v0, p0, Lh0/h$a;->a:Lh0/h;

    const/4 v1, 0x0

    .line 8
    iput-boolean v1, v0, Lh0/h;->f:Z

    .line 9
    iput-boolean v1, v0, Lh0/h;->m:Z

    return-void
.end method
