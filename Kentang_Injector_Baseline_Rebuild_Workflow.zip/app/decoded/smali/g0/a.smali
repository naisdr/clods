.class public final enum Lg0/a;
.super Ljava/lang/Enum;
.source "SourceFile"

# interfaces
.implements Landroid/os/Parcelable;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Enum<",
        "Lg0/a;",
        ">;",
        "Landroid/os/Parcelable;"
    }
.end annotation


# static fields
.field public static final CREATOR:Landroid/os/Parcelable$Creator;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Landroid/os/Parcelable$Creator<",
            "Lg0/a;",
            ">;"
        }
    .end annotation
.end field

.field public static final enum a:Lg0/a;

.field public static final enum b:Lg0/a;

.field public static final enum c:Lg0/a;

.field public static final enum d:Lg0/a;

.field public static final enum e:Lg0/a;

.field public static final enum f:Lg0/a;

.field public static final enum g:Lg0/a;

.field public static final enum h:Lg0/a;

.field public static final synthetic i:[Lg0/a;


# direct methods
.method public static constructor <clinit>()V
    .locals 16

    new-instance v0, Lg0/a;

    const-string v1, "LEVEL_CONNECTED"

    const/4 v2, 0x0

    invoke-direct {v0, v1, v2}, Lg0/a;-><init>(Ljava/lang/String;I)V

    sput-object v0, Lg0/a;->a:Lg0/a;

    new-instance v1, Lg0/a;

    const-string v3, "LEVEL_CONNECTING_SERVER_REPLIED"

    const/4 v4, 0x1

    invoke-direct {v1, v3, v4}, Lg0/a;-><init>(Ljava/lang/String;I)V

    sput-object v1, Lg0/a;->b:Lg0/a;

    new-instance v3, Lg0/a;

    const-string v5, "LEVEL_CONNECTING_NO_SERVER_REPLY_YET"

    const/4 v6, 0x2

    invoke-direct {v3, v5, v6}, Lg0/a;-><init>(Ljava/lang/String;I)V

    sput-object v3, Lg0/a;->c:Lg0/a;

    new-instance v5, Lg0/a;

    const-string v7, "LEVEL_NONETWORK"

    const/4 v8, 0x3

    invoke-direct {v5, v7, v8}, Lg0/a;-><init>(Ljava/lang/String;I)V

    new-instance v7, Lg0/a;

    const-string v9, "LEVEL_NOTCONNECTED"

    const/4 v10, 0x4

    invoke-direct {v7, v9, v10}, Lg0/a;-><init>(Ljava/lang/String;I)V

    sput-object v7, Lg0/a;->d:Lg0/a;

    new-instance v9, Lg0/a;

    const-string v11, "LEVEL_START"

    const/4 v12, 0x5

    invoke-direct {v9, v11, v12}, Lg0/a;-><init>(Ljava/lang/String;I)V

    sput-object v9, Lg0/a;->e:Lg0/a;

    new-instance v11, Lg0/a;

    const-string v13, "LEVEL_AUTH_FAILED"

    const/4 v14, 0x6

    invoke-direct {v11, v13, v14}, Lg0/a;-><init>(Ljava/lang/String;I)V

    sput-object v11, Lg0/a;->f:Lg0/a;

    new-instance v13, Lg0/a;

    const-string v15, "LEVEL_WAITING_FOR_USER_INPUT"

    const/4 v14, 0x7

    invoke-direct {v13, v15, v14}, Lg0/a;-><init>(Ljava/lang/String;I)V

    sput-object v13, Lg0/a;->g:Lg0/a;

    new-instance v15, Lg0/a;

    const-string v14, "UNKNOWN_LEVEL"

    const/16 v12, 0x8

    invoke-direct {v15, v14, v12}, Lg0/a;-><init>(Ljava/lang/String;I)V

    sput-object v15, Lg0/a;->h:Lg0/a;

    const/16 v14, 0x9

    new-array v14, v14, [Lg0/a;

    aput-object v0, v14, v2

    aput-object v1, v14, v4

    aput-object v3, v14, v6

    aput-object v5, v14, v8

    aput-object v7, v14, v10

    const/4 v0, 0x5

    aput-object v9, v14, v0

    const/4 v0, 0x6

    aput-object v11, v14, v0

    const/4 v0, 0x7

    aput-object v13, v14, v0

    aput-object v15, v14, v12

    sput-object v14, Lg0/a;->i:[Lg0/a;

    new-instance v0, Lg0/a$a;

    invoke-direct {v0}, Lg0/a$a;-><init>()V

    sput-object v0, Lg0/a;->CREATOR:Landroid/os/Parcelable$Creator;

    return-void
.end method

.method public constructor <init>(Ljava/lang/String;I)V
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()V"
        }
    .end annotation

    invoke-direct {p0, p1, p2}, Ljava/lang/Enum;-><init>(Ljava/lang/String;I)V

    return-void
.end method

.method public static valueOf(Ljava/lang/String;)Lg0/a;
    .locals 1

    const-class v0, Lg0/a;

    invoke-static {v0, p0}, Ljava/lang/Enum;->valueOf(Ljava/lang/Class;Ljava/lang/String;)Ljava/lang/Enum;

    move-result-object p0

    check-cast p0, Lg0/a;

    return-object p0
.end method

.method public static values()[Lg0/a;
    .locals 1

    sget-object v0, Lg0/a;->i:[Lg0/a;

    invoke-virtual {v0}, [Lg0/a;->clone()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, [Lg0/a;

    return-object v0
.end method


# virtual methods
.method public final describeContents()I
    .locals 1

    const/4 v0, 0x0

    return v0
.end method

.method public final writeToParcel(Landroid/os/Parcel;I)V
    .locals 0

    invoke-virtual {p0}, Ljava/lang/Enum;->ordinal()I

    move-result p2

    invoke-virtual {p1, p2}, Landroid/os/Parcel;->writeInt(I)V

    return-void
.end method
