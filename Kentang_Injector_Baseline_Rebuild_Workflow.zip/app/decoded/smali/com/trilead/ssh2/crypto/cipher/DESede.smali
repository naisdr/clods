.class public Lcom/trilead/ssh2/crypto/cipher/DESede;
.super Lcom/trilead/ssh2/crypto/cipher/DES;
.source "SourceFile"


# instance fields
.field public o:[I

.field public p:[I

.field public q:[I

.field public r:Z


# direct methods
.method public constructor <init>()V
    .locals 1

    invoke-direct {p0}, Lcom/trilead/ssh2/crypto/cipher/DES;-><init>()V

    const/4 v0, 0x0

    iput-object v0, p0, Lcom/trilead/ssh2/crypto/cipher/DESede;->o:[I

    iput-object v0, p0, Lcom/trilead/ssh2/crypto/cipher/DESede;->p:[I

    iput-object v0, p0, Lcom/trilead/ssh2/crypto/cipher/DESede;->q:[I

    return-void
.end method


# virtual methods
.method public final a()I
    .locals 1

    const/16 v0, 0x8

    return v0
.end method

.method public final b(Z[B)V
    .locals 2

    const/4 v0, 0x0

    invoke-virtual {p0, p1, p2, v0}, Lcom/trilead/ssh2/crypto/cipher/DES;->e(Z[BI)[I

    move-result-object v0

    iput-object v0, p0, Lcom/trilead/ssh2/crypto/cipher/DESede;->o:[I

    xor-int/lit8 v0, p1, 0x1

    const/16 v1, 0x8

    invoke-virtual {p0, v0, p2, v1}, Lcom/trilead/ssh2/crypto/cipher/DES;->e(Z[BI)[I

    move-result-object v0

    iput-object v0, p0, Lcom/trilead/ssh2/crypto/cipher/DESede;->p:[I

    const/16 v0, 0x10

    invoke-virtual {p0, p1, p2, v0}, Lcom/trilead/ssh2/crypto/cipher/DES;->e(Z[BI)[I

    move-result-object p2

    iput-object p2, p0, Lcom/trilead/ssh2/crypto/cipher/DESede;->q:[I

    iput-boolean p1, p0, Lcom/trilead/ssh2/crypto/cipher/DESede;->r:Z

    return-void
.end method

.method public final c([BI[BI)V
    .locals 6

    iget-object v1, p0, Lcom/trilead/ssh2/crypto/cipher/DESede;->o:[I

    if-eqz v1, :cond_1

    iget-boolean v0, p0, Lcom/trilead/ssh2/crypto/cipher/DESede;->r:Z

    if-eqz v0, :cond_0

    move-object v0, p0

    move-object v2, p1

    move v3, p2

    move-object v4, p3

    move v5, p4

    invoke-virtual/range {v0 .. v5}, Lcom/trilead/ssh2/crypto/cipher/DES;->d([I[BI[BI)V

    iget-object v1, p0, Lcom/trilead/ssh2/crypto/cipher/DESede;->p:[I

    move-object v2, p3

    move v3, p4

    invoke-virtual/range {v0 .. v5}, Lcom/trilead/ssh2/crypto/cipher/DES;->d([I[BI[BI)V

    iget-object v1, p0, Lcom/trilead/ssh2/crypto/cipher/DESede;->q:[I

    invoke-virtual/range {v0 .. v5}, Lcom/trilead/ssh2/crypto/cipher/DES;->d([I[BI[BI)V

    goto :goto_0

    :cond_0
    iget-object v1, p0, Lcom/trilead/ssh2/crypto/cipher/DESede;->q:[I

    move-object v0, p0

    move-object v2, p1

    move v3, p2

    move-object v4, p3

    move v5, p4

    invoke-virtual/range {v0 .. v5}, Lcom/trilead/ssh2/crypto/cipher/DES;->d([I[BI[BI)V

    iget-object v1, p0, Lcom/trilead/ssh2/crypto/cipher/DESede;->p:[I

    move-object v2, p3

    move v3, p4

    invoke-virtual/range {v0 .. v5}, Lcom/trilead/ssh2/crypto/cipher/DES;->d([I[BI[BI)V

    iget-object v1, p0, Lcom/trilead/ssh2/crypto/cipher/DESede;->o:[I

    invoke-virtual/range {v0 .. v5}, Lcom/trilead/ssh2/crypto/cipher/DES;->d([I[BI[BI)V

    :goto_0
    return-void

    :cond_1
    new-instance v0, Ljava/lang/IllegalStateException;

    const-string v1, "DESede engine not initialised!"

    invoke-direct {v0, v1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    throw v0
.end method
