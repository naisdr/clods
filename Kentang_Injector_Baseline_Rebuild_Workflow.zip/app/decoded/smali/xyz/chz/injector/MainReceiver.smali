.class public Lxyz/chz/injector/MainReceiver;
.super Landroid/content/BroadcastReceiver;
.source "SourceFile"


# direct methods
.method public constructor <init>()V
    .locals 0

    invoke-direct {p0}, Landroid/content/BroadcastReceiver;-><init>()V

    return-void
.end method


# virtual methods
.method public final onReceive(Landroid/content/Context;Landroid/content/Intent;)V
    .locals 1

    invoke-virtual {p2}, Landroid/content/Intent;->getAction()Ljava/lang/String;

    move-result-object p2

    if-nez p2, :cond_0

    return-void

    :cond_0
    const-string v0, "sshtunnelservicestop"

    invoke-virtual {p2, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_2

    const-string v0, "sshTunnelServiceRestsrt"

    invoke-virtual {p2, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p2

    if-nez p2, :cond_1

    goto :goto_0

    :cond_1
    new-instance p2, Landroid/content/Intent;

    sget-object v0, Lxyz/chz/injector/HttpService;->n:Ljava/lang/String;

    invoke-direct {p2, v0}, Landroid/content/Intent;-><init>(Ljava/lang/String;)V

    invoke-static {p1}, Lh/a;->a(Landroid/content/Context;)Lh/a;

    move-result-object p1

    invoke-virtual {p1, p2}, Lh/a;->c(Landroid/content/Intent;)Z

    goto :goto_0

    :cond_2
    new-instance p2, Landroid/content/Intent;

    sget-object v0, Lxyz/chz/injector/HttpService;->o:Ljava/lang/String;

    invoke-direct {p2, v0}, Landroid/content/Intent;-><init>(Ljava/lang/String;)V

    invoke-static {p1}, Lh/a;->a(Landroid/content/Context;)Lh/a;

    move-result-object p1

    invoke-virtual {p1, p2}, Lh/a;->c(Landroid/content/Intent;)Z

    :goto_0
    return-void
.end method
