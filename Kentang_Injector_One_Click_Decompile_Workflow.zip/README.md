# Kentang Injector 2.7.0 — workflow dekompilasi awal

## Cara menjalankan
1. Buat repository GitHub baru.
2. Upload seluruh isi ZIP ini ke root repository (termasuk folder `.github`).
3. Buka tab **Actions**.
4. Pilih workflow **Analyze and Decompile Kentang Injector**.
5. Tekan **Run workflow**.
6. Setelah selesai, buka hasil run dan unduh artifact `kentang-injector-decompiled-analysis`.

## Apa yang dihasilkan
- `apktool/`: hasil decode resource dan AndroidManifest.
- `jadx/`: hasil dekompilasi DEX menjadi tampilan kode Java.
- `apk-metadata.txt`: metadata dan daftar isi APK.

## Batasan penting
Workflow ini adalah tahap pemeriksaan/reverse engineering otomatis. Hasil JADX/APKTool **belum merupakan source project Android asli yang siap di-build**. Dekompilasi tidak otomatis memulihkan file Gradle, source Kotlin/Java asli, konfigurasi signing, atau seluruh dependensi. Setelah hasil artifact diperiksa, struktur proyek dan bagian VPN perlu direkonstruksi sebelum workflow build APK final dibuat.

Jangan menghapus APK dari folder `input/` sebelum workflow dijalankan.
