.class public final Li0/a$a;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ljava/lang/Comparable;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Li0/a;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x9
    name = "a"
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Object;",
        "Ljava/lang/Comparable<",
        "Li0/a$a;",
        ">;"
    }
.end annotation


# instance fields
.field public a:Ljava/math/BigInteger;

.field public b:I

.field public c:Z

.field public d:Z

.field public e:Ljava/math/BigInteger;

.field public f:Ljava/math/BigInteger;


# direct methods
.method public constructor <init>(Ld/a;Z)V
    .locals 5

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-boolean p2, p0, Li0/a$a;->c:Z

    .line 1
    iget-object p2, p1, Ld/a;->c:Ljava/lang/Object;

    check-cast p2, Ljava/lang/String;

    const-string v0, "\\."

    .line 2
    invoke-virtual {p2, v0}, Ljava/lang/String;->split(Ljava/lang/String;)[Ljava/lang/String;

    move-result-object p2

    const/4 v0, 0x0

    aget-object v0, p2, v0

    invoke-static {v0}, Ljava/lang/Long;->parseLong(Ljava/lang/String;)J

    move-result-wide v0

    const/16 v2, 0x18

    shl-long/2addr v0, v2

    const-wide/16 v2, 0x0

    add-long/2addr v0, v2

    const/4 v2, 0x1

    aget-object v3, p2, v2

    invoke-static {v3}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I

    move-result v3

    shl-int/lit8 v3, v3, 0x10

    int-to-long v3, v3

    add-long/2addr v0, v3

    const/4 v3, 0x2

    aget-object v3, p2, v3

    invoke-static {v3}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I

    move-result v3

    shl-int/lit8 v3, v3, 0x8

    int-to-long v3, v3

    add-long/2addr v0, v3

    const/4 v3, 0x3

    aget-object p2, p2, v3

    invoke-static {p2}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I

    move-result p2

    int-to-long v3, p2

    add-long/2addr v0, v3

    .line 3
    invoke-static {v0, v1}, Ljava/math/BigInteger;->valueOf(J)Ljava/math/BigInteger;

    move-result-object p2

    iput-object p2, p0, Li0/a$a;->a:Ljava/math/BigInteger;

    iget p1, p1, Ld/a;->b:I

    iput p1, p0, Li0/a$a;->b:I

    iput-boolean v2, p0, Li0/a$a;->d:Z

    return-void
.end method

.method public constructor <init>(Ljava/math/BigInteger;IZZ)V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Li0/a$a;->a:Ljava/math/BigInteger;

    iput p2, p0, Li0/a$a;->b:I

    iput-boolean p3, p0, Li0/a$a;->c:Z

    iput-boolean p4, p0, Li0/a$a;->d:Z

    return-void
.end method


# virtual methods
.method public final a(Li0/a$a;)Z
    .locals 4

    invoke-virtual {p0}, Li0/a$a;->b()Ljava/math/BigInteger;

    move-result-object v0

    invoke-virtual {p0}, Li0/a$a;->d()Ljava/math/BigInteger;

    move-result-object v1

    invoke-virtual {p1}, Li0/a$a;->b()Ljava/math/BigInteger;

    move-result-object v2

    invoke-virtual {p1}, Li0/a$a;->d()Ljava/math/BigInteger;

    move-result-object p1

    invoke-virtual {v0, v2}, Ljava/math/BigInteger;->compareTo(Ljava/math/BigInteger;)I

    move-result v0

    const/4 v2, 0x0

    const/4 v3, 0x1

    if-eq v0, v3, :cond_0

    const/4 v0, 0x1

    goto :goto_0

    :cond_0
    const/4 v0, 0x0

    :goto_0
    invoke-virtual {v1, p1}, Ljava/math/BigInteger;->compareTo(Ljava/math/BigInteger;)I

    move-result p1

    const/4 v1, -0x1

    if-eq p1, v1, :cond_1

    const/4 p1, 0x1

    goto :goto_1

    :cond_1
    const/4 p1, 0x0

    :goto_1
    if-eqz v0, :cond_2

    if-eqz p1, :cond_2

    const/4 v2, 0x1

    :cond_2
    return v2
.end method

.method public final b()Ljava/math/BigInteger;
    .locals 1

    iget-object v0, p0, Li0/a$a;->e:Ljava/math/BigInteger;

    if-nez v0, :cond_0

    const/4 v0, 0x0

    invoke-virtual {p0, v0}, Li0/a$a;->e(Z)Ljava/math/BigInteger;

    move-result-object v0

    iput-object v0, p0, Li0/a$a;->e:Ljava/math/BigInteger;

    :cond_0
    iget-object v0, p0, Li0/a$a;->e:Ljava/math/BigInteger;

    return-object v0
.end method

.method public final c()Ljava/lang/String;
    .locals 9

    iget-object v0, p0, Li0/a$a;->a:Ljava/math/BigInteger;

    invoke-virtual {v0}, Ljava/math/BigInteger;->longValue()J

    move-result-wide v0

    sget-object v2, Ljava/util/Locale;->US:Ljava/util/Locale;

    const/4 v3, 0x4

    new-array v3, v3, [Ljava/lang/Object;

    const/4 v4, 0x0

    const/16 v5, 0x18

    shr-long v5, v0, v5

    const-wide/16 v7, 0x100

    rem-long/2addr v5, v7

    invoke-static {v5, v6}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v5

    aput-object v5, v3, v4

    const/4 v4, 0x1

    const/16 v5, 0x10

    shr-long v5, v0, v5

    rem-long/2addr v5, v7

    invoke-static {v5, v6}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v5

    aput-object v5, v3, v4

    const/4 v4, 0x2

    const/16 v5, 0x8

    shr-long v5, v0, v5

    rem-long/2addr v5, v7

    invoke-static {v5, v6}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v5

    aput-object v5, v3, v4

    const/4 v4, 0x3

    rem-long/2addr v0, v7

    invoke-static {v0, v1}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v0

    aput-object v0, v3, v4

    const-string v0, "%d.%d.%d.%d"

    invoke-static {v2, v0, v3}, Ljava/lang/String;->format(Ljava/util/Locale;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method

.method public final compareTo(Ljava/lang/Object;)I
    .locals 2

    check-cast p1, Li0/a$a;

    invoke-virtual {p0}, Li0/a$a;->b()Ljava/math/BigInteger;

    move-result-object v0

    invoke-virtual {p1}, Li0/a$a;->b()Ljava/math/BigInteger;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/math/BigInteger;->compareTo(Ljava/math/BigInteger;)I

    move-result v0

    if-eqz v0, :cond_0

    goto :goto_0

    :cond_0
    iget v0, p0, Li0/a$a;->b:I

    iget p1, p1, Li0/a$a;->b:I

    if-le v0, p1, :cond_1

    const/4 v0, -0x1

    goto :goto_0

    :cond_1
    if-ne p1, v0, :cond_2

    const/4 v0, 0x0

    goto :goto_0

    :cond_2
    const/4 v0, 0x1

    :goto_0
    return v0
.end method

.method public final d()Ljava/math/BigInteger;
    .locals 1

    iget-object v0, p0, Li0/a$a;->f:Ljava/math/BigInteger;

    if-nez v0, :cond_0

    const/4 v0, 0x1

    invoke-virtual {p0, v0}, Li0/a$a;->e(Z)Ljava/math/BigInteger;

    move-result-object v0

    iput-object v0, p0, Li0/a$a;->f:Ljava/math/BigInteger;

    :cond_0
    iget-object v0, p0, Li0/a$a;->f:Ljava/math/BigInteger;

    return-object v0
.end method

.method public final e(Z)Ljava/math/BigInteger;
    .locals 3

    iget-object v0, p0, Li0/a$a;->a:Ljava/math/BigInteger;

    iget-boolean v1, p0, Li0/a$a;->d:Z

    if-eqz v1, :cond_0

    iget v1, p0, Li0/a$a;->b:I

    rsub-int/lit8 v1, v1, 0x20

    goto :goto_0

    :cond_0
    iget v1, p0, Li0/a$a;->b:I

    rsub-int v1, v1, 0x80

    :goto_0
    const/4 v2, 0x0

    :goto_1
    if-ge v2, v1, :cond_2

    if-eqz p1, :cond_1

    invoke-virtual {v0, v2}, Ljava/math/BigInteger;->setBit(I)Ljava/math/BigInteger;

    move-result-object v0

    goto :goto_2

    :cond_1
    invoke-virtual {v0, v2}, Ljava/math/BigInteger;->clearBit(I)Ljava/math/BigInteger;

    move-result-object v0

    :goto_2
    add-int/lit8 v2, v2, 0x1

    goto :goto_1

    :cond_2
    return-object v0
.end method

.method public final equals(Ljava/lang/Object;)Z
    .locals 2

    instance-of v0, p1, Li0/a$a;

    if-nez v0, :cond_0

    invoke-super {p0, p1}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    move-result p1

    return p1

    :cond_0
    check-cast p1, Li0/a$a;

    iget v0, p0, Li0/a$a;->b:I

    iget v1, p1, Li0/a$a;->b:I

    if-ne v0, v1, :cond_1

    invoke-virtual {p1}, Li0/a$a;->b()Ljava/math/BigInteger;

    move-result-object p1

    invoke-virtual {p0}, Li0/a$a;->b()Ljava/math/BigInteger;

    move-result-object v0

    invoke-virtual {p1, v0}, Ljava/math/BigInteger;->equals(Ljava/lang/Object;)Z

    move-result p1

    if-eqz p1, :cond_1

    const/4 p1, 0x1

    goto :goto_0

    :cond_1
    const/4 p1, 0x0

    :goto_0
    return p1
.end method

.method public final f()[Li0/a$a;
    .locals 7

    new-instance v0, Li0/a$a;

    invoke-virtual {p0}, Li0/a$a;->b()Ljava/math/BigInteger;

    move-result-object v1

    iget v2, p0, Li0/a$a;->b:I

    const/4 v3, 0x1

    add-int/2addr v2, v3

    iget-boolean v4, p0, Li0/a$a;->c:Z

    iget-boolean v5, p0, Li0/a$a;->d:Z

    invoke-direct {v0, v1, v2, v4, v5}, Li0/a$a;-><init>(Ljava/math/BigInteger;IZZ)V

    new-instance v1, Li0/a$a;

    invoke-virtual {v0}, Li0/a$a;->d()Ljava/math/BigInteger;

    move-result-object v2

    sget-object v4, Ljava/math/BigInteger;->ONE:Ljava/math/BigInteger;

    invoke-virtual {v2, v4}, Ljava/math/BigInteger;->add(Ljava/math/BigInteger;)Ljava/math/BigInteger;

    move-result-object v2

    iget v4, p0, Li0/a$a;->b:I

    add-int/2addr v4, v3

    iget-boolean v5, p0, Li0/a$a;->c:Z

    iget-boolean v6, p0, Li0/a$a;->d:Z

    invoke-direct {v1, v2, v4, v5, v6}, Li0/a$a;-><init>(Ljava/math/BigInteger;IZZ)V

    const/4 v2, 0x2

    new-array v2, v2, [Li0/a$a;

    const/4 v4, 0x0

    aput-object v0, v2, v4

    aput-object v1, v2, v3

    return-object v2
.end method

.method public final toString()Ljava/lang/String;
    .locals 14

    iget-boolean v0, p0, Li0/a$a;->d:Z

    const-string v1, "%s/%d"

    const/4 v2, 0x2

    const/4 v3, 0x1

    const/4 v4, 0x0

    if-eqz v0, :cond_0

    sget-object v0, Ljava/util/Locale;->US:Ljava/util/Locale;

    new-array v2, v2, [Ljava/lang/Object;

    invoke-virtual {p0}, Li0/a$a;->c()Ljava/lang/String;

    move-result-object v5

    aput-object v5, v2, v4

    iget v4, p0, Li0/a$a;->b:I

    invoke-static {v4}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v4

    aput-object v4, v2, v3

    invoke-static {v0, v1, v2}, Ljava/lang/String;->format(Ljava/util/Locale;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v0

    return-object v0

    :cond_0
    sget-object v0, Ljava/util/Locale;->US:Ljava/util/Locale;

    new-array v5, v2, [Ljava/lang/Object;

    .line 1
    iget-object v6, p0, Li0/a$a;->a:Ljava/math/BigInteger;

    const/4 v7, 0x0

    const/4 v8, 0x1

    :goto_0
    sget-object v9, Ljava/math/BigInteger;->ZERO:Ljava/math/BigInteger;

    invoke-virtual {v6, v9}, Ljava/math/BigInteger;->compareTo(Ljava/math/BigInteger;)I

    move-result v9

    if-ne v9, v3, :cond_5

    const-wide/32 v9, 0x10000

    invoke-static {v9, v10}, Ljava/math/BigInteger;->valueOf(J)Ljava/math/BigInteger;

    move-result-object v9

    invoke-virtual {v6, v9}, Ljava/math/BigInteger;->mod(Ljava/math/BigInteger;)Ljava/math/BigInteger;

    move-result-object v9

    invoke-virtual {v9}, Ljava/math/BigInteger;->longValue()J

    move-result-wide v9

    if-nez v7, :cond_1

    const-wide/16 v11, 0x0

    cmp-long v13, v9, v11

    if-eqz v13, :cond_4

    :cond_1
    if-nez v7, :cond_2

    if-nez v8, :cond_2

    const-string v7, ":"

    :cond_2
    if-eqz v8, :cond_3

    sget-object v8, Ljava/util/Locale;->US:Ljava/util/Locale;

    new-array v11, v2, [Ljava/lang/Object;

    invoke-static {v9, v10}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v9

    aput-object v9, v11, v4

    aput-object v7, v11, v3

    const-string v7, "%x"

    invoke-static {v8, v7, v11}, Ljava/lang/String;->format(Ljava/util/Locale;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v7

    goto :goto_1

    :cond_3
    sget-object v8, Ljava/util/Locale;->US:Ljava/util/Locale;

    new-array v11, v2, [Ljava/lang/Object;

    invoke-static {v9, v10}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v9

    aput-object v9, v11, v4

    aput-object v7, v11, v3

    const-string v7, "%x:%s"

    invoke-static {v8, v7, v11}, Ljava/lang/String;->format(Ljava/util/Locale;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v7

    :cond_4
    :goto_1
    const/16 v8, 0x10

    invoke-virtual {v6, v8}, Ljava/math/BigInteger;->shiftRight(I)Ljava/math/BigInteger;

    move-result-object v6

    const/4 v8, 0x0

    goto :goto_0

    :cond_5
    if-nez v7, :cond_6

    const-string v7, "::"

    :cond_6
    aput-object v7, v5, v4

    .line 2
    iget v2, p0, Li0/a$a;->b:I

    invoke-static {v2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v2

    aput-object v2, v5, v3

    invoke-static {v0, v1, v5}, Ljava/lang/String;->format(Ljava/util/Locale;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method
