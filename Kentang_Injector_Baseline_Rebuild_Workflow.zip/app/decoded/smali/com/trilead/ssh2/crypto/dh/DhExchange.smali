.class public Lcom/trilead/ssh2/crypto/dh/DhExchange;
.super Ljava/lang/Object;
.source "SourceFile"


# static fields
.field public static final g:La/b;

.field public static final h:Ljava/math/BigInteger;

.field public static final i:Ljava/math/BigInteger;

.field public static final j:Ljava/math/BigInteger;


# instance fields
.field public a:Ljava/math/BigInteger;

.field public b:Ljava/math/BigInteger;

.field public c:Ljava/math/BigInteger;

.field public d:Ljava/math/BigInteger;

.field public e:Ljava/math/BigInteger;

.field public final f:Ljava/lang/String;


# direct methods
.method public static constructor <clinit>()V
    .locals 3

    const-class v0, Lcom/trilead/ssh2/crypto/dh/DhExchange;

    .line 1
    new-instance v1, La/b;

    invoke-direct {v1, v0}, La/b;-><init>(Ljava/lang/Class;)V

    .line 2
    sput-object v1, Lcom/trilead/ssh2/crypto/dh/DhExchange;->g:La/b;

    new-instance v0, Ljava/math/BigInteger;

    const-string v1, "179769313486231590770839156793787453197860296048756011706444423684197180216158519368947833795864925541502180565485980503646440548199239100050792877003355816639229553136239076508735759914822574862575007425302077447712589550957937778424442426617334727629299387668709205606050270810842907692932019128194467627007"

    invoke-direct {v0, v1}, Ljava/math/BigInteger;-><init>(Ljava/lang/String;)V

    sput-object v0, Lcom/trilead/ssh2/crypto/dh/DhExchange;->h:Ljava/math/BigInteger;

    new-instance v0, Ljava/math/BigInteger;

    const/16 v1, 0x10

    const-string v2, "FFFFFFFFFFFFFFFFC90FDAA22168C234C4C6628B80DC1CD129024E088A67CC74020BBEA63B139B22514A08798E3404DDEF9519B3CD3A431B302B0A6DF25F14374FE1356D6D51C245E485B576625E7EC6F44C42E9A637ED6B0BFF5CB6F406B7EDEE386BFB5A899FA5AE9F24117C4B1FE649286651ECE45B3DC2007CB8A163BF0598DA48361C55D39A69163FA8FD24CF5F83655D23DCA3AD961C62F356208552BB9ED529077096966D670C354E4ABC9804F1746C08CA18217C32905E462E36CE3BE39E772C180E86039B2783A2EC07A28FB5C55DF06F4C52C9DE2BCBF6955817183995497CEA956AE515D2261898FA051015728E5A8AACAA68FFFFFFFFFFFFFFFF"

    invoke-direct {v0, v2, v1}, Ljava/math/BigInteger;-><init>(Ljava/lang/String;I)V

    sput-object v0, Lcom/trilead/ssh2/crypto/dh/DhExchange;->i:Ljava/math/BigInteger;

    new-instance v0, Ljava/math/BigInteger;

    const-string v1, "2"

    invoke-direct {v0, v1}, Ljava/math/BigInteger;-><init>(Ljava/lang/String;)V

    sput-object v0, Lcom/trilead/ssh2/crypto/dh/DhExchange;->j:Ljava/math/BigInteger;

    return-void
.end method

.method public constructor <init>()V
    .locals 1
    .annotation runtime Ljava/lang/Deprecated;
    .end annotation

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const-string v0, "SHA1"

    iput-object v0, p0, Lcom/trilead/ssh2/crypto/dh/DhExchange;->f:Ljava/lang/String;

    return-void
.end method

.method public constructor <init>(Ljava/lang/String;)V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const-string p1, "SHA1"

    iput-object p1, p0, Lcom/trilead/ssh2/crypto/dh/DhExchange;->f:Ljava/lang/String;

    return-void
.end method


# virtual methods
.method public final a([B[B[B[B[B)[B
    .locals 2

    new-instance v0, Lcom/trilead/ssh2/crypto/digest/HashForSSH2Types;

    .line 1
    iget-object v1, p0, Lcom/trilead/ssh2/crypto/dh/DhExchange;->f:Ljava/lang/String;

    .line 2
    invoke-direct {v0, v1}, Lcom/trilead/ssh2/crypto/digest/HashForSSH2Types;-><init>(Ljava/lang/String;)V

    sget-object v1, Lcom/trilead/ssh2/crypto/dh/DhExchange;->g:La/b;

    invoke-static {v1}, Ljava/util/Objects;->requireNonNull(Ljava/lang/Object;)Ljava/lang/Object;

    .line 3
    array-length v1, p1

    invoke-virtual {v0, v1}, Lcom/trilead/ssh2/crypto/digest/HashForSSH2Types;->e(I)V

    invoke-virtual {v0, p1}, Lcom/trilead/ssh2/crypto/digest/HashForSSH2Types;->d([B)V

    array-length p1, p2

    invoke-virtual {v0, p1}, Lcom/trilead/ssh2/crypto/digest/HashForSSH2Types;->e(I)V

    invoke-virtual {v0, p2}, Lcom/trilead/ssh2/crypto/digest/HashForSSH2Types;->d([B)V

    array-length p1, p3

    invoke-virtual {v0, p1}, Lcom/trilead/ssh2/crypto/digest/HashForSSH2Types;->e(I)V

    invoke-virtual {v0, p3}, Lcom/trilead/ssh2/crypto/digest/HashForSSH2Types;->d([B)V

    array-length p1, p4

    invoke-virtual {v0, p1}, Lcom/trilead/ssh2/crypto/digest/HashForSSH2Types;->e(I)V

    invoke-virtual {v0, p4}, Lcom/trilead/ssh2/crypto/digest/HashForSSH2Types;->d([B)V

    array-length p1, p5

    invoke-virtual {v0, p1}, Lcom/trilead/ssh2/crypto/digest/HashForSSH2Types;->e(I)V

    invoke-virtual {v0, p5}, Lcom/trilead/ssh2/crypto/digest/HashForSSH2Types;->d([B)V

    .line 4
    iget-object p1, p0, Lcom/trilead/ssh2/crypto/dh/DhExchange;->b:Ljava/math/BigInteger;

    invoke-virtual {v0, p1}, Lcom/trilead/ssh2/crypto/digest/HashForSSH2Types;->b(Ljava/math/BigInteger;)V

    iget-object p1, p0, Lcom/trilead/ssh2/crypto/dh/DhExchange;->d:Ljava/math/BigInteger;

    invoke-virtual {v0, p1}, Lcom/trilead/ssh2/crypto/digest/HashForSSH2Types;->b(Ljava/math/BigInteger;)V

    iget-object p1, p0, Lcom/trilead/ssh2/crypto/dh/DhExchange;->e:Ljava/math/BigInteger;

    invoke-virtual {v0, p1}, Lcom/trilead/ssh2/crypto/digest/HashForSSH2Types;->b(Ljava/math/BigInteger;)V

    invoke-virtual {v0}, Lcom/trilead/ssh2/crypto/digest/HashForSSH2Types;->a()[B

    move-result-object p1

    return-object p1
.end method

.method public final b()Ljava/math/BigInteger;
    .locals 2

    iget-object v0, p0, Lcom/trilead/ssh2/crypto/dh/DhExchange;->b:Ljava/math/BigInteger;

    if-eqz v0, :cond_0

    return-object v0

    :cond_0
    new-instance v0, Ljava/lang/IllegalStateException;

    const-string v1, "DhDsaExchange not initialized!"

    invoke-direct {v0, v1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    throw v0
.end method

.method public final c()Ljava/lang/String;
    .locals 1

    iget-object v0, p0, Lcom/trilead/ssh2/crypto/dh/DhExchange;->f:Ljava/lang/String;

    return-object v0
.end method

.method public final d()Ljava/math/BigInteger;
    .locals 2

    iget-object v0, p0, Lcom/trilead/ssh2/crypto/dh/DhExchange;->e:Ljava/math/BigInteger;

    if-eqz v0, :cond_0

    return-object v0

    :cond_0
    new-instance v0, Ljava/lang/IllegalStateException;

    const-string v1, "Shared secret not yet known, need f first!"

    invoke-direct {v0, v1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    throw v0
.end method

.method public final e(ILjava/security/SecureRandom;)V
    .locals 2

    const/4 v0, 0x0

    iput-object v0, p0, Lcom/trilead/ssh2/crypto/dh/DhExchange;->e:Ljava/math/BigInteger;

    const/4 v0, 0x1

    if-ne p1, v0, :cond_0

    sget-object p1, Lcom/trilead/ssh2/crypto/dh/DhExchange;->h:Ljava/math/BigInteger;

    goto :goto_0

    :cond_0
    const/16 v1, 0xe

    if-ne p1, v1, :cond_1

    sget-object p1, Lcom/trilead/ssh2/crypto/dh/DhExchange;->i:Ljava/math/BigInteger;

    :goto_0
    iput-object p1, p0, Lcom/trilead/ssh2/crypto/dh/DhExchange;->a:Ljava/math/BigInteger;

    new-instance p1, Ljava/math/BigInteger;

    iget-object v1, p0, Lcom/trilead/ssh2/crypto/dh/DhExchange;->a:Ljava/math/BigInteger;

    invoke-virtual {v1}, Ljava/math/BigInteger;->bitLength()I

    move-result v1

    sub-int/2addr v1, v0

    invoke-direct {p1, v1, p2}, Ljava/math/BigInteger;-><init>(ILjava/util/Random;)V

    iput-object p1, p0, Lcom/trilead/ssh2/crypto/dh/DhExchange;->c:Ljava/math/BigInteger;

    sget-object p2, Lcom/trilead/ssh2/crypto/dh/DhExchange;->j:Ljava/math/BigInteger;

    iget-object v0, p0, Lcom/trilead/ssh2/crypto/dh/DhExchange;->a:Ljava/math/BigInteger;

    invoke-virtual {p2, p1, v0}, Ljava/math/BigInteger;->modPow(Ljava/math/BigInteger;Ljava/math/BigInteger;)Ljava/math/BigInteger;

    move-result-object p1

    iput-object p1, p0, Lcom/trilead/ssh2/crypto/dh/DhExchange;->b:Ljava/math/BigInteger;

    return-void

    :cond_1
    new-instance p2, Ljava/lang/IllegalArgumentException;

    const-string v0, "Unknown DH group "

    .line 1
    invoke-static {v0, p1}, Lcom/trilead/ssh2/crypto/digest/a;->c(Ljava/lang/String;I)Ljava/lang/String;

    move-result-object p1

    .line 2
    invoke-direct {p2, p1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw p2
.end method

.method public final f(Ljava/math/BigInteger;)V
    .locals 2

    iget-object v0, p0, Lcom/trilead/ssh2/crypto/dh/DhExchange;->b:Ljava/math/BigInteger;

    if-eqz v0, :cond_1

    const-wide/16 v0, 0x0

    invoke-static {v0, v1}, Ljava/math/BigInteger;->valueOf(J)Ljava/math/BigInteger;

    move-result-object v0

    invoke-virtual {v0, p1}, Ljava/math/BigInteger;->compareTo(Ljava/math/BigInteger;)I

    move-result v0

    if-gez v0, :cond_0

    iget-object v0, p0, Lcom/trilead/ssh2/crypto/dh/DhExchange;->a:Ljava/math/BigInteger;

    invoke-virtual {v0, p1}, Ljava/math/BigInteger;->compareTo(Ljava/math/BigInteger;)I

    move-result v0

    if-lez v0, :cond_0

    iput-object p1, p0, Lcom/trilead/ssh2/crypto/dh/DhExchange;->d:Ljava/math/BigInteger;

    iget-object v0, p0, Lcom/trilead/ssh2/crypto/dh/DhExchange;->c:Ljava/math/BigInteger;

    iget-object v1, p0, Lcom/trilead/ssh2/crypto/dh/DhExchange;->a:Ljava/math/BigInteger;

    invoke-virtual {p1, v0, v1}, Ljava/math/BigInteger;->modPow(Ljava/math/BigInteger;Ljava/math/BigInteger;)Ljava/math/BigInteger;

    move-result-object p1

    iput-object p1, p0, Lcom/trilead/ssh2/crypto/dh/DhExchange;->e:Ljava/math/BigInteger;

    return-void

    :cond_0
    new-instance p1, Ljava/lang/IllegalArgumentException;

    const-string v0, "Invalid f specified!"

    invoke-direct {p1, v0}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw p1

    :cond_1
    new-instance p1, Ljava/lang/IllegalStateException;

    const-string v0, "DhDsaExchange not initialized!"

    invoke-direct {p1, v0}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    throw p1
.end method
