.class public final Lu/c;
.super Ljava/io/IOException;
.source "SourceFile"


# static fields
.field public static final c:[Ljava/lang/String;

.field public static final d:[Ljava/lang/String;


# instance fields
.field public a:Ljava/lang/String;

.field public b:I


# direct methods
.method public static constructor <clinit>()V
    .locals 9

    const-string v0, "Succeeded"

    const-string v1, "General SOCKS server failure"

    const-string v2, "Connection not allowed by ruleset"

    const-string v3, "Network unreachable"

    const-string v4, "Host unreachable"

    const-string v5, "Connection refused"

    const-string v6, "TTL expired"

    const-string v7, "Command not supported"

    const-string v8, "Address type not supported"

    filled-new-array/range {v0 .. v8}, [Ljava/lang/String;

    move-result-object v0

    sput-object v0, Lu/c;->c:[Ljava/lang/String;

    const-string v1, "SOCKS server not specified"

    const-string v2, "Unable to contact SOCKS server"

    const-string v3, "IO error"

    const-string v4, "None of Authentication methods are supported"

    const-string v5, "Authentication failed"

    const-string v6, "General SOCKS fault"

    filled-new-array/range {v1 .. v6}, [Ljava/lang/String;

    move-result-object v0

    sput-object v0, Lu/c;->d:[Ljava/lang/String;

    return-void
.end method

.method public constructor <init>(I)V
    .locals 3

    invoke-direct {p0}, Ljava/io/IOException;-><init>()V

    iput p1, p0, Lu/c;->b:I

    shr-int/lit8 v0, p1, 0x10

    const-string v1, "Unknown error message"

    if-nez v0, :cond_0

    sget-object v0, Lu/c;->c:[Ljava/lang/String;

    const/16 v2, 0x9

    if-gt p1, v2, :cond_1

    aget-object v1, v0, p1

    goto :goto_0

    :cond_0
    add-int/lit8 v0, v0, -0x1

    sget-object p1, Lu/c;->d:[Ljava/lang/String;

    const/4 v2, 0x6

    if-gt v0, v2, :cond_1

    aget-object v1, p1, v0

    :cond_1
    :goto_0
    iput-object v1, p0, Lu/c;->a:Ljava/lang/String;

    return-void
.end method


# virtual methods
.method public final toString()Ljava/lang/String;
    .locals 1

    iget-object v0, p0, Lu/c;->a:Ljava/lang/String;

    return-object v0
.end method
