.class public final Lg0/d;
.super Ljava/lang/Object;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lg0/d$a;,
        Lg0/d$b;
    }
.end annotation


# static fields
.field public static final a:Ljava/util/LinkedList;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/LinkedList<",
            "Lg0/b;",
            ">;"
        }
    .end annotation
.end field

.field public static b:Ljava/util/Vector;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/Vector<",
            "Lg0/d$a;",
            ">;"
        }
    .end annotation
.end field

.field public static c:Ljava/util/Vector;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/Vector<",
            "Lg0/d$b;",
            ">;"
        }
    .end annotation
.end field

.field public static d:Lg0/a;

.field public static e:Ljava/lang/String;

.field public static f:Ljava/lang/String;

.field public static g:I

.field public static h:Landroid/content/Intent;

.field public static final i:[B

.field public static final j:[B


# direct methods
.method public static constructor <clinit>()V
    .locals 2

    sget-object v0, Lg0/a;->d:Lg0/a;

    sput-object v0, Lg0/d;->d:Lg0/a;

    const-string v0, ""

    sput-object v0, Lg0/d;->e:Ljava/lang/String;

    const-string v0, "NOPROCESS"

    sput-object v0, Lg0/d;->f:Ljava/lang/String;

    const v0, 0x7f0b0035

    sput v0, Lg0/d;->g:I

    const/4 v0, 0x0

    sput-object v0, Lg0/d;->h:Landroid/content/Intent;

    const/16 v0, 0x14

    new-array v1, v0, [B

    fill-array-data v1, :array_0

    sput-object v1, Lg0/d;->i:[B

    new-array v0, v0, [B

    fill-array-data v0, :array_1

    sput-object v0, Lg0/d;->j:[B

    new-instance v0, Ljava/util/LinkedList;

    invoke-direct {v0}, Ljava/util/LinkedList;-><init>()V

    sput-object v0, Lg0/d;->a:Ljava/util/LinkedList;

    new-instance v0, Ljava/util/Vector;

    invoke-direct {v0}, Ljava/util/Vector;-><init>()V

    sput-object v0, Lg0/d;->b:Ljava/util/Vector;

    new-instance v0, Ljava/util/Vector;

    invoke-direct {v0}, Ljava/util/Vector;-><init>()V

    sput-object v0, Lg0/d;->c:Ljava/util/Vector;

    invoke-static {}, Lg0/d;->i()V

    return-void

    nop

    :array_0
    .array-data 1
        0x5dt
        -0x48t
        0x58t
        0x67t
        -0x80t
        0x73t
        -0x1t
        -0x2ft
        0x78t
        0x71t
        0x62t
        -0x38t
        0xct
        -0x38t
        0x34t
        -0x3et
        0x5ft
        -0x2t
        -0x72t
        0x5ft
    .end array-data

    :array_1
    .array-data 1
        -0x29t
        0x49t
        0x3at
        0x66t
        -0x51t
        -0x1bt
        -0x78t
        0x2dt
        -0x38t
        -0x3t
        0x35t
        -0x31t
        0x77t
        -0x61t
        -0x14t
        -0x50t
        0x41t
        0x44t
        -0x48t
        -0x16t
    .end array-data
.end method

.method public static declared-synchronized a(Lg0/d$b;)V
    .locals 2

    const-class v0, Lg0/d;

    monitor-enter v0

    :try_start_0
    sget-object v1, Lg0/d;->c:Ljava/util/Vector;

    invoke-virtual {v1, p0}, Ljava/util/Vector;->contains(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_0

    sget-object v1, Lg0/d;->c:Ljava/util/Vector;

    invoke-virtual {v1, p0}, Ljava/util/Vector;->add(Ljava/lang/Object;)Z

    sget-object v1, Lg0/d;->f:Ljava/lang/String;

    if-eqz v1, :cond_0

    sget-object v1, Lg0/d;->d:Lg0/a;

    invoke-interface {p0, v1}, Lg0/d$b;->a(Lg0/a;)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    :cond_0
    monitor-exit v0

    return-void

    :catchall_0
    move-exception p0

    monitor-exit v0

    throw p0
.end method

.method public static declared-synchronized b()V
    .locals 3

    const-class v0, Lg0/d;

    monitor-enter v0

    :try_start_0
    sget-object v1, Lg0/d;->a:Ljava/util/LinkedList;

    invoke-virtual {v1}, Ljava/util/LinkedList;->clear()V

    invoke-static {}, Lg0/d;->i()V

    sget-object v1, Lg0/d;->b:Ljava/util/Vector;

    invoke-virtual {v1}, Ljava/util/Vector;->iterator()Ljava/util/Iterator;

    move-result-object v1

    :goto_0
    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    move-result v2

    if-eqz v2, :cond_0

    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Lg0/d$a;

    invoke-interface {v2}, Lg0/d$a;->a()V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    goto :goto_0

    :cond_0
    monitor-exit v0

    return-void

    :catchall_0
    move-exception v1

    monitor-exit v0

    throw v1
.end method

.method public static c(Ljava/lang/String;)I
    .locals 2

    invoke-static {p0}, Ljava/util/Objects;->requireNonNull(Ljava/lang/Object;)Ljava/lang/Object;

    invoke-virtual {p0}, Ljava/lang/String;->hashCode()I

    move-result v0

    const/4 v1, -0x1

    sparse-switch v0, :sswitch_data_0

    goto/16 :goto_0

    :sswitch_0
    const-string v0, "INICIANDO"

    invoke-virtual {p0, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p0

    if-nez p0, :cond_0

    goto/16 :goto_0

    :cond_0
    const/16 v1, 0xd

    goto/16 :goto_0

    :sswitch_1
    const-string v0, "CONECTADO"

    invoke-virtual {p0, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p0

    if-nez p0, :cond_1

    goto/16 :goto_0

    :cond_1
    const/16 v1, 0xc

    goto/16 :goto_0

    :sswitch_2
    const-string v0, "RESOLVE"

    invoke-virtual {p0, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p0

    if-nez p0, :cond_2

    goto/16 :goto_0

    :cond_2
    const/16 v1, 0xb

    goto/16 :goto_0

    :sswitch_3
    const-string v0, "ADD_ROUTES"

    invoke-virtual {p0, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p0

    if-nez p0, :cond_3

    goto/16 :goto_0

    :cond_3
    const/16 v1, 0xa

    goto/16 :goto_0

    :sswitch_4
    const-string v0, "CONECTANDO"

    invoke-virtual {p0, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p0

    if-nez p0, :cond_4

    goto/16 :goto_0

    :cond_4
    const/16 v1, 0x9

    goto/16 :goto_0

    :sswitch_5
    const-string v0, "TCP_CONNECT"

    invoke-virtual {p0, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p0

    if-nez p0, :cond_5

    goto/16 :goto_0

    :cond_5
    const/16 v1, 0x8

    goto/16 :goto_0

    :sswitch_6
    const-string v0, "AUTENTICANDO"

    invoke-virtual {p0, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p0

    if-nez p0, :cond_6

    goto :goto_0

    :cond_6
    const/4 v1, 0x7

    goto :goto_0

    :sswitch_7
    const-string v0, "PARANDO"

    invoke-virtual {p0, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p0

    if-nez p0, :cond_7

    goto :goto_0

    :cond_7
    const/4 v1, 0x6

    goto :goto_0

    :sswitch_8
    const-string v0, "ASSIGN_IP"

    invoke-virtual {p0, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p0

    if-nez p0, :cond_8

    goto :goto_0

    :cond_8
    const/4 v1, 0x5

    goto :goto_0

    :sswitch_9
    const-string v0, "GET_CONFIG"

    invoke-virtual {p0, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p0

    if-nez p0, :cond_9

    goto :goto_0

    :cond_9
    const/4 v1, 0x4

    goto :goto_0

    :sswitch_a
    const-string v0, "DESCONECTADO"

    invoke-virtual {p0, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p0

    if-nez p0, :cond_a

    goto :goto_0

    :cond_a
    const/4 v1, 0x3

    goto :goto_0

    :sswitch_b
    const-string v0, "AUTH_PENDING"

    invoke-virtual {p0, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p0

    if-nez p0, :cond_b

    goto :goto_0

    :cond_b
    const/4 v1, 0x2

    goto :goto_0

    :sswitch_c
    const-string v0, "RECONECTANDO"

    invoke-virtual {p0, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p0

    if-nez p0, :cond_c

    goto :goto_0

    :cond_c
    const/4 v1, 0x1

    goto :goto_0

    :sswitch_d
    const-string v0, "AGUARDANDO"

    invoke-virtual {p0, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p0

    if-nez p0, :cond_d

    goto :goto_0

    :cond_d
    const/4 v1, 0x0

    :goto_0
    packed-switch v1, :pswitch_data_0

    const p0, 0x7f0b0048

    return p0

    :pswitch_0
    const p0, 0x7f0b003a

    return p0

    :pswitch_1
    const p0, 0x7f0b0030

    return p0

    :pswitch_2
    const p0, 0x7f0b0039

    return p0

    :pswitch_3
    const p0, 0x7f0b002a

    return p0

    :pswitch_4
    const p0, 0x7f0b0031

    return p0

    :pswitch_5
    const p0, 0x7f0b003c

    return p0

    :pswitch_6
    const p0, 0x7f0b002c

    return p0

    :pswitch_7
    const p0, 0x7f0b003b

    return p0

    :pswitch_8
    const p0, 0x7f0b002b

    return p0

    :pswitch_9
    const p0, 0x7f0b0033

    return p0

    :pswitch_a
    const p0, 0x7f0b0032

    return p0

    :pswitch_b
    const p0, 0x7f0b002e

    return p0

    :pswitch_c
    const p0, 0x7f0b0038

    return p0

    :pswitch_d
    const p0, 0x7f0b0034

    return p0

    nop

    :sswitch_data_0
    .sparse-switch
        -0x5e5c31a4 -> :sswitch_d
        -0x57613741 -> :sswitch_c
        -0x31f19620 -> :sswitch_b
        -0x2b3a8e7a -> :sswitch_a
        -0x1b0a8795 -> :sswitch_9
        -0x559e189 -> :sswitch_8
        -0x4803a87 -> :sswitch_7
        0x51d237d -> :sswitch_6
        0xfb59e4c -> :sswitch_5
        0x1013a24c -> :sswitch_4
        0x3281a8c8 -> :sswitch_3
        0x6c340dcc -> :sswitch_2
        0x7421a938 -> :sswitch_1
        0x7a3e57a2 -> :sswitch_0
    .end sparse-switch

    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_d
        :pswitch_c
        :pswitch_b
        :pswitch_a
        :pswitch_9
        :pswitch_8
        :pswitch_7
        :pswitch_6
        :pswitch_5
        :pswitch_4
        :pswitch_3
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method

.method public static d(Ljava/lang/String;)V
    .locals 2

    new-instance v0, Lg0/b;

    const/4 v1, 0x5

    invoke-direct {v0, v1, p0}, Lg0/b;-><init>(ILjava/lang/String;)V

    invoke-static {v0}, Lg0/d;->l(Lg0/b;)V

    return-void
.end method

.method public static e(Ljava/lang/String;)V
    .locals 2

    new-instance v0, Lg0/b;

    const/4 v1, 0x2

    invoke-direct {v0, v1, p0}, Lg0/b;-><init>(ILjava/lang/String;)V

    invoke-static {v0}, Lg0/d;->l(Lg0/b;)V

    return-void
.end method

.method public static f(Ljava/lang/String;Ljava/lang/Exception;)V
    .locals 6

    new-instance v0, Ljava/io/StringWriter;

    invoke-direct {v0}, Ljava/io/StringWriter;-><init>()V

    new-instance v1, Ljava/io/PrintWriter;

    invoke-direct {v1, v0}, Ljava/io/PrintWriter;-><init>(Ljava/io/Writer;)V

    invoke-virtual {p1, v1}, Ljava/lang/Throwable;->printStackTrace(Ljava/io/PrintWriter;)V

    new-instance v1, Lg0/b;

    const/4 v2, 0x2

    const/4 v3, 0x1

    const/4 v4, 0x0

    if-eqz p0, :cond_0

    const/4 v5, 0x3

    new-array v5, v5, [Ljava/lang/Object;

    aput-object p0, v5, v4

    invoke-virtual {p1}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    move-result-object p0

    aput-object p0, v5, v3

    invoke-virtual {v0}, Ljava/io/StringWriter;->toString()Ljava/lang/String;

    move-result-object p0

    aput-object p0, v5, v2

    const-string p0, "%s: %s, %s"

    invoke-static {p0, v5}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object p0

    goto :goto_0

    :cond_0
    new-array p0, v2, [Ljava/lang/Object;

    invoke-virtual {p1}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    move-result-object p1

    aput-object p1, p0, v4

    invoke-virtual {v0}, Ljava/io/StringWriter;->toString()Ljava/lang/String;

    move-result-object p1

    aput-object p1, p0, v3

    const-string p1, "Erro: %s, %s"

    invoke-static {p1, p0}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object p0

    :goto_0
    invoke-direct {v1, v2, p0}, Lg0/b;-><init>(ILjava/lang/String;)V

    invoke-static {v1}, Lg0/d;->l(Lg0/b;)V

    return-void
.end method

.method public static varargs g(I[Ljava/lang/Object;)V
    .locals 2

    new-instance v0, Lg0/b;

    const/4 v1, 0x1

    invoke-direct {v0, v1, p0, p1}, Lg0/b;-><init>(II[Ljava/lang/Object;)V

    invoke-static {v0}, Lg0/d;->l(Lg0/b;)V

    return-void
.end method

.method public static h(Ljava/lang/String;)V
    .locals 2

    new-instance v0, Lg0/b;

    const/4 v1, 0x1

    invoke-direct {v0, v1, p0}, Lg0/b;-><init>(ILjava/lang/String;)V

    invoke-static {v0}, Lg0/d;->l(Lg0/b;)V

    return-void
.end method

.method public static i()V
    .locals 6

    const/4 v0, 0x5

    new-array v0, v0, [Ljava/lang/Object;

    sget-object v1, Landroid/os/Build;->MODEL:Ljava/lang/String;

    const/4 v2, 0x0

    aput-object v1, v0, v2

    sget-object v1, Landroid/os/Build;->BOARD:Ljava/lang/String;

    const/4 v3, 0x1

    aput-object v1, v0, v3

    sget-object v1, Landroid/os/Build;->BRAND:Ljava/lang/String;

    const/4 v4, 0x2

    aput-object v1, v0, v4

    sget v1, Landroid/os/Build$VERSION;->SDK_INT:I

    invoke-static {v1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v1

    const/4 v5, 0x3

    aput-object v1, v0, v5

    sget-object v1, Landroid/os/Build$VERSION;->RELEASE:Ljava/lang/String;

    const/4 v5, 0x4

    aput-object v1, v0, v5

    const v1, 0x7f0b001b

    invoke-static {v1, v0}, Lg0/d;->g(I[Ljava/lang/Object;)V

    new-array v0, v4, [Ljava/lang/Object;

    const-string v1, ""

    aput-object v1, v0, v2

    aput-object v1, v0, v3

    const v1, 0x7f0b0001

    invoke-static {v1, v0}, Lg0/d;->g(I[Ljava/lang/Object;)V

    return-void
.end method

.method public static varargs j(I[Ljava/lang/Object;)V
    .locals 2

    new-instance v0, Lg0/b;

    const/4 v1, 0x3

    invoke-direct {v0, v1, p0, p1}, Lg0/b;-><init>(II[Ljava/lang/Object;)V

    invoke-static {v0}, Lg0/d;->l(Lg0/b;)V

    return-void
.end method

.method public static k(Ljava/lang/String;)V
    .locals 2

    new-instance v0, Lg0/b;

    const/4 v1, 0x3

    invoke-direct {v0, v1, p0}, Lg0/b;-><init>(ILjava/lang/String;)V

    invoke-static {v0}, Lg0/d;->l(Lg0/b;)V

    return-void
.end method

.method public static l(Lg0/b;)V
    .locals 4

    const-class v0, Lg0/d;

    monitor-enter v0

    :try_start_0
    sget-object v1, Lg0/d;->a:Ljava/util/LinkedList;

    invoke-virtual {v1, p0}, Ljava/util/LinkedList;->addLast(Ljava/lang/Object;)V

    invoke-virtual {v1}, Ljava/util/LinkedList;->size()I

    move-result v1

    const/16 v2, 0x5dc

    if-le v1, v2, :cond_0

    :goto_0
    sget-object v1, Lg0/d;->a:Ljava/util/LinkedList;

    invoke-virtual {v1}, Ljava/util/LinkedList;->size()I

    move-result v2

    const/16 v3, 0x3e8

    if-le v2, v3, :cond_0

    invoke-virtual {v1}, Ljava/util/LinkedList;->removeFirst()Ljava/lang/Object;

    goto :goto_0

    :cond_0
    sget-object v1, Lg0/d;->b:Ljava/util/Vector;

    invoke-virtual {v1}, Ljava/util/Vector;->iterator()Ljava/util/Iterator;

    move-result-object v1

    :goto_1
    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    move-result v2

    if-eqz v2, :cond_1

    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Lg0/d$a;

    invoke-interface {v2, p0}, Lg0/d$a;->b(Lg0/b;)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    goto :goto_1

    :cond_1
    monitor-exit v0

    return-void

    :catchall_0
    move-exception p0

    monitor-exit v0

    throw p0
.end method

.method public static declared-synchronized m(Lg0/d$b;)V
    .locals 2

    const-class v0, Lg0/d;

    monitor-enter v0

    :try_start_0
    sget-object v1, Lg0/d;->c:Ljava/util/Vector;

    invoke-virtual {v1, p0}, Ljava/util/Vector;->contains(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_0

    sget-object v1, Lg0/d;->c:Ljava/util/Vector;

    invoke-virtual {v1, p0}, Ljava/util/Vector;->remove(Ljava/lang/Object;)Z
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    :cond_0
    monitor-exit v0

    return-void

    :catchall_0
    move-exception p0

    monitor-exit v0

    throw p0
.end method

.method public static n(Ljava/lang/String;Ljava/lang/String;)V
    .locals 8

    invoke-static {p0}, Lg0/d;->c(Ljava/lang/String;)I

    move-result v0

    const-string v1, "INICIANDO"

    const-string v2, "CONECTANDO"

    const-string v3, "AGUARDANDO"

    const-string v4, "RECONECTANDO"

    const-string v5, "RESOLVE"

    const-string v6, "TCP_CONNECT"

    .line 1
    filled-new-array/range {v1 .. v6}, [Ljava/lang/String;

    move-result-object v1

    const-string v2, "AUTENTICANDO"

    const-string v3, "GET_CONFIG"

    const-string v4, "ASSIGN_IP"

    const-string v5, "ADD_ROUTES"

    const-string v6, "AUTH_PENDING"

    filled-new-array {v2, v3, v4, v5, v6}, [Ljava/lang/String;

    move-result-object v2

    const-string v3, "CONECTADO"

    filled-new-array {v3}, [Ljava/lang/String;

    move-result-object v3

    const-string v4, "DESCONECTADO"

    filled-new-array {v4}, [Ljava/lang/String;

    move-result-object v4

    const/4 v5, 0x0

    const/4 v6, 0x0

    :goto_0
    const/4 v7, 0x6

    if-ge v6, v7, :cond_1

    aget-object v7, v1, v6

    invoke-virtual {p0, v7}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v7

    if-eqz v7, :cond_0

    sget-object v1, Lg0/a;->c:Lg0/a;

    goto :goto_4

    :cond_0
    add-int/lit8 v6, v6, 0x1

    goto :goto_0

    :cond_1
    const/4 v1, 0x0

    :goto_1
    const/4 v6, 0x5

    if-ge v1, v6, :cond_3

    aget-object v6, v2, v1

    invoke-virtual {p0, v6}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v6

    if-eqz v6, :cond_2

    sget-object v1, Lg0/a;->b:Lg0/a;

    goto :goto_4

    :cond_2
    add-int/lit8 v1, v1, 0x1

    goto :goto_1

    :cond_3
    const/4 v1, 0x0

    :goto_2
    const/4 v2, 0x1

    if-ge v1, v2, :cond_5

    aget-object v2, v3, v1

    invoke-virtual {p0, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v2

    if-eqz v2, :cond_4

    sget-object v1, Lg0/a;->a:Lg0/a;

    goto :goto_4

    :cond_4
    add-int/lit8 v1, v1, 0x1

    goto :goto_2

    :cond_5
    :goto_3
    if-ge v5, v2, :cond_7

    aget-object v1, v4, v5

    invoke-virtual {p0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_6

    sget-object v1, Lg0/a;->d:Lg0/a;

    goto :goto_4

    :cond_6
    add-int/lit8 v5, v5, 0x1

    goto :goto_3

    :cond_7
    sget-object v1, Lg0/a;->h:Lg0/a;

    .line 2
    :goto_4
    invoke-static {p0, p1, v0, v1}, Lg0/d;->o(Ljava/lang/String;Ljava/lang/String;ILg0/a;)V

    return-void
.end method

.method public static declared-synchronized o(Ljava/lang/String;Ljava/lang/String;ILg0/a;)V
    .locals 1

    const-class v0, Lg0/d;

    monitor-enter v0

    :try_start_0
    invoke-static {p0, p1, p2, p3}, Lg0/d;->p(Ljava/lang/String;Ljava/lang/String;ILg0/a;)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    monitor-exit v0

    return-void

    :catchall_0
    move-exception p0

    monitor-exit v0

    throw p0
.end method

.method public static declared-synchronized p(Ljava/lang/String;Ljava/lang/String;ILg0/a;)V
    .locals 5

    const-class v0, Lg0/d;

    monitor-enter v0

    :try_start_0
    sget-object v1, Lg0/d;->d:Lg0/a;

    sget-object v2, Lg0/a;->a:Lg0/a;

    if-ne v1, v2, :cond_0

    const-string v1, "AUTENTICANDO"

    invoke-virtual {p0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_0

    new-instance p2, Lg0/b;

    const/4 v1, 0x5

    const-string v2, "Ignoring ChzHttp Status in CONNECTED state (%s->%s): %s"

    const/4 v3, 0x3

    new-array v3, v3, [Ljava/lang/Object;

    const/4 v4, 0x0

    aput-object p0, v3, v4

    const/4 p0, 0x1

    invoke-virtual {p3}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object p3

    aput-object p3, v3, p0

    const/4 p0, 0x2

    aput-object p1, v3, p0

    invoke-static {v2, v3}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object p0

    invoke-direct {p2, v1, p0}, Lg0/b;-><init>(ILjava/lang/String;)V

    invoke-static {p2}, Lg0/d;->l(Lg0/b;)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    monitor-exit v0

    return-void

    :cond_0
    :try_start_1
    sput-object p0, Lg0/d;->f:Ljava/lang/String;

    sput-object p1, Lg0/d;->e:Ljava/lang/String;

    sput p2, Lg0/d;->g:I

    sput-object p3, Lg0/d;->d:Lg0/a;

    const/4 p0, 0x0

    sput-object p0, Lg0/d;->h:Landroid/content/Intent;

    sget-object p0, Lg0/d;->c:Ljava/util/Vector;

    invoke-virtual {p0}, Ljava/util/Vector;->iterator()Ljava/util/Iterator;

    move-result-object p0

    :goto_0
    invoke-interface {p0}, Ljava/util/Iterator;->hasNext()Z

    move-result p1

    if-eqz p1, :cond_1

    invoke-interface {p0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Lg0/d$b;

    invoke-interface {p1, p3}, Lg0/d$b;->a(Lg0/a;)V
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    goto :goto_0

    :cond_1
    monitor-exit v0

    return-void

    :catchall_0
    move-exception p0

    monitor-exit v0

    throw p0
.end method
