.class public final synthetic Lc0/e;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Landroid/content/DialogInterface$OnClickListener;


# static fields
.field public static final synthetic b:Lc0/e;

.field public static final synthetic c:Lc0/e;


# instance fields
.field public final synthetic a:I


# direct methods
.method static synthetic constructor <clinit>()V
    .locals 2

    new-instance v0, Lc0/e;

    const/4 v1, 0x0

    invoke-direct {v0, v1}, Lc0/e;-><init>(I)V

    sput-object v0, Lc0/e;->b:Lc0/e;

    new-instance v0, Lc0/e;

    const/4 v1, 0x1

    invoke-direct {v0, v1}, Lc0/e;-><init>(I)V

    sput-object v0, Lc0/e;->c:Lc0/e;

    return-void
.end method

.method public synthetic constructor <init>(I)V
    .locals 0

    iput p1, p0, Lc0/e;->a:I

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final onClick(Landroid/content/DialogInterface;I)V
    .locals 0

    iget p1, p0, Lc0/e;->a:I

    packed-switch p1, :pswitch_data_0

    goto :goto_0

    :pswitch_0
    sget-object p1, Lc0/g;->s:Lj0/c;

    return-void

    :goto_0
    sget-object p1, Lc0/g;->s:Lj0/c;

    return-void

    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_0
    .end packed-switch
.end method
