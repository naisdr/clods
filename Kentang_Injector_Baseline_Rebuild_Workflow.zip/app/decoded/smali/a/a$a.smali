.class public final La/a$a;
.super La/d;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = La/a;->k()La/d;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1
    name = null
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "La/d<",
        "TK;TV;>;"
    }
.end annotation


# instance fields
.field public final synthetic d:La/a;


# direct methods
.method public constructor <init>(La/a;)V
    .locals 0

    iput-object p1, p0, La/a$a;->d:La/a;

    invoke-direct {p0}, La/d;-><init>()V

    return-void
.end method


# virtual methods
.method public final a()V
    .locals 1

    iget-object v0, p0, La/a$a;->d:La/a;

    invoke-virtual {v0}, La/e;->clear()V

    return-void
.end method

.method public final b(II)Ljava/lang/Object;
    .locals 1

    iget-object v0, p0, La/a$a;->d:La/a;

    iget-object v0, v0, La/e;->b:[Ljava/lang/Object;

    shl-int/lit8 p1, p1, 0x1

    add-int/2addr p1, p2

    aget-object p1, v0, p1

    return-object p1
.end method

.method public final c(Ljava/lang/Object;)I
    .locals 1

    iget-object v0, p0, La/a$a;->d:La/a;

    invoke-virtual {v0, p1}, La/e;->e(Ljava/lang/Object;)I

    move-result p1

    return p1
.end method

.method public final d(I)V
    .locals 1

    iget-object v0, p0, La/a$a;->d:La/a;

    invoke-virtual {v0, p1}, La/e;->i(I)Ljava/lang/Object;

    return-void
.end method
