.class public final enum Lr/f$b$b;
.super Lr/f$b;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lr/f$b;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x4011
    name = null
.end annotation


# direct methods
.method public varargs constructor <init>([Ljava/lang/String;)V
    .locals 8

    const-string v1, "DES_CBC"

    const/4 v2, 0x1

    const/16 v3, 0x8

    const/16 v4, 0x8

    const-string v5, "des-cbc"

    const/4 v7, 0x0

    move-object v0, p0

    move-object v6, p1

    invoke-direct/range {v0 .. v7}, Lr/f$b;-><init>(Ljava/lang/String;IIILjava/lang/String;[Ljava/lang/String;Lr/f$a;)V

    return-void
.end method


# virtual methods
.method public final a([B[B)Lcom/trilead/ssh2/crypto/cipher/BlockCipher;
    .locals 2

    new-instance v0, Lcom/trilead/ssh2/crypto/cipher/DES;

    invoke-direct {v0}, Lcom/trilead/ssh2/crypto/cipher/DES;-><init>()V

    const/4 v1, 0x0

    invoke-virtual {v0, v1, p1}, Lcom/trilead/ssh2/crypto/cipher/DES;->b(Z[B)V

    new-instance p1, Lcom/trilead/ssh2/crypto/cipher/CBCMode;

    invoke-direct {p1, v0, p2, v1}, Lcom/trilead/ssh2/crypto/cipher/CBCMode;-><init>(Lcom/trilead/ssh2/crypto/cipher/BlockCipher;[BZ)V

    return-object p1
.end method
