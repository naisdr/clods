.class public final Lm/i;
.super Ljava/lang/Object;
.source "SourceFile"


# instance fields
.field public a:I

.field public b:Ljava/lang/String;

.field public c:Ljava/lang/Object;

.field public d:Ljava/lang/Object;


# direct methods
.method public synthetic constructor <init>(Lo/c;Ljava/lang/String;)V
    .locals 1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lm/i;->c:Ljava/lang/Object;

    iput-object p2, p0, Lm/i;->b:Ljava/lang/String;

    const/16 v0, 0x50

    iput v0, p0, Lm/i;->a:I

    new-instance v0, Lo/h;

    invoke-direct {v0, p1, p2}, Lo/h;-><init>(Lo/c;Ljava/lang/String;)V

    iput-object v0, p0, Lm/i;->d:Ljava/lang/Object;

    const/4 p1, 0x1

    invoke-virtual {v0, p1}, Ljava/lang/Thread;->setDaemon(Z)V

    iget-object p1, p0, Lm/i;->d:Ljava/lang/Object;

    check-cast p1, Lo/h;

    invoke-virtual {p1}, Ljava/lang/Thread;->start()V

    return-void
.end method
