.class public final Li0/a;
.super Ljava/lang/Object;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Li0/a$a;
    }
.end annotation


# instance fields
.field public a:Ljava/util/TreeSet;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/TreeSet<",
            "Li0/a$a;",
            ">;"
        }
    .end annotation
.end field


# direct methods
.method public constructor <init>()V
    .locals 1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    new-instance v0, Ljava/util/TreeSet;

    invoke-direct {v0}, Ljava/util/TreeSet;-><init>()V

    iput-object v0, p0, Li0/a;->a:Ljava/util/TreeSet;

    return-void
.end method


# virtual methods
.method public final a(Ld/a;Z)V
    .locals 2

    iget-object v0, p0, Li0/a;->a:Ljava/util/TreeSet;

    new-instance v1, Li0/a$a;

    invoke-direct {v1, p1, p2}, Li0/a$a;-><init>(Ld/a;Z)V

    invoke-virtual {v0, v1}, Ljava/util/TreeSet;->add(Ljava/lang/Object;)Z

    return-void
.end method

.method public final b()V
    .locals 1

    iget-object v0, p0, Li0/a;->a:Ljava/util/TreeSet;

    invoke-virtual {v0}, Ljava/util/TreeSet;->clear()V

    return-void
.end method

.method public final c(Z)Ljava/util/Collection;
    .locals 4
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(Z)",
            "Ljava/util/Collection<",
            "Li0/a$a;",
            ">;"
        }
    .end annotation

    new-instance v0, Ljava/util/Vector;

    invoke-direct {v0}, Ljava/util/Vector;-><init>()V

    iget-object v1, p0, Li0/a;->a:Ljava/util/TreeSet;

    invoke-virtual {v1}, Ljava/util/TreeSet;->iterator()Ljava/util/Iterator;

    move-result-object v1

    :cond_0
    :goto_0
    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    move-result v2

    if-eqz v2, :cond_1

    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Li0/a$a;

    .line 1
    iget-boolean v3, v2, Li0/a$a;->c:Z

    if-ne v3, p1, :cond_0

    .line 2
    invoke-virtual {v0, v2}, Ljava/util/Vector;->add(Ljava/lang/Object;)Z

    goto :goto_0

    :cond_1
    return-object v0
.end method

.method public final d()Ljava/util/Collection;
    .locals 8
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/Collection<",
            "Li0/a$a;",
            ">;"
        }
    .end annotation

    .line 1
    new-instance v0, Ljava/util/PriorityQueue;

    iget-object v1, p0, Li0/a;->a:Ljava/util/TreeSet;

    invoke-direct {v0, v1}, Ljava/util/PriorityQueue;-><init>(Ljava/util/SortedSet;)V

    new-instance v1, Ljava/util/TreeSet;

    invoke-direct {v1}, Ljava/util/TreeSet;-><init>()V

    invoke-virtual {v0}, Ljava/util/PriorityQueue;->poll()Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Li0/a$a;

    if-nez v2, :cond_0

    goto/16 :goto_4

    :cond_0
    :goto_0
    if-eqz v2, :cond_9

    invoke-virtual {v0}, Ljava/util/PriorityQueue;->poll()Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Li0/a$a;

    if-eqz v3, :cond_8

    invoke-virtual {v2}, Li0/a$a;->d()Ljava/math/BigInteger;

    move-result-object v4

    invoke-virtual {v3}, Li0/a$a;->b()Ljava/math/BigInteger;

    move-result-object v5

    invoke-virtual {v4, v5}, Ljava/math/BigInteger;->compareTo(Ljava/math/BigInteger;)I

    move-result v4

    const/4 v5, -0x1

    if-ne v4, v5, :cond_1

    goto/16 :goto_2

    :cond_1
    invoke-virtual {v2}, Li0/a$a;->b()Ljava/math/BigInteger;

    move-result-object v4

    invoke-virtual {v3}, Li0/a$a;->b()Ljava/math/BigInteger;

    move-result-object v5

    invoke-virtual {v4, v5}, Ljava/math/BigInteger;->equals(Ljava/lang/Object;)Z

    move-result v4

    const/4 v5, 0x0

    const/4 v6, 0x1

    if-eqz v4, :cond_5

    iget v4, v2, Li0/a$a;->b:I

    iget v7, v3, Li0/a$a;->b:I

    if-lt v4, v7, :cond_5

    .line 2
    iget-boolean v4, v2, Li0/a$a;->c:Z

    iget-boolean v7, v3, Li0/a$a;->c:Z

    if-ne v4, v7, :cond_2

    goto :goto_3

    .line 3
    :cond_2
    invoke-virtual {v3}, Li0/a$a;->f()[Li0/a$a;

    move-result-object v3

    aget-object v4, v3, v6

    invoke-virtual {v0, v4}, Ljava/util/PriorityQueue;->contains(Ljava/lang/Object;)Z

    move-result v4

    if-nez v4, :cond_3

    aget-object v4, v3, v6

    invoke-virtual {v0, v4}, Ljava/util/PriorityQueue;->add(Ljava/lang/Object;)Z

    :cond_3
    aget-object v4, v3, v5

    invoke-virtual {v4}, Li0/a$a;->d()Ljava/math/BigInteger;

    move-result-object v4

    invoke-virtual {v2}, Li0/a$a;->d()Ljava/math/BigInteger;

    move-result-object v6

    invoke-virtual {v4, v6}, Ljava/math/BigInteger;->equals(Ljava/lang/Object;)Z

    move-result v4

    if-eqz v4, :cond_4

    goto :goto_0

    :cond_4
    aget-object v4, v3, v5

    invoke-virtual {v0, v4}, Ljava/util/PriorityQueue;->contains(Ljava/lang/Object;)Z

    move-result v4

    if-nez v4, :cond_0

    aget-object v3, v3, v5

    invoke-virtual {v0, v3}, Ljava/util/PriorityQueue;->add(Ljava/lang/Object;)Z

    goto :goto_0

    .line 4
    :cond_5
    iget-boolean v4, v2, Li0/a$a;->c:Z

    iget-boolean v7, v3, Li0/a$a;->c:Z

    if-ne v4, v7, :cond_6

    goto :goto_0

    .line 5
    :cond_6
    invoke-virtual {v2}, Li0/a$a;->f()[Li0/a$a;

    move-result-object v2

    aget-object v4, v2, v6

    iget v4, v4, Li0/a$a;->b:I

    iget v7, v3, Li0/a$a;->b:I

    if-ne v4, v7, :cond_7

    goto :goto_1

    :cond_7
    aget-object v4, v2, v6

    invoke-virtual {v0, v4}, Ljava/util/PriorityQueue;->add(Ljava/lang/Object;)Z

    :goto_1
    invoke-virtual {v0, v3}, Ljava/util/PriorityQueue;->add(Ljava/lang/Object;)Z

    aget-object v2, v2, v5

    goto/16 :goto_0

    :cond_8
    :goto_2
    invoke-virtual {v1, v2}, Ljava/util/TreeSet;->add(Ljava/lang/Object;)Z

    :goto_3
    move-object v2, v3

    goto/16 :goto_0

    .line 6
    :cond_9
    :goto_4
    new-instance v0, Ljava/util/Vector;

    invoke-direct {v0}, Ljava/util/Vector;-><init>()V

    invoke-virtual {v1}, Ljava/util/TreeSet;->iterator()Ljava/util/Iterator;

    move-result-object v1

    :cond_a
    :goto_5
    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    move-result v2

    if-eqz v2, :cond_b

    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Li0/a$a;

    .line 7
    iget-boolean v3, v2, Li0/a$a;->c:Z

    if-eqz v3, :cond_a

    .line 8
    invoke-virtual {v0, v2}, Ljava/util/Vector;->add(Ljava/lang/Object;)Z

    goto :goto_5

    :cond_b
    return-object v0
.end method
