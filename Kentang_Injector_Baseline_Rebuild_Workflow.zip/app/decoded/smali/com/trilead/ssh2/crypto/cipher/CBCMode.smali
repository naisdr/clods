.class public Lcom/trilead/ssh2/crypto/cipher/CBCMode;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lcom/trilead/ssh2/crypto/cipher/BlockCipher;


# instance fields
.field public a:Lcom/trilead/ssh2/crypto/cipher/BlockCipher;

.field public b:I

.field public c:Z

.field public d:[B

.field public e:[B


# direct methods
.method public constructor <init>(Lcom/trilead/ssh2/crypto/cipher/BlockCipher;[BZ)V
    .locals 1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lcom/trilead/ssh2/crypto/cipher/CBCMode;->a:Lcom/trilead/ssh2/crypto/cipher/BlockCipher;

    invoke-interface {p1}, Lcom/trilead/ssh2/crypto/cipher/BlockCipher;->a()I

    move-result p1

    iput p1, p0, Lcom/trilead/ssh2/crypto/cipher/CBCMode;->b:I

    iput-boolean p3, p0, Lcom/trilead/ssh2/crypto/cipher/CBCMode;->c:Z

    array-length p3, p2

    if-ne p1, p3, :cond_0

    new-array p3, p1, [B

    iput-object p3, p0, Lcom/trilead/ssh2/crypto/cipher/CBCMode;->d:[B

    new-array v0, p1, [B

    iput-object v0, p0, Lcom/trilead/ssh2/crypto/cipher/CBCMode;->e:[B

    const/4 v0, 0x0

    invoke-static {p2, v0, p3, v0, p1}, Ljava/lang/System;->arraycopy(Ljava/lang/Object;ILjava/lang/Object;II)V

    return-void

    :cond_0
    new-instance p1, Ljava/lang/IllegalArgumentException;

    const-string p3, "IV must be "

    .line 1
    invoke-static {p3}, Lcom/trilead/ssh2/crypto/digest/a;->e(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object p3

    .line 2
    iget v0, p0, Lcom/trilead/ssh2/crypto/cipher/CBCMode;->b:I

    invoke-virtual {p3, v0}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string v0, " bytes long! (currently "

    invoke-virtual {p3, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    array-length p2, p2

    invoke-virtual {p3, p2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string p2, ")"

    invoke-virtual {p3, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p2

    invoke-direct {p1, p2}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw p1
.end method


# virtual methods
.method public final a()I
    .locals 1

    iget v0, p0, Lcom/trilead/ssh2/crypto/cipher/CBCMode;->b:I

    return v0
.end method

.method public final b(Z[B)V
    .locals 0

    return-void
.end method

.method public final c([BI[BI)V
    .locals 5

    iget-boolean v0, p0, Lcom/trilead/ssh2/crypto/cipher/CBCMode;->c:Z

    const/4 v1, 0x0

    if-eqz v0, :cond_1

    const/4 v0, 0x0

    .line 1
    :goto_0
    iget v2, p0, Lcom/trilead/ssh2/crypto/cipher/CBCMode;->b:I

    if-ge v0, v2, :cond_0

    iget-object v2, p0, Lcom/trilead/ssh2/crypto/cipher/CBCMode;->d:[B

    aget-byte v3, v2, v0

    add-int v4, p2, v0

    aget-byte v4, p1, v4

    xor-int/2addr v3, v4

    int-to-byte v3, v3

    aput-byte v3, v2, v0

    add-int/lit8 v0, v0, 0x1

    goto :goto_0

    :cond_0
    iget-object p1, p0, Lcom/trilead/ssh2/crypto/cipher/CBCMode;->a:Lcom/trilead/ssh2/crypto/cipher/BlockCipher;

    iget-object p2, p0, Lcom/trilead/ssh2/crypto/cipher/CBCMode;->d:[B

    invoke-interface {p1, p2, v1, p3, p4}, Lcom/trilead/ssh2/crypto/cipher/BlockCipher;->c([BI[BI)V

    iget-object p1, p0, Lcom/trilead/ssh2/crypto/cipher/CBCMode;->d:[B

    iget p2, p0, Lcom/trilead/ssh2/crypto/cipher/CBCMode;->b:I

    invoke-static {p3, p4, p1, v1, p2}, Ljava/lang/System;->arraycopy(Ljava/lang/Object;ILjava/lang/Object;II)V

    goto :goto_2

    .line 2
    :cond_1
    iget-object v0, p0, Lcom/trilead/ssh2/crypto/cipher/CBCMode;->e:[B

    iget v2, p0, Lcom/trilead/ssh2/crypto/cipher/CBCMode;->b:I

    invoke-static {p1, p2, v0, v1, v2}, Ljava/lang/System;->arraycopy(Ljava/lang/Object;ILjava/lang/Object;II)V

    iget-object v0, p0, Lcom/trilead/ssh2/crypto/cipher/CBCMode;->a:Lcom/trilead/ssh2/crypto/cipher/BlockCipher;

    invoke-interface {v0, p1, p2, p3, p4}, Lcom/trilead/ssh2/crypto/cipher/BlockCipher;->c([BI[BI)V

    :goto_1
    iget p1, p0, Lcom/trilead/ssh2/crypto/cipher/CBCMode;->b:I

    if-ge v1, p1, :cond_2

    add-int p1, p4, v1

    aget-byte p2, p3, p1

    iget-object v0, p0, Lcom/trilead/ssh2/crypto/cipher/CBCMode;->d:[B

    aget-byte v0, v0, v1

    xor-int/2addr p2, v0

    int-to-byte p2, p2

    aput-byte p2, p3, p1

    add-int/lit8 v1, v1, 0x1

    goto :goto_1

    :cond_2
    iget-object p1, p0, Lcom/trilead/ssh2/crypto/cipher/CBCMode;->d:[B

    iget-object p2, p0, Lcom/trilead/ssh2/crypto/cipher/CBCMode;->e:[B

    iput-object p2, p0, Lcom/trilead/ssh2/crypto/cipher/CBCMode;->d:[B

    iput-object p1, p0, Lcom/trilead/ssh2/crypto/cipher/CBCMode;->e:[B

    :goto_2
    return-void
.end method
