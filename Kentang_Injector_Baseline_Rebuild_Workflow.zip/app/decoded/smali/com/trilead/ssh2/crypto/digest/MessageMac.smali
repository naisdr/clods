.class public final Lcom/trilead/ssh2/crypto/digest/MessageMac;
.super Lcom/trilead/ssh2/crypto/digest/MAC;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/trilead/ssh2/crypto/digest/MessageMac$Hmac;
    }
.end annotation


# instance fields
.field public final c:Ljavax/crypto/Mac;


# direct methods
.method public constructor <init>(Ljava/lang/String;[B)V
    .locals 2

    invoke-direct {p0, p1, p2}, Lcom/trilead/ssh2/crypto/digest/MAC;-><init>(Ljava/lang/String;[B)V

    :try_start_0
    invoke-static {p1}, Lcom/trilead/ssh2/crypto/digest/MessageMac$Hmac;->a(Ljava/lang/String;)Lcom/trilead/ssh2/crypto/digest/MessageMac$Hmac;

    move-result-object v0

    .line 1
    iget-object v0, v0, Lcom/trilead/ssh2/crypto/digest/MessageMac$Hmac;->b:Ljava/lang/String;

    .line 2
    invoke-static {v0}, Ljavax/crypto/Mac;->getInstance(Ljava/lang/String;)Ljavax/crypto/Mac;

    move-result-object v0

    iput-object v0, p0, Lcom/trilead/ssh2/crypto/digest/MessageMac;->c:Ljavax/crypto/Mac;

    new-instance v1, Ljavax/crypto/spec/SecretKeySpec;

    invoke-direct {v1, p2, p1}, Ljavax/crypto/spec/SecretKeySpec;-><init>([BLjava/lang/String;)V

    invoke-virtual {v0, v1}, Ljavax/crypto/Mac;->init(Ljava/security/Key;)V
    :try_end_0
    .catch Ljava/security/GeneralSecurityException; {:try_start_0 .. :try_end_0} :catch_0

    return-void

    :catch_0
    move-exception p1

    new-instance p2, Ljava/lang/IllegalArgumentException;

    const-string v0, "Could not create Mac"

    invoke-direct {p2, v0, p1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;Ljava/lang/Throwable;)V

    throw p2
.end method

.method public static e(Ljava/lang/String;)I
    .locals 0

    invoke-static {p0}, Lcom/trilead/ssh2/crypto/digest/MessageMac$Hmac;->a(Ljava/lang/String;)Lcom/trilead/ssh2/crypto/digest/MessageMac$Hmac;

    move-result-object p0

    iget p0, p0, Lcom/trilead/ssh2/crypto/digest/MessageMac$Hmac;->c:I

    return p0
.end method

.method public static f()[Ljava/lang/String;
    .locals 6

    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    invoke-static {}, Lcom/trilead/ssh2/crypto/digest/MessageMac$Hmac;->values()[Lcom/trilead/ssh2/crypto/digest/MessageMac$Hmac;

    move-result-object v1

    array-length v2, v1

    const/4 v3, 0x0

    const/4 v4, 0x0

    :goto_0
    if-ge v4, v2, :cond_0

    aget-object v5, v1, v4

    .line 1
    iget-object v5, v5, Lcom/trilead/ssh2/crypto/digest/MessageMac$Hmac;->a:Ljava/lang/String;

    .line 2
    invoke-virtual {v0, v3, v5}, Ljava/util/ArrayList;->add(ILjava/lang/Object;)V

    add-int/lit8 v4, v4, 0x1

    goto :goto_0

    :cond_0
    invoke-virtual {v0}, Ljava/util/ArrayList;->size()I

    move-result v1

    new-array v1, v1, [Ljava/lang/String;

    invoke-virtual {v0, v1}, Ljava/util/ArrayList;->toArray([Ljava/lang/Object;)[Ljava/lang/Object;

    move-result-object v0

    check-cast v0, [Ljava/lang/String;

    return-object v0
.end method


# virtual methods
.method public final a([B)V
    .locals 3

    iget-object v0, p0, Lcom/trilead/ssh2/crypto/digest/MessageMac;->c:Ljavax/crypto/Mac;

    invoke-virtual {v0}, Ljavax/crypto/Mac;->doFinal()[B

    move-result-object v0

    array-length v1, v0

    const/4 v2, 0x0

    sub-int/2addr v1, v2

    invoke-static {v0, v2, p1, v2, v1}, Ljava/lang/System;->arraycopy(Ljava/lang/Object;ILjava/lang/Object;II)V

    return-void
.end method

.method public final b(I)V
    .locals 2

    iget-object v0, p0, Lcom/trilead/ssh2/crypto/digest/MessageMac;->c:Ljavax/crypto/Mac;

    invoke-virtual {v0}, Ljavax/crypto/Mac;->reset()V

    iget-object v0, p0, Lcom/trilead/ssh2/crypto/digest/MessageMac;->c:Ljavax/crypto/Mac;

    shr-int/lit8 v1, p1, 0x18

    int-to-byte v1, v1

    invoke-virtual {v0, v1}, Ljavax/crypto/Mac;->update(B)V

    iget-object v0, p0, Lcom/trilead/ssh2/crypto/digest/MessageMac;->c:Ljavax/crypto/Mac;

    shr-int/lit8 v1, p1, 0x10

    int-to-byte v1, v1

    invoke-virtual {v0, v1}, Ljavax/crypto/Mac;->update(B)V

    iget-object v0, p0, Lcom/trilead/ssh2/crypto/digest/MessageMac;->c:Ljavax/crypto/Mac;

    shr-int/lit8 v1, p1, 0x8

    int-to-byte v1, v1

    invoke-virtual {v0, v1}, Ljavax/crypto/Mac;->update(B)V

    iget-object v0, p0, Lcom/trilead/ssh2/crypto/digest/MessageMac;->c:Ljavax/crypto/Mac;

    int-to-byte p1, p1

    invoke-virtual {v0, p1}, Ljavax/crypto/Mac;->update(B)V

    return-void
.end method

.method public final c()I
    .locals 1

    iget-object v0, p0, Lcom/trilead/ssh2/crypto/digest/MessageMac;->c:Ljavax/crypto/Mac;

    invoke-virtual {v0}, Ljavax/crypto/Mac;->getMacLength()I

    move-result v0

    return v0
.end method

.method public final d([BI)V
    .locals 2

    iget-object v0, p0, Lcom/trilead/ssh2/crypto/digest/MessageMac;->c:Ljavax/crypto/Mac;

    const/4 v1, 0x0

    invoke-virtual {v0, p1, v1, p2}, Ljavax/crypto/Mac;->update([BII)V

    return-void
.end method
