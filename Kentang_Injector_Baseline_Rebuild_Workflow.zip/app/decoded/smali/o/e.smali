.class public final Lo/e;
.super Ljava/lang/Thread;
.source "SourceFile"

# interfaces
.implements Lo/g;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lo/e$a;
    }
.end annotation


# static fields
.field public static final d:La/b;


# instance fields
.field public a:Lo/c;

.field public b:Ljava/util/concurrent/Semaphore;

.field public c:Ljava/net/ServerSocket;


# direct methods
.method public static constructor <clinit>()V
    .locals 2

    const-class v0, Lo/e;

    .line 1
    new-instance v1, La/b;

    invoke-direct {v1, v0}, La/b;-><init>(Ljava/lang/Class;)V

    .line 2
    sput-object v1, Lo/e;->d:La/b;

    return-void
.end method

.method public constructor <init>(Lo/c;II)V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Thread;-><init>()V

    iput-object p1, p0, Lo/e;->a:Lo/c;

    const-string p1, "DynamicAcceptThread"

    invoke-virtual {p0, p1}, Ljava/lang/Thread;->setName(Ljava/lang/String;)V

    new-instance p1, Ljava/net/ServerSocket;

    invoke-direct {p1, p2}, Ljava/net/ServerSocket;-><init>(I)V

    iput-object p1, p0, Lo/e;->c:Ljava/net/ServerSocket;

    const/4 p1, 0x2

    if-ge p3, p1, :cond_0

    const/16 p3, 0x19

    :cond_0
    new-instance p1, Ljava/util/concurrent/Semaphore;

    invoke-direct {p1, p3}, Ljava/util/concurrent/Semaphore;-><init>(I)V

    iput-object p1, p0, Lo/e;->b:Ljava/util/concurrent/Semaphore;

    return-void
.end method


# virtual methods
.method public final a()V
    .locals 1

    :try_start_0
    iget-object v0, p0, Lo/e;->c:Ljava/net/ServerSocket;

    invoke-virtual {v0}, Ljava/net/ServerSocket;->close()V
    :try_end_0
    .catch Ljava/io/IOException; {:try_start_0 .. :try_end_0} :catch_0

    :catch_0
    return-void
.end method

.method public final run()V
    .locals 3

    :try_start_0
    iget-object v0, p0, Lo/e;->a:Lo/c;

    invoke-virtual {v0, p0}, Lo/c;->q(Lo/g;)V
    :try_end_0
    .catch Ljava/io/IOException; {:try_start_0 .. :try_end_0} :catch_1

    :goto_0
    :try_start_1
    iget-object v0, p0, Lo/e;->c:Ljava/net/ServerSocket;

    invoke-virtual {v0}, Ljava/net/ServerSocket;->accept()Ljava/net/Socket;

    move-result-object v0
    :try_end_1
    .catch Ljava/io/IOException; {:try_start_1 .. :try_end_1} :catch_0

    iget-object v1, p0, Lo/e;->b:Ljava/util/concurrent/Semaphore;

    invoke-virtual {v1}, Ljava/util/concurrent/Semaphore;->acquireUninterruptibly()V

    new-instance v1, Lo/e$a;

    new-instance v2, Lv/b;

    invoke-direct {v2}, Lv/b;-><init>()V

    invoke-direct {v1, p0, v2, v0}, Lo/e$a;-><init>(Lo/e;Lv/a;Ljava/net/Socket;)V

    new-instance v0, Ljava/lang/Thread;

    invoke-direct {v0, v1}, Ljava/lang/Thread;-><init>(Ljava/lang/Runnable;)V

    const/4 v1, 0x1

    invoke-virtual {v0, v1}, Ljava/lang/Thread;->setDaemon(Z)V

    invoke-virtual {v0}, Ljava/lang/Thread;->start()V

    goto :goto_0

    :catch_0
    invoke-virtual {p0}, Lo/e;->a()V

    return-void

    :catch_1
    invoke-virtual {p0}, Lo/e;->a()V

    return-void
.end method
