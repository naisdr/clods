.class public final Lo/c;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ls/d;


# static fields
.field public static final h:La/b;


# instance fields
.field public a:Ljava/util/HashMap;

.field public b:Ls/i;

.field public c:Ljava/util/Vector;

.field public d:I

.field public e:Ljava/util/HashMap;

.field public f:Ljava/util/Vector;

.field public g:Z


# direct methods
.method public static constructor <clinit>()V
    .locals 2

    const-class v0, Lo/c;

    .line 1
    new-instance v1, La/b;

    invoke-direct {v1, v0}, La/b;-><init>(Ljava/lang/Class;)V

    .line 2
    sput-object v1, Lo/c;->h:La/b;

    return-void
.end method

.method public constructor <init>(Ls/i;)V
    .locals 2

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    new-instance v0, Ljava/util/HashMap;

    invoke-direct {v0}, Ljava/util/HashMap;-><init>()V

    iput-object v0, p0, Lo/c;->a:Ljava/util/HashMap;

    new-instance v0, Ljava/util/Vector;

    invoke-direct {v0}, Ljava/util/Vector;-><init>()V

    iput-object v0, p0, Lo/c;->c:Ljava/util/Vector;

    const/16 v0, 0x64

    iput v0, p0, Lo/c;->d:I

    new-instance v1, Ljava/util/HashMap;

    invoke-direct {v1}, Ljava/util/HashMap;-><init>()V

    iput-object v1, p0, Lo/c;->e:Ljava/util/HashMap;

    new-instance v1, Ljava/util/Vector;

    invoke-direct {v1}, Ljava/util/Vector;-><init>()V

    iput-object v1, p0, Lo/c;->f:Ljava/util/Vector;

    const/4 v1, 0x1

    iput-boolean v1, p0, Lo/c;->g:Z

    iput-object p1, p0, Lo/c;->b:Ls/i;

    const/16 v1, 0x50

    invoke-virtual {p1, p0, v1, v0}, Ls/i;->i(Ls/d;II)V

    return-void
.end method


# virtual methods
.method public final a(Ljava/lang/Throwable;)V
    .locals 7

    sget-object v0, Lo/c;->h:La/b;

    invoke-static {v0}, Ljava/util/Objects;->requireNonNull(Ljava/lang/Object;)Ljava/lang/Object;

    iget-object v0, p0, Lo/c;->f:Ljava/util/Vector;

    monitor-enter v0

    const/4 v1, 0x0

    const/4 v2, 0x0

    :goto_0
    :try_start_0
    iget-object v3, p0, Lo/c;->f:Ljava/util/Vector;

    invoke-virtual {v3}, Ljava/util/Vector;->size()I

    move-result v3

    if-ge v2, v3, :cond_0

    iget-object v3, p0, Lo/c;->f:Ljava/util/Vector;

    invoke-virtual {v3, v2}, Ljava/util/Vector;->elementAt(I)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Lo/g;

    invoke-interface {v3}, Lo/g;->a()V

    add-int/lit8 v2, v2, 0x1

    goto :goto_0

    :cond_0
    iput-boolean v1, p0, Lo/c;->g:Z

    monitor-exit v0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_3

    iget-object v2, p0, Lo/c;->c:Ljava/util/Vector;

    monitor-enter v2

    const/4 v0, 0x0

    :goto_1
    :try_start_1
    iget-object v3, p0, Lo/c;->c:Ljava/util/Vector;

    invoke-virtual {v3}, Ljava/util/Vector;->size()I

    move-result v3

    if-ge v0, v3, :cond_2

    iget-object v3, p0, Lo/c;->c:Ljava/util/Vector;

    invoke-virtual {v3, v0}, Ljava/util/Vector;->elementAt(I)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Lo/a;

    monitor-enter v3
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_2

    :try_start_2
    invoke-virtual {v3}, Lo/a;->a()V

    const/4 v4, 0x4

    iput v4, v3, Lo/a;->k:I

    new-instance v4, Ljava/io/IOException;

    const-string v5, "The connection is being shutdown"

    invoke-direct {v4, v5}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    invoke-virtual {v4, p1}, Ljava/lang/Throwable;->initCause(Ljava/lang/Throwable;)Ljava/lang/Throwable;

    move-result-object v4

    .line 1
    iget-object v5, v3, Lo/a;->q:Ljava/lang/Object;

    monitor-enter v5
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_1

    :try_start_3
    iget-object v6, v3, Lo/a;->r:Ljava/lang/Throwable;

    if-nez v6, :cond_1

    iput-object v4, v3, Lo/a;->r:Ljava/lang/Throwable;

    :cond_1
    monitor-exit v5
    :try_end_3
    .catchall {:try_start_3 .. :try_end_3} :catchall_0

    .line 2
    :try_start_4
    invoke-virtual {v3}, Ljava/lang/Object;->notifyAll()V

    monitor-exit v3
    :try_end_4
    .catchall {:try_start_4 .. :try_end_4} :catchall_1

    add-int/lit8 v0, v0, 0x1

    goto :goto_1

    :catchall_0
    move-exception p1

    .line 3
    :try_start_5
    monitor-exit v5
    :try_end_5
    .catchall {:try_start_5 .. :try_end_5} :catchall_0

    :try_start_6
    throw p1

    :catchall_1
    move-exception p1

    .line 4
    monitor-exit v3
    :try_end_6
    .catchall {:try_start_6 .. :try_end_6} :catchall_1

    :try_start_7
    throw p1

    :cond_2
    iget-object p1, p0, Lo/c;->c:Ljava/util/Vector;

    invoke-virtual {p1, v1}, Ljava/util/Vector;->setSize(I)V

    iget-object p1, p0, Lo/c;->c:Ljava/util/Vector;

    invoke-virtual {p1}, Ljava/util/Vector;->trimToSize()V

    iget-object p1, p0, Lo/c;->c:Ljava/util/Vector;

    invoke-virtual {p1}, Ljava/lang/Object;->notifyAll()V

    monitor-exit v2

    return-void

    :catchall_2
    move-exception p1

    monitor-exit v2
    :try_end_7
    .catchall {:try_start_7 .. :try_end_7} :catchall_2

    throw p1

    :catchall_3
    move-exception p1

    :try_start_8
    monitor-exit v0
    :try_end_8
    .catchall {:try_start_8 .. :try_end_8} :catchall_3

    throw p1
.end method

.method public final b([BI)V
    .locals 7

    const/4 v0, 0x0

    aget-byte v1, p1, v0

    const/4 v2, 0x1

    packed-switch v1, :pswitch_data_0

    const/4 v3, 0x3

    const/4 v4, 0x4

    const/4 v5, 0x5

    const/4 v6, 0x2

    packed-switch v1, :pswitch_data_1

    new-instance p2, Ljava/io/IOException;

    const-string v1, "Cannot handle unknown channel message "

    .line 1
    invoke-static {v1}, Lcom/trilead/ssh2/crypto/digest/a;->e(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    .line 2
    aget-byte p1, p1, v0

    and-int/lit16 p1, p1, 0xff

    invoke-virtual {v1, p1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    invoke-direct {p2, p1}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    throw p2

    .line 3
    :pswitch_0
    iget-object p1, p0, Lo/c;->c:Ljava/util/Vector;

    monitor-enter p1

    :try_start_0
    iget-object p2, p0, Lo/c;->c:Ljava/util/Vector;

    invoke-virtual {p2}, Ljava/lang/Object;->notifyAll()V

    monitor-exit p1
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    sget-object p1, Lo/c;->h:La/b;

    invoke-static {p1}, Ljava/util/Objects;->requireNonNull(Ljava/lang/Object;)Ljava/lang/Object;

    goto/16 :goto_3

    :catchall_0
    move-exception p2

    :try_start_1
    monitor-exit p1
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    throw p2

    .line 4
    :pswitch_1
    iget-object v1, p0, Lo/c;->c:Ljava/util/Vector;

    monitor-enter v1

    :try_start_2
    iget-object p1, p0, Lo/c;->c:Ljava/util/Vector;

    invoke-virtual {p1}, Ljava/lang/Object;->notifyAll()V

    monitor-exit v1
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_1

    sget-object p1, Lo/c;->h:La/b;

    invoke-static {p1}, Ljava/util/Objects;->requireNonNull(Ljava/lang/Object;)Ljava/lang/Object;

    goto/16 :goto_3

    :catchall_1
    move-exception p1

    :try_start_3
    monitor-exit v1
    :try_end_3
    .catchall {:try_start_3 .. :try_end_3} :catchall_1

    throw p1

    .line 5
    :pswitch_2
    new-instance v1, Lq/c;

    invoke-direct {v1, p1, p2}, Lq/c;-><init>([BI)V

    invoke-virtual {v1}, Lq/c;->b()I

    invoke-virtual {v1}, Lq/c;->g()Ljava/lang/String;

    invoke-virtual {v1}, Lq/c;->a()Z

    move-result p1

    if-eqz p1, :cond_0

    new-array p1, v2, [B

    const/16 p2, 0x52

    aput-byte p2, p1, v0

    iget-object p2, p0, Lo/c;->b:Ls/i;

    invoke-virtual {p2, p1}, Ls/i;->k([B)V

    :cond_0
    sget-object p1, Lo/c;->h:La/b;

    invoke-static {p1}, Ljava/util/Objects;->requireNonNull(Ljava/lang/Object;)Ljava/lang/Object;

    goto/16 :goto_3

    .line 6
    :pswitch_3
    invoke-virtual {p0, p1, p2}, Lo/c;->k([BI)V

    goto/16 :goto_3

    :pswitch_4
    invoke-virtual {p0, p1, p2}, Lo/c;->n([BI)V

    goto/16 :goto_3

    :pswitch_5
    invoke-virtual {p0, p1, p2}, Lo/c;->m([BI)V

    goto/16 :goto_3

    :pswitch_6
    invoke-virtual {p0, p1, p2}, Lo/c;->h([BI)V

    goto/16 :goto_3

    :pswitch_7
    if-ne p2, v5, :cond_2

    .line 7
    aget-byte p2, p1, v2

    and-int/lit16 p2, p2, 0xff

    shl-int/lit8 p2, p2, 0x18

    aget-byte v0, p1, v6

    and-int/lit16 v0, v0, 0xff

    shl-int/lit8 v0, v0, 0x10

    or-int/2addr p2, v0

    aget-byte v0, p1, v3

    and-int/lit16 v0, v0, 0xff

    shl-int/lit8 v0, v0, 0x8

    or-int/2addr p2, v0

    aget-byte p1, p1, v4

    and-int/lit16 p1, p1, 0xff

    or-int/2addr p1, p2

    invoke-virtual {p0, p1}, Lo/c;->f(I)Lo/a;

    move-result-object p2

    if-eqz p2, :cond_1

    invoke-virtual {p2}, Lo/a;->a()V

    sget-object p1, Lo/c;->h:La/b;

    invoke-static {p1}, Ljava/util/Objects;->requireNonNull(Ljava/lang/Object;)Ljava/lang/Object;

    goto/16 :goto_3

    :cond_1
    new-instance p2, Ljava/io/IOException;

    const-string v0, "Unexpected SSH_MSG_CHANNEL_EOF message for non-existent channel "

    .line 8
    invoke-static {v0, p1}, Lcom/trilead/ssh2/crypto/digest/a;->c(Ljava/lang/String;I)Ljava/lang/String;

    move-result-object p1

    .line 9
    invoke-direct {p2, p1}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    throw p2

    :cond_2
    new-instance p1, Ljava/io/IOException;

    const-string v0, "SSH_MSG_CHANNEL_EOF message has wrong size ("

    const-string v1, ")"

    .line 10
    invoke-static {v0, p2, v1}, Lcom/trilead/ssh2/crypto/digest/a;->d(Ljava/lang/String;ILjava/lang/String;)Ljava/lang/String;

    move-result-object p2

    .line 11
    invoke-direct {p1, p2}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    throw p1

    .line 12
    :pswitch_8
    invoke-virtual {p0, p1, p2}, Lo/c;->j([BI)V

    goto/16 :goto_3

    :pswitch_9
    invoke-virtual {p0, p1, p2}, Lo/c;->i([BI)V

    goto/16 :goto_3

    :pswitch_a
    invoke-virtual {p0, p1, p2}, Lo/c;->o([BI)V

    goto/16 :goto_3

    :pswitch_b
    if-lt p2, v5, :cond_a

    .line 13
    new-instance v1, Lq/c;

    invoke-direct {v1, p1, p2}, Lq/c;-><init>([BI)V

    invoke-virtual {v1}, Lq/c;->b()I

    invoke-virtual {v1}, Lq/c;->i()I

    move-result p1

    invoke-virtual {p0, p1}, Lo/c;->f(I)Lo/a;

    move-result-object p2

    if-eqz p2, :cond_9

    invoke-virtual {v1}, Lq/c;->i()I

    move-result p1

    const-string v5, "UTF-8"

    invoke-virtual {v1, v5}, Lq/c;->h(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    if-eq p1, v2, :cond_6

    if-eq p1, v6, :cond_5

    if-eq p1, v3, :cond_4

    if-eq p1, v4, :cond_3

    const-string v2, "UNKNOWN REASON CODE ("

    const-string v3, ")"

    .line 14
    invoke-static {v2, p1, v3}, Lcom/trilead/ssh2/crypto/digest/a;->d(Ljava/lang/String;ILjava/lang/String;)Ljava/lang/String;

    move-result-object p1

    goto :goto_0

    :cond_3
    const-string p1, "SSH_OPEN_RESOURCE_SHORTAGE"

    goto :goto_0

    :cond_4
    const-string p1, "SSH_OPEN_UNKNOWN_CHANNEL_TYPE"

    goto :goto_0

    :cond_5
    const-string p1, "SSH_OPEN_CONNECT_FAILED"

    goto :goto_0

    :cond_6
    const-string p1, "SSH_OPEN_ADMINISTRATIVELY_PROHIBITED"

    .line 15
    :goto_0
    new-instance v2, Ljava/lang/StringBuffer;

    invoke-direct {v2}, Ljava/lang/StringBuffer;-><init>()V

    invoke-virtual {v2, v1}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    :goto_1
    invoke-virtual {v2}, Ljava/lang/StringBuffer;->length()I

    move-result v1

    if-ge v0, v1, :cond_8

    invoke-virtual {v2, v0}, Ljava/lang/StringBuffer;->charAt(I)C

    move-result v1

    const/16 v3, 0x20

    if-lt v1, v3, :cond_7

    const/16 v3, 0x7e

    if-gt v1, v3, :cond_7

    goto :goto_2

    :cond_7
    const v1, 0xfffd

    invoke-virtual {v2, v0, v1}, Ljava/lang/StringBuffer;->setCharAt(IC)V

    :goto_2
    add-int/lit8 v0, v0, 0x1

    goto :goto_1

    :cond_8
    monitor-enter p2

    :try_start_4
    invoke-virtual {p2}, Lo/a;->a()V

    iput v4, p2, Lo/a;->k:I

    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const-string v1, "The server refused to open the channel ("

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string p1, ", \'"

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object p1

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string p1, "\')"

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    invoke-virtual {p2, p1}, Lo/a;->c(Ljava/lang/String;)V

    invoke-virtual {p2}, Ljava/lang/Object;->notifyAll()V

    monitor-exit p2
    :try_end_4
    .catchall {:try_start_4 .. :try_end_4} :catchall_2

    sget-object p1, Lo/c;->h:La/b;

    invoke-static {p1}, Ljava/util/Objects;->requireNonNull(Ljava/lang/Object;)Ljava/lang/Object;

    goto/16 :goto_3

    :catchall_2
    move-exception p1

    :try_start_5
    monitor-exit p2
    :try_end_5
    .catchall {:try_start_5 .. :try_end_5} :catchall_2

    throw p1

    :cond_9
    new-instance p2, Ljava/io/IOException;

    const-string v0, "Unexpected SSH_MSG_CHANNEL_OPEN_FAILURE message for non-existent channel "

    .line 16
    invoke-static {v0, p1}, Lcom/trilead/ssh2/crypto/digest/a;->c(Ljava/lang/String;I)Ljava/lang/String;

    move-result-object p1

    .line 17
    invoke-direct {p2, p1}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    throw p2

    :cond_a
    new-instance p1, Ljava/io/IOException;

    const-string v0, "SSH_MSG_CHANNEL_OPEN_FAILURE message has wrong size ("

    const-string v1, ")"

    .line 18
    invoke-static {v0, p2, v1}, Lcom/trilead/ssh2/crypto/digest/a;->d(Ljava/lang/String;ILjava/lang/String;)Ljava/lang/String;

    move-result-object p2

    .line 19
    invoke-direct {p1, p2}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    throw p1

    .line 20
    :pswitch_c
    new-array v1, p2, [B

    invoke-static {p1, v0, v1, v0, p2}, Ljava/lang/System;->arraycopy(Ljava/lang/Object;ILjava/lang/Object;II)V

    new-instance v0, Lq/c;

    invoke-direct {v0, p1, p2}, Lq/c;-><init>([BI)V

    invoke-virtual {v0}, Lq/c;->b()I

    move-result p1

    const/16 p2, 0x5b

    if-ne p1, p2, :cond_e

    invoke-virtual {v0}, Lq/c;->i()I

    move-result p1

    invoke-virtual {v0}, Lq/c;->i()I

    move-result p2

    invoke-virtual {v0}, Lq/c;->i()I

    move-result v1

    invoke-virtual {v0}, Lq/c;->i()I

    move-result v3

    .line 21
    iget v4, v0, Lq/c;->c:I

    iget v0, v0, Lq/c;->b:I

    sub-int/2addr v4, v0

    if-nez v4, :cond_d

    .line 22
    invoke-virtual {p0, p1}, Lo/c;->f(I)Lo/a;

    move-result-object v0

    if-eqz v0, :cond_c

    monitor-enter v0

    :try_start_6
    iget v4, v0, Lo/a;->k:I

    if-ne v4, v2, :cond_b

    iput p2, v0, Lo/a;->g:I

    int-to-long p1, v1

    const-wide v1, 0xffffffffL

    and-long/2addr p1, v1

    iput-wide p1, v0, Lo/a;->m:J

    iput v3, v0, Lo/a;->o:I

    iput v6, v0, Lo/a;->k:I

    invoke-virtual {v0}, Ljava/lang/Object;->notifyAll()V

    monitor-exit v0
    :try_end_6
    .catchall {:try_start_6 .. :try_end_6} :catchall_3

    sget-object p1, Lo/c;->h:La/b;

    invoke-static {p1}, Ljava/util/Objects;->requireNonNull(Ljava/lang/Object;)Ljava/lang/Object;

    goto :goto_3

    :cond_b
    :try_start_7
    new-instance p2, Ljava/io/IOException;

    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const-string v2, "Unexpected SSH_MSG_CHANNEL_OPEN_CONFIRMATION message for channel "

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1, p1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    invoke-direct {p2, p1}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    throw p2

    :catchall_3
    move-exception p1

    monitor-exit v0
    :try_end_7
    .catchall {:try_start_7 .. :try_end_7} :catchall_3

    throw p1

    :cond_c
    new-instance p2, Ljava/io/IOException;

    const-string v0, "Unexpected SSH_MSG_CHANNEL_OPEN_CONFIRMATION message for non-existent channel "

    .line 23
    invoke-static {v0, p1}, Lcom/trilead/ssh2/crypto/digest/a;->c(Ljava/lang/String;I)Ljava/lang/String;

    move-result-object p1

    .line 24
    invoke-direct {p2, p1}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    throw p2

    .line 25
    :cond_d
    new-instance p1, Ljava/io/IOException;

    const-string p2, "Padding in SSH_MSG_CHANNEL_OPEN_CONFIRMATION packet!"

    invoke-direct {p1, p2}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    throw p1

    :cond_e
    new-instance p2, Ljava/io/IOException;

    const-string v0, "This is not a SSH_MSG_CHANNEL_OPEN_CONFIRMATION! ("

    const-string v1, ")"

    .line 26
    invoke-static {v0, p1, v1}, Lcom/trilead/ssh2/crypto/digest/a;->d(Ljava/lang/String;ILjava/lang/String;)Ljava/lang/String;

    move-result-object p1

    .line 27
    invoke-direct {p2, p1}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    throw p2

    .line 28
    :pswitch_d
    invoke-virtual {p0, p1, p2}, Lo/c;->l([BI)V

    :goto_3
    return-void

    :pswitch_data_0
    .packed-switch 0x50
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch

    :pswitch_data_1
    .packed-switch 0x5a
        :pswitch_d
        :pswitch_c
        :pswitch_b
        :pswitch_a
        :pswitch_9
        :pswitch_8
        :pswitch_7
        :pswitch_6
        :pswitch_5
        :pswitch_4
        :pswitch_3
    .end packed-switch
.end method

.method public final c(Lo/a;)I
    .locals 2

    iget-object v0, p0, Lo/c;->c:Ljava/util/Vector;

    monitor-enter v0

    :try_start_0
    iget-object v1, p0, Lo/c;->c:Ljava/util/Vector;

    invoke-virtual {v1, p1}, Ljava/util/Vector;->addElement(Ljava/lang/Object;)V

    iget p1, p0, Lo/c;->d:I

    add-int/lit8 v1, p1, 0x1

    iput v1, p0, Lo/c;->d:I

    monitor-exit v0

    return p1

    :catchall_0
    move-exception p1

    monitor-exit v0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    throw p1
.end method

.method public final d()V
    .locals 4

    sget-object v0, Lo/c;->h:La/b;

    invoke-static {v0}, Ljava/util/Objects;->requireNonNull(Ljava/lang/Object;)Ljava/lang/Object;

    iget-object v0, p0, Lo/c;->c:Ljava/util/Vector;

    monitor-enter v0

    :try_start_0
    iget-object v1, p0, Lo/c;->c:Ljava/util/Vector;

    invoke-virtual {v1}, Ljava/util/Vector;->clone()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/util/Vector;

    monitor-exit v0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v0, 0x0

    :goto_0
    invoke-virtual {v1}, Ljava/util/Vector;->size()I

    move-result v2

    if-ge v0, v2, :cond_0

    invoke-virtual {v1, v0}, Ljava/util/Vector;->elementAt(I)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Lo/a;

    :try_start_1
    const-string v3, "Closing all channels"

    invoke-virtual {p0, v2, v3}, Lo/c;->e(Lo/a;Ljava/lang/String;)V
    :try_end_1
    .catch Ljava/io/IOException; {:try_start_1 .. :try_end_1} :catch_0

    :catch_0
    add-int/lit8 v0, v0, 0x1

    goto :goto_0

    :cond_0
    return-void

    :catchall_0
    move-exception v1

    :try_start_2
    monitor-exit v0
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_0

    throw v1
.end method

.method public final e(Lo/a;Ljava/lang/String;)V
    .locals 5

    const/4 v0, 0x5

    new-array v0, v0, [B

    monitor-enter p1

    const/4 v1, 0x4

    :try_start_0
    iput v1, p1, Lo/a;->k:I

    invoke-virtual {p1}, Lo/a;->a()V

    invoke-virtual {p1, p2}, Lo/a;->c(Ljava/lang/String;)V

    const/4 p2, 0x0

    const/16 v2, 0x61

    aput-byte v2, v0, p2

    iget p2, p1, Lo/a;->g:I

    shr-int/lit8 v2, p2, 0x18

    int-to-byte v2, v2

    const/4 v3, 0x1

    aput-byte v2, v0, v3

    const/4 v2, 0x2

    shr-int/lit8 v4, p2, 0x10

    int-to-byte v4, v4

    aput-byte v4, v0, v2

    const/4 v2, 0x3

    shr-int/lit8 v4, p2, 0x8

    int-to-byte v4, v4

    aput-byte v4, v0, v2

    int-to-byte p2, p2

    aput-byte p2, v0, v1

    invoke-virtual {p1}, Ljava/lang/Object;->notifyAll()V

    monitor-exit p1
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_1

    iget-object p2, p1, Lo/a;->h:Ljava/lang/Object;

    monitor-enter p2

    :try_start_1
    iget-boolean v1, p1, Lo/a;->i:Z

    if-ne v1, v3, :cond_0

    monitor-exit p2

    return-void

    :cond_0
    iget-object v1, p0, Lo/c;->b:Ls/i;

    invoke-virtual {v1, v0}, Ls/i;->m([B)V

    iput-boolean v3, p1, Lo/a;->i:Z

    monitor-exit p2
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    sget-object p1, Lo/c;->h:La/b;

    invoke-static {p1}, Ljava/util/Objects;->requireNonNull(Ljava/lang/Object;)Ljava/lang/Object;

    return-void

    :catchall_0
    move-exception p1

    :try_start_2
    monitor-exit p2
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_0

    throw p1

    :catchall_1
    move-exception p2

    :try_start_3
    monitor-exit p1
    :try_end_3
    .catchall {:try_start_3 .. :try_end_3} :catchall_1

    throw p2
.end method

.method public final f(I)Lo/a;
    .locals 4

    iget-object v0, p0, Lo/c;->c:Ljava/util/Vector;

    monitor-enter v0

    const/4 v1, 0x0

    :goto_0
    :try_start_0
    iget-object v2, p0, Lo/c;->c:Ljava/util/Vector;

    invoke-virtual {v2}, Ljava/util/Vector;->size()I

    move-result v2

    if-ge v1, v2, :cond_1

    iget-object v2, p0, Lo/c;->c:Ljava/util/Vector;

    invoke-virtual {v2, v1}, Ljava/util/Vector;->elementAt(I)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Lo/a;

    iget v3, v2, Lo/a;->f:I

    if-ne v3, p1, :cond_0

    monitor-exit v0

    return-object v2

    :cond_0
    add-int/lit8 v1, v1, 0x1

    goto :goto_0

    :cond_1
    monitor-exit v0

    const/4 p1, 0x0

    return-object p1

    :catchall_0
    move-exception p1

    monitor-exit v0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    throw p1
.end method

.method public final g(Ljava/lang/String;Lo/a;)Ljava/io/IOException;
    .locals 1

    new-instance v0, Ljava/io/IOException;

    invoke-direct {v0, p1}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    .line 1
    iget-object p1, p2, Lo/a;->q:Ljava/lang/Object;

    monitor-enter p1

    :try_start_0
    iget-object p2, p2, Lo/a;->r:Ljava/lang/Throwable;

    monitor-exit p1
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 2
    invoke-virtual {v0, p2}, Ljava/lang/Throwable;->initCause(Ljava/lang/Throwable;)Ljava/lang/Throwable;

    move-result-object p1

    check-cast p1, Ljava/io/IOException;

    return-object p1

    :catchall_0
    move-exception p2

    .line 3
    :try_start_1
    monitor-exit p1
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    throw p2
.end method

.method public final h([BI)V
    .locals 2

    const/4 v0, 0x5

    if-ne p2, v0, :cond_1

    const/4 p2, 0x1

    aget-byte p2, p1, p2

    and-int/lit16 p2, p2, 0xff

    shl-int/lit8 p2, p2, 0x18

    const/4 v0, 0x2

    aget-byte v0, p1, v0

    and-int/lit16 v0, v0, 0xff

    shl-int/lit8 v0, v0, 0x10

    or-int/2addr p2, v0

    const/4 v0, 0x3

    aget-byte v0, p1, v0

    and-int/lit16 v0, v0, 0xff

    shl-int/lit8 v0, v0, 0x8

    or-int/2addr p2, v0

    const/4 v0, 0x4

    aget-byte p1, p1, v0

    and-int/lit16 p1, p1, 0xff

    or-int/2addr p1, p2

    invoke-virtual {p0, p1}, Lo/c;->f(I)Lo/a;

    move-result-object p2

    if-eqz p2, :cond_0

    monitor-enter p2

    :try_start_0
    invoke-virtual {p2}, Lo/a;->a()V

    iput v0, p2, Lo/a;->k:I

    const-string p1, "Close requested by remote"

    invoke-virtual {p2, p1}, Lo/a;->c(Ljava/lang/String;)V

    iget p1, p2, Lo/a;->f:I

    invoke-virtual {p0, p1}, Lo/c;->r(I)V

    invoke-virtual {p2}, Ljava/lang/Object;->notifyAll()V

    monitor-exit p2
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    sget-object p1, Lo/c;->h:La/b;

    invoke-static {p1}, Ljava/util/Objects;->requireNonNull(Ljava/lang/Object;)Ljava/lang/Object;

    return-void

    :catchall_0
    move-exception p1

    :try_start_1
    monitor-exit p2
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    throw p1

    :cond_0
    new-instance p2, Ljava/io/IOException;

    const-string v0, "Unexpected SSH_MSG_CHANNEL_CLOSE message for non-existent channel "

    .line 1
    invoke-static {v0, p1}, Lcom/trilead/ssh2/crypto/digest/a;->c(Ljava/lang/String;I)Ljava/lang/String;

    move-result-object p1

    .line 2
    invoke-direct {p2, p1}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    throw p2

    :cond_1
    new-instance p1, Ljava/io/IOException;

    const-string v0, "SSH_MSG_CHANNEL_CLOSE message has wrong size ("

    const-string v1, ")"

    .line 3
    invoke-static {v0, p2, v1}, Lcom/trilead/ssh2/crypto/digest/a;->d(Ljava/lang/String;ILjava/lang/String;)Ljava/lang/String;

    move-result-object p2

    .line 4
    invoke-direct {p1, p2}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    throw p1
.end method

.method public final i([BI)V
    .locals 7

    const/16 v0, 0x9

    if-le p2, v0, :cond_5

    const/4 v1, 0x1

    aget-byte v1, p1, v1

    and-int/lit16 v1, v1, 0xff

    shl-int/lit8 v1, v1, 0x18

    const/4 v2, 0x2

    aget-byte v3, p1, v2

    and-int/lit16 v3, v3, 0xff

    shl-int/lit8 v3, v3, 0x10

    or-int/2addr v1, v3

    const/4 v3, 0x3

    aget-byte v3, p1, v3

    and-int/lit16 v3, v3, 0xff

    const/16 v4, 0x8

    shl-int/2addr v3, v4

    or-int/2addr v1, v3

    const/4 v3, 0x4

    aget-byte v5, p1, v3

    and-int/lit16 v5, v5, 0xff

    or-int/2addr v1, v5

    const/4 v5, 0x5

    aget-byte v5, p1, v5

    and-int/lit16 v5, v5, 0xff

    shl-int/lit8 v5, v5, 0x18

    const/4 v6, 0x6

    aget-byte v6, p1, v6

    and-int/lit16 v6, v6, 0xff

    shl-int/lit8 v6, v6, 0x10

    or-int/2addr v5, v6

    const/4 v6, 0x7

    aget-byte v6, p1, v6

    and-int/lit16 v6, v6, 0xff

    shl-int/2addr v6, v4

    or-int/2addr v5, v6

    aget-byte v4, p1, v4

    and-int/lit16 v4, v4, 0xff

    or-int/2addr v4, v5

    invoke-virtual {p0, v1}, Lo/c;->f(I)Lo/a;

    move-result-object v5

    if-eqz v5, :cond_4

    sub-int/2addr p2, v0

    if-ne v4, p2, :cond_3

    sget-object p2, Lo/c;->h:La/b;

    invoke-static {p2}, Ljava/util/Objects;->requireNonNull(Ljava/lang/Object;)Ljava/lang/Object;

    monitor-enter v5

    :try_start_0
    iget p2, v5, Lo/a;->k:I

    if-ne p2, v3, :cond_0

    monitor-exit v5

    return-void

    :cond_0
    if-ne p2, v2, :cond_2

    iget p2, v5, Lo/a;->l:I

    if-lt p2, v4, :cond_1

    sub-int/2addr p2, v4

    iput p2, v5, Lo/a;->l:I

    iget-object p2, v5, Lo/a;->d:Lo/a$a;

    .line 1
    iget-object p2, p2, Lo/a$a;->b:Lo/f;

    invoke-static {p2}, Ljava/util/Objects;->requireNonNull(Ljava/lang/Object;)Ljava/lang/Object;
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    :try_start_1
    invoke-virtual {p2, p1, v0, v4}, Lo/f;->b([BII)V
    :try_end_1
    .catch Ljava/lang/InterruptedException; {:try_start_1 .. :try_end_1} :catch_0
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    .line 2
    :try_start_2
    monitor-exit v5

    return-void

    .line 3
    :catch_0
    new-instance p1, Ljava/io/InterruptedIOException;

    invoke-direct {p1}, Ljava/io/InterruptedIOException;-><init>()V

    throw p1

    .line 4
    :cond_1
    new-instance p1, Ljava/io/IOException;

    const-string p2, "Remote sent too much data, does not fit into window."

    invoke-direct {p1, p2}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    throw p1

    :cond_2
    new-instance p1, Ljava/io/IOException;

    new-instance p2, Ljava/lang/StringBuilder;

    invoke-direct {p2}, Ljava/lang/StringBuilder;-><init>()V

    const-string v0, "Got SSH_MSG_CHANNEL_DATA, but channel is not in correct state ("

    invoke-virtual {p2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget v0, v5, Lo/a;->k:I

    invoke-virtual {p2, v0}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string v0, ")"

    invoke-virtual {p2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p2

    invoke-direct {p1, p2}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    throw p1

    :catchall_0
    move-exception p1

    monitor-exit v5
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_0

    throw p1

    :cond_3
    new-instance p1, Ljava/io/IOException;

    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const-string v1, "SSH_MSG_CHANNEL_DATA message has wrong len (calculated "

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0, p2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string p2, ", got "

    invoke-virtual {v0, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0, v4}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string p2, ")"

    invoke-virtual {v0, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p2

    invoke-direct {p1, p2}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    throw p1

    :cond_4
    new-instance p1, Ljava/io/IOException;

    const-string p2, "Unexpected SSH_MSG_CHANNEL_DATA message for non-existent channel "

    .line 5
    invoke-static {p2, v1}, Lcom/trilead/ssh2/crypto/digest/a;->c(Ljava/lang/String;I)Ljava/lang/String;

    move-result-object p2

    .line 6
    invoke-direct {p1, p2}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    throw p1

    :cond_5
    new-instance p1, Ljava/io/IOException;

    const-string v0, "SSH_MSG_CHANNEL_DATA message has wrong size ("

    const-string v1, ")"

    .line 7
    invoke-static {v0, p2, v1}, Lcom/trilead/ssh2/crypto/digest/a;->d(Ljava/lang/String;ILjava/lang/String;)Ljava/lang/String;

    move-result-object p2

    .line 8
    invoke-direct {p1, p2}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    throw p1
.end method

.method public final j([BI)V
    .locals 8

    const/16 v0, 0xd

    if-le p2, v0, :cond_6

    const/4 v1, 0x1

    aget-byte v2, p1, v1

    and-int/lit16 v2, v2, 0xff

    shl-int/lit8 v2, v2, 0x18

    const/4 v3, 0x2

    aget-byte v4, p1, v3

    and-int/lit16 v4, v4, 0xff

    shl-int/lit8 v4, v4, 0x10

    or-int/2addr v2, v4

    const/4 v4, 0x3

    aget-byte v4, p1, v4

    and-int/lit16 v4, v4, 0xff

    const/16 v5, 0x8

    shl-int/2addr v4, v5

    or-int/2addr v2, v4

    const/4 v4, 0x4

    aget-byte v6, p1, v4

    and-int/lit16 v6, v6, 0xff

    or-int/2addr v2, v6

    const/4 v6, 0x5

    aget-byte v6, p1, v6

    and-int/lit16 v6, v6, 0xff

    shl-int/lit8 v6, v6, 0x18

    const/4 v7, 0x6

    aget-byte v7, p1, v7

    and-int/lit16 v7, v7, 0xff

    shl-int/lit8 v7, v7, 0x10

    or-int/2addr v6, v7

    const/4 v7, 0x7

    aget-byte v7, p1, v7

    and-int/lit16 v7, v7, 0xff

    shl-int/2addr v7, v5

    or-int/2addr v6, v7

    aget-byte v5, p1, v5

    and-int/lit16 v5, v5, 0xff

    or-int/2addr v5, v6

    const/16 v6, 0x9

    aget-byte v6, p1, v6

    and-int/lit16 v6, v6, 0xff

    shl-int/lit8 v6, v6, 0x18

    const/16 v7, 0xa

    aget-byte v7, p1, v7

    and-int/lit16 v7, v7, 0xff

    shl-int/lit8 v7, v7, 0x10

    or-int/2addr v6, v7

    const/16 v7, 0xb

    aget-byte v7, p1, v7

    and-int/lit16 v7, v7, 0xff

    shl-int/lit8 v7, v7, 0x8

    or-int/2addr v6, v7

    const/16 v7, 0xc

    aget-byte v7, p1, v7

    and-int/lit16 v7, v7, 0xff

    or-int/2addr v6, v7

    invoke-virtual {p0, v2}, Lo/c;->f(I)Lo/a;

    move-result-object v7

    if-eqz v7, :cond_5

    if-ne v5, v1, :cond_4

    sub-int/2addr p2, v0

    if-ne v6, p2, :cond_3

    sget-object p2, Lo/c;->h:La/b;

    invoke-static {p2}, Ljava/util/Objects;->requireNonNull(Ljava/lang/Object;)Ljava/lang/Object;

    monitor-enter v7

    :try_start_0
    iget p2, v7, Lo/a;->k:I

    if-ne p2, v4, :cond_0

    monitor-exit v7

    return-void

    :cond_0
    if-ne p2, v3, :cond_2

    iget p2, v7, Lo/a;->l:I

    if-lt p2, v6, :cond_1

    sub-int/2addr p2, v6

    iput p2, v7, Lo/a;->l:I

    iget-object p2, v7, Lo/a;->e:Lo/a$a;

    .line 1
    iget-object p2, p2, Lo/a$a;->b:Lo/f;

    invoke-static {p2}, Ljava/util/Objects;->requireNonNull(Ljava/lang/Object;)Ljava/lang/Object;
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    :try_start_1
    invoke-virtual {p2, p1, v0, v6}, Lo/f;->b([BII)V
    :try_end_1
    .catch Ljava/lang/InterruptedException; {:try_start_1 .. :try_end_1} :catch_0
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    .line 2
    :try_start_2
    monitor-exit v7

    return-void

    .line 3
    :catch_0
    new-instance p1, Ljava/io/InterruptedIOException;

    invoke-direct {p1}, Ljava/io/InterruptedIOException;-><init>()V

    throw p1

    .line 4
    :cond_1
    new-instance p1, Ljava/io/IOException;

    const-string p2, "Remote sent too much data, does not fit into window."

    invoke-direct {p1, p2}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    throw p1

    :cond_2
    new-instance p1, Ljava/io/IOException;

    new-instance p2, Ljava/lang/StringBuilder;

    invoke-direct {p2}, Ljava/lang/StringBuilder;-><init>()V

    const-string v0, "Got SSH_MSG_CHANNEL_EXTENDED_DATA, but channel is not in correct state ("

    invoke-virtual {p2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget v0, v7, Lo/a;->k:I

    invoke-virtual {p2, v0}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string v0, ")"

    invoke-virtual {p2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p2

    invoke-direct {p1, p2}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    throw p1

    :catchall_0
    move-exception p1

    monitor-exit v7
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_0

    throw p1

    :cond_3
    new-instance p1, Ljava/io/IOException;

    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const-string v1, "SSH_MSG_CHANNEL_EXTENDED_DATA message has wrong len (calculated "

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0, p2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string p2, ", got "

    invoke-virtual {v0, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0, v6}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string p2, ")"

    invoke-virtual {v0, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p2

    invoke-direct {p1, p2}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    throw p1

    :cond_4
    new-instance p1, Ljava/io/IOException;

    const-string p2, "SSH_MSG_CHANNEL_EXTENDED_DATA message has unknown type ("

    const-string v0, ")"

    .line 5
    invoke-static {p2, v5, v0}, Lcom/trilead/ssh2/crypto/digest/a;->d(Ljava/lang/String;ILjava/lang/String;)Ljava/lang/String;

    move-result-object p2

    .line 6
    invoke-direct {p1, p2}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    throw p1

    :cond_5
    new-instance p1, Ljava/io/IOException;

    const-string p2, "Unexpected SSH_MSG_CHANNEL_EXTENDED_DATA message for non-existent channel "

    .line 7
    invoke-static {p2, v2}, Lcom/trilead/ssh2/crypto/digest/a;->c(Ljava/lang/String;I)Ljava/lang/String;

    move-result-object p2

    .line 8
    invoke-direct {p1, p2}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    throw p1

    :cond_6
    new-instance p1, Ljava/io/IOException;

    const-string v0, "SSH_MSG_CHANNEL_EXTENDED_DATA message has wrong size ("

    const-string v1, ")"

    .line 9
    invoke-static {v0, p2, v1}, Lcom/trilead/ssh2/crypto/digest/a;->d(Ljava/lang/String;ILjava/lang/String;)Ljava/lang/String;

    move-result-object p2

    .line 10
    invoke-direct {p1, p2}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    throw p1
.end method

.method public final k([BI)V
    .locals 2

    const/4 v0, 0x5

    if-ne p2, v0, :cond_1

    const/4 p2, 0x1

    aget-byte p2, p1, p2

    and-int/lit16 p2, p2, 0xff

    shl-int/lit8 p2, p2, 0x18

    const/4 v0, 0x2

    aget-byte v0, p1, v0

    and-int/lit16 v0, v0, 0xff

    shl-int/lit8 v0, v0, 0x10

    or-int/2addr p2, v0

    const/4 v0, 0x3

    aget-byte v0, p1, v0

    and-int/lit16 v0, v0, 0xff

    shl-int/lit8 v0, v0, 0x8

    or-int/2addr p2, v0

    const/4 v0, 0x4

    aget-byte p1, p1, v0

    and-int/lit16 p1, p1, 0xff

    or-int/2addr p1, p2

    invoke-virtual {p0, p1}, Lo/c;->f(I)Lo/a;

    move-result-object p2

    if-eqz p2, :cond_0

    monitor-enter p2

    :try_start_0
    invoke-virtual {p2}, Ljava/lang/Object;->notifyAll()V

    monitor-exit p2
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    sget-object p1, Lo/c;->h:La/b;

    invoke-static {p1}, Ljava/util/Objects;->requireNonNull(Ljava/lang/Object;)Ljava/lang/Object;

    return-void

    :catchall_0
    move-exception p1

    :try_start_1
    monitor-exit p2
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    throw p1

    :cond_0
    new-instance p2, Ljava/io/IOException;

    const-string v0, "Unexpected SSH_MSG_CHANNEL_FAILURE message for non-existent channel "

    .line 1
    invoke-static {v0, p1}, Lcom/trilead/ssh2/crypto/digest/a;->c(Ljava/lang/String;I)Ljava/lang/String;

    move-result-object p1

    .line 2
    invoke-direct {p2, p1}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    throw p2

    :cond_1
    new-instance p1, Ljava/io/IOException;

    const-string v0, "SSH_MSG_CHANNEL_FAILURE message has wrong size ("

    const-string v1, ")"

    .line 3
    invoke-static {v0, p2, v1}, Lcom/trilead/ssh2/crypto/digest/a;->d(Ljava/lang/String;ILjava/lang/String;)Ljava/lang/String;

    move-result-object p2

    .line 4
    invoke-direct {p1, p2}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    throw p1
.end method

.method public final l([BI)V
    .locals 9

    new-instance v0, Lq/c;

    invoke-direct {v0, p1, p2}, Lq/c;-><init>([BI)V

    invoke-virtual {v0}, Lq/c;->b()I

    invoke-virtual {v0}, Lq/c;->g()Ljava/lang/String;

    move-result-object p1

    invoke-virtual {v0}, Lq/c;->i()I

    move-result p2

    invoke-virtual {v0}, Lq/c;->i()I

    move-result v1

    invoke-virtual {v0}, Lq/c;->i()I

    move-result v2

    const-string v3, "x11"

    invoke-virtual {v3, p1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v3

    const-wide v4, 0xffffffffL

    const/16 v6, 0x5c

    const/4 v7, 0x1

    if-eqz v3, :cond_1

    iget-object v3, p0, Lo/c;->a:Ljava/util/HashMap;

    monitor-enter v3

    :try_start_0
    iget-object p1, p0, Lo/c;->a:Ljava/util/HashMap;

    invoke-virtual {p1}, Ljava/util/HashMap;->size()I

    move-result p1

    if-nez p1, :cond_0

    const-string p1, "X11 forwarding not activated"

    const-string v0, ""

    iget-object v1, p0, Lo/c;->b:Ls/i;

    .line 1
    new-instance v2, Lq/b;

    invoke-direct {v2}, Lq/b;-><init>()V

    invoke-virtual {v2, v6}, Lq/b;->d(I)V

    invoke-virtual {v2, p2}, Lq/b;->j(I)V

    invoke-virtual {v2, v7}, Lq/b;->j(I)V

    invoke-virtual {v2, p1}, Lq/b;->h(Ljava/lang/String;)V

    invoke-virtual {v2, v0}, Lq/b;->h(Ljava/lang/String;)V

    invoke-virtual {v2}, Lq/b;->a()[B

    move-result-object p1

    .line 2
    invoke-virtual {v1, p1}, Ls/i;->k([B)V

    sget-object p1, Lo/c;->h:La/b;

    invoke-static {p1}, Ljava/util/Objects;->requireNonNull(Ljava/lang/Object;)Ljava/lang/Object;

    monitor-exit v3

    return-void

    :cond_0
    monitor-exit v3
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_1

    invoke-virtual {v0}, Lq/c;->g()Ljava/lang/String;

    invoke-virtual {v0}, Lq/c;->i()I

    new-instance p1, Lo/a;

    invoke-direct {p1, p0}, Lo/a;-><init>(Lo/c;)V

    monitor-enter p1

    :try_start_1
    iput p2, p1, Lo/a;->g:I

    int-to-long v0, v1

    and-long/2addr v0, v4

    iput-wide v0, p1, Lo/a;->m:J

    iput v2, p1, Lo/a;->o:I

    invoke-virtual {p0, p1}, Lo/c;->c(Lo/a;)I

    move-result p2

    iput p2, p1, Lo/a;->f:I

    monitor-exit p1
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    new-instance p2, Lo/k;

    invoke-direct {p2, p1}, Lo/k;-><init>(Lo/a;)V

    invoke-virtual {p2, v7}, Ljava/lang/Thread;->setDaemon(Z)V

    invoke-virtual {p2}, Ljava/lang/Thread;->start()V

    return-void

    :catchall_0
    move-exception p2

    :try_start_2
    monitor-exit p1
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_0

    throw p2

    :catchall_1
    move-exception p1

    :try_start_3
    monitor-exit v3
    :try_end_3
    .catchall {:try_start_3 .. :try_end_3} :catchall_1

    throw p1

    :cond_1
    const-string v3, "forwarded-tcpip"

    invoke-virtual {v3, p1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p1

    if-eqz p1, :cond_3

    invoke-virtual {v0}, Lq/c;->g()Ljava/lang/String;

    invoke-virtual {v0}, Lq/c;->i()I

    move-result p1

    invoke-virtual {v0}, Lq/c;->g()Ljava/lang/String;

    invoke-virtual {v0}, Lq/c;->i()I

    iget-object v0, p0, Lo/c;->e:Ljava/util/HashMap;

    monitor-enter v0

    :try_start_4
    iget-object v3, p0, Lo/c;->e:Ljava/util/HashMap;

    new-instance v8, Ljava/lang/Integer;

    invoke-direct {v8, p1}, Ljava/lang/Integer;-><init>(I)V

    invoke-virtual {v3, v8}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Lo/j;

    monitor-exit v0
    :try_end_4
    .catchall {:try_start_4 .. :try_end_4} :catchall_3

    if-nez p1, :cond_2

    const-string p1, "No thanks, unknown port in forwarded-tcpip request"

    const-string v0, ""

    iget-object v1, p0, Lo/c;->b:Ls/i;

    .line 3
    new-instance v2, Lq/b;

    invoke-direct {v2}, Lq/b;-><init>()V

    invoke-virtual {v2, v6}, Lq/b;->d(I)V

    invoke-virtual {v2, p2}, Lq/b;->j(I)V

    invoke-virtual {v2, v7}, Lq/b;->j(I)V

    invoke-virtual {v2, p1}, Lq/b;->h(Ljava/lang/String;)V

    invoke-virtual {v2, v0}, Lq/b;->h(Ljava/lang/String;)V

    invoke-virtual {v2}, Lq/b;->a()[B

    move-result-object p1

    .line 4
    invoke-virtual {v1, p1}, Ls/i;->k([B)V

    sget-object p1, Lo/c;->h:La/b;

    invoke-static {p1}, Ljava/util/Objects;->requireNonNull(Ljava/lang/Object;)Ljava/lang/Object;

    return-void

    :cond_2
    new-instance p1, Lo/a;

    invoke-direct {p1, p0}, Lo/a;-><init>(Lo/c;)V

    monitor-enter p1

    :try_start_5
    iput p2, p1, Lo/a;->g:I

    int-to-long v0, v1

    and-long/2addr v0, v4

    iput-wide v0, p1, Lo/a;->m:J

    iput v2, p1, Lo/a;->o:I

    invoke-virtual {p0, p1}, Lo/c;->c(Lo/a;)I

    move-result p2

    iput p2, p1, Lo/a;->f:I

    monitor-exit p1
    :try_end_5
    .catchall {:try_start_5 .. :try_end_5} :catchall_2

    new-instance p2, Lo/i;

    invoke-direct {p2, p1}, Lo/i;-><init>(Lo/a;)V

    invoke-virtual {p2, v7}, Ljava/lang/Thread;->setDaemon(Z)V

    invoke-virtual {p2}, Ljava/lang/Thread;->start()V

    return-void

    :catchall_2
    move-exception p2

    :try_start_6
    monitor-exit p1
    :try_end_6
    .catchall {:try_start_6 .. :try_end_6} :catchall_2

    throw p2

    :catchall_3
    move-exception p1

    :try_start_7
    monitor-exit v0
    :try_end_7
    .catchall {:try_start_7 .. :try_end_7} :catchall_3

    throw p1

    :cond_3
    const/4 p1, 0x3

    const-string v0, "Unknown channel type"

    const-string v1, ""

    iget-object v2, p0, Lo/c;->b:Ls/i;

    .line 5
    new-instance v3, Lq/b;

    invoke-direct {v3}, Lq/b;-><init>()V

    invoke-virtual {v3, v6}, Lq/b;->d(I)V

    invoke-virtual {v3, p2}, Lq/b;->j(I)V

    invoke-virtual {v3, p1}, Lq/b;->j(I)V

    invoke-virtual {v3, v0}, Lq/b;->h(Ljava/lang/String;)V

    invoke-virtual {v3, v1}, Lq/b;->h(Ljava/lang/String;)V

    invoke-virtual {v3}, Lq/b;->a()[B

    move-result-object p1

    .line 6
    invoke-virtual {v2, p1}, Ls/i;->k([B)V

    sget-object p1, Lo/c;->h:La/b;

    invoke-static {p1}, Ljava/util/Objects;->requireNonNull(Ljava/lang/Object;)Ljava/lang/Object;

    return-void
.end method

.method public final m([BI)V
    .locals 3

    new-instance v0, Lq/c;

    invoke-direct {v0, p1, p2}, Lq/c;-><init>([BI)V

    invoke-virtual {v0}, Lq/c;->b()I

    invoke-virtual {v0}, Lq/c;->i()I

    move-result p1

    invoke-virtual {p0, p1}, Lo/c;->f(I)Lo/a;

    move-result-object p2

    if-eqz p2, :cond_7

    const-string p1, "US-ASCII"

    invoke-virtual {v0, p1}, Lq/c;->h(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    invoke-virtual {v0}, Lq/c;->a()Z

    move-result v1

    sget-object v2, Lo/c;->h:La/b;

    invoke-static {v2}, Ljava/util/Objects;->requireNonNull(Ljava/lang/Object;)Ljava/lang/Object;

    const-string v2, "exit-status"

    invoke-virtual {p1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v2

    if-eqz v2, :cond_2

    if-nez v1, :cond_1

    invoke-virtual {v0}, Lq/c;->i()I

    move-result p1

    .line 1
    iget v1, v0, Lq/c;->c:I

    iget v0, v0, Lq/c;->b:I

    sub-int/2addr v1, v0

    if-nez v1, :cond_0

    .line 2
    monitor-enter p2

    :try_start_0
    new-instance v0, Ljava/lang/Integer;

    invoke-direct {v0, p1}, Ljava/lang/Integer;-><init>(I)V

    invoke-virtual {p2}, Ljava/lang/Object;->notifyAll()V

    monitor-exit p2

    return-void

    :catchall_0
    move-exception p1

    monitor-exit p2
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    throw p1

    :cond_0
    new-instance p1, Ljava/io/IOException;

    const-string p2, "Badly formatted SSH_MSG_CHANNEL_REQUEST message"

    invoke-direct {p1, p2}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    throw p1

    :cond_1
    new-instance p1, Ljava/io/IOException;

    const-string p2, "Badly formatted SSH_MSG_CHANNEL_REQUEST message, \'want reply\' is true"

    invoke-direct {p1, p2}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    throw p1

    :cond_2
    const-string v2, "exit-signal"

    invoke-virtual {p1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p1

    if-eqz p1, :cond_5

    if-nez v1, :cond_4

    const-string p1, "US-ASCII"

    invoke-virtual {v0, p1}, Lq/c;->h(Ljava/lang/String;)Ljava/lang/String;

    invoke-virtual {v0}, Lq/c;->a()Z

    invoke-virtual {v0}, Lq/c;->g()Ljava/lang/String;

    invoke-virtual {v0}, Lq/c;->g()Ljava/lang/String;

    .line 3
    iget p1, v0, Lq/c;->c:I

    iget v0, v0, Lq/c;->b:I

    sub-int/2addr p1, v0

    if-nez p1, :cond_3

    .line 4
    monitor-enter p2

    :try_start_1
    invoke-virtual {p2}, Ljava/lang/Object;->notifyAll()V

    monitor-exit p2

    return-void

    :catchall_1
    move-exception p1

    monitor-exit p2
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_1

    throw p1

    :cond_3
    new-instance p1, Ljava/io/IOException;

    const-string p2, "Badly formatted SSH_MSG_CHANNEL_REQUEST message"

    invoke-direct {p1, p2}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    throw p1

    :cond_4
    new-instance p1, Ljava/io/IOException;

    const-string p2, "Badly formatted SSH_MSG_CHANNEL_REQUEST message, \'want reply\' is true"

    invoke-direct {p1, p2}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    throw p1

    :cond_5
    if-eqz v1, :cond_6

    const/4 p1, 0x5

    new-array p1, p1, [B

    const/16 v0, 0x64

    const/4 v1, 0x0

    aput-byte v0, p1, v1

    const/4 v0, 0x1

    iget p2, p2, Lo/a;->g:I

    shr-int/lit8 v1, p2, 0x18

    int-to-byte v1, v1

    aput-byte v1, p1, v0

    const/4 v0, 0x2

    shr-int/lit8 v1, p2, 0x10

    int-to-byte v1, v1

    aput-byte v1, p1, v0

    const/4 v0, 0x3

    shr-int/lit8 v1, p2, 0x8

    int-to-byte v1, v1

    aput-byte v1, p1, v0

    const/4 v0, 0x4

    int-to-byte p2, p2

    aput-byte p2, p1, v0

    iget-object p2, p0, Lo/c;->b:Ls/i;

    invoke-virtual {p2, p1}, Ls/i;->k([B)V

    :cond_6
    return-void

    :cond_7
    new-instance p2, Ljava/io/IOException;

    const-string v0, "Unexpected SSH_MSG_CHANNEL_REQUEST message for non-existent channel "

    .line 5
    invoke-static {v0, p1}, Lcom/trilead/ssh2/crypto/digest/a;->c(Ljava/lang/String;I)Ljava/lang/String;

    move-result-object p1

    .line 6
    invoke-direct {p2, p1}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    throw p2
.end method

.method public final n([BI)V
    .locals 2

    const/4 v0, 0x5

    if-ne p2, v0, :cond_1

    const/4 p2, 0x1

    aget-byte p2, p1, p2

    and-int/lit16 p2, p2, 0xff

    shl-int/lit8 p2, p2, 0x18

    const/4 v0, 0x2

    aget-byte v0, p1, v0

    and-int/lit16 v0, v0, 0xff

    shl-int/lit8 v0, v0, 0x10

    or-int/2addr p2, v0

    const/4 v0, 0x3

    aget-byte v0, p1, v0

    and-int/lit16 v0, v0, 0xff

    shl-int/lit8 v0, v0, 0x8

    or-int/2addr p2, v0

    const/4 v0, 0x4

    aget-byte p1, p1, v0

    and-int/lit16 p1, p1, 0xff

    or-int/2addr p1, p2

    invoke-virtual {p0, p1}, Lo/c;->f(I)Lo/a;

    move-result-object p2

    if-eqz p2, :cond_0

    monitor-enter p2

    :try_start_0
    invoke-virtual {p2}, Ljava/lang/Object;->notifyAll()V

    monitor-exit p2
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    sget-object p1, Lo/c;->h:La/b;

    invoke-static {p1}, Ljava/util/Objects;->requireNonNull(Ljava/lang/Object;)Ljava/lang/Object;

    return-void

    :catchall_0
    move-exception p1

    :try_start_1
    monitor-exit p2
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    throw p1

    :cond_0
    new-instance p2, Ljava/io/IOException;

    const-string v0, "Unexpected SSH_MSG_CHANNEL_SUCCESS message for non-existent channel "

    .line 1
    invoke-static {v0, p1}, Lcom/trilead/ssh2/crypto/digest/a;->c(Ljava/lang/String;I)Ljava/lang/String;

    move-result-object p1

    .line 2
    invoke-direct {p2, p1}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    throw p2

    :cond_1
    new-instance p1, Ljava/io/IOException;

    const-string v0, "SSH_MSG_CHANNEL_SUCCESS message has wrong size ("

    const-string v1, ")"

    .line 3
    invoke-static {v0, p2, v1}, Lcom/trilead/ssh2/crypto/digest/a;->d(Ljava/lang/String;ILjava/lang/String;)Ljava/lang/String;

    move-result-object p2

    .line 4
    invoke-direct {p1, p2}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    throw p1
.end method

.method public final o([BI)V
    .locals 5

    const/16 v0, 0x9

    if-ne p2, v0, :cond_2

    const/4 p2, 0x1

    aget-byte p2, p1, p2

    and-int/lit16 p2, p2, 0xff

    shl-int/lit8 p2, p2, 0x18

    const/4 v0, 0x2

    aget-byte v0, p1, v0

    and-int/lit16 v0, v0, 0xff

    shl-int/lit8 v0, v0, 0x10

    or-int/2addr p2, v0

    const/4 v0, 0x3

    aget-byte v0, p1, v0

    and-int/lit16 v0, v0, 0xff

    const/16 v1, 0x8

    shl-int/2addr v0, v1

    or-int/2addr p2, v0

    const/4 v0, 0x4

    aget-byte v0, p1, v0

    and-int/lit16 v0, v0, 0xff

    or-int/2addr p2, v0

    const/4 v0, 0x5

    aget-byte v0, p1, v0

    and-int/lit16 v0, v0, 0xff

    shl-int/lit8 v0, v0, 0x18

    const/4 v2, 0x6

    aget-byte v2, p1, v2

    and-int/lit16 v2, v2, 0xff

    shl-int/lit8 v2, v2, 0x10

    or-int/2addr v0, v2

    const/4 v2, 0x7

    aget-byte v2, p1, v2

    and-int/lit16 v2, v2, 0xff

    shl-int/2addr v2, v1

    or-int/2addr v0, v2

    aget-byte p1, p1, v1

    and-int/lit16 p1, p1, 0xff

    or-int/2addr p1, v0

    invoke-virtual {p0, p2}, Lo/c;->f(I)Lo/a;

    move-result-object v0

    if-eqz v0, :cond_1

    monitor-enter v0

    :try_start_0
    iget-wide v1, v0, Lo/a;->m:J

    int-to-long p1, p1

    const-wide v3, 0xffffffffL

    and-long/2addr p1, v3

    add-long/2addr v1, p1

    iput-wide v1, v0, Lo/a;->m:J

    cmp-long p1, v1, v3

    if-lez p1, :cond_0

    iput-wide v3, v0, Lo/a;->m:J

    :cond_0
    invoke-virtual {v0}, Ljava/lang/Object;->notifyAll()V

    monitor-exit v0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    sget-object p1, Lo/c;->h:La/b;

    invoke-static {p1}, Ljava/util/Objects;->requireNonNull(Ljava/lang/Object;)Ljava/lang/Object;

    return-void

    :catchall_0
    move-exception p1

    :try_start_1
    monitor-exit v0
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    throw p1

    :cond_1
    new-instance p1, Ljava/io/IOException;

    const-string v0, "Unexpected SSH_MSG_CHANNEL_WINDOW_ADJUST message for non-existent channel "

    .line 1
    invoke-static {v0, p2}, Lcom/trilead/ssh2/crypto/digest/a;->c(Ljava/lang/String;I)Ljava/lang/String;

    move-result-object p2

    .line 2
    invoke-direct {p1, p2}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    throw p1

    :cond_2
    new-instance p1, Ljava/io/IOException;

    const-string v0, "SSH_MSG_CHANNEL_WINDOW_ADJUST message has wrong size ("

    const-string v1, ")"

    .line 3
    invoke-static {v0, p2, v1}, Lcom/trilead/ssh2/crypto/digest/a;->d(Ljava/lang/String;ILjava/lang/String;)Ljava/lang/String;

    move-result-object p2

    .line 4
    invoke-direct {p1, p2}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    throw p1
.end method

.method public final p(Ljava/lang/String;ILjava/lang/String;I)Lo/a;
    .locals 7

    new-instance v0, Lo/a;

    invoke-direct {v0, p0}, Lo/a;-><init>(Lo/c;)V

    monitor-enter v0

    :try_start_0
    invoke-virtual {p0, v0}, Lo/c;->c(Lo/a;)I

    move-result v1

    iput v1, v0, Lo/a;->f:I

    monitor-exit v0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_1

    iget v2, v0, Lo/a;->l:I

    iget v3, v0, Lo/a;->n:I

    iget-object v4, p0, Lo/c;->b:Ls/i;

    .line 1
    new-instance v5, Lq/b;

    invoke-direct {v5}, Lq/b;-><init>()V

    const/16 v6, 0x5a

    invoke-virtual {v5, v6}, Lq/b;->d(I)V

    const-string v6, "direct-tcpip"

    invoke-virtual {v5, v6}, Lq/b;->h(Ljava/lang/String;)V

    invoke-virtual {v5, v1}, Lq/b;->j(I)V

    invoke-virtual {v5, v2}, Lq/b;->j(I)V

    invoke-virtual {v5, v3}, Lq/b;->j(I)V

    invoke-virtual {v5, p1}, Lq/b;->h(Ljava/lang/String;)V

    invoke-virtual {v5, p2}, Lq/b;->j(I)V

    invoke-virtual {v5, p3}, Lq/b;->h(Ljava/lang/String;)V

    invoke-virtual {v5, p4}, Lq/b;->j(I)V

    invoke-virtual {v5}, Lq/b;->a()[B

    move-result-object p1

    .line 2
    invoke-virtual {v4, p1}, Ls/i;->m([B)V

    .line 3
    monitor-enter v0

    :goto_0
    :try_start_1
    iget p1, v0, Lo/a;->k:I
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    const/4 p2, 0x1

    if-ne p1, p2, :cond_0

    :try_start_2
    invoke-virtual {v0}, Ljava/lang/Object;->wait()V
    :try_end_2
    .catch Ljava/lang/InterruptedException; {:try_start_2 .. :try_end_2} :catch_0
    .catchall {:try_start_2 .. :try_end_2} :catchall_0

    goto :goto_0

    :catch_0
    :try_start_3
    new-instance p1, Ljava/io/InterruptedIOException;

    invoke-direct {p1}, Ljava/io/InterruptedIOException;-><init>()V

    throw p1

    :cond_0
    const/4 p2, 0x2

    if-ne p1, p2, :cond_1

    monitor-exit v0

    return-object v0

    :cond_1
    iget p1, v0, Lo/a;->f:I

    invoke-virtual {p0, p1}, Lo/c;->r(I)V

    new-instance p1, Ljava/lang/StringBuilder;

    invoke-direct {p1}, Ljava/lang/StringBuilder;-><init>()V

    const-string p2, "Could not open channel (state:"

    invoke-virtual {p1, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget p2, v0, Lo/a;->k:I

    invoke-virtual {p1, p2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string p2, ")"

    invoke-virtual {p1, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    invoke-virtual {p0, p1, v0}, Lo/c;->g(Ljava/lang/String;Lo/a;)Ljava/io/IOException;

    move-result-object p1

    throw p1

    :catchall_0
    move-exception p1

    monitor-exit v0
    :try_end_3
    .catchall {:try_start_3 .. :try_end_3} :catchall_0

    throw p1

    :catchall_1
    move-exception p1

    .line 4
    :try_start_4
    monitor-exit v0
    :try_end_4
    .catchall {:try_start_4 .. :try_end_4} :catchall_1

    throw p1
.end method

.method public final q(Lo/g;)V
    .locals 2

    iget-object v0, p0, Lo/c;->f:Ljava/util/Vector;

    monitor-enter v0

    :try_start_0
    iget-boolean v1, p0, Lo/c;->g:Z

    if-eqz v1, :cond_0

    iget-object v1, p0, Lo/c;->f:Ljava/util/Vector;

    invoke-virtual {v1, p1}, Ljava/util/Vector;->addElement(Ljava/lang/Object;)V

    monitor-exit v0

    return-void

    :cond_0
    new-instance p1, Ljava/io/IOException;

    const-string v1, "Too late, this connection is closed."

    invoke-direct {p1, v1}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    throw p1

    :catchall_0
    move-exception p1

    monitor-exit v0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    throw p1
.end method

.method public final r(I)V
    .locals 3

    iget-object v0, p0, Lo/c;->c:Ljava/util/Vector;

    monitor-enter v0

    const/4 v1, 0x0

    :goto_0
    :try_start_0
    iget-object v2, p0, Lo/c;->c:Ljava/util/Vector;

    invoke-virtual {v2}, Ljava/util/Vector;->size()I

    move-result v2

    if-ge v1, v2, :cond_1

    iget-object v2, p0, Lo/c;->c:Ljava/util/Vector;

    invoke-virtual {v2, v1}, Ljava/util/Vector;->elementAt(I)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Lo/a;

    iget v2, v2, Lo/a;->f:I

    if-ne v2, p1, :cond_0

    iget-object p1, p0, Lo/c;->c:Ljava/util/Vector;

    invoke-virtual {p1, v1}, Ljava/util/Vector;->removeElementAt(I)V

    goto :goto_1

    :cond_0
    add-int/lit8 v1, v1, 0x1

    goto :goto_0

    :cond_1
    :goto_1
    monitor-exit v0

    return-void

    :catchall_0
    move-exception p1

    monitor-exit v0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    throw p1
.end method

.method public final s(Lo/a;)V
    .locals 7

    monitor-enter p1

    :try_start_0
    iget v0, p1, Lo/a;->k:I

    const/4 v1, 0x1

    if-eq v0, v1, :cond_0

    monitor-exit p1

    return-void

    :cond_0
    const/4 v0, 0x2

    iput v0, p1, Lo/a;->k:I

    iget v0, p1, Lo/a;->g:I

    iget v2, p1, Lo/a;->f:I

    iget v3, p1, Lo/a;->l:I

    iget v4, p1, Lo/a;->n:I

    monitor-exit p1
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_1

    iget-object v5, p1, Lo/a;->h:Ljava/lang/Object;

    monitor-enter v5

    :try_start_1
    iget-boolean p1, p1, Lo/a;->i:Z

    if-ne p1, v1, :cond_1

    monitor-exit v5

    return-void

    :cond_1
    iget-object p1, p0, Lo/c;->b:Ls/i;

    .line 1
    new-instance v1, Lq/b;

    invoke-direct {v1}, Lq/b;-><init>()V

    const/16 v6, 0x5b

    invoke-virtual {v1, v6}, Lq/b;->d(I)V

    invoke-virtual {v1, v0}, Lq/b;->j(I)V

    invoke-virtual {v1, v2}, Lq/b;->j(I)V

    invoke-virtual {v1, v3}, Lq/b;->j(I)V

    invoke-virtual {v1, v4}, Lq/b;->j(I)V

    invoke-virtual {v1}, Lq/b;->a()[B

    move-result-object v0

    .line 2
    invoke-virtual {p1, v0}, Ls/i;->m([B)V

    monitor-exit v5

    return-void

    :catchall_0
    move-exception p1

    monitor-exit v5
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    throw p1

    :catchall_1
    move-exception v0

    :try_start_2
    monitor-exit p1
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_1

    throw v0
.end method
