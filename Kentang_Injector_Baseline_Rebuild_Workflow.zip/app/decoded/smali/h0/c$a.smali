.class public final Lh0/c$a;
.super Ljava/lang/Thread;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lh0/c;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1
    name = "a"
.end annotation


# instance fields
.field public final a:Ljava/net/Socket;

.field public final synthetic b:Lh0/c;


# direct methods
.method public constructor <init>(Lh0/c;Ljava/net/Socket;)V
    .locals 0

    iput-object p1, p0, Lh0/c$a;->b:Lh0/c;

    invoke-direct {p0}, Ljava/lang/Thread;-><init>()V

    iput-object p2, p0, Lh0/c$a;->a:Ljava/net/Socket;

    return-void
.end method


# virtual methods
.method public final run()V
    .locals 2

    iget-object v0, p0, Lh0/c$a;->a:Ljava/net/Socket;

    iget-object v1, p0, Lh0/c$a;->b:Lh0/c;

    iget-object v1, v1, Lh0/c;->a:Ljava/net/Socket;

    invoke-static {v0, v1}, Lh0/c;->c(Ljava/net/Socket;Ljava/net/Socket;)V

    return-void
.end method
