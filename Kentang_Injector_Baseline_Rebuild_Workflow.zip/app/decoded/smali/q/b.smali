.class public final Lq/b;
.super Ljava/lang/Object;
.source "SourceFile"


# instance fields
.field public a:[B

.field public b:I


# direct methods
.method public synthetic constructor <init>()V
    .locals 1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/16 v0, 0x100

    new-array v0, v0, [B

    iput-object v0, p0, Lq/b;->a:[B

    const/4 v0, 0x0

    iput v0, p0, Lq/b;->b:I

    return-void
.end method


# virtual methods
.method public final a()[B
    .locals 4

    iget v0, p0, Lq/b;->b:I

    new-array v1, v0, [B

    iget-object v2, p0, Lq/b;->a:[B

    const/4 v3, 0x0

    invoke-static {v2, v3, v1, v3, v0}, Ljava/lang/System;->arraycopy(Ljava/lang/Object;ILjava/lang/Object;II)V

    return-object v1
.end method

.method public final b(I)V
    .locals 3

    new-array p1, p1, [B

    iget-object v0, p0, Lq/b;->a:[B

    array-length v1, v0

    const/4 v2, 0x0

    invoke-static {v0, v2, p1, v2, v1}, Ljava/lang/System;->arraycopy(Ljava/lang/Object;ILjava/lang/Object;II)V

    iput-object p1, p0, Lq/b;->a:[B

    return-void
.end method

.method public final c(Z)V
    .locals 3

    iget v0, p0, Lq/b;->b:I

    add-int/lit8 v0, v0, 0x1

    iget-object v1, p0, Lq/b;->a:[B

    array-length v2, v1

    if-le v0, v2, :cond_0

    array-length v0, v1

    add-int/lit8 v0, v0, 0x20

    invoke-virtual {p0, v0}, Lq/b;->b(I)V

    :cond_0
    iget-object v0, p0, Lq/b;->a:[B

    iget v1, p0, Lq/b;->b:I

    add-int/lit8 v2, v1, 0x1

    iput v2, p0, Lq/b;->b:I

    aput-byte p1, v0, v1

    return-void
.end method

.method public final d(I)V
    .locals 3

    iget v0, p0, Lq/b;->b:I

    add-int/lit8 v1, v0, 0x1

    .line 1
    iget-object v2, p0, Lq/b;->a:[B

    array-length v2, v2

    if-le v1, v2, :cond_0

    add-int/lit8 v1, v0, 0x20

    invoke-virtual {p0, v1}, Lq/b;->b(I)V

    :cond_0
    iget-object v1, p0, Lq/b;->a:[B

    int-to-byte p1, p1

    aput-byte p1, v1, v0

    .line 2
    iget p1, p0, Lq/b;->b:I

    add-int/lit8 p1, p1, 0x1

    iput p1, p0, Lq/b;->b:I

    return-void
.end method

.method public final e([BII)V
    .locals 3

    iget v0, p0, Lq/b;->b:I

    add-int/2addr v0, p3

    iget-object v1, p0, Lq/b;->a:[B

    array-length v2, v1

    if-le v0, v2, :cond_0

    array-length v0, v1

    add-int/2addr v0, p3

    add-int/lit8 v0, v0, 0x20

    invoke-virtual {p0, v0}, Lq/b;->b(I)V

    :cond_0
    iget-object v0, p0, Lq/b;->a:[B

    iget v1, p0, Lq/b;->b:I

    invoke-static {p1, p2, v0, v1, p3}, Ljava/lang/System;->arraycopy(Ljava/lang/Object;ILjava/lang/Object;II)V

    iget p1, p0, Lq/b;->b:I

    add-int/2addr p1, p3

    iput p1, p0, Lq/b;->b:I

    return-void
.end method

.method public final f(Ljava/math/BigInteger;)V
    .locals 3

    invoke-virtual {p1}, Ljava/math/BigInteger;->toByteArray()[B

    move-result-object p1

    array-length v0, p1

    const/4 v1, 0x0

    const/4 v2, 0x1

    if-ne v0, v2, :cond_0

    aget-byte v0, p1, v1

    if-nez v0, :cond_0

    invoke-virtual {p0, v1}, Lq/b;->j(I)V

    goto :goto_0

    :cond_0
    array-length v0, p1

    invoke-virtual {p0, p1, v1, v0}, Lq/b;->i([BII)V

    :goto_0
    return-void
.end method

.method public final g([Ljava/lang/String;)V
    .locals 3

    new-instance v0, Ljava/lang/StringBuffer;

    invoke-direct {v0}, Ljava/lang/StringBuffer;-><init>()V

    const/4 v1, 0x0

    :goto_0
    array-length v2, p1

    if-ge v1, v2, :cond_1

    if-lez v1, :cond_0

    const/16 v2, 0x2c

    invoke-virtual {v0, v2}, Ljava/lang/StringBuffer;->append(C)Ljava/lang/StringBuffer;

    :cond_0
    aget-object v2, p1, v1

    invoke-virtual {v0, v2}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    add-int/lit8 v1, v1, 0x1

    goto :goto_0

    :cond_1
    invoke-virtual {v0}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object p1

    invoke-virtual {p0, p1}, Lq/b;->h(Ljava/lang/String;)V

    return-void
.end method

.method public final h(Ljava/lang/String;)V
    .locals 2

    :try_start_0
    const-string v0, "ISO-8859-1"

    invoke-virtual {p1, v0}, Ljava/lang/String;->getBytes(Ljava/lang/String;)[B

    move-result-object p1
    :try_end_0
    .catch Ljava/io/UnsupportedEncodingException; {:try_start_0 .. :try_end_0} :catch_0

    goto :goto_0

    :catch_0
    invoke-virtual {p1}, Ljava/lang/String;->getBytes()[B

    move-result-object p1

    :goto_0
    array-length v0, p1

    invoke-virtual {p0, v0}, Lq/b;->j(I)V

    const/4 v0, 0x0

    array-length v1, p1

    invoke-virtual {p0, p1, v0, v1}, Lq/b;->e([BII)V

    return-void
.end method

.method public final i([BII)V
    .locals 0

    invoke-virtual {p0, p3}, Lq/b;->j(I)V

    invoke-virtual {p0, p1, p2, p3}, Lq/b;->e([BII)V

    return-void
.end method

.method public final j(I)V
    .locals 4

    iget v0, p0, Lq/b;->b:I

    add-int/lit8 v1, v0, 0x4

    .line 1
    iget-object v2, p0, Lq/b;->a:[B

    array-length v2, v2

    if-le v1, v2, :cond_0

    add-int/lit8 v1, v0, 0x20

    invoke-virtual {p0, v1}, Lq/b;->b(I)V

    :cond_0
    iget-object v1, p0, Lq/b;->a:[B

    add-int/lit8 v2, v0, 0x1

    shr-int/lit8 v3, p1, 0x18

    int-to-byte v3, v3

    aput-byte v3, v1, v0

    add-int/lit8 v0, v2, 0x1

    shr-int/lit8 v3, p1, 0x10

    int-to-byte v3, v3

    aput-byte v3, v1, v2

    add-int/lit8 v2, v0, 0x1

    shr-int/lit8 v3, p1, 0x8

    int-to-byte v3, v3

    aput-byte v3, v1, v0

    int-to-byte p1, p1

    aput-byte p1, v1, v2

    .line 2
    iget p1, p0, Lq/b;->b:I

    add-int/lit8 p1, p1, 0x4

    iput p1, p0, Lq/b;->b:I

    return-void
.end method
