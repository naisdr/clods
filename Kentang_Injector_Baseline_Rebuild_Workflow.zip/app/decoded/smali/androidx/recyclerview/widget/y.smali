.class public final Landroidx/recyclerview/widget/y;
.super Ljava/lang/Object;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Landroidx/recyclerview/widget/y$a;
    }
.end annotation


# instance fields
.field public final a:La/e;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "La/e<",
            "Landroidx/recyclerview/widget/RecyclerView$y;",
            "Landroidx/recyclerview/widget/y$a;",
            ">;"
        }
    .end annotation
.end field

.field public final b:La/c;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "La/c<",
            "Landroidx/recyclerview/widget/RecyclerView$y;",
            ">;"
        }
    .end annotation
.end field


# direct methods
.method public constructor <init>()V
    .locals 1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    new-instance v0, La/e;

    invoke-direct {v0}, La/e;-><init>()V

    iput-object v0, p0, Landroidx/recyclerview/widget/y;->a:La/e;

    new-instance v0, La/c;

    invoke-direct {v0}, La/c;-><init>()V

    iput-object v0, p0, Landroidx/recyclerview/widget/y;->b:La/c;

    return-void
.end method


# virtual methods
.method public final a(Landroidx/recyclerview/widget/RecyclerView$y;)V
    .locals 2

    iget-object v0, p0, Landroidx/recyclerview/widget/y;->a:La/e;

    invoke-virtual {v0, p1}, La/e;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Landroidx/recyclerview/widget/y$a;

    if-nez v0, :cond_0

    invoke-static {}, Landroidx/recyclerview/widget/y$a;->a()Landroidx/recyclerview/widget/y$a;

    move-result-object v0

    iget-object v1, p0, Landroidx/recyclerview/widget/y;->a:La/e;

    invoke-virtual {v1, p1, v0}, La/e;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    :cond_0
    iget p1, v0, Landroidx/recyclerview/widget/y$a;->a:I

    or-int/lit8 p1, p1, 0x1

    iput p1, v0, Landroidx/recyclerview/widget/y$a;->a:I

    return-void
.end method

.method public final b(JLandroidx/recyclerview/widget/RecyclerView$y;)V
    .locals 7

    iget-object v0, p0, Landroidx/recyclerview/widget/y;->b:La/c;

    iget-object v1, v0, La/c;->b:[J

    iget v2, v0, La/c;->d:I

    invoke-static {v1, v2, p1, p2}, La/b;->b([JIJ)I

    move-result v1

    if-ltz v1, :cond_0

    iget-object p1, v0, La/c;->c:[Ljava/lang/Object;

    aput-object p3, p1, v1

    goto :goto_0

    :cond_0
    not-int v1, v1

    iget v2, v0, La/c;->d:I

    if-ge v1, v2, :cond_1

    iget-object v3, v0, La/c;->c:[Ljava/lang/Object;

    aget-object v4, v3, v1

    sget-object v5, La/c;->e:Ljava/lang/Object;

    if-ne v4, v5, :cond_1

    iget-object v0, v0, La/c;->b:[J

    aput-wide p1, v0, v1

    aput-object p3, v3, v1

    goto :goto_0

    :cond_1
    iget-boolean v3, v0, La/c;->a:Z

    if-eqz v3, :cond_2

    iget-object v3, v0, La/c;->b:[J

    array-length v3, v3

    if-lt v2, v3, :cond_2

    invoke-virtual {v0}, La/c;->a()V

    iget-object v1, v0, La/c;->b:[J

    iget v2, v0, La/c;->d:I

    invoke-static {v1, v2, p1, p2}, La/b;->b([JIJ)I

    move-result v1

    not-int v1, v1

    :cond_2
    iget v2, v0, La/c;->d:I

    iget-object v3, v0, La/c;->b:[J

    array-length v3, v3

    if-lt v2, v3, :cond_3

    add-int/lit8 v2, v2, 0x1

    invoke-static {v2}, La/b;->d(I)I

    move-result v2

    new-array v3, v2, [J

    new-array v2, v2, [Ljava/lang/Object;

    iget-object v4, v0, La/c;->b:[J

    array-length v5, v4

    const/4 v6, 0x0

    invoke-static {v4, v6, v3, v6, v5}, Ljava/lang/System;->arraycopy(Ljava/lang/Object;ILjava/lang/Object;II)V

    iget-object v4, v0, La/c;->c:[Ljava/lang/Object;

    array-length v5, v4

    invoke-static {v4, v6, v2, v6, v5}, Ljava/lang/System;->arraycopy(Ljava/lang/Object;ILjava/lang/Object;II)V

    iput-object v3, v0, La/c;->b:[J

    iput-object v2, v0, La/c;->c:[Ljava/lang/Object;

    :cond_3
    iget v2, v0, La/c;->d:I

    sub-int/2addr v2, v1

    if-eqz v2, :cond_4

    iget-object v3, v0, La/c;->b:[J

    add-int/lit8 v4, v1, 0x1

    invoke-static {v3, v1, v3, v4, v2}, Ljava/lang/System;->arraycopy(Ljava/lang/Object;ILjava/lang/Object;II)V

    iget-object v2, v0, La/c;->c:[Ljava/lang/Object;

    iget v3, v0, La/c;->d:I

    sub-int/2addr v3, v1

    invoke-static {v2, v1, v2, v4, v3}, Ljava/lang/System;->arraycopy(Ljava/lang/Object;ILjava/lang/Object;II)V

    :cond_4
    iget-object v2, v0, La/c;->b:[J

    aput-wide p1, v2, v1

    iget-object p1, v0, La/c;->c:[Ljava/lang/Object;

    aput-object p3, p1, v1

    iget p1, v0, La/c;->d:I

    add-int/lit8 p1, p1, 0x1

    iput p1, v0, La/c;->d:I

    :goto_0
    return-void
.end method

.method public final c(Landroidx/recyclerview/widget/RecyclerView$y;Landroidx/recyclerview/widget/RecyclerView$i$c;)V
    .locals 2

    iget-object v0, p0, Landroidx/recyclerview/widget/y;->a:La/e;

    invoke-virtual {v0, p1}, La/e;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Landroidx/recyclerview/widget/y$a;

    if-nez v0, :cond_0

    invoke-static {}, Landroidx/recyclerview/widget/y$a;->a()Landroidx/recyclerview/widget/y$a;

    move-result-object v0

    iget-object v1, p0, Landroidx/recyclerview/widget/y;->a:La/e;

    invoke-virtual {v1, p1, v0}, La/e;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    :cond_0
    iput-object p2, v0, Landroidx/recyclerview/widget/y$a;->c:Landroidx/recyclerview/widget/RecyclerView$i$c;

    iget p1, v0, Landroidx/recyclerview/widget/y$a;->a:I

    or-int/lit8 p1, p1, 0x8

    iput p1, v0, Landroidx/recyclerview/widget/y$a;->a:I

    return-void
.end method

.method public final d(Landroidx/recyclerview/widget/RecyclerView$y;Landroidx/recyclerview/widget/RecyclerView$i$c;)V
    .locals 2

    iget-object v0, p0, Landroidx/recyclerview/widget/y;->a:La/e;

    invoke-virtual {v0, p1}, La/e;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Landroidx/recyclerview/widget/y$a;

    if-nez v0, :cond_0

    invoke-static {}, Landroidx/recyclerview/widget/y$a;->a()Landroidx/recyclerview/widget/y$a;

    move-result-object v0

    iget-object v1, p0, Landroidx/recyclerview/widget/y;->a:La/e;

    invoke-virtual {v1, p1, v0}, La/e;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    :cond_0
    iput-object p2, v0, Landroidx/recyclerview/widget/y$a;->b:Landroidx/recyclerview/widget/RecyclerView$i$c;

    iget p1, v0, Landroidx/recyclerview/widget/y$a;->a:I

    or-int/lit8 p1, p1, 0x4

    iput p1, v0, Landroidx/recyclerview/widget/y$a;->a:I

    return-void
.end method

.method public final e()V
    .locals 6

    iget-object v0, p0, Landroidx/recyclerview/widget/y;->a:La/e;

    invoke-virtual {v0}, La/e;->clear()V

    iget-object v0, p0, Landroidx/recyclerview/widget/y;->b:La/c;

    iget v1, v0, La/c;->d:I

    iget-object v2, v0, La/c;->c:[Ljava/lang/Object;

    const/4 v3, 0x0

    const/4 v4, 0x0

    :goto_0
    if-ge v4, v1, :cond_0

    const/4 v5, 0x0

    aput-object v5, v2, v4

    add-int/lit8 v4, v4, 0x1

    goto :goto_0

    :cond_0
    iput v3, v0, La/c;->d:I

    iput-boolean v3, v0, La/c;->a:Z

    return-void
.end method

.method public final f(Landroidx/recyclerview/widget/RecyclerView$y;I)Landroidx/recyclerview/widget/RecyclerView$i$c;
    .locals 4

    iget-object v0, p0, Landroidx/recyclerview/widget/y;->a:La/e;

    invoke-virtual {v0, p1}, La/e;->e(Ljava/lang/Object;)I

    move-result p1

    const/4 v0, 0x0

    if-gez p1, :cond_0

    return-object v0

    :cond_0
    iget-object v1, p0, Landroidx/recyclerview/widget/y;->a:La/e;

    invoke-virtual {v1, p1}, La/e;->j(I)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Landroidx/recyclerview/widget/y$a;

    if-eqz v1, :cond_4

    iget v2, v1, Landroidx/recyclerview/widget/y$a;->a:I

    and-int v3, v2, p2

    if-eqz v3, :cond_4

    not-int v0, p2

    and-int/2addr v0, v2

    iput v0, v1, Landroidx/recyclerview/widget/y$a;->a:I

    const/4 v2, 0x4

    if-ne p2, v2, :cond_1

    iget-object p2, v1, Landroidx/recyclerview/widget/y$a;->b:Landroidx/recyclerview/widget/RecyclerView$i$c;

    goto :goto_0

    :cond_1
    const/16 v2, 0x8

    if-ne p2, v2, :cond_3

    iget-object p2, v1, Landroidx/recyclerview/widget/y$a;->c:Landroidx/recyclerview/widget/RecyclerView$i$c;

    :goto_0
    and-int/lit8 v0, v0, 0xc

    if-nez v0, :cond_2

    iget-object v0, p0, Landroidx/recyclerview/widget/y;->a:La/e;

    invoke-virtual {v0, p1}, La/e;->i(I)Ljava/lang/Object;

    invoke-static {v1}, Landroidx/recyclerview/widget/y$a;->b(Landroidx/recyclerview/widget/y$a;)V

    :cond_2
    return-object p2

    :cond_3
    new-instance p1, Ljava/lang/IllegalArgumentException;

    const-string p2, "Must provide flag PRE or POST"

    invoke-direct {p1, p2}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw p1

    :cond_4
    return-object v0
.end method

.method public final g(Landroidx/recyclerview/widget/RecyclerView$y;)V
    .locals 1

    iget-object v0, p0, Landroidx/recyclerview/widget/y;->a:La/e;

    invoke-virtual {v0, p1}, La/e;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Landroidx/recyclerview/widget/y$a;

    if-nez p1, :cond_0

    return-void

    :cond_0
    iget v0, p1, Landroidx/recyclerview/widget/y$a;->a:I

    and-int/lit8 v0, v0, -0x2

    iput v0, p1, Landroidx/recyclerview/widget/y$a;->a:I

    return-void
.end method

.method public final h(Landroidx/recyclerview/widget/RecyclerView$y;)V
    .locals 6

    iget-object v0, p0, Landroidx/recyclerview/widget/y;->b:La/c;

    .line 1
    iget-boolean v1, v0, La/c;->a:Z

    if-eqz v1, :cond_0

    invoke-virtual {v0}, La/c;->a()V

    :cond_0
    iget v0, v0, La/c;->d:I

    const/4 v1, 0x1

    sub-int/2addr v0, v1

    :goto_0
    if-ltz v0, :cond_3

    .line 2
    iget-object v2, p0, Landroidx/recyclerview/widget/y;->b:La/c;

    .line 3
    iget-boolean v3, v2, La/c;->a:Z

    if-eqz v3, :cond_1

    invoke-virtual {v2}, La/c;->a()V

    :cond_1
    iget-object v2, v2, La/c;->c:[Ljava/lang/Object;

    aget-object v2, v2, v0

    if-ne p1, v2, :cond_2

    .line 4
    iget-object v2, p0, Landroidx/recyclerview/widget/y;->b:La/c;

    .line 5
    iget-object v3, v2, La/c;->c:[Ljava/lang/Object;

    aget-object v4, v3, v0

    sget-object v5, La/c;->e:Ljava/lang/Object;

    if-eq v4, v5, :cond_3

    aput-object v5, v3, v0

    iput-boolean v1, v2, La/c;->a:Z

    goto :goto_1

    :cond_2
    add-int/lit8 v0, v0, -0x1

    goto :goto_0

    .line 6
    :cond_3
    :goto_1
    iget-object v0, p0, Landroidx/recyclerview/widget/y;->a:La/e;

    invoke-virtual {v0, p1}, La/e;->remove(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Landroidx/recyclerview/widget/y$a;

    if-eqz p1, :cond_4

    invoke-static {p1}, Landroidx/recyclerview/widget/y$a;->b(Landroidx/recyclerview/widget/y$a;)V

    :cond_4
    return-void
.end method
