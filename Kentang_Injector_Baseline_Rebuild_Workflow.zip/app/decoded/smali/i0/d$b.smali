.class public final Li0/d$b;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Li0/c$a;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Li0/d;->a(Ljava/lang/String;[Ljava/lang/String;ZLjava/lang/String;Z)Z
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1
    name = null
.end annotation


# instance fields
.field public final synthetic a:Li0/d;


# direct methods
.method public constructor <init>(Li0/d;)V
    .locals 0

    iput-object p1, p0, Li0/d$b;->a:Li0/d;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method
