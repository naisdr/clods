.class public final Lm/a;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field public final synthetic a:Lm/b;

.field public final synthetic b:Lm/c;


# direct methods
.method public constructor <init>(Lm/c;Lm/b;)V
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()V"
        }
    .end annotation

    iput-object p1, p0, Lm/a;->b:Lm/c;

    iput-object p2, p0, Lm/a;->a:Lm/b;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final run()V
    .locals 4

    iget-object v0, p0, Lm/a;->a:Lm/b;

    monitor-enter v0

    :try_start_0
    iget-object v1, p0, Lm/a;->a:Lm/b;

    iget-boolean v2, v1, Lm/b;->a:Z

    if-eqz v2, :cond_0

    monitor-exit v0

    return-void

    :cond_0
    const/4 v2, 0x1

    iput-boolean v2, v1, Lm/b;->b:Z

    iget-object v1, p0, Lm/a;->b:Lm/c;

    new-instance v2, Ljava/net/SocketTimeoutException;

    const-string v3, "The connect timeout expired"

    invoke-direct {v2, v3}, Ljava/net/SocketTimeoutException;-><init>(Ljava/lang/String;)V

    .line 1
    invoke-virtual {v1, v2}, Lm/c;->e(Ljava/lang/Throwable;)V

    .line 2
    monitor-exit v0

    return-void

    :catchall_0
    move-exception v1

    monitor-exit v0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    throw v1
.end method
