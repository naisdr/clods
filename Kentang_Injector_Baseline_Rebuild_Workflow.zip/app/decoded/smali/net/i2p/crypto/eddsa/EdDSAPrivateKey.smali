.class public Lnet/i2p/crypto/eddsa/EdDSAPrivateKey;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lnet/i2p/crypto/eddsa/EdDSAKey;
.implements Ljava/security/PrivateKey;


# instance fields
.field public final a:[B

.field public final b:[B

.field public final c:[B

.field public final d:Lnet/i2p/crypto/eddsa/math/GroupElement;

.field public final e:[B

.field public final f:Lnet/i2p/crypto/eddsa/spec/EdDSAParameterSpec;


# direct methods
.method public constructor <init>(Lnet/i2p/crypto/eddsa/spec/EdDSAPrivateKeySpec;)V
    .locals 1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 1
    iget-object v0, p1, Lnet/i2p/crypto/eddsa/spec/EdDSAPrivateKeySpec;->a:[B

    .line 2
    iput-object v0, p0, Lnet/i2p/crypto/eddsa/EdDSAPrivateKey;->a:[B

    .line 3
    iget-object v0, p1, Lnet/i2p/crypto/eddsa/spec/EdDSAPrivateKeySpec;->b:[B

    .line 4
    iput-object v0, p0, Lnet/i2p/crypto/eddsa/EdDSAPrivateKey;->b:[B

    .line 5
    iget-object v0, p1, Lnet/i2p/crypto/eddsa/spec/EdDSAPrivateKeySpec;->c:[B

    .line 6
    iput-object v0, p0, Lnet/i2p/crypto/eddsa/EdDSAPrivateKey;->c:[B

    .line 7
    iget-object v0, p1, Lnet/i2p/crypto/eddsa/spec/EdDSAPrivateKeySpec;->d:Lnet/i2p/crypto/eddsa/math/GroupElement;

    .line 8
    iput-object v0, p0, Lnet/i2p/crypto/eddsa/EdDSAPrivateKey;->d:Lnet/i2p/crypto/eddsa/math/GroupElement;

    invoke-virtual {v0}, Lnet/i2p/crypto/eddsa/math/GroupElement;->n()[B

    move-result-object v0

    iput-object v0, p0, Lnet/i2p/crypto/eddsa/EdDSAPrivateKey;->e:[B

    .line 9
    iget-object p1, p1, Lnet/i2p/crypto/eddsa/spec/EdDSAPrivateKeySpec;->e:Lnet/i2p/crypto/eddsa/spec/EdDSAParameterSpec;

    .line 10
    iput-object p1, p0, Lnet/i2p/crypto/eddsa/EdDSAPrivateKey;->f:Lnet/i2p/crypto/eddsa/spec/EdDSAParameterSpec;

    return-void
.end method


# virtual methods
.method public final a()Lnet/i2p/crypto/eddsa/spec/EdDSAParameterSpec;
    .locals 1

    iget-object v0, p0, Lnet/i2p/crypto/eddsa/EdDSAPrivateKey;->f:Lnet/i2p/crypto/eddsa/spec/EdDSAParameterSpec;

    return-object v0
.end method

.method public final equals(Ljava/lang/Object;)Z
    .locals 4

    const/4 v0, 0x1

    if-ne p1, p0, :cond_0

    return v0

    :cond_0
    instance-of v1, p1, Lnet/i2p/crypto/eddsa/EdDSAPrivateKey;

    const/4 v2, 0x0

    if-nez v1, :cond_1

    return v2

    :cond_1
    check-cast p1, Lnet/i2p/crypto/eddsa/EdDSAPrivateKey;

    iget-object v1, p0, Lnet/i2p/crypto/eddsa/EdDSAPrivateKey;->a:[B

    .line 1
    iget-object v3, p1, Lnet/i2p/crypto/eddsa/EdDSAPrivateKey;->a:[B

    .line 2
    invoke-static {v1, v3}, Ljava/util/Arrays;->equals([B[B)Z

    move-result v1

    if-eqz v1, :cond_2

    iget-object v1, p0, Lnet/i2p/crypto/eddsa/EdDSAPrivateKey;->f:Lnet/i2p/crypto/eddsa/spec/EdDSAParameterSpec;

    .line 3
    iget-object p1, p1, Lnet/i2p/crypto/eddsa/EdDSAPrivateKey;->f:Lnet/i2p/crypto/eddsa/spec/EdDSAParameterSpec;

    .line 4
    invoke-virtual {v1, p1}, Lnet/i2p/crypto/eddsa/spec/EdDSAParameterSpec;->equals(Ljava/lang/Object;)Z

    move-result p1

    if-eqz p1, :cond_2

    goto :goto_0

    :cond_2
    const/4 v0, 0x0

    :goto_0
    return v0
.end method

.method public final getAlgorithm()Ljava/lang/String;
    .locals 1

    const-string v0, "EdDSA"

    return-object v0
.end method

.method public final getEncoded()[B
    .locals 10

    iget-object v0, p0, Lnet/i2p/crypto/eddsa/EdDSAPrivateKey;->f:Lnet/i2p/crypto/eddsa/spec/EdDSAParameterSpec;

    sget-object v1, Lnet/i2p/crypto/eddsa/spec/EdDSANamedCurveTable;->a:Lnet/i2p/crypto/eddsa/spec/EdDSANamedCurveSpec;

    invoke-virtual {v0, v1}, Lnet/i2p/crypto/eddsa/spec/EdDSAParameterSpec;->equals(Ljava/lang/Object;)Z

    move-result v0

    const/4 v1, 0x0

    if-nez v0, :cond_0

    return-object v1

    :cond_0
    iget-object v0, p0, Lnet/i2p/crypto/eddsa/EdDSAPrivateKey;->a:[B

    if-nez v0, :cond_1

    return-object v1

    :cond_1
    array-length v1, v0

    const/16 v2, 0x10

    add-int/2addr v1, v2

    new-array v3, v1, [B

    const/4 v4, 0x0

    const/16 v5, 0x30

    aput-byte v5, v3, v4

    const/4 v6, 0x2

    sub-int/2addr v1, v6

    int-to-byte v1, v1

    const/4 v7, 0x1

    aput-byte v1, v3, v7

    aput-byte v6, v3, v6

    const/4 v1, 0x3

    aput-byte v7, v3, v1

    const/4 v7, 0x4

    aput-byte v4, v3, v7

    const/4 v8, 0x5

    aput-byte v5, v3, v8

    const/4 v5, 0x7

    const/4 v9, 0x6

    aput-byte v8, v3, v9

    const/16 v8, 0x8

    aput-byte v9, v3, v5

    const/16 v5, 0x9

    aput-byte v1, v3, v8

    const/16 v1, 0xa

    const/16 v8, 0x2b

    aput-byte v8, v3, v5

    const/16 v5, 0xb

    const/16 v8, 0x65

    aput-byte v8, v3, v1

    const/16 v1, 0xc

    const/16 v8, 0x70

    aput-byte v8, v3, v5

    const/16 v5, 0xd

    aput-byte v7, v3, v1

    const/16 v1, 0xe

    array-length v8, v0

    add-int/2addr v8, v6

    int-to-byte v6, v8

    aput-byte v6, v3, v5

    const/16 v5, 0xf

    aput-byte v7, v3, v1

    array-length v1, v0

    int-to-byte v1, v1

    aput-byte v1, v3, v5

    array-length v1, v0

    invoke-static {v0, v4, v3, v2, v1}, Ljava/lang/System;->arraycopy(Ljava/lang/Object;ILjava/lang/Object;II)V

    return-object v3
.end method

.method public final getFormat()Ljava/lang/String;
    .locals 1

    const-string v0, "PKCS#8"

    return-object v0
.end method

.method public final hashCode()I
    .locals 1

    iget-object v0, p0, Lnet/i2p/crypto/eddsa/EdDSAPrivateKey;->a:[B

    invoke-static {v0}, Ljava/util/Arrays;->hashCode([B)I

    move-result v0

    return v0
.end method
