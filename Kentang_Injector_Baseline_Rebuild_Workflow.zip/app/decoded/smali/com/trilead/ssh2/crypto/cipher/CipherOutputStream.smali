.class public Lcom/trilead/ssh2/crypto/cipher/CipherOutputStream;
.super Ljava/lang/Object;
.source "SourceFile"


# instance fields
.field public a:Lcom/trilead/ssh2/crypto/cipher/BlockCipher;

.field public b:Ljava/io/OutputStream;

.field public c:[B

.field public d:[B

.field public e:I

.field public f:I

.field public g:[B

.field public h:I


# direct methods
.method public constructor <init>(Lcom/trilead/ssh2/crypto/cipher/BlockCipher;Ljava/io/OutputStream;)V
    .locals 1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/16 v0, 0x800

    new-array v0, v0, [B

    iput-object v0, p0, Lcom/trilead/ssh2/crypto/cipher/CipherOutputStream;->g:[B

    const/4 v0, 0x0

    iput v0, p0, Lcom/trilead/ssh2/crypto/cipher/CipherOutputStream;->h:I

    iput-object p2, p0, Lcom/trilead/ssh2/crypto/cipher/CipherOutputStream;->b:Ljava/io/OutputStream;

    .line 1
    iput-object p1, p0, Lcom/trilead/ssh2/crypto/cipher/CipherOutputStream;->a:Lcom/trilead/ssh2/crypto/cipher/BlockCipher;

    check-cast p1, Lcom/trilead/ssh2/crypto/cipher/NullCipher;

    .line 2
    iget p1, p1, Lcom/trilead/ssh2/crypto/cipher/NullCipher;->a:I

    .line 3
    iput p1, p0, Lcom/trilead/ssh2/crypto/cipher/CipherOutputStream;->e:I

    new-array p2, p1, [B

    iput-object p2, p0, Lcom/trilead/ssh2/crypto/cipher/CipherOutputStream;->c:[B

    new-array p1, p1, [B

    iput-object p1, p0, Lcom/trilead/ssh2/crypto/cipher/CipherOutputStream;->d:[B

    iput v0, p0, Lcom/trilead/ssh2/crypto/cipher/CipherOutputStream;->f:I

    return-void
.end method


# virtual methods
.method public final a([BI)V
    .locals 5

    const/4 v0, 0x0

    const/4 v1, 0x0

    :cond_0
    :goto_0
    if-lez p2, :cond_2

    iget v2, p0, Lcom/trilead/ssh2/crypto/cipher/CipherOutputStream;->h:I

    rsub-int v3, v2, 0x800

    if-le p2, v3, :cond_1

    goto :goto_1

    :cond_1
    move v3, p2

    :goto_1
    iget-object v4, p0, Lcom/trilead/ssh2/crypto/cipher/CipherOutputStream;->g:[B

    invoke-static {p1, v1, v4, v2, v3}, Ljava/lang/System;->arraycopy(Ljava/lang/Object;ILjava/lang/Object;II)V

    add-int/2addr v1, v3

    iget v2, p0, Lcom/trilead/ssh2/crypto/cipher/CipherOutputStream;->h:I

    add-int/2addr v2, v3

    iput v2, p0, Lcom/trilead/ssh2/crypto/cipher/CipherOutputStream;->h:I

    sub-int/2addr p2, v3

    const/16 v3, 0x800

    if-lt v2, v3, :cond_0

    iget-object v2, p0, Lcom/trilead/ssh2/crypto/cipher/CipherOutputStream;->b:Ljava/io/OutputStream;

    iget-object v4, p0, Lcom/trilead/ssh2/crypto/cipher/CipherOutputStream;->g:[B

    invoke-virtual {v2, v4, v0, v3}, Ljava/io/OutputStream;->write([BII)V

    iput v0, p0, Lcom/trilead/ssh2/crypto/cipher/CipherOutputStream;->h:I

    goto :goto_0

    :cond_2
    return-void
.end method

.method public final b([BI)V
    .locals 5

    const/4 v0, 0x0

    const/4 v1, 0x0

    :cond_0
    :goto_0
    if-lez p2, :cond_1

    iget v2, p0, Lcom/trilead/ssh2/crypto/cipher/CipherOutputStream;->e:I

    iget v3, p0, Lcom/trilead/ssh2/crypto/cipher/CipherOutputStream;->f:I

    sub-int/2addr v2, v3

    invoke-static {v2, p2}, Ljava/lang/Math;->min(II)I

    move-result v2

    iget-object v3, p0, Lcom/trilead/ssh2/crypto/cipher/CipherOutputStream;->c:[B

    iget v4, p0, Lcom/trilead/ssh2/crypto/cipher/CipherOutputStream;->f:I

    invoke-static {p1, v1, v3, v4, v2}, Ljava/lang/System;->arraycopy(Ljava/lang/Object;ILjava/lang/Object;II)V

    iget v3, p0, Lcom/trilead/ssh2/crypto/cipher/CipherOutputStream;->f:I

    add-int/2addr v3, v2

    iput v3, p0, Lcom/trilead/ssh2/crypto/cipher/CipherOutputStream;->f:I

    add-int/2addr v1, v2

    sub-int/2addr p2, v2

    iget v2, p0, Lcom/trilead/ssh2/crypto/cipher/CipherOutputStream;->e:I

    if-lt v3, v2, :cond_0

    :try_start_0
    iget-object v2, p0, Lcom/trilead/ssh2/crypto/cipher/CipherOutputStream;->a:Lcom/trilead/ssh2/crypto/cipher/BlockCipher;

    iget-object v3, p0, Lcom/trilead/ssh2/crypto/cipher/CipherOutputStream;->c:[B

    iget-object v4, p0, Lcom/trilead/ssh2/crypto/cipher/CipherOutputStream;->d:[B

    invoke-interface {v2, v3, v0, v4, v0}, Lcom/trilead/ssh2/crypto/cipher/BlockCipher;->c([BI[BI)V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    iget-object v2, p0, Lcom/trilead/ssh2/crypto/cipher/CipherOutputStream;->d:[B

    iget v3, p0, Lcom/trilead/ssh2/crypto/cipher/CipherOutputStream;->e:I

    invoke-virtual {p0, v2, v3}, Lcom/trilead/ssh2/crypto/cipher/CipherOutputStream;->a([BI)V

    iput v0, p0, Lcom/trilead/ssh2/crypto/cipher/CipherOutputStream;->f:I

    goto :goto_0

    :catch_0
    move-exception p1

    new-instance p2, Ljava/io/IOException;

    const-string v0, "Error while decrypting block."

    invoke-direct {p2, v0}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    invoke-virtual {p2, p1}, Ljava/lang/Throwable;->initCause(Ljava/lang/Throwable;)Ljava/lang/Throwable;

    move-result-object p1

    check-cast p1, Ljava/io/IOException;

    throw p1

    :cond_1
    return-void
.end method
