.class public final Lxyz/chz/injector/HttpService$c;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lxyz/chz/injector/HttpService;->b()V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1
    name = null
.end annotation


# instance fields
.field public final synthetic a:Lxyz/chz/injector/HttpService;


# direct methods
.method public constructor <init>(Lxyz/chz/injector/HttpService;)V
    .locals 0

    iput-object p1, p0, Lxyz/chz/injector/HttpService$c;->a:Lxyz/chz/injector/HttpService;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final run()V
    .locals 2

    iget-object v0, p0, Lxyz/chz/injector/HttpService$c;->a:Lxyz/chz/injector/HttpService;

    const/4 v1, 0x1

    invoke-virtual {v0, v1}, Landroid/app/Service;->stopForeground(Z)V

    iget-object v0, p0, Lxyz/chz/injector/HttpService$c;->a:Lxyz/chz/injector/HttpService;

    invoke-virtual {v0}, Landroid/app/Service;->stopSelf()V

    iget-object v0, p0, Lxyz/chz/injector/HttpService$c;->a:Lxyz/chz/injector/HttpService;

    invoke-static {v0}, Lg0/d;->m(Lg0/d$b;)V

    return-void
.end method
