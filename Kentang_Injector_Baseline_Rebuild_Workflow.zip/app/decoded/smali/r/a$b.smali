.class public final Lr/a$b;
.super Lcom/trilead/ssh2/crypto/CertificateDecoder;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lr/a;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x9
    name = "b"
.end annotation


# direct methods
.method public constructor <init>()V
    .locals 0

    invoke-direct {p0}, Lcom/trilead/ssh2/crypto/CertificateDecoder;-><init>()V

    return-void
.end method


# virtual methods
.method public final a(Lcom/trilead/ssh2/crypto/PEMStructure;)Ljava/security/KeyPair;
    .locals 6

    new-instance v0, Lcom/trilead/ssh2/crypto/SimpleDERReader;

    .line 1
    iget-object p1, p1, Lcom/trilead/ssh2/crypto/PEMStructure;->c:[B

    .line 2
    invoke-direct {v0, p1}, Lcom/trilead/ssh2/crypto/SimpleDERReader;-><init>([B)V

    invoke-virtual {v0}, Lcom/trilead/ssh2/crypto/SimpleDERReader;->f()[B

    move-result-object p1

    .line 3
    iget v1, v0, Lcom/trilead/ssh2/crypto/SimpleDERReader;->c:I

    const-string v2, "Padding in DSA PRIVATE KEY DER stream."

    if-nez v1, :cond_2

    .line 4
    array-length v1, p1

    .line 5
    iput-object p1, v0, Lcom/trilead/ssh2/crypto/SimpleDERReader;->a:[B

    const/4 p1, 0x0

    iput p1, v0, Lcom/trilead/ssh2/crypto/SimpleDERReader;->b:I

    iput v1, v0, Lcom/trilead/ssh2/crypto/SimpleDERReader;->c:I

    .line 6
    invoke-virtual {v0}, Lcom/trilead/ssh2/crypto/SimpleDERReader;->c()Ljava/math/BigInteger;

    move-result-object p1

    sget-object v1, Ljava/math/BigInteger;->ZERO:Ljava/math/BigInteger;

    invoke-virtual {p1, v1}, Ljava/math/BigInteger;->compareTo(Ljava/math/BigInteger;)I

    move-result v1

    if-nez v1, :cond_1

    invoke-virtual {v0}, Lcom/trilead/ssh2/crypto/SimpleDERReader;->c()Ljava/math/BigInteger;

    move-result-object p1

    invoke-virtual {v0}, Lcom/trilead/ssh2/crypto/SimpleDERReader;->c()Ljava/math/BigInteger;

    move-result-object v1

    invoke-virtual {v0}, Lcom/trilead/ssh2/crypto/SimpleDERReader;->c()Ljava/math/BigInteger;

    move-result-object v3

    invoke-virtual {v0}, Lcom/trilead/ssh2/crypto/SimpleDERReader;->c()Ljava/math/BigInteger;

    move-result-object v4

    invoke-virtual {v0}, Lcom/trilead/ssh2/crypto/SimpleDERReader;->c()Ljava/math/BigInteger;

    move-result-object v5

    .line 7
    iget v0, v0, Lcom/trilead/ssh2/crypto/SimpleDERReader;->c:I

    if-nez v0, :cond_0

    .line 8
    :try_start_0
    new-instance v0, Ljava/security/spec/DSAPrivateKeySpec;

    invoke-direct {v0, v5, p1, v1, v3}, Ljava/security/spec/DSAPrivateKeySpec;-><init>(Ljava/math/BigInteger;Ljava/math/BigInteger;Ljava/math/BigInteger;Ljava/math/BigInteger;)V

    new-instance v2, Ljava/security/spec/DSAPublicKeySpec;

    invoke-direct {v2, v4, p1, v1, v3}, Ljava/security/spec/DSAPublicKeySpec;-><init>(Ljava/math/BigInteger;Ljava/math/BigInteger;Ljava/math/BigInteger;Ljava/math/BigInteger;)V

    const-string p1, "DSA"

    invoke-static {p1}, Ljava/security/KeyFactory;->getInstance(Ljava/lang/String;)Ljava/security/KeyFactory;

    move-result-object p1

    invoke-virtual {p1, v0}, Ljava/security/KeyFactory;->generatePrivate(Ljava/security/spec/KeySpec;)Ljava/security/PrivateKey;

    move-result-object v0

    invoke-virtual {p1, v2}, Ljava/security/KeyFactory;->generatePublic(Ljava/security/spec/KeySpec;)Ljava/security/PublicKey;

    move-result-object p1

    new-instance v1, Ljava/security/KeyPair;

    invoke-direct {v1, p1, v0}, Ljava/security/KeyPair;-><init>(Ljava/security/PublicKey;Ljava/security/PrivateKey;)V
    :try_end_0
    .catch Ljava/security/GeneralSecurityException; {:try_start_0 .. :try_end_0} :catch_0

    return-object v1

    :catch_0
    new-instance p1, Ljava/io/IOException;

    const-string v0, "Could not decode DSA key pair"

    invoke-direct {p1, v0}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    throw p1

    :cond_0
    new-instance p1, Ljava/io/IOException;

    invoke-direct {p1, v2}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    throw p1

    :cond_1
    new-instance v0, Ljava/io/IOException;

    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const-string v2, "Wrong version ("

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const-string p1, ") in DSA PRIVATE KEY DER stream."

    invoke-virtual {v1, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    invoke-direct {v0, p1}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    throw v0

    :cond_2
    new-instance p1, Ljava/io/IOException;

    invoke-direct {p1, v2}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    throw p1
.end method

.method public final c()Ljava/lang/String;
    .locals 1

    const-string v0, "-----END DSA PRIVATE KEY-----"

    return-object v0
.end method

.method public final d()Ljava/lang/String;
    .locals 1

    const-string v0, "-----BEGIN DSA PRIVATE KEY-----"

    return-object v0
.end method
