.class public final Lt/a;
.super Ljava/lang/Object;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lt/a$b;
    }
.end annotation


# static fields
.field public static final a:Lt/a$a;

.field public static final b:Ljava/util/concurrent/ScheduledExecutorService;


# direct methods
.method public static constructor <clinit>()V
    .locals 2

    new-instance v0, Lt/a$a;

    invoke-direct {v0}, Lt/a$a;-><init>()V

    sput-object v0, Lt/a;->a:Lt/a$a;

    const/16 v1, 0x14

    invoke-static {v1, v0}, Ljava/util/concurrent/Executors;->newScheduledThreadPool(ILjava/util/concurrent/ThreadFactory;)Ljava/util/concurrent/ScheduledExecutorService;

    move-result-object v0

    sput-object v0, Lt/a;->b:Ljava/util/concurrent/ScheduledExecutorService;

    return-void
.end method
