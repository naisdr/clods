.class public interface abstract Lcom/trilead/ssh2/crypto/cipher/BlockCipher;
.super Ljava/lang/Object;
.source "SourceFile"


# virtual methods
.method public abstract a()I
.end method

.method public abstract b(Z[B)V
.end method

.method public abstract c([BI[BI)V
.end method
