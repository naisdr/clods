.class public Lcom/trilead/ssh2/compression/a;
.super Ljava/lang/Object;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/trilead/ssh2/compression/a$a;
    }
.end annotation


# static fields
.field public static a:Ljava/util/Vector;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/Vector<",
            "Lcom/trilead/ssh2/compression/a$a;",
            ">;"
        }
    .end annotation
.end field


# direct methods
.method public static constructor <clinit>()V
    .locals 3

    new-instance v0, Ljava/util/Vector;

    invoke-direct {v0}, Ljava/util/Vector;-><init>()V

    sput-object v0, Lcom/trilead/ssh2/compression/a;->a:Ljava/util/Vector;

    new-instance v1, Lcom/trilead/ssh2/compression/a$a;

    const-string v2, "zlib"

    invoke-direct {v1, v2}, Lcom/trilead/ssh2/compression/a$a;-><init>(Ljava/lang/String;)V

    invoke-virtual {v0, v1}, Ljava/util/Vector;->addElement(Ljava/lang/Object;)V

    sget-object v0, Lcom/trilead/ssh2/compression/a;->a:Ljava/util/Vector;

    new-instance v1, Lcom/trilead/ssh2/compression/a$a;

    const-string v2, "zlib@openssh.com"

    invoke-direct {v1, v2}, Lcom/trilead/ssh2/compression/a$a;-><init>(Ljava/lang/String;)V

    invoke-virtual {v0, v1}, Ljava/util/Vector;->addElement(Ljava/lang/Object;)V

    sget-object v0, Lcom/trilead/ssh2/compression/a;->a:Ljava/util/Vector;

    new-instance v1, Lcom/trilead/ssh2/compression/a$a;

    const-string v2, "none"

    invoke-direct {v1, v2}, Lcom/trilead/ssh2/compression/a$a;-><init>(Ljava/lang/String;)V

    invoke-virtual {v0, v1}, Ljava/util/Vector;->addElement(Ljava/lang/Object;)V

    return-void
.end method

.method public constructor <init>()V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method public static a()[Ljava/lang/String;
    .locals 4

    sget-object v0, Lcom/trilead/ssh2/compression/a;->a:Ljava/util/Vector;

    invoke-virtual {v0}, Ljava/util/Vector;->size()I

    move-result v0

    new-array v0, v0, [Ljava/lang/String;

    const/4 v1, 0x0

    :goto_0
    sget-object v2, Lcom/trilead/ssh2/compression/a;->a:Ljava/util/Vector;

    invoke-virtual {v2}, Ljava/util/Vector;->size()I

    move-result v2

    if-ge v1, v2, :cond_0

    sget-object v2, Lcom/trilead/ssh2/compression/a;->a:Ljava/util/Vector;

    invoke-virtual {v2, v1}, Ljava/util/Vector;->elementAt(I)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Lcom/trilead/ssh2/compression/a$a;

    new-instance v3, Ljava/lang/String;

    iget-object v2, v2, Lcom/trilead/ssh2/compression/a$a;->a:Ljava/lang/String;

    invoke-direct {v3, v2}, Ljava/lang/String;-><init>(Ljava/lang/String;)V

    aput-object v3, v0, v1

    add-int/lit8 v1, v1, 0x1

    goto :goto_0

    :cond_0
    return-object v0
.end method
