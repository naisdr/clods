.class public final Ls/i$a;
.super Ljava/lang/Thread;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Ls/i;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1
    name = "a"
.end annotation


# instance fields
.field public final synthetic a:Ls/i;


# direct methods
.method public constructor <init>(Ls/i;)V
    .locals 0

    iput-object p1, p0, Ls/i$a;->a:Ls/i;

    invoke-direct {p0}, Ljava/lang/Thread;-><init>()V

    return-void
.end method


# virtual methods
.method public final run()V
    .locals 4

    :goto_0
    iget-object v0, p0, Ls/i$a;->a:Ls/i;

    .line 1
    iget-object v0, v0, Ls/i;->a:Ljava/util/Vector;

    .line 2
    monitor-enter v0

    :try_start_0
    iget-object v1, p0, Ls/i$a;->a:Ls/i;

    .line 3
    iget-object v1, v1, Ls/i;->a:Ljava/util/Vector;

    .line 4
    invoke-virtual {v1}, Ljava/util/Vector;->size()I

    move-result v1
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    if-nez v1, :cond_0

    :try_start_1
    iget-object v1, p0, Ls/i$a;->a:Ls/i;

    .line 5
    iget-object v1, v1, Ls/i;->a:Ljava/util/Vector;

    const-wide/16 v2, 0x7d0

    .line 6
    invoke-virtual {v1, v2, v3}, Ljava/lang/Object;->wait(J)V
    :try_end_1
    .catch Ljava/lang/InterruptedException; {:try_start_1 .. :try_end_1} :catch_0
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    :catch_0
    :try_start_2
    iget-object v1, p0, Ls/i$a;->a:Ls/i;

    .line 7
    iget-object v1, v1, Ls/i;->a:Ljava/util/Vector;

    .line 8
    invoke-virtual {v1}, Ljava/util/Vector;->size()I

    move-result v1

    if-nez v1, :cond_0

    iget-object v1, p0, Ls/i$a;->a:Ls/i;

    const/4 v2, 0x0

    .line 9
    iput-object v2, v1, Ls/i;->b:Ljava/lang/Thread;

    .line 10
    monitor-exit v0

    return-void

    :cond_0
    iget-object v1, p0, Ls/i$a;->a:Ls/i;

    .line 11
    iget-object v1, v1, Ls/i;->a:Ljava/util/Vector;

    const/4 v2, 0x0

    .line 12
    invoke-virtual {v1, v2}, Ljava/util/Vector;->remove(I)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, [B

    monitor-exit v0
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_0

    :try_start_3
    iget-object v0, p0, Ls/i$a;->a:Ls/i;

    invoke-virtual {v0, v1}, Ls/i;->m([B)V
    :try_end_3
    .catch Ljava/io/IOException; {:try_start_3 .. :try_end_3} :catch_1

    goto :goto_0

    :catch_1
    return-void

    :catchall_0
    move-exception v1

    :try_start_4
    monitor-exit v0
    :try_end_4
    .catchall {:try_start_4 .. :try_end_4} :catchall_0

    throw v1
.end method
