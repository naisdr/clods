.class public final Ll/c;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ljava/lang/Cloneable;


# instance fields
.field public a:[B

.field public b:[B

.field public c:[B


# direct methods
.method public constructor <init>()V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final clone()Ljava/lang/Object;
    .locals 5

    invoke-super {p0}, Ljava/lang/Object;->clone()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ll/c;

    iget-object v1, v0, Ll/c;->a:[B

    const/4 v2, 0x0

    if-eqz v1, :cond_0

    array-length v3, v1

    new-array v4, v3, [B

    invoke-static {v1, v2, v4, v2, v3}, Ljava/lang/System;->arraycopy(Ljava/lang/Object;ILjava/lang/Object;II)V

    iput-object v4, v0, Ll/c;->a:[B

    :cond_0
    iget-object v1, v0, Ll/c;->b:[B

    if-eqz v1, :cond_1

    array-length v3, v1

    new-array v4, v3, [B

    invoke-static {v1, v2, v4, v2, v3}, Ljava/lang/System;->arraycopy(Ljava/lang/Object;ILjava/lang/Object;II)V

    iput-object v4, v0, Ll/c;->b:[B

    :cond_1
    iget-object v1, v0, Ll/c;->c:[B

    if-eqz v1, :cond_2

    array-length v3, v1

    new-array v4, v3, [B

    invoke-static {v1, v2, v4, v2, v3}, Ljava/lang/System;->arraycopy(Ljava/lang/Object;ILjava/lang/Object;II)V

    iput-object v4, v0, Ll/c;->c:[B

    :cond_2
    return-object v0
.end method
