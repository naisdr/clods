.class public final Ls/a;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ls/d;


# static fields
.field public static final q:La/b;

.field public static final r:Ljava/util/ArrayList;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/List<",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation
.end field


# instance fields
.field public a:Ls/c;

.field public b:I

.field public c:Lcom/trilead/ssh2/crypto/KeyMaterial;

.field public d:[B

.field public e:Lq/a;

.field public final f:Ljava/lang/Object;

.field public g:Ll/e;

.field public h:Z

.field public i:Z

.field public final j:Ls/i;

.field public k:Lcom/trilead/ssh2/crypto/CryptoWishList;

.field public l:La/b;

.field public m:Lm/k;

.field public final n:Ljava/lang/String;

.field public final o:I

.field public final p:Ljava/security/SecureRandom;


# direct methods
.method public static constructor <clinit>()V
    .locals 4

    const-class v0, Ls/a;

    .line 1
    new-instance v1, La/b;

    invoke-direct {v1, v0}, La/b;-><init>(Ljava/lang/Class;)V

    .line 2
    sput-object v1, Ls/a;->q:La/b;

    .line 3
    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    .line 4
    sget-object v1, Lr/e;->a:Ljava/util/Collection;

    .line 5
    invoke-interface {v1}, Ljava/util/Collection;->iterator()Ljava/util/Iterator;

    move-result-object v1

    :goto_0
    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    move-result v2

    if-eqz v2, :cond_0

    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Lr/d;

    invoke-virtual {v0}, Ljava/util/ArrayList;->size()I

    move-result v3

    .line 6
    iget-object v2, v2, Lr/d;->b:Ljava/lang/String;

    .line 7
    invoke-virtual {v0, v3, v2}, Ljava/util/ArrayList;->add(ILjava/lang/Object;)V

    goto :goto_0

    .line 8
    :cond_0
    sput-object v0, Ls/a;->r:Ljava/util/ArrayList;

    return-void
.end method

.method public constructor <init>(Ls/i;Lq/a;Lcom/trilead/ssh2/crypto/CryptoWishList;Ljava/lang/String;ILm/k;Ljava/security/SecureRandom;)V
    .locals 2

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v0, 0x0

    iput v0, p0, Ls/a;->b:I

    new-instance v1, Ljava/lang/Object;

    invoke-direct {v1}, Ljava/lang/Object;-><init>()V

    iput-object v1, p0, Ls/a;->f:Ljava/lang/Object;

    const/4 v1, 0x0

    iput-object v1, p0, Ls/a;->g:Ll/e;

    iput-boolean v0, p0, Ls/a;->h:Z

    iput-boolean v0, p0, Ls/a;->i:Z

    iput-object p1, p0, Ls/a;->j:Ls/i;

    iput-object p2, p0, Ls/a;->e:Lq/a;

    iput-object p3, p0, Ls/a;->k:Lcom/trilead/ssh2/crypto/CryptoWishList;

    new-instance p1, La/b;

    invoke-direct {p1}, La/b;-><init>()V

    iput-object p1, p0, Ls/a;->l:La/b;

    iput-object p4, p0, Ls/a;->n:Ljava/lang/String;

    iput p5, p0, Ls/a;->o:I

    iput-object p6, p0, Ls/a;->m:Lm/k;

    iput-object p7, p0, Ls/a;->p:Ljava/security/SecureRandom;

    return-void
.end method


# virtual methods
.method public final a(Ljava/lang/Throwable;)V
    .locals 1

    iget-object p1, p0, Ls/a;->f:Ljava/lang/Object;

    monitor-enter p1

    const/4 v0, 0x1

    :try_start_0
    iput-boolean v0, p0, Ls/a;->h:Z

    iget-object v0, p0, Ls/a;->f:Ljava/lang/Object;

    invoke-virtual {v0}, Ljava/lang/Object;->notifyAll()V

    monitor-exit p1

    return-void

    :catchall_0
    move-exception v0

    monitor-exit p1
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    throw v0
.end method

.method public final declared-synchronized b([BI)V
    .locals 10

    monitor-enter p0

    :try_start_0
    iget-object v0, p0, Ls/a;->a:Ls/c;

    const/16 v1, 0x14

    const/4 v2, 0x0

    if-nez v0, :cond_1

    aget-byte v3, p1, v2

    if-ne v3, v1, :cond_0

    goto :goto_0

    :cond_0
    new-instance p2, Ljava/io/IOException;

    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const-string v1, "Unexpected KEX message (type "

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    aget-byte p1, p1, v2

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string p1, ")"

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    invoke-direct {p2, p1}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    throw p2

    :cond_1
    :goto_0
    iget-boolean v3, p0, Ls/a;->i:Z

    if-eqz v3, :cond_2

    iput-boolean v2, p0, Ls/a;->i:Z
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_1

    monitor-exit p0

    return-void

    :cond_2
    :try_start_1
    aget-byte v3, p1, v2

    const/4 v4, 0x1

    if-ne v3, v1, :cond_e

    if-eqz v0, :cond_4

    iget v1, v0, Ls/c;->d:I

    if-nez v1, :cond_3

    goto :goto_1

    :cond_3
    new-instance p1, Ljava/io/IOException;

    const-string p2, "Unexpected SSH_MSG_KEXINIT message during on-going kex exchange!"

    invoke-direct {p1, p2}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    throw p1

    :cond_4
    :goto_1
    if-nez v0, :cond_5

    new-instance v0, Ls/c;

    invoke-direct {v0}, Ls/c;-><init>()V

    iput-object v0, p0, Ls/a;->a:Ls/c;

    iget-object v1, p0, Ls/a;->l:La/b;

    iput-object v1, v0, Ls/c;->j:La/b;

    new-instance v0, Lm/e;

    iget-object v1, p0, Ls/a;->k:Lcom/trilead/ssh2/crypto/CryptoWishList;

    iget-object v2, p0, Ls/a;->p:Ljava/security/SecureRandom;

    invoke-direct {v0, v1, v2}, Lm/e;-><init>(Lcom/trilead/ssh2/crypto/CryptoWishList;Ljava/security/SecureRandom;)V

    iget-object v1, p0, Ls/a;->a:Ls/c;

    iput-object v0, v1, Ls/c;->a:Lm/e;

    iget-object v1, p0, Ls/a;->j:Ls/i;

    invoke-virtual {v0}, Lm/e;->b()[B

    move-result-object v0

    invoke-virtual {v1, v0}, Ls/i;->l([B)V

    :cond_5
    new-instance v0, Lm/e;

    invoke-direct {v0, p1, p2}, Lm/e;-><init>([BI)V

    iget-object p1, p0, Ls/a;->a:Ls/c;

    iput-object v0, p1, Ls/c;->b:Lm/e;

    iget-object p2, p1, Ls/c;->a:Lm/e;

    invoke-virtual {p2}, Lm/e;->a()Ls/b;

    move-result-object p2

    iget-object v0, p0, Ls/a;->a:Ls/c;

    iget-object v0, v0, Ls/c;->b:Lm/e;

    invoke-virtual {v0}, Lm/e;->a()Ls/b;

    move-result-object v0

    invoke-virtual {p0, p2, v0}, Ls/a;->f(Ls/b;Ls/b;)Ls/f;

    move-result-object p2

    iput-object p2, p1, Ls/c;->c:Ls/f;

    iget-object p1, p0, Ls/a;->a:Ls/c;

    iget-object p2, p1, Ls/c;->c:Ls/f;

    if-eqz p2, :cond_d

    iget-object p1, p1, Ls/c;->b:Lm/e;

    invoke-virtual {p1}, Lm/e;->c()Z

    move-result p1

    if-eqz p1, :cond_6

    iget-object p1, p0, Ls/a;->a:Ls/c;

    iget-object p1, p1, Ls/c;->c:Ls/f;

    iget-boolean p1, p1, Ls/f;->a:Z

    if-nez p1, :cond_6

    iput-boolean v4, p0, Ls/a;->i:Z

    :cond_6
    iget-object p1, p0, Ls/a;->a:Ls/c;

    iget-object p1, p1, Ls/c;->c:Ls/f;

    iget-object p1, p1, Ls/f;->b:Ljava/lang/String;

    const-string p2, "diffie-hellman-group-exchange-sha1"

    invoke-virtual {p1, p2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p1

    const/16 p2, 0x1e

    if-nez p1, :cond_b

    iget-object p1, p0, Ls/a;->a:Ls/c;

    iget-object p1, p1, Ls/c;->c:Ls/f;

    iget-object p1, p1, Ls/f;->b:Ljava/lang/String;

    const-string v0, "diffie-hellman-group-exchange-sha256"

    invoke-virtual {p1, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p1

    if-eqz p1, :cond_7

    goto/16 :goto_4

    :cond_7
    iget-object p1, p0, Ls/a;->a:Ls/c;

    iget-object p1, p1, Ls/c;->c:Ls/f;

    iget-object p1, p1, Ls/f;->b:Ljava/lang/String;

    const-string v0, "diffie-hellman-group1-sha1"

    invoke-virtual {p1, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p1

    if-nez p1, :cond_9

    iget-object p1, p0, Ls/a;->a:Ls/c;

    iget-object p1, p1, Ls/c;->c:Ls/f;

    iget-object p1, p1, Ls/f;->b:Ljava/lang/String;

    const-string v0, "diffie-hellman-group14-sha1"

    invoke-virtual {p1, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p1

    if-eqz p1, :cond_8

    goto :goto_2

    :cond_8
    new-instance p1, Ljava/lang/IllegalStateException;

    const-string p2, "Unkown KEX method!"

    invoke-direct {p1, p2}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    throw p1

    :cond_9
    :goto_2
    iget-object p1, p0, Ls/a;->a:Ls/c;

    new-instance v0, Lcom/trilead/ssh2/crypto/dh/DhExchange;

    const-string v1, "SHA1"

    invoke-direct {v0, v1}, Lcom/trilead/ssh2/crypto/dh/DhExchange;-><init>(Ljava/lang/String;)V

    iput-object v0, p1, Ls/c;->h:Lcom/trilead/ssh2/crypto/dh/DhExchange;

    iget-object p1, p0, Ls/a;->a:Ls/c;

    iget-object p1, p1, Ls/c;->c:Ls/f;

    iget-object p1, p1, Ls/f;->b:Ljava/lang/String;

    const-string v0, "diffie-hellman-group1-sha1"

    invoke-virtual {p1, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p1

    if-eqz p1, :cond_a

    iget-object p1, p0, Ls/a;->a:Ls/c;

    iget-object p1, p1, Ls/c;->h:Lcom/trilead/ssh2/crypto/dh/DhExchange;

    iget-object v0, p0, Ls/a;->p:Ljava/security/SecureRandom;

    invoke-virtual {p1, v4, v0}, Lcom/trilead/ssh2/crypto/dh/DhExchange;->e(ILjava/security/SecureRandom;)V

    goto :goto_3

    :cond_a
    iget-object p1, p0, Ls/a;->a:Ls/c;

    iget-object p1, p1, Ls/c;->h:Lcom/trilead/ssh2/crypto/dh/DhExchange;

    const/16 v0, 0xe

    iget-object v1, p0, Ls/a;->p:Ljava/security/SecureRandom;

    invoke-virtual {p1, v0, v1}, Lcom/trilead/ssh2/crypto/dh/DhExchange;->e(ILjava/security/SecureRandom;)V

    :goto_3
    iget-object p1, p0, Ls/a;->a:Ls/c;

    iget-object p1, p1, Ls/c;->h:Lcom/trilead/ssh2/crypto/dh/DhExchange;

    invoke-virtual {p1}, Lcom/trilead/ssh2/crypto/dh/DhExchange;->b()Ljava/math/BigInteger;

    move-result-object p1

    iget-object v0, p0, Ls/a;->j:Ls/i;

    .line 1
    new-instance v1, Lq/b;

    invoke-direct {v1}, Lq/b;-><init>()V

    invoke-virtual {v1, p2}, Lq/b;->d(I)V

    invoke-virtual {v1, p1}, Lq/b;->f(Ljava/math/BigInteger;)V

    invoke-virtual {v1}, Lq/b;->a()[B

    move-result-object p1

    .line 2
    invoke-virtual {v0, p1}, Ls/i;->l([B)V

    iget-object p1, p0, Ls/a;->a:Ls/c;

    iput v4, p1, Ls/c;->d:I

    iget-object p2, p1, Ls/c;->h:Lcom/trilead/ssh2/crypto/dh/DhExchange;

    invoke-virtual {p2}, Lcom/trilead/ssh2/crypto/dh/DhExchange;->c()Ljava/lang/String;

    move-result-object p2

    invoke-virtual {p1, p2}, Ls/c;->b(Ljava/lang/String;)V
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_1

    monitor-exit p0

    return-void

    :cond_b
    :goto_4
    :try_start_2
    iget-object p1, p0, Ls/a;->a:Ls/c;

    iget-object p1, p1, Ls/c;->j:La/b;

    invoke-static {p1}, Ljava/util/Objects;->requireNonNull(Ljava/lang/Object;)Ljava/lang/Object;

    iget-object p1, p0, Ls/a;->a:Ls/c;

    iget-object p1, p1, Ls/c;->j:La/b;

    .line 3
    invoke-static {p1}, Ljava/util/Objects;->requireNonNull(Ljava/lang/Object;)Ljava/lang/Object;

    const/16 p1, 0x400

    const/16 p2, 0x800

    const/16 v0, 0x1000

    .line 4
    iget-object v1, p0, Ls/a;->j:Ls/i;

    .line 5
    new-instance v2, Lq/b;

    invoke-direct {v2}, Lq/b;-><init>()V

    const/16 v3, 0x22

    invoke-virtual {v2, v3}, Lq/b;->d(I)V

    invoke-virtual {v2, p1}, Lq/b;->j(I)V

    invoke-virtual {v2, p2}, Lq/b;->j(I)V

    invoke-virtual {v2, v0}, Lq/b;->j(I)V

    invoke-virtual {v2}, Lq/b;->a()[B

    move-result-object p1

    .line 6
    invoke-virtual {v1, p1}, Ls/i;->l([B)V

    iget-object p1, p0, Ls/a;->a:Ls/c;

    iput v4, p1, Ls/c;->d:I

    iget-object p1, p1, Ls/c;->c:Ls/f;

    iget-object p1, p1, Ls/f;->b:Ljava/lang/String;

    const-string p2, "sha1"

    invoke-virtual {p1, p2}, Ljava/lang/String;->endsWith(Ljava/lang/String;)Z

    move-result p1

    if-eqz p1, :cond_c

    iget-object p1, p0, Ls/a;->a:Ls/c;

    const-string p2, "SHA1"

    goto :goto_5

    :cond_c
    iget-object p1, p0, Ls/a;->a:Ls/c;

    const-string p2, "SHA-256"

    :goto_5
    invoke-virtual {p1, p2}, Ls/c;->b(Ljava/lang/String;)V
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_1

    monitor-exit p0

    return-void

    :cond_d
    :try_start_3
    new-instance p1, Ljava/io/IOException;

    const-string p2, "Cannot negotiate, proposals do not match."

    invoke-direct {p1, p2}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    throw p1

    :cond_e
    aget-byte v1, p1, v2

    const/16 v3, 0x15

    if-ne v1, v3, :cond_10

    iget-object p1, p0, Ls/a;->c:Lcom/trilead/ssh2/crypto/KeyMaterial;
    :try_end_3
    .catchall {:try_start_3 .. :try_end_3} :catchall_1

    if-eqz p1, :cond_f

    :try_start_4
    iget-object p2, v0, Ls/c;->c:Ls/f;

    iget-object p2, p2, Ls/f;->e:Ljava/lang/String;

    iget-object v0, p1, Lcom/trilead/ssh2/crypto/KeyMaterial;->d:[B

    iget-object p1, p1, Lcom/trilead/ssh2/crypto/KeyMaterial;->b:[B

    invoke-static {p2, v2, v0, p1}, Lcom/trilead/ssh2/crypto/cipher/BlockCipherFactory;->a(Ljava/lang/String;Z[B[B)Lcom/trilead/ssh2/crypto/cipher/BlockCipher;

    move-result-object p1

    new-instance p2, Lcom/trilead/ssh2/crypto/digest/MessageMac;

    iget-object v0, p0, Ls/a;->a:Ls/c;

    iget-object v0, v0, Ls/c;->c:Ls/f;

    iget-object v0, v0, Ls/f;->g:Ljava/lang/String;

    iget-object v1, p0, Ls/a;->c:Lcom/trilead/ssh2/crypto/KeyMaterial;

    iget-object v1, v1, Lcom/trilead/ssh2/crypto/KeyMaterial;->f:[B

    invoke-direct {p2, v0, v1}, Lcom/trilead/ssh2/crypto/digest/MessageMac;-><init>(Ljava/lang/String;[B)V
    :try_end_4
    .catch Ljava/lang/IllegalArgumentException; {:try_start_4 .. :try_end_4} :catch_0
    .catchall {:try_start_4 .. :try_end_4} :catchall_1

    :try_start_5
    iget-object v0, p0, Ls/a;->j:Ls/i;

    invoke-virtual {v0, p1, p2}, Ls/i;->a(Lcom/trilead/ssh2/crypto/cipher/BlockCipher;Lcom/trilead/ssh2/crypto/digest/MAC;)V

    new-instance p1, Ll/e;

    invoke-direct {p1}, Ll/e;-><init>()V

    iget p2, p0, Ls/a;->b:I

    add-int/2addr p2, v4

    iput p2, p0, Ls/a;->b:I

    iget-object v0, p0, Ls/a;->a:Ls/c;

    iget-object v0, v0, Ls/c;->c:Ls/f;

    iget-object v0, v0, Ls/f;->b:Ljava/lang/String;

    iput p2, p1, Ll/e;->a:I

    iget-object p2, p0, Ls/a;->f:Ljava/lang/Object;

    monitor-enter p2
    :try_end_5
    .catchall {:try_start_5 .. :try_end_5} :catchall_1

    :try_start_6
    iput-object p1, p0, Ls/a;->g:Ll/e;

    iget-object p1, p0, Ls/a;->f:Ljava/lang/Object;

    invoke-virtual {p1}, Ljava/lang/Object;->notifyAll()V

    monitor-exit p2
    :try_end_6
    .catchall {:try_start_6 .. :try_end_6} :catchall_0

    const/4 p1, 0x0

    :try_start_7
    iput-object p1, p0, Ls/a;->a:Ls/c;
    :try_end_7
    .catchall {:try_start_7 .. :try_end_7} :catchall_1

    monitor-exit p0

    return-void

    :catchall_0
    move-exception p1

    :try_start_8
    monitor-exit p2
    :try_end_8
    .catchall {:try_start_8 .. :try_end_8} :catchall_0

    :try_start_9
    throw p1

    :catch_0
    new-instance p1, Ljava/io/IOException;

    const-string p2, "Fatal error during MAC startup!"

    invoke-direct {p1, p2}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    throw p1

    :cond_f
    new-instance p1, Ljava/io/IOException;

    const-string p2, "Peer sent SSH_MSG_NEWKEYS, but I have no key material ready!"

    invoke-direct {p1, p2}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    throw p1

    :cond_10
    if-eqz v0, :cond_21

    iget v1, v0, Ls/c;->d:I

    if-eqz v1, :cond_21

    iget-object v0, v0, Ls/c;->c:Ls/f;

    iget-object v0, v0, Ls/f;->b:Ljava/lang/String;

    const-string v1, "diffie-hellman-group-exchange-sha1"

    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    const/4 v1, -0x1

    const/16 v3, 0x1f

    if-nez v0, :cond_18

    iget-object v0, p0, Ls/a;->a:Ls/c;

    iget-object v0, v0, Ls/c;->c:Ls/f;

    iget-object v0, v0, Ls/f;->b:Ljava/lang/String;

    const-string v5, "diffie-hellman-group-exchange-sha256"

    invoke-virtual {v0, v5}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_11

    goto/16 :goto_7

    :cond_11
    iget-object v0, p0, Ls/a;->a:Ls/c;

    iget-object v0, v0, Ls/c;->c:Ls/f;

    iget-object v0, v0, Ls/f;->b:Ljava/lang/String;

    const-string v5, "diffie-hellman-group1-sha1"

    invoke-virtual {v0, v5}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_12

    iget-object v0, p0, Ls/a;->a:Ls/c;

    iget-object v0, v0, Ls/c;->c:Ls/f;

    iget-object v0, v0, Ls/f;->b:Ljava/lang/String;

    const-string v5, "diffie-hellman-group14-sha1"

    invoke-virtual {v0, v5}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_17

    :cond_12
    iget-object v0, p0, Ls/a;->a:Ls/c;

    iget v0, v0, Ls/c;->d:I

    if-ne v0, v4, :cond_17

    const-string v0, ")"

    .line 7
    new-array v4, p2, [B

    invoke-static {p1, v2, v4, v2, p2}, Ljava/lang/System;->arraycopy(Ljava/lang/Object;ILjava/lang/Object;II)V

    new-instance v2, Lq/c;

    invoke-direct {v2, p1, p2}, Lq/c;-><init>([BI)V

    invoke-virtual {v2}, Lq/c;->b()I

    move-result p1

    if-ne p1, v3, :cond_16

    invoke-virtual {v2}, Lq/c;->c()[B

    move-result-object v9

    invoke-virtual {v2}, Lq/c;->e()Ljava/math/BigInteger;

    move-result-object p1

    invoke-virtual {v2}, Lq/c;->c()[B

    move-result-object p2

    .line 8
    iget v0, v2, Lq/c;->c:I

    iget v2, v2, Lq/c;->b:I

    sub-int/2addr v0, v2

    if-nez v0, :cond_15

    .line 9
    iget-object v0, p0, Ls/a;->a:Ls/c;

    iput-object v9, v0, Ls/c;->g:[B

    iget-object v2, p0, Ls/a;->m:Lm/k;
    :try_end_9
    .catchall {:try_start_9 .. :try_end_9} :catchall_1

    if-eqz v2, :cond_13

    :try_start_a
    iget-object v3, p0, Ls/a;->n:Ljava/lang/String;

    iget-object v0, v0, Ls/c;->c:Ls/f;

    iget-object v0, v0, Ls/f;->c:Ljava/lang/String;

    check-cast v2, Lh0/h;

    invoke-virtual {v2, v3, v0, v9}, Lh0/h;->m(Ljava/lang/String;Ljava/lang/String;[B)V
    :try_end_a
    .catch Ljava/lang/Exception; {:try_start_a .. :try_end_a} :catch_1
    .catchall {:try_start_a .. :try_end_a} :catchall_1

    goto :goto_6

    :catch_1
    move-exception p1

    :try_start_b
    new-instance p2, Ljava/io/IOException;

    const-string v0, "The server hostkey was not accepted by the verifier callback."

    invoke-direct {p2, v0, p1}, Ljava/io/IOException;-><init>(Ljava/lang/String;Ljava/lang/Throwable;)V

    throw p2

    :cond_13
    :goto_6
    iget-object v0, p0, Ls/a;->a:Ls/c;

    iget-object v0, v0, Ls/c;->h:Lcom/trilead/ssh2/crypto/dh/DhExchange;

    invoke-virtual {v0, p1}, Lcom/trilead/ssh2/crypto/dh/DhExchange;->f(Ljava/math/BigInteger;)V
    :try_end_b
    .catchall {:try_start_b .. :try_end_b} :catchall_1

    :try_start_c
    iget-object p1, p0, Ls/a;->a:Ls/c;

    iget-object v4, p1, Ls/c;->h:Lcom/trilead/ssh2/crypto/dh/DhExchange;

    iget-object v0, p0, Ls/a;->e:Lq/a;

    invoke-virtual {v0}, Lq/a;->a()[B

    move-result-object v5

    iget-object v0, p0, Ls/a;->e:Lq/a;

    invoke-virtual {v0}, Lq/a;->b()[B

    move-result-object v6

    iget-object v0, p0, Ls/a;->a:Ls/c;

    iget-object v0, v0, Ls/c;->a:Lm/e;

    invoke-virtual {v0}, Lm/e;->b()[B

    move-result-object v7

    iget-object v0, p0, Ls/a;->a:Ls/c;

    iget-object v0, v0, Ls/c;->b:Lm/e;

    invoke-virtual {v0}, Lm/e;->b()[B

    move-result-object v8

    invoke-virtual/range {v4 .. v9}, Lcom/trilead/ssh2/crypto/dh/DhExchange;->a([B[B[B[B[B)[B

    move-result-object v0

    iput-object v0, p1, Ls/c;->f:[B
    :try_end_c
    .catch Ljava/lang/IllegalArgumentException; {:try_start_c .. :try_end_c} :catch_2
    .catchall {:try_start_c .. :try_end_c} :catchall_1

    :try_start_d
    iget-object p1, p0, Ls/a;->a:Ls/c;

    iget-object p1, p1, Ls/c;->g:[B

    invoke-virtual {p0, p2, p1}, Ls/a;->g([B[B)Z

    move-result p1

    if-eqz p1, :cond_14

    iget-object p1, p0, Ls/a;->a:Ls/c;

    iget-object p2, p1, Ls/c;->h:Lcom/trilead/ssh2/crypto/dh/DhExchange;

    invoke-virtual {p2}, Lcom/trilead/ssh2/crypto/dh/DhExchange;->d()Ljava/math/BigInteger;

    move-result-object p2

    iput-object p2, p1, Ls/c;->e:Ljava/math/BigInteger;

    invoke-virtual {p0}, Ls/a;->d()V

    iget-object p1, p0, Ls/a;->a:Ls/c;

    iput v1, p1, Ls/c;->d:I
    :try_end_d
    .catchall {:try_start_d .. :try_end_d} :catchall_1

    monitor-exit p0

    return-void

    :cond_14
    :try_start_e
    new-instance p1, Ljava/io/IOException;

    const-string p2, "Hostkey signature sent by remote is wrong!"

    invoke-direct {p1, p2}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    throw p1

    :catch_2
    move-exception p1

    new-instance p2, Ljava/io/IOException;

    const-string v0, "KEX error."

    invoke-direct {p2, v0, p1}, Ljava/io/IOException;-><init>(Ljava/lang/String;Ljava/lang/Throwable;)V

    throw p2

    .line 10
    :cond_15
    new-instance p1, Ljava/io/IOException;

    const-string p2, "PADDING IN SSH_MSG_KEXDH_REPLY!"

    invoke-direct {p1, p2}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    throw p1

    :cond_16
    new-instance p2, Ljava/io/IOException;

    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const-string v2, "This is not a SSH_MSG_KEXDH_REPLY! ("

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1, p1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    invoke-direct {p2, p1}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    throw p2

    .line 11
    :cond_17
    new-instance p1, Ljava/lang/IllegalStateException;

    new-instance p2, Ljava/lang/StringBuilder;

    invoke-direct {p2}, Ljava/lang/StringBuilder;-><init>()V

    const-string v0, "Unkown KEX method! ("

    invoke-virtual {p2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object v0, p0, Ls/a;->a:Ls/c;

    iget-object v0, v0, Ls/c;->c:Ls/f;

    iget-object v0, v0, Ls/f;->b:Ljava/lang/String;

    invoke-virtual {p2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v0, ")"

    invoke-virtual {p2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p2

    invoke-direct {p1, p2}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    throw p1

    :cond_18
    :goto_7
    iget-object v0, p0, Ls/a;->a:Ls/c;

    iget v0, v0, Ls/c;->d:I

    const/4 v5, 0x2

    if-ne v0, v4, :cond_1b

    new-array v0, p2, [B

    invoke-static {p1, v2, v0, v2, p2}, Ljava/lang/System;->arraycopy(Ljava/lang/Object;ILjava/lang/Object;II)V

    new-instance v0, Lq/c;

    invoke-direct {v0, p1, p2}, Lq/c;-><init>([BI)V

    invoke-virtual {v0}, Lq/c;->b()I

    move-result p1

    if-ne p1, v3, :cond_1a

    invoke-virtual {v0}, Lq/c;->e()Ljava/math/BigInteger;

    move-result-object p1

    invoke-virtual {v0}, Lq/c;->e()Ljava/math/BigInteger;

    move-result-object p2

    .line 12
    iget v1, v0, Lq/c;->c:I

    iget v0, v0, Lq/c;->b:I

    sub-int/2addr v1, v0

    if-nez v1, :cond_19

    .line 13
    iget-object v0, p0, Ls/a;->a:Ls/c;

    new-instance v1, Lcom/trilead/ssh2/crypto/dh/DhGroupExchange;

    invoke-virtual {v0}, Ls/c;->a()Ljava/lang/String;

    move-result-object v2

    invoke-direct {v1, v2, p1, p2}, Lcom/trilead/ssh2/crypto/dh/DhGroupExchange;-><init>(Ljava/lang/String;Ljava/math/BigInteger;Ljava/math/BigInteger;)V

    iput-object v1, v0, Ls/c;->i:Lcom/trilead/ssh2/crypto/dh/DhGroupExchange;

    iget-object p1, p0, Ls/a;->a:Ls/c;

    iget-object p1, p1, Ls/c;->i:Lcom/trilead/ssh2/crypto/dh/DhGroupExchange;

    iget-object p2, p0, Ls/a;->p:Ljava/security/SecureRandom;

    invoke-virtual {p1, p2}, Lcom/trilead/ssh2/crypto/dh/DhGroupExchange;->d(Ljava/security/SecureRandom;)V

    iget-object p1, p0, Ls/a;->a:Ls/c;

    iget-object p1, p1, Ls/c;->i:Lcom/trilead/ssh2/crypto/dh/DhGroupExchange;

    invoke-virtual {p1}, Lcom/trilead/ssh2/crypto/dh/DhGroupExchange;->b()Ljava/math/BigInteger;

    move-result-object p1

    iget-object p2, p0, Ls/a;->j:Ls/i;

    .line 14
    new-instance v0, Lq/b;

    invoke-direct {v0}, Lq/b;-><init>()V

    const/16 v1, 0x20

    invoke-virtual {v0, v1}, Lq/b;->d(I)V

    invoke-virtual {v0, p1}, Lq/b;->f(Ljava/math/BigInteger;)V

    invoke-virtual {v0}, Lq/b;->a()[B

    move-result-object p1

    .line 15
    invoke-virtual {p2, p1}, Ls/i;->l([B)V

    iget-object p1, p0, Ls/a;->a:Ls/c;

    iput v5, p1, Ls/c;->d:I
    :try_end_e
    .catchall {:try_start_e .. :try_end_e} :catchall_1

    monitor-exit p0

    return-void

    .line 16
    :cond_19
    :try_start_f
    new-instance p1, Ljava/io/IOException;

    const-string p2, "PADDING IN SSH_MSG_KEX_DH_GEX_GROUP!"

    invoke-direct {p1, p2}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    throw p1

    :cond_1a
    new-instance p2, Ljava/lang/IllegalArgumentException;

    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const-string v1, "This is not a SSH_MSG_KEX_DH_GEX_GROUP! ("

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string p1, ")"

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    invoke-direct {p2, p1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw p2

    :cond_1b
    if-ne v0, v5, :cond_20

    const-string v0, ")"

    .line 17
    new-array v3, p2, [B

    invoke-static {p1, v2, v3, v2, p2}, Ljava/lang/System;->arraycopy(Ljava/lang/Object;ILjava/lang/Object;II)V

    new-instance v2, Lq/c;

    invoke-direct {v2, p1, p2}, Lq/c;-><init>([BI)V

    invoke-virtual {v2}, Lq/c;->b()I

    move-result p1

    const/16 p2, 0x21

    if-ne p1, p2, :cond_1f

    invoke-virtual {v2}, Lq/c;->c()[B

    move-result-object v8

    invoke-virtual {v2}, Lq/c;->e()Ljava/math/BigInteger;

    move-result-object p1

    invoke-virtual {v2}, Lq/c;->c()[B

    move-result-object p2

    .line 18
    iget v0, v2, Lq/c;->c:I

    iget v2, v2, Lq/c;->b:I

    sub-int/2addr v0, v2

    if-nez v0, :cond_1e

    .line 19
    iget-object v0, p0, Ls/a;->a:Ls/c;

    iput-object v8, v0, Ls/c;->g:[B

    iget-object v2, p0, Ls/a;->m:Lm/k;
    :try_end_f
    .catchall {:try_start_f .. :try_end_f} :catchall_1

    if-eqz v2, :cond_1c

    :try_start_10
    iget-object v3, p0, Ls/a;->n:Ljava/lang/String;

    iget-object v0, v0, Ls/c;->c:Ls/f;

    iget-object v0, v0, Ls/f;->c:Ljava/lang/String;

    check-cast v2, Lh0/h;

    invoke-virtual {v2, v3, v0, v8}, Lh0/h;->m(Ljava/lang/String;Ljava/lang/String;[B)V
    :try_end_10
    .catch Ljava/lang/Exception; {:try_start_10 .. :try_end_10} :catch_3
    .catchall {:try_start_10 .. :try_end_10} :catchall_1

    goto :goto_8

    :catch_3
    move-exception p1

    :try_start_11
    new-instance p2, Ljava/io/IOException;

    const-string v0, "The server hostkey was not accepted by the verifier callback."

    invoke-direct {p2, v0, p1}, Ljava/io/IOException;-><init>(Ljava/lang/String;Ljava/lang/Throwable;)V

    throw p2

    :cond_1c
    :goto_8
    iget-object v0, p0, Ls/a;->a:Ls/c;

    iget-object v0, v0, Ls/c;->i:Lcom/trilead/ssh2/crypto/dh/DhGroupExchange;

    invoke-virtual {v0, p1}, Lcom/trilead/ssh2/crypto/dh/DhGroupExchange;->e(Ljava/math/BigInteger;)V
    :try_end_11
    .catchall {:try_start_11 .. :try_end_11} :catchall_1

    :try_start_12
    iget-object p1, p0, Ls/a;->a:Ls/c;

    iget-object v3, p1, Ls/c;->i:Lcom/trilead/ssh2/crypto/dh/DhGroupExchange;

    iget-object v0, p0, Ls/a;->e:Lq/a;

    invoke-virtual {v0}, Lq/a;->a()[B

    move-result-object v4

    iget-object v0, p0, Ls/a;->e:Lq/a;

    invoke-virtual {v0}, Lq/a;->b()[B

    move-result-object v5

    iget-object v0, p0, Ls/a;->a:Ls/c;

    iget-object v0, v0, Ls/c;->a:Lm/e;

    invoke-virtual {v0}, Lm/e;->b()[B

    move-result-object v6

    iget-object v0, p0, Ls/a;->a:Ls/c;

    iget-object v0, v0, Ls/c;->b:Lm/e;

    invoke-virtual {v0}, Lm/e;->b()[B

    move-result-object v7

    iget-object v0, p0, Ls/a;->a:Ls/c;

    iget-object v9, v0, Ls/c;->j:La/b;

    invoke-virtual/range {v3 .. v9}, Lcom/trilead/ssh2/crypto/dh/DhGroupExchange;->a([B[B[B[B[BLa/b;)[B

    move-result-object v0

    iput-object v0, p1, Ls/c;->f:[B
    :try_end_12
    .catch Ljava/lang/IllegalArgumentException; {:try_start_12 .. :try_end_12} :catch_4
    .catchall {:try_start_12 .. :try_end_12} :catchall_1

    :try_start_13
    iget-object p1, p0, Ls/a;->a:Ls/c;

    iget-object p1, p1, Ls/c;->g:[B

    invoke-virtual {p0, p2, p1}, Ls/a;->g([B[B)Z

    move-result p1

    if-eqz p1, :cond_1d

    iget-object p1, p0, Ls/a;->a:Ls/c;

    iget-object p2, p1, Ls/c;->i:Lcom/trilead/ssh2/crypto/dh/DhGroupExchange;

    invoke-virtual {p2}, Lcom/trilead/ssh2/crypto/dh/DhGroupExchange;->c()Ljava/math/BigInteger;

    move-result-object p2

    iput-object p2, p1, Ls/c;->e:Ljava/math/BigInteger;

    invoke-virtual {p0}, Ls/a;->d()V

    iget-object p1, p0, Ls/a;->a:Ls/c;

    iput v1, p1, Ls/c;->d:I
    :try_end_13
    .catchall {:try_start_13 .. :try_end_13} :catchall_1

    monitor-exit p0

    return-void

    :cond_1d
    :try_start_14
    new-instance p1, Ljava/io/IOException;

    const-string p2, "Hostkey signature sent by remote is wrong!"

    invoke-direct {p1, p2}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    throw p1

    :catch_4
    move-exception p1

    new-instance p2, Ljava/io/IOException;

    const-string v0, "KEX error."

    invoke-direct {p2, v0, p1}, Ljava/io/IOException;-><init>(Ljava/lang/String;Ljava/lang/Throwable;)V

    throw p2

    .line 20
    :cond_1e
    new-instance p1, Ljava/io/IOException;

    const-string p2, "PADDING IN SSH_MSG_KEX_DH_GEX_REPLY!"

    invoke-direct {p1, p2}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    throw p1

    :cond_1f
    new-instance p2, Ljava/io/IOException;

    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const-string v2, "This is not a SSH_MSG_KEX_DH_GEX_REPLY! ("

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1, p1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    invoke-direct {p2, p1}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    throw p2

    .line 21
    :cond_20
    new-instance p1, Ljava/lang/IllegalStateException;

    const-string p2, "Illegal State in KEX Exchange!"

    invoke-direct {p1, p2}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    throw p1

    :cond_21
    new-instance p1, Ljava/io/IOException;

    const-string p2, "Unexpected Kex submessage!"

    invoke-direct {p1, p2}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    throw p1
    :try_end_14
    .catchall {:try_start_14 .. :try_end_14} :catchall_1

    :catchall_1
    move-exception p1

    monitor-exit p0

    throw p1
.end method

.method public final c([Ljava/lang/String;[Ljava/lang/String;)Z
    .locals 2

    if-eqz p1, :cond_3

    if-eqz p2, :cond_3

    array-length v0, p1

    if-nez v0, :cond_0

    array-length v0, p2

    if-nez v0, :cond_0

    const/4 p1, 0x1

    return p1

    :cond_0
    array-length v0, p1

    const/4 v1, 0x0

    if-eqz v0, :cond_2

    array-length v0, p2

    if-nez v0, :cond_1

    goto :goto_0

    :cond_1
    aget-object p1, p1, v1

    aget-object p2, p2, v1

    invoke-virtual {p1, p2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p1

    return p1

    :cond_2
    :goto_0
    return v1

    :cond_3
    new-instance p1, Ljava/lang/IllegalArgumentException;

    invoke-direct {p1}, Ljava/lang/IllegalArgumentException;-><init>()V

    throw p1
.end method

.method public final d()V
    .locals 11

    iget-object v0, p0, Ls/a;->d:[B

    if-nez v0, :cond_0

    iget-object v0, p0, Ls/a;->a:Ls/c;

    iget-object v0, v0, Ls/c;->f:[B

    iput-object v0, p0, Ls/a;->d:[B

    .line 1
    :cond_0
    :try_start_0
    iget-object v0, p0, Ls/a;->a:Ls/c;

    iget-object v0, v0, Ls/c;->c:Ls/f;

    iget-object v0, v0, Ls/f;->f:Ljava/lang/String;

    invoke-static {v0}, Lcom/trilead/ssh2/crypto/digest/MessageMac;->e(Ljava/lang/String;)I

    move-result v7

    iget-object v0, p0, Ls/a;->a:Ls/c;

    iget-object v0, v0, Ls/c;->c:Ls/f;

    iget-object v0, v0, Ls/f;->d:Ljava/lang/String;

    invoke-static {v0}, Lcom/trilead/ssh2/crypto/cipher/BlockCipherFactory;->e(Ljava/lang/String;)I

    move-result v5

    iget-object v0, p0, Ls/a;->a:Ls/c;

    iget-object v0, v0, Ls/c;->c:Ls/f;

    iget-object v0, v0, Ls/f;->d:Ljava/lang/String;

    invoke-static {v0}, Lcom/trilead/ssh2/crypto/cipher/BlockCipherFactory;->b(Ljava/lang/String;)I

    move-result v6

    iget-object v0, p0, Ls/a;->a:Ls/c;

    iget-object v0, v0, Ls/c;->c:Ls/f;

    iget-object v0, v0, Ls/f;->g:Ljava/lang/String;

    invoke-static {v0}, Lcom/trilead/ssh2/crypto/digest/MessageMac;->e(Ljava/lang/String;)I

    move-result v10

    iget-object v0, p0, Ls/a;->a:Ls/c;

    iget-object v0, v0, Ls/c;->c:Ls/f;

    iget-object v0, v0, Ls/f;->e:Ljava/lang/String;

    invoke-static {v0}, Lcom/trilead/ssh2/crypto/cipher/BlockCipherFactory;->e(Ljava/lang/String;)I

    move-result v8

    iget-object v0, p0, Ls/a;->a:Ls/c;

    iget-object v0, v0, Ls/c;->c:Ls/f;

    iget-object v0, v0, Ls/f;->e:Ljava/lang/String;

    invoke-static {v0}, Lcom/trilead/ssh2/crypto/cipher/BlockCipherFactory;->b(Ljava/lang/String;)I

    move-result v9

    iget-object v0, p0, Ls/a;->a:Ls/c;

    .line 2
    iget-object v1, v0, Ls/c;->k:Ljava/lang/String;

    .line 3
    iget-object v2, v0, Ls/c;->f:[B

    iget-object v3, v0, Ls/c;->e:Ljava/math/BigInteger;

    iget-object v4, p0, Ls/a;->d:[B

    invoke-static/range {v1 .. v10}, Lcom/trilead/ssh2/crypto/KeyMaterial;->b(Ljava/lang/String;[BLjava/math/BigInteger;[BIIIIII)Lcom/trilead/ssh2/crypto/KeyMaterial;

    move-result-object v0

    iput-object v0, p0, Ls/a;->c:Lcom/trilead/ssh2/crypto/KeyMaterial;
    :try_end_0
    .catch Ljava/lang/IllegalArgumentException; {:try_start_0 .. :try_end_0} :catch_0

    .line 4
    :catch_0
    iget-object v0, p0, Ls/a;->j:Ls/i;

    const/16 v1, 0x100

    new-array v1, v1, [B

    const/16 v2, 0x15

    int-to-byte v2, v2

    const/4 v3, 0x0

    aput-byte v2, v1, v3

    const/4 v2, 0x1

    new-array v4, v2, [B

    .line 5
    invoke-static {v1, v3, v4, v3, v2}, Ljava/lang/System;->arraycopy(Ljava/lang/Object;ILjava/lang/Object;II)V

    .line 6
    invoke-virtual {v0, v4}, Ls/i;->l([B)V

    :try_start_1
    iget-object v0, p0, Ls/a;->a:Ls/c;

    iget-object v0, v0, Ls/c;->c:Ls/f;

    iget-object v0, v0, Ls/f;->d:Ljava/lang/String;

    iget-object v1, p0, Ls/a;->c:Lcom/trilead/ssh2/crypto/KeyMaterial;

    iget-object v4, v1, Lcom/trilead/ssh2/crypto/KeyMaterial;->c:[B

    iget-object v1, v1, Lcom/trilead/ssh2/crypto/KeyMaterial;->a:[B

    invoke-static {v0, v2, v4, v1}, Lcom/trilead/ssh2/crypto/cipher/BlockCipherFactory;->a(Ljava/lang/String;Z[B[B)Lcom/trilead/ssh2/crypto/cipher/BlockCipher;

    move-result-object v0

    new-instance v1, Lcom/trilead/ssh2/crypto/digest/MessageMac;

    iget-object v4, p0, Ls/a;->a:Ls/c;

    iget-object v4, v4, Ls/c;->c:Ls/f;

    iget-object v4, v4, Ls/f;->f:Ljava/lang/String;

    iget-object v5, p0, Ls/a;->c:Lcom/trilead/ssh2/crypto/KeyMaterial;

    iget-object v5, v5, Lcom/trilead/ssh2/crypto/KeyMaterial;->e:[B

    invoke-direct {v1, v4, v5}, Lcom/trilead/ssh2/crypto/digest/MessageMac;-><init>(Ljava/lang/String;[B)V
    :try_end_1
    .catch Ljava/lang/IllegalArgumentException; {:try_start_1 .. :try_end_1} :catch_1

    iget-object v4, p0, Ls/a;->j:Ls/i;

    .line 7
    iget-object v4, v4, Ls/i;->k:Ls/g;

    invoke-static {v4}, Ljava/util/Objects;->requireNonNull(Ljava/lang/Object;)Ljava/lang/Object;

    .line 8
    instance-of v5, v0, Lcom/trilead/ssh2/crypto/cipher/NullCipher;

    if-nez v5, :cond_1

    iput-boolean v2, v4, Ls/g;->e:Z

    :cond_1
    iget-object v2, v4, Ls/g;->d:Lcom/trilead/ssh2/crypto/cipher/CipherOutputStream;

    .line 9
    iput-object v0, v2, Lcom/trilead/ssh2/crypto/cipher/CipherOutputStream;->a:Lcom/trilead/ssh2/crypto/cipher/BlockCipher;

    invoke-interface {v0}, Lcom/trilead/ssh2/crypto/cipher/BlockCipher;->a()I

    move-result v5

    iput v5, v2, Lcom/trilead/ssh2/crypto/cipher/CipherOutputStream;->e:I

    new-array v6, v5, [B

    iput-object v6, v2, Lcom/trilead/ssh2/crypto/cipher/CipherOutputStream;->c:[B

    new-array v5, v5, [B

    iput-object v5, v2, Lcom/trilead/ssh2/crypto/cipher/CipherOutputStream;->d:[B

    iput v3, v2, Lcom/trilead/ssh2/crypto/cipher/CipherOutputStream;->f:I

    .line 10
    iput-object v1, v4, Ls/g;->f:Lcom/trilead/ssh2/crypto/digest/MAC;

    invoke-virtual {v1}, Lcom/trilead/ssh2/crypto/digest/MessageMac;->c()I

    move-result v1

    new-array v1, v1, [B

    iput-object v1, v4, Ls/g;->g:[B

    invoke-interface {v0}, Lcom/trilead/ssh2/crypto/cipher/BlockCipher;->a()I

    move-result v0

    iput v0, v4, Ls/g;->h:I

    const/16 v1, 0x8

    if-ge v0, v1, :cond_2

    iput v1, v4, Ls/g;->h:I

    .line 11
    :cond_2
    iget-object v0, p0, Ls/a;->j:Ls/i;

    .line 12
    iget-object v1, v0, Ls/i;->h:Ljava/lang/Object;

    monitor-enter v1

    :try_start_2
    iput-boolean v3, v0, Ls/i;->i:Z

    iget-object v0, v0, Ls/i;->h:Ljava/lang/Object;

    invoke-virtual {v0}, Ljava/lang/Object;->notifyAll()V

    monitor-exit v1

    return-void

    :catchall_0
    move-exception v0

    monitor-exit v1
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_0

    throw v0

    .line 13
    :catch_1
    new-instance v0, Ljava/io/IOException;

    const-string v1, "Fatal error during MAC startup!"

    invoke-direct {v0, v1}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    throw v0
.end method

.method public final e([Ljava/lang/String;[Ljava/lang/String;)Ljava/lang/String;
    .locals 7

    if-eqz p1, :cond_4

    if-eqz p2, :cond_4

    array-length v0, p1

    if-nez v0, :cond_0

    const/4 p1, 0x0

    return-object p1

    :cond_0
    array-length v0, p1

    const/4 v1, 0x0

    const/4 v2, 0x0

    :goto_0
    if-ge v2, v0, :cond_3

    aget-object v3, p1, v2

    array-length v4, p2

    const/4 v5, 0x0

    :goto_1
    if-ge v5, v4, :cond_2

    aget-object v6, p2, v5

    invoke-virtual {v3, v6}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v6

    if-eqz v6, :cond_1

    return-object v3

    :cond_1
    add-int/lit8 v5, v5, 0x1

    goto :goto_1

    :cond_2
    add-int/lit8 v2, v2, 0x1

    goto :goto_0

    :cond_3
    new-instance p1, Ls/e;

    invoke-direct {p1}, Ls/e;-><init>()V

    throw p1

    :cond_4
    new-instance p1, Ljava/lang/IllegalArgumentException;

    invoke-direct {p1}, Ljava/lang/IllegalArgumentException;-><init>()V

    throw p1
.end method

.method public final f(Ls/b;Ls/b;)Ls/f;
    .locals 4

    new-instance v0, Ls/f;

    invoke-direct {v0}, Ls/f;-><init>()V

    :try_start_0
    iget-object v1, p1, Ls/b;->b:[Ljava/lang/String;

    iget-object v2, p2, Ls/b;->b:[Ljava/lang/String;

    invoke-virtual {p0, v1, v2}, Ls/a;->e([Ljava/lang/String;[Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    iput-object v1, v0, Ls/f;->b:Ljava/lang/String;

    sget-object v1, Ls/a;->q:La/b;

    invoke-static {v1}, Ljava/util/Objects;->requireNonNull(Ljava/lang/Object;)Ljava/lang/Object;

    iget-object v1, p1, Ls/b;->c:[Ljava/lang/String;

    iget-object v2, p2, Ls/b;->c:[Ljava/lang/String;

    invoke-virtual {p0, v1, v2}, Ls/a;->e([Ljava/lang/String;[Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    iput-object v1, v0, Ls/f;->c:Ljava/lang/String;

    iget-object v1, p1, Ls/b;->d:[Ljava/lang/String;

    iget-object v2, p2, Ls/b;->d:[Ljava/lang/String;

    invoke-virtual {p0, v1, v2}, Ls/a;->e([Ljava/lang/String;[Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    iput-object v1, v0, Ls/f;->d:Ljava/lang/String;

    iget-object v1, p1, Ls/b;->e:[Ljava/lang/String;

    iget-object v2, p2, Ls/b;->e:[Ljava/lang/String;

    invoke-virtual {p0, v1, v2}, Ls/a;->e([Ljava/lang/String;[Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    iput-object v1, v0, Ls/f;->e:Ljava/lang/String;

    iget-object v1, p1, Ls/b;->f:[Ljava/lang/String;

    iget-object v2, p2, Ls/b;->f:[Ljava/lang/String;

    invoke-virtual {p0, v1, v2}, Ls/a;->e([Ljava/lang/String;[Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    iput-object v1, v0, Ls/f;->f:Ljava/lang/String;

    iget-object v1, p1, Ls/b;->g:[Ljava/lang/String;

    iget-object v2, p2, Ls/b;->g:[Ljava/lang/String;

    invoke-virtual {p0, v1, v2}, Ls/a;->e([Ljava/lang/String;[Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    iput-object v1, v0, Ls/f;->g:Ljava/lang/String;

    iget-object v1, p1, Ls/b;->h:[Ljava/lang/String;

    iget-object v2, p2, Ls/b;->h:[Ljava/lang/String;

    invoke-virtual {p0, v1, v2}, Ls/a;->e([Ljava/lang/String;[Ljava/lang/String;)Ljava/lang/String;

    iget-object v1, p1, Ls/b;->i:[Ljava/lang/String;

    iget-object v2, p2, Ls/b;->i:[Ljava/lang/String;

    invoke-virtual {p0, v1, v2}, Ls/a;->e([Ljava/lang/String;[Ljava/lang/String;)Ljava/lang/String;
    :try_end_0
    .catch Ls/e; {:try_start_0 .. :try_end_0} :catch_2

    :try_start_1
    iget-object v1, p1, Ls/b;->j:[Ljava/lang/String;

    iget-object v2, p2, Ls/b;->j:[Ljava/lang/String;

    invoke-virtual {p0, v1, v2}, Ls/a;->e([Ljava/lang/String;[Ljava/lang/String;)Ljava/lang/String;
    :try_end_1
    .catch Ls/e; {:try_start_1 .. :try_end_1} :catch_0

    :catch_0
    :try_start_2
    iget-object v1, p1, Ls/b;->k:[Ljava/lang/String;

    iget-object v2, p2, Ls/b;->k:[Ljava/lang/String;

    invoke-virtual {p0, v1, v2}, Ls/a;->e([Ljava/lang/String;[Ljava/lang/String;)Ljava/lang/String;
    :try_end_2
    .catch Ls/e; {:try_start_2 .. :try_end_2} :catch_1

    goto :goto_0

    :catch_1
    nop

    .line 1
    :goto_0
    iget-object v1, p1, Ls/b;->b:[Ljava/lang/String;

    iget-object v2, p2, Ls/b;->b:[Ljava/lang/String;

    invoke-virtual {p0, v1, v2}, Ls/a;->c([Ljava/lang/String;[Ljava/lang/String;)Z

    move-result v1

    const/4 v2, 0x0

    const/4 v3, 0x1

    if-nez v1, :cond_0

    goto :goto_1

    :cond_0
    iget-object p1, p1, Ls/b;->c:[Ljava/lang/String;

    iget-object p2, p2, Ls/b;->c:[Ljava/lang/String;

    invoke-virtual {p0, p1, p2}, Ls/a;->c([Ljava/lang/String;[Ljava/lang/String;)Z

    move-result p1

    if-nez p1, :cond_1

    goto :goto_1

    :cond_1
    const/4 v2, 0x1

    :goto_1
    if-eqz v2, :cond_2

    .line 2
    iput-boolean v3, v0, Ls/f;->a:Z

    :cond_2
    return-object v0

    :catch_2
    const/4 p1, 0x0

    return-object p1
.end method

.method public final g([B[B)Z
    .locals 4

    .line 1
    sget-object v0, Lr/e;->a:Ljava/util/Collection;

    .line 2
    invoke-interface {v0}, Ljava/util/Collection;->iterator()Ljava/util/Iterator;

    move-result-object v0

    :cond_0
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v1

    if-eqz v1, :cond_2

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Lr/d;

    .line 3
    iget-object v2, v1, Lr/d;->b:Ljava/lang/String;

    .line 4
    iget-object v3, p0, Ls/a;->a:Ls/c;

    iget-object v3, v3, Ls/c;->c:Ls/f;

    iget-object v3, v3, Ls/f;->c:Ljava/lang/String;

    invoke-virtual {v2, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v2

    if-eqz v2, :cond_0

    invoke-virtual {v1, p2}, Lr/d;->a([B)Ljava/security/PublicKey;

    move-result-object p2

    invoke-virtual {v1, p1}, Lr/d;->b([B)[B

    move-result-object p1

    iget-object v0, p0, Ls/a;->a:Ls/c;

    iget-object v0, v0, Ls/c;->f:[B

    .line 5
    :try_start_0
    iget-object v2, v1, Lr/d;->d:Ljava/security/Provider;

    if-nez v2, :cond_1

    iget-object v1, v1, Lr/d;->a:Ljava/lang/String;

    invoke-static {v1}, Ljava/security/Signature;->getInstance(Ljava/lang/String;)Ljava/security/Signature;

    move-result-object v1

    goto :goto_0

    :cond_1
    iget-object v1, v1, Lr/d;->a:Ljava/lang/String;

    invoke-static {v1, v2}, Ljava/security/Signature;->getInstance(Ljava/lang/String;Ljava/security/Provider;)Ljava/security/Signature;

    move-result-object v1

    :goto_0
    invoke-virtual {v1, p2}, Ljava/security/Signature;->initVerify(Ljava/security/PublicKey;)V

    invoke-virtual {v1, v0}, Ljava/security/Signature;->update([B)V

    invoke-virtual {v1, p1}, Ljava/security/Signature;->verify([B)Z

    move-result p1
    :try_end_0
    .catch Ljava/security/GeneralSecurityException; {:try_start_0 .. :try_end_0} :catch_0

    return p1

    :catch_0
    move-exception p1

    new-instance p2, Ljava/io/IOException;

    const-string v0, "Could not verify signature"

    invoke-direct {p2, v0, p1}, Ljava/io/IOException;-><init>(Ljava/lang/String;Ljava/lang/Throwable;)V

    throw p2

    .line 6
    :cond_2
    new-instance p1, Ljava/io/IOException;

    const-string p2, "Unknown server host key algorithm \'"

    .line 7
    invoke-static {p2}, Lcom/trilead/ssh2/crypto/digest/a;->e(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object p2

    .line 8
    iget-object v0, p0, Ls/a;->a:Ls/c;

    iget-object v0, v0, Ls/c;->c:Ls/f;

    iget-object v0, v0, Ls/f;->c:Ljava/lang/String;

    invoke-virtual {p2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v0, "\'"

    invoke-virtual {p2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p2

    invoke-direct {p1, p2}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    throw p1
.end method
