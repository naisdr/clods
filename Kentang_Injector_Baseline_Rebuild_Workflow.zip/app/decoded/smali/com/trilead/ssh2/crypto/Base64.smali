.class public Lcom/trilead/ssh2/crypto/Base64;
.super Ljava/lang/Object;
.source "SourceFile"


# static fields
.field public static final a:[C


# direct methods
.method public static constructor <clinit>()V
    .locals 1

    const-string v0, "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/"

    invoke-virtual {v0}, Ljava/lang/String;->toCharArray()[C

    move-result-object v0

    sput-object v0, Lcom/trilead/ssh2/crypto/Base64;->a:[C

    return-void
.end method

.method public constructor <init>()V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method public static a([B)[C
    .locals 8

    new-instance v0, Ljava/io/CharArrayWriter;

    array-length v1, p0

    mul-int/lit8 v1, v1, 0x4

    const/4 v2, 0x3

    div-int/2addr v1, v2

    invoke-direct {v0, v1}, Ljava/io/CharArrayWriter;-><init>(I)V

    const/4 v1, 0x0

    const/4 v3, 0x0

    const/4 v4, 0x0

    const/4 v5, 0x0

    :goto_0
    array-length v6, p0

    const/4 v7, 0x1

    if-ge v3, v6, :cond_3

    if-nez v4, :cond_0

    aget-byte v5, p0, v3

    and-int/lit16 v5, v5, 0xff

    shl-int/lit8 v5, v5, 0x10

    goto :goto_2

    :cond_0
    if-ne v4, v7, :cond_1

    aget-byte v6, p0, v3

    and-int/lit16 v6, v6, 0xff

    shl-int/lit8 v6, v6, 0x8

    goto :goto_1

    :cond_1
    aget-byte v6, p0, v3

    and-int/lit16 v6, v6, 0xff

    :goto_1
    or-int/2addr v5, v6

    :goto_2
    add-int/lit8 v4, v4, 0x1

    if-ne v4, v2, :cond_2

    sget-object v4, Lcom/trilead/ssh2/crypto/Base64;->a:[C

    shr-int/lit8 v6, v5, 0x12

    aget-char v6, v4, v6

    invoke-virtual {v0, v6}, Ljava/io/CharArrayWriter;->write(I)V

    shr-int/lit8 v6, v5, 0xc

    and-int/lit8 v6, v6, 0x3f

    aget-char v6, v4, v6

    invoke-virtual {v0, v6}, Ljava/io/CharArrayWriter;->write(I)V

    shr-int/lit8 v6, v5, 0x6

    and-int/lit8 v6, v6, 0x3f

    aget-char v6, v4, v6

    invoke-virtual {v0, v6}, Ljava/io/CharArrayWriter;->write(I)V

    and-int/lit8 v6, v5, 0x3f

    aget-char v4, v4, v6

    invoke-virtual {v0, v4}, Ljava/io/CharArrayWriter;->write(I)V

    const/4 v4, 0x0

    :cond_2
    add-int/lit8 v3, v3, 0x1

    goto :goto_0

    :cond_3
    const/16 p0, 0x3d

    if-ne v4, v7, :cond_4

    sget-object v1, Lcom/trilead/ssh2/crypto/Base64;->a:[C

    shr-int/lit8 v2, v5, 0x12

    aget-char v2, v1, v2

    invoke-virtual {v0, v2}, Ljava/io/CharArrayWriter;->write(I)V

    shr-int/lit8 v2, v5, 0xc

    and-int/lit8 v2, v2, 0x3f

    aget-char v1, v1, v2

    invoke-virtual {v0, v1}, Ljava/io/CharArrayWriter;->write(I)V

    invoke-virtual {v0, p0}, Ljava/io/CharArrayWriter;->write(I)V

    invoke-virtual {v0, p0}, Ljava/io/CharArrayWriter;->write(I)V

    :cond_4
    const/4 v1, 0x2

    if-ne v4, v1, :cond_5

    sget-object v1, Lcom/trilead/ssh2/crypto/Base64;->a:[C

    shr-int/lit8 v2, v5, 0x12

    aget-char v2, v1, v2

    invoke-virtual {v0, v2}, Ljava/io/CharArrayWriter;->write(I)V

    shr-int/lit8 v2, v5, 0xc

    and-int/lit8 v2, v2, 0x3f

    aget-char v2, v1, v2

    invoke-virtual {v0, v2}, Ljava/io/CharArrayWriter;->write(I)V

    shr-int/lit8 v2, v5, 0x6

    and-int/lit8 v2, v2, 0x3f

    aget-char v1, v1, v2

    invoke-virtual {v0, v1}, Ljava/io/CharArrayWriter;->write(I)V

    invoke-virtual {v0, p0}, Ljava/io/CharArrayWriter;->write(I)V

    :cond_5
    invoke-virtual {v0}, Ljava/io/CharArrayWriter;->toCharArray()[C

    move-result-object p0

    return-object p0
.end method
