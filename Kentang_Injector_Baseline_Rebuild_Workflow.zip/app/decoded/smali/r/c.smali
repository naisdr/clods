.class public final Lr/c;
.super Lr/d;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "Lr/d<",
        "Lnet/i2p/crypto/eddsa/EdDSAPublicKey;",
        "Lnet/i2p/crypto/eddsa/EdDSAPrivateKey;",
        ">;"
    }
.end annotation


# direct methods
.method public constructor <init>()V
    .locals 2

    const-class v0, Lnet/i2p/crypto/eddsa/EdDSAPrivateKey;

    new-instance v1, Lnet/i2p/crypto/eddsa/EdDSASecurityProvider;

    invoke-direct {v1}, Lnet/i2p/crypto/eddsa/EdDSASecurityProvider;-><init>()V

    invoke-direct {p0, v0, v1}, Lr/d;-><init>(Ljava/lang/Class;Ljava/security/Provider;)V

    return-void
.end method


# virtual methods
.method public final a([B)Ljava/security/PublicKey;
    .locals 3

    .line 1
    new-instance v0, Lq/c;

    invoke-direct {v0, p1}, Lq/c;-><init>([B)V

    invoke-virtual {v0}, Lq/c;->g()Ljava/lang/String;

    move-result-object p1

    const-string v1, "ssh-ed25519"

    invoke-virtual {p1, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p1

    if-eqz p1, :cond_1

    invoke-virtual {v0}, Lq/c;->c()[B

    move-result-object p1

    .line 2
    iget v1, v0, Lq/c;->c:I

    iget v0, v0, Lq/c;->b:I

    sub-int/2addr v1, v0

    if-nez v1, :cond_0

    .line 3
    new-instance v0, Lnet/i2p/crypto/eddsa/EdDSAPublicKey;

    new-instance v1, Lnet/i2p/crypto/eddsa/spec/EdDSAPublicKeySpec;

    const-string v2, "Ed25519"

    invoke-static {v2}, Lnet/i2p/crypto/eddsa/spec/EdDSANamedCurveTable;->a(Ljava/lang/String;)Lnet/i2p/crypto/eddsa/spec/EdDSANamedCurveSpec;

    move-result-object v2

    invoke-direct {v1, p1, v2}, Lnet/i2p/crypto/eddsa/spec/EdDSAPublicKeySpec;-><init>([BLnet/i2p/crypto/eddsa/spec/EdDSAParameterSpec;)V

    invoke-direct {v0, v1}, Lnet/i2p/crypto/eddsa/EdDSAPublicKey;-><init>(Lnet/i2p/crypto/eddsa/spec/EdDSAPublicKeySpec;)V

    return-object v0

    :cond_0
    new-instance p1, Ljava/io/IOException;

    const-string v0, "Unexpected padding in public key"

    invoke-direct {p1, v0}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    throw p1

    :cond_1
    new-instance p1, Ljava/io/IOException;

    const-string v0, "Invalid key type"

    invoke-direct {p1, v0}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    throw p1
.end method

.method public final b([B)[B
    .locals 2

    new-instance v0, Lq/c;

    invoke-direct {v0, p1}, Lq/c;-><init>([B)V

    invoke-virtual {v0}, Lq/c;->g()Ljava/lang/String;

    move-result-object p1

    const-string v1, "ssh-ed25519"

    invoke-virtual {p1, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p1

    if-eqz p1, :cond_1

    invoke-virtual {v0}, Lq/c;->c()[B

    move-result-object p1

    .line 1
    iget v1, v0, Lq/c;->c:I

    iget v0, v0, Lq/c;->b:I

    sub-int/2addr v1, v0

    if-nez v1, :cond_0

    return-object p1

    .line 2
    :cond_0
    new-instance p1, Ljava/io/IOException;

    const-string v0, "Unexpected padding in signature"

    invoke-direct {p1, v0}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    throw p1

    :cond_1
    new-instance p1, Ljava/io/IOException;

    const-string v0, "Invalid signature format"

    invoke-direct {p1, v0}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    throw p1
.end method

.method public final c(Ljava/security/PublicKey;)[B
    .locals 3

    check-cast p1, Lnet/i2p/crypto/eddsa/EdDSAPublicKey;

    .line 1
    iget-object p1, p1, Lnet/i2p/crypto/eddsa/EdDSAPublicKey;->c:[B

    .line 2
    new-instance v0, Lq/b;

    invoke-direct {v0}, Lq/b;-><init>()V

    const-string v1, "ssh-ed25519"

    invoke-virtual {v0, v1}, Lq/b;->h(Ljava/lang/String;)V

    const/4 v1, 0x0

    array-length v2, p1

    invoke-virtual {v0, p1, v1, v2}, Lq/b;->i([BII)V

    invoke-virtual {v0}, Lq/b;->a()[B

    move-result-object p1

    return-object p1
.end method

.method public final d([B)[B
    .locals 3

    new-instance v0, Lq/b;

    invoke-direct {v0}, Lq/b;-><init>()V

    const-string v1, "ssh-ed25519"

    invoke-virtual {v0, v1}, Lq/b;->h(Ljava/lang/String;)V

    array-length v1, p1

    const/4 v2, 0x0

    invoke-virtual {v0, p1, v2, v1}, Lq/b;->i([BII)V

    invoke-virtual {v0}, Lq/b;->a()[B

    move-result-object p1

    return-object p1
.end method

.method public final e()Ljava/util/List;
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/List<",
            "Lcom/trilead/ssh2/crypto/CertificateDecoder;",
            ">;"
        }
    .end annotation

    new-instance v0, Lr/c$a;

    invoke-direct {v0}, Lr/c$a;-><init>()V

    invoke-static {v0}, Ljava/util/Collections;->singletonList(Ljava/lang/Object;)Ljava/util/List;

    move-result-object v0

    return-object v0
.end method
