.class public final Lo/d;
.super Ljava/io/OutputStream;
.source "SourceFile"


# instance fields
.field public a:Lo/a;

.field public b:Z


# direct methods
.method public constructor <init>(Lo/a;)V
    .locals 1

    invoke-direct {p0}, Ljava/io/OutputStream;-><init>()V

    const/4 v0, 0x0

    iput-boolean v0, p0, Lo/d;->b:Z

    iput-object p1, p0, Lo/d;->a:Lo/a;

    return-void
.end method


# virtual methods
.method public final close()V
    .locals 7

    iget-boolean v0, p0, Lo/d;->b:Z

    if-nez v0, :cond_2

    const/4 v0, 0x1

    iput-boolean v0, p0, Lo/d;->b:Z

    iget-object v1, p0, Lo/d;->a:Lo/a;

    iget-object v2, v1, Lo/a;->b:Lo/c;

    invoke-static {v2}, Ljava/util/Objects;->requireNonNull(Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v3, 0x5

    new-array v3, v3, [B

    monitor-enter v1

    :try_start_0
    iget v4, v1, Lo/a;->k:I

    const/4 v5, 0x2

    if-eq v4, v5, :cond_0

    monitor-exit v1

    goto :goto_0

    :cond_0
    const/4 v4, 0x0

    const/16 v6, 0x60

    aput-byte v6, v3, v4

    iget v4, v1, Lo/a;->g:I

    shr-int/lit8 v6, v4, 0x18

    int-to-byte v6, v6

    aput-byte v6, v3, v0

    shr-int/lit8 v6, v4, 0x10

    int-to-byte v6, v6

    aput-byte v6, v3, v5

    const/4 v5, 0x3

    shr-int/lit8 v6, v4, 0x8

    int-to-byte v6, v6

    aput-byte v6, v3, v5

    const/4 v5, 0x4

    int-to-byte v4, v4

    aput-byte v4, v3, v5

    monitor-exit v1
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_1

    iget-object v4, v1, Lo/a;->h:Ljava/lang/Object;

    monitor-enter v4

    :try_start_1
    iget-boolean v1, v1, Lo/a;->i:Z

    if-ne v1, v0, :cond_1

    monitor-exit v4

    goto :goto_0

    :cond_1
    iget-object v0, v2, Lo/c;->b:Ls/i;

    invoke-virtual {v0, v3}, Ls/i;->m([B)V

    monitor-exit v4
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    sget-object v0, Lo/c;->h:La/b;

    invoke-static {v0}, Ljava/util/Objects;->requireNonNull(Ljava/lang/Object;)Ljava/lang/Object;

    goto :goto_0

    :catchall_0
    move-exception v0

    :try_start_2
    monitor-exit v4
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_0

    throw v0

    :catchall_1
    move-exception v0

    :try_start_3
    monitor-exit v1
    :try_end_3
    .catchall {:try_start_3 .. :try_end_3} :catchall_1

    throw v0

    :cond_2
    :goto_0
    return-void
.end method

.method public final flush()V
    .locals 2

    iget-boolean v0, p0, Lo/d;->b:Z

    if-nez v0, :cond_0

    return-void

    :cond_0
    new-instance v0, Ljava/io/IOException;

    const-string v1, "This OutputStream is closed."

    invoke-direct {v0, v1}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    throw v0
.end method

.method public final write(I)V
    .locals 3

    const/4 v0, 0x1

    new-array v1, v0, [B

    int-to-byte p1, p1

    const/4 v2, 0x0

    aput-byte p1, v1, v2

    invoke-virtual {p0, v1, v2, v0}, Lo/d;->write([BII)V

    return-void
.end method

.method public final write([B)V
    .locals 2

    array-length v0, p1

    const/4 v1, 0x0

    invoke-virtual {p0, p1, v1, v0}, Lo/d;->write([BII)V

    return-void
.end method

.method public final write([BII)V
    .locals 16

    move-object/from16 v1, p0

    move-object/from16 v0, p1

    move/from16 v2, p2

    iget-boolean v3, v1, Lo/d;->b:Z

    if-nez v3, :cond_a

    invoke-static/range {p1 .. p1}, Ljava/util/Objects;->requireNonNull(Ljava/lang/Object;)Ljava/lang/Object;

    if-ltz v2, :cond_9

    if-ltz p3, :cond_9

    add-int v3, v2, p3

    array-length v4, v0

    if-gt v3, v4, :cond_9

    if-ltz v3, :cond_9

    array-length v3, v0

    if-gt v2, v3, :cond_9

    if-nez p3, :cond_0

    return-void

    :cond_0
    iget-object v3, v1, Lo/d;->a:Lo/a;

    iget-object v4, v3, Lo/a;->b:Lo/c;

    invoke-static {v4}, Ljava/util/Objects;->requireNonNull(Ljava/lang/Object;)Ljava/lang/Object;

    move/from16 v5, p3

    :goto_0
    if-lez v5, :cond_8

    .line 1
    monitor-enter v3

    :goto_1
    :try_start_0
    iget v6, v3, Lo/a;->k:I

    const/4 v7, 0x4

    if-eq v6, v7, :cond_7

    const/4 v8, 0x2

    if-ne v6, v8, :cond_6

    iget-wide v9, v3, Lo/a;->m:J

    const-wide/16 v11, 0x0

    cmp-long v6, v9, v11

    if-eqz v6, :cond_5

    int-to-long v11, v5

    cmp-long v6, v9, v11

    if-ltz v6, :cond_1

    move v6, v5

    goto :goto_2

    :cond_1
    long-to-int v6, v9

    :goto_2
    iget v11, v3, Lo/a;->o:I

    iget-object v12, v4, Lo/c;->b:Ls/i;

    .line 2
    iget-object v12, v12, Ls/i;->k:Ls/g;

    .line 3
    iget v13, v12, Ls/g;->h:I

    add-int/lit8 v13, v13, -0x1

    const/16 v14, 0x9

    add-int/2addr v13, v14

    iget-object v12, v12, Ls/g;->g:[B

    array-length v12, v12

    add-int/2addr v13, v12

    add-int/2addr v13, v14

    sub-int/2addr v11, v13

    const/4 v12, 0x1

    if-gtz v11, :cond_2

    const/4 v11, 0x1

    :cond_2
    if-le v6, v11, :cond_3

    move v6, v11

    :cond_3
    int-to-long v14, v6

    sub-long/2addr v9, v14

    .line 4
    iput-wide v9, v3, Lo/a;->m:J

    add-int/lit8 v9, v6, 0x9

    new-array v9, v9, [B

    const/4 v10, 0x0

    const/16 v11, 0x5e

    aput-byte v11, v9, v10

    iget v10, v3, Lo/a;->g:I

    shr-int/lit8 v11, v10, 0x18

    int-to-byte v11, v11

    aput-byte v11, v9, v12

    shr-int/lit8 v11, v10, 0x10

    int-to-byte v11, v11

    aput-byte v11, v9, v8

    const/4 v8, 0x3

    shr-int/lit8 v11, v10, 0x8

    int-to-byte v11, v11

    aput-byte v11, v9, v8

    int-to-byte v8, v10

    aput-byte v8, v9, v7

    const/4 v7, 0x5

    shr-int/lit8 v8, v6, 0x18

    int-to-byte v8, v8

    aput-byte v8, v9, v7

    const/4 v7, 0x6

    shr-int/lit8 v8, v6, 0x10

    int-to-byte v8, v8

    aput-byte v8, v9, v7

    const/4 v7, 0x7

    shr-int/lit8 v8, v6, 0x8

    int-to-byte v8, v8

    aput-byte v8, v9, v7

    int-to-byte v7, v6

    const/16 v8, 0x8

    aput-byte v7, v9, v8

    const/16 v7, 0x9

    invoke-static {v0, v2, v9, v7, v6}, Ljava/lang/System;->arraycopy(Ljava/lang/Object;ILjava/lang/Object;II)V

    monitor-exit v3
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_1

    iget-object v7, v3, Lo/a;->h:Ljava/lang/Object;

    monitor-enter v7

    :try_start_1
    iget-boolean v8, v3, Lo/a;->i:Z

    if-eq v8, v12, :cond_4

    iget-object v8, v4, Lo/c;->b:Ls/i;

    invoke-virtual {v8, v9}, Ls/i;->m([B)V

    monitor-exit v7

    add-int/2addr v2, v6

    sub-int/2addr v5, v6

    goto/16 :goto_0

    :cond_4
    const-string v0, "SSH channel is closed"

    invoke-virtual {v4, v0, v3}, Lo/c;->g(Ljava/lang/String;Lo/a;)Ljava/io/IOException;

    move-result-object v0

    throw v0

    :catchall_0
    move-exception v0

    monitor-exit v7
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    throw v0

    :cond_5
    :try_start_2
    invoke-virtual {v3}, Ljava/lang/Object;->wait()V
    :try_end_2
    .catch Ljava/lang/InterruptedException; {:try_start_2 .. :try_end_2} :catch_0
    .catchall {:try_start_2 .. :try_end_2} :catchall_1

    goto/16 :goto_1

    :catch_0
    :try_start_3
    new-instance v0, Ljava/io/InterruptedIOException;

    invoke-direct {v0}, Ljava/io/InterruptedIOException;-><init>()V

    throw v0

    :cond_6
    new-instance v0, Ljava/io/IOException;

    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const-string v4, "SSH channel in strange state. ("

    invoke-virtual {v2, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget v4, v3, Lo/a;->k:I

    invoke-virtual {v2, v4}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string v4, ")"

    invoke-virtual {v2, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-direct {v0, v2}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    throw v0

    :cond_7
    const-string v0, "SSH channel is closed"

    invoke-virtual {v4, v0, v3}, Lo/c;->g(Ljava/lang/String;Lo/a;)Ljava/io/IOException;

    move-result-object v0

    throw v0

    :catchall_1
    move-exception v0

    monitor-exit v3
    :try_end_3
    .catchall {:try_start_3 .. :try_end_3} :catchall_1

    throw v0

    :cond_8
    return-void

    .line 5
    :cond_9
    new-instance v0, Ljava/lang/IndexOutOfBoundsException;

    invoke-direct {v0}, Ljava/lang/IndexOutOfBoundsException;-><init>()V

    throw v0

    :cond_a
    new-instance v0, Ljava/io/IOException;

    const-string v2, "This OutputStream is closed."

    invoke-direct {v0, v2}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    throw v0
.end method
