.class public final Li0/f;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field public final synthetic a:Li0/g;


# direct methods
.method public constructor <init>(Li0/g;)V
    .locals 0

    iput-object p1, p0, Li0/f;->a:Li0/g;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final run()V
    .locals 10

    iget-object v0, p0, Li0/f;->a:Li0/g;

    .line 1
    iget-object v1, v0, Li0/g;->g:Li0/h;

    .line 2
    iget-object v3, v1, Li0/h;->a:Ljava/lang/String;

    iget-object v4, v1, Li0/h;->c:[Ljava/lang/String;

    iget-boolean v5, v1, Li0/h;->b:Z

    iget-object v6, v1, Li0/h;->d:Ljava/lang/String;

    iget-boolean v7, v1, Li0/h;->f:Z

    .line 3
    iget-object v1, v0, Li0/g;->d:Ljava/util/concurrent/atomic/AtomicBoolean;

    const/4 v8, 0x0

    invoke-virtual {v1, v8}, Ljava/util/concurrent/atomic/AtomicBoolean;->set(Z)V

    const/4 v1, 0x1

    :try_start_0
    iget-object v9, v0, Li0/g;->e:Li0/d;

    .line 4
    monitor-enter v9
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_1
    .catchall {:try_start_0 .. :try_end_0} :catchall_1

    move-object v2, v9

    :try_start_1
    invoke-virtual/range {v2 .. v7}, Li0/d;->a(Ljava/lang/String;[Ljava/lang/String;ZLjava/lang/String;Z)Z

    move-result v2
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    :try_start_2
    monitor-exit v9

    if-eqz v2, :cond_0

    const-string v2, "TunnelManager"

    const-string v3, "VPN service running"

    .line 5
    invoke-static {v2, v3}, Landroid/util/Log;->i(Ljava/lang/String;Ljava/lang/String;)I

    iget-object v2, v0, Li0/g;->a:Lxyz/chz/injector/tunnel/vpn/TunnelVpnService;

    invoke-virtual {v2, v1}, Lxyz/chz/injector/tunnel/vpn/TunnelVpnService;->a(Z)V
    :try_end_2
    .catch Ljava/lang/Exception; {:try_start_2 .. :try_end_2} :catch_1
    .catchall {:try_start_2 .. :try_end_2} :catchall_1

    :try_start_3
    iget-object v2, v0, Li0/g;->b:Ljava/util/concurrent/CountDownLatch;

    invoke-virtual {v2}, Ljava/util/concurrent/CountDownLatch;->await()V
    :try_end_3
    .catch Ljava/lang/InterruptedException; {:try_start_3 .. :try_end_3} :catch_0
    .catch Ljava/lang/Exception; {:try_start_3 .. :try_end_3} :catch_1
    .catchall {:try_start_3 .. :try_end_3} :catchall_1

    goto :goto_0

    :catch_0
    :try_start_4
    invoke-static {}, Ljava/lang/Thread;->currentThread()Ljava/lang/Thread;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/Thread;->interrupt()V

    :goto_0
    iget-object v2, v0, Li0/g;->d:Ljava/util/concurrent/atomic/AtomicBoolean;

    invoke-virtual {v2, v1}, Ljava/util/concurrent/atomic/AtomicBoolean;->set(Z)V
    :try_end_4
    .catch Ljava/lang/Exception; {:try_start_4 .. :try_end_4} :catch_1
    .catchall {:try_start_4 .. :try_end_4} :catchall_1

    iget-object v2, v0, Li0/g;->f:Ljava/util/concurrent/atomic/AtomicBoolean;

    invoke-virtual {v2}, Ljava/util/concurrent/atomic/AtomicBoolean;->get()Z

    move-result v2

    if-eqz v2, :cond_1

    goto :goto_1

    :cond_0
    :try_start_5
    new-instance v2, Ljava/lang/Exception;

    const-string v3, "application is not prepared or revoked"

    invoke-direct {v2, v3}, Ljava/lang/Exception;-><init>(Ljava/lang/String;)V

    throw v2

    :catchall_0
    move-exception v2

    .line 6
    monitor-exit v9

    throw v2
    :try_end_5
    .catch Ljava/lang/Exception; {:try_start_5 .. :try_end_5} :catch_1
    .catchall {:try_start_5 .. :try_end_5} :catchall_1

    :catchall_1
    move-exception v2

    goto :goto_3

    :catch_1
    move-exception v2

    :try_start_6
    const-string v3, "TunnelManager"

    const-string v4, "Start tunnel failed: %s"

    new-array v5, v1, [Ljava/lang/Object;

    .line 7
    invoke-virtual {v2}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    move-result-object v2

    aput-object v2, v5, v8

    invoke-static {v4, v5}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v2

    invoke-static {v3, v2}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    iget-object v2, v0, Li0/g;->a:Lxyz/chz/injector/tunnel/vpn/TunnelVpnService;

    invoke-virtual {v2, v8}, Lxyz/chz/injector/tunnel/vpn/TunnelVpnService;->a(Z)V
    :try_end_6
    .catchall {:try_start_6 .. :try_end_6} :catchall_1

    iget-object v2, v0, Li0/g;->f:Ljava/util/concurrent/atomic/AtomicBoolean;

    invoke-virtual {v2}, Ljava/util/concurrent/atomic/AtomicBoolean;->get()Z

    move-result v2

    if-eqz v2, :cond_1

    :goto_1
    const-string v1, "TunnelManager"

    const-string v2, "Stopping tunnel."

    invoke-static {v1, v2}, Landroid/util/Log;->i(Ljava/lang/String;Ljava/lang/String;)I

    iget-object v1, v0, Li0/g;->e:Li0/d;

    invoke-virtual {v1}, Li0/d;->e()V

    goto :goto_2

    :cond_1
    const-string v2, "TunnelManager"

    const-string v3, "Stopping VPN and tunnel."

    invoke-static {v2, v3}, Landroid/util/Log;->i(Ljava/lang/String;Ljava/lang/String;)I

    iget-object v2, v0, Li0/g;->e:Li0/d;

    invoke-virtual {v2}, Li0/d;->c()V

    iget-object v2, v0, Li0/g;->a:Lxyz/chz/injector/tunnel/vpn/TunnelVpnService;

    invoke-virtual {v2, v1}, Landroid/app/Service;->stopForeground(Z)V

    iget-object v1, v0, Li0/g;->a:Lxyz/chz/injector/tunnel/vpn/TunnelVpnService;

    invoke-virtual {v1}, Landroid/app/Service;->stopSelf()V

    :goto_2
    iget-object v0, v0, Li0/g;->f:Ljava/util/concurrent/atomic/AtomicBoolean;

    invoke-virtual {v0, v8}, Ljava/util/concurrent/atomic/AtomicBoolean;->set(Z)V

    return-void

    :goto_3
    iget-object v3, v0, Li0/g;->f:Ljava/util/concurrent/atomic/AtomicBoolean;

    invoke-virtual {v3}, Ljava/util/concurrent/atomic/AtomicBoolean;->get()Z

    move-result v3

    if-eqz v3, :cond_2

    const-string v1, "TunnelManager"

    const-string v3, "Stopping tunnel."

    invoke-static {v1, v3}, Landroid/util/Log;->i(Ljava/lang/String;Ljava/lang/String;)I

    iget-object v1, v0, Li0/g;->e:Li0/d;

    invoke-virtual {v1}, Li0/d;->e()V

    goto :goto_4

    :cond_2
    const-string v3, "TunnelManager"

    const-string v4, "Stopping VPN and tunnel."

    invoke-static {v3, v4}, Landroid/util/Log;->i(Ljava/lang/String;Ljava/lang/String;)I

    iget-object v3, v0, Li0/g;->e:Li0/d;

    invoke-virtual {v3}, Li0/d;->c()V

    iget-object v3, v0, Li0/g;->a:Lxyz/chz/injector/tunnel/vpn/TunnelVpnService;

    invoke-virtual {v3, v1}, Landroid/app/Service;->stopForeground(Z)V

    iget-object v1, v0, Li0/g;->a:Lxyz/chz/injector/tunnel/vpn/TunnelVpnService;

    invoke-virtual {v1}, Landroid/app/Service;->stopSelf()V

    :goto_4
    iget-object v0, v0, Li0/g;->f:Ljava/util/concurrent/atomic/AtomicBoolean;

    invoke-virtual {v0, v8}, Ljava/util/concurrent/atomic/AtomicBoolean;->set(Z)V

    throw v2
.end method
